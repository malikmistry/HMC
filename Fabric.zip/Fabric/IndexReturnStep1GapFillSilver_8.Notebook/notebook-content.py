# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "920a12cc-7104-4013-a2a3-d7baa57e9e3f",
# META       "default_lakehouse_name": "lh_raw",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "920a12cc-7104-4013-a2a3-d7baa57e9e3f"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************


# There are 4 notebooks for index return processing.  A prerequisite is that the raw Bloomberg data files were processed 
# by the MDF FileTask.  (Other prerequisites are data files containing time series data for new index, SOIL or manual benchmark.)
#
# The first notebook reads the raw data from "{bronze_lh_id}/Tables/Bronze/BloombergIndexReturn".  It then processes the 
# raw data to fill in gaps. E.g. the BB data does not have values for weekends or holidays, but, the HMC Index Return SLA 
# states that we will have continuous data points.  So, we roll forward a Friday value into Saturday.  This first notebook
# does that work.
#
# The second through fourth notebooks contain a more detailed description of their work, but, a quick description is: 
# second: compute returns from levels and levels from returns, third: compute HMC custom blends and fourth: promote 
# frequencies such as Dailies that are promoted to Monthlies
#
# Note that the last step in this notebook is to write out a dataframe as a parquet file: {curated_lh_id}/Files/BloombergIndexReturnGapsFilled
# The next notebook read that file



#this notebook does several things:
# 1. validates data and logs issues
# 2.a starts with index return data that is missing some dates (e.g. weekends) and produces a continous set of data points
# 2.b for 2 indices, change date to be month end (e.g. 5/30/2025 needs to change to 5/31/2025)
# 3. enriches data by mapping from vendor conventions into HMC values

#real data has a mixture of index IDs, frequencies and currencies (and dates)
#also, some indices report as level and some as return

#todo: support rolling forward of both level and/or return

#todo: handle rolling forward returns if index reports as return
#todo: handle different data sources/purposes: Bloomberg nightly load, Bloomberg new index since inception, SOIL load, use generated manual benchmark files

# Version History
# 1 basic functionality demonstrates that logic works for canned data
# 2 migrated to "Dev - Crimson" and change to read parquet file
# 3 rename to IndexReturn Gap Fill Bronze 3 to denote this is Raw to Bronze processing
# 4 change to read initial data from lh_bronze delta table, stop using IndexReturn_STAGE, now use tmp parquet file in Files


# standard parameters passed in via MDF
WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import SparkSession
from datetime import date
from pyspark.sql.functions import col, lit, to_date, trim, when, upper, lead, datediff, expr, when, pandas_udf, explode, struct, current_timestamp, concat, last_day, row_number, current_date
from pyspark.sql.window import Window
import pandas as pd
from pyspark.sql.types import ArrayType, StringType

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# The data we are processing is time series data and so each data point has a date and either a level or a return.  Some datapoints also have a currency else we default to USD.
# Different sources of data will have different columns.  An early step in processing normalized to a well know set of columns.
# We use the variable dataLoadType with one of these values:
#    NEW_INDEX_LOAD
#    NIGHTLY_INDEX_LOAD_ALL
#    NIGHTLY_INDEX_LOAD_SOIL
#    MANUAL_BENCHMARK_LOAD
# The first three all origiante from Bloomberg files and so they all have the same columns.
# MANUAL_BENCHMARK_LOAD originates from an HMC defined .xlsx and it has different columns from Bloomberg

#xxx for development, set type.  todo: get or derrive type from parameters passed to this notebok
dataLoadType = "MANUAL_BENCHMARK_LOAD"

if dataLoadType == "MANUAL_BENCHMARK_LOAD":
    print ("xxxxxxxxxxxxxxxxxxxxxxxxxx")
    # The MDF got the *.txt files all the way to bronze, so this notebook picks up by reading the Bronze delta table
    df_stage = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/ManualBenchmarkLoad")
    #df_stage = df_stage.withColumn("SecurityIdentifier", upper(col("SecurityIdentifier").cast("string")))
    df_stage.show(13)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#xxx this cell handles data from Bloomberg.  A FileTask got BB data into a delta table and this cell reads it




#xxx need to read different file for a new index load


# The MDF got the *.txt files all the way to bronze, so this notebook picks up by reading the Bronze delta table
df_stage = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/BloombergIndexReturn")
df_stage = df_stage.withColumn("SecurityIdentifier", upper(col("SecurityIdentifier").cast("string")))
df_stage.show(13)


# xxx todo: cleanup dup tickers
# for this notebook, first purge erroneous indices that need to be cleaned up
# e.g. the below shows two indices with the same ticker.  That is not supported 
# SELECT IndexId, DisplayName, Ticker, IsActive, CurrencyId FROM dbo.[Index] WHERE Ticker = 'SMLLBV Index'
# IndexId	DisplayName	Ticker	IsActive	CurrencyId
#04aa2a49-255e-439e-adff-3935e49e4c8c	BM&F Bovespa Small Cap BRL	SMLLBV Index	1	26
#ba9bac3b-7e86-4eff-97ac-fe339c2871fa	BM&F Bovespa Small Cap USD	SMLLBV Index	1	1

df_stage = df_stage.filter(col("SecurityIdentifier") != "SMLLBV INDEX")

df_stage.printSchema()

df_check_for_dups = df_stage.filter(col("Status") == "0").groupBy("SecurityIdentifier", "Date", "Currency") \
    .count() \
    .filter("count > 1")
if df_check_for_dups.count() > 0:
    display(df_check_for_dups)
    raise Exception("Problem: found duplicate rows.  Need to investigate. Were there more than one days worth of files in the Bloomberg/Nightly folder?")



# xxx =============================================================================================
# =============================================================================================
# =============================================================================================
df_with_errors = df_stage.withColumn(
    "ErrorMessage",
    when(col("Status") != "0", concat(lit("Bloomberg error: "), col("Status")))
    .when(col("Date").isNull(), lit("NULL Date"))
    .when(col("Date") == "", lit("Blank Date"))
    .when(col("Level").isNull(), lit("NULL Level"))
    .when(col("Level") == "", lit("Blank Level"))
    .when(col("Level") == "0", lit("Zero Level"))
    .otherwise(lit(None))
)

df_with_errors = df_with_errors.filter(col("ErrorMessage").isNotNull())
df_with_errors.show(22)

if df_with_errors.count() > 0:
    df_log = df_with_errors.select(
        lit("IndexReturn").alias("ApplicationName"), 
        df_with_errors["ErrorMessage"],
        df_with_errors["ETLLoadDateTime"]
    )
    df_log.show(7)
    #df_log.write.format("delta").mode("append").saveAsTable("Bronze.Log")
    path = f"{bronze_lh_id}/Tables/Bronze/Log"
    print(path)
    #df_log.write.format("delta").option("overwriteSchema", "true").mode("overwrite").save(path)
    df_log.write.format("delta").mode("append").save(path)

# filter out invalid data so that we only have good data to process
#xxx need to test this filter (non-zero status code is working, but, test other error criteria)
#xxx todo: record these errors via Purvue or other means
df_stage = df_stage.filter(
    (col("Status") == 0) &    #this Status has been tested
    (col("Date").isNotNull()) &
    (trim(col("Date")) != "") &
    (col("Level").isNotNull()) &
    (trim(col("Level").cast("string")) != "")
)
df_stage.show(20)

# and look up at HMC to get index Frequency (we only fill gaps for 8/Daily).  also get LEVEL/RETURN based and/or other metadata
df_stage = df_stage.select(
    col("SecurityIdentifier"),
    to_date(col("Date"), "yyyyMMdd").alias("AsOfDate"),
    col("Currency").alias("CurrencyId"),
    col("Level").alias("IndexLevel"),
    lit(0).alias("IndexReturn"),
    col("RunPurpose"),
    col("Guid"),
    col("AdditionalParam")
)

# Preview the result
df_stage.show(5)

df_debug = df_stage.filter((col("SecurityIdentifier") == "HFRIRVA INDEX") & (col("AsOfDate") == "2025-08-31") & (col("CurrencyId") == "USD")).orderBy(col("AsOfDate").desc())
df_debug.show(7)
df_debug.printSchema()







# xxx =============================================================================================
# =============================================================================================
# =============================================================================================

#todo: note: for BB sourced, use Ticker to get to HMC Index.  But, for manual, need the INT ID from HMCstaging to make to HMC
# get GUID and other metadata type values
#dfIndexXref = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index").select("IndexId", "Ticker", "Frequency", "IsLevelBased").filter(col("IsActive") == 1)

# do not filter out inactive because we need their tickers because we are retrieving them from Bloomberg
#Note that sometimes we query Bloomberg for ticker "RU30GRTR Index" and the time series data comes back with ticker "RU30GRTR INDEX"
#So, we need to handle the tickers case-insensitive. Convert to upper.
dfIndexXref = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index").select("IndexId", upper(col("Ticker")).alias("Ticker"), "Frequency", "IsLevelBased")
dfCurrencyXref = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Currency").select("CurrencyId", "ISOCode")

dfIndexXref.show(5)
dfIndexXref.filter(col("Ticker") == "XET CURNCY").show(5)

dfWithHmcId = df_stage.join(dfIndexXref, df_stage["SecurityIdentifier"] == dfIndexXref["Ticker"], how="left")
dfUnmatched = dfWithHmcId.filter(col("Ticker").isNull())

display(dfWithHmcId)

#todo: how to handle this error... when raw vendor data does not resolve to an HMC index?
#todo: maybe log isue, purge from the staged data and then continue
#note: this will happen when the BB files includes the C2R securities
if dfUnmatched.count() > 0:
    dfUnmatched.show(10)
    dfUniqueTickers = dfUnmatched.select(col("SecurityIdentifier")).distinct()
    dfUniqueTickers.show(100)
    raise Exception(f"join failed, unmatched count = {dfUnmatched.count()}")

dfWithHmcId = dfWithHmcId.select(
    col("IndexId"),
    col("Frequency").alias("FrequencyId"),
    col("AsOfDate"),
    col("CurrencyId").alias("CurrencyCode"),
    col("IndexLevel"),
    col("IndexReturn"),
    when(col("IsLevelBased") == True, "LEVEL").otherwise("RETURN").alias("VendorIndexReturnUnit"),
    col("RunPurpose"),
    col("Guid"),
    col("AdditionalParam")
)
dfWithHmcId = dfWithHmcId.join(dfCurrencyXref, dfWithHmcId["CurrencyCode"] == dfCurrencyXref["ISOCode"])
df_stage = dfWithHmcId.drop("CurrencyCode").drop("ISOCode")
df_stage.show(25)

df_debug = df_stage.filter(col("FrequencyId").isNull())
if df_debug.count() > 0:
    df_debug.show(19)
    raise Exception("Problem: missing Frequency")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# hardcode Daily: we only fill gaps for 8/Daily
# filter for 8/Daily and only fill gaps for 8.  But, need to carry along any other frequencies

# this will cause grouping by the three columns and then ordered by the AsOfDate
window_spec = Window.partitionBy("IndexId", "FrequencyId", "CurrencyId").orderBy("AsOfDate")

# get value from "next" row knowing that we have sorted by AsOfDate 
df_date_list = (
    df_stage
    .filter(
        (col("FrequencyId") == 8)
    )
    .withColumn("AsOfDateNext", lead("AsOfDate", 1).over(window_spec))
    .selectExpr(
        "IndexId", "CurrencyId", "FrequencyId", "AsOfDate", 
        "AsOfDateNext"
    )
)

df_date_list.orderBy(col("AsOfDate").desc()).show(10)

# Identify Gaps
df_gap = df_date_list.filter(
    datediff("AsOfDateNext", "AsOfDate") > 1
).withColumn("DaysDiff", datediff("AsOfDateNext", "AsOfDate")) \
 .withColumn("EventComment", lit(None).cast("string")) \
 .withColumn("ErrorType", lit("GAP"))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

# Step 1: Define the window
window_spec = Window.partitionBy("IndexId", "FrequencyId", "CurrencyId").orderBy("AsOfDate")

# Step 2: Filter and prepare df_stage
df_filtered = df_stage.filter(col("FrequencyId") == 8)
df_filtered_none_daily = df_stage.filter(col("FrequencyId") != 8)

# Step 3: Add AsOfDateNext (lead) and a flag for the last row in each group
df_date_list = df_filtered.withColumn("AsOfDateNext", lead("AsOfDate", 1).over(window_spec))

# Step 4: Fill in current date as AsOfDateNext where it's the last row (null lead)
df_date_list = df_date_list.withColumn(
    "AsOfDateNext",
    when(col("AsOfDateNext").isNull(), current_date()).otherwise(col("AsOfDateNext"))
)

# Step 5: Select only what you need
df_date_list = df_date_list.select(
    "IndexId", "CurrencyId", "FrequencyId", "AsOfDate", "AsOfDateNext"
)

# Step 6: Identify Gaps
df_gap = df_date_list.filter(
    datediff("AsOfDateNext", "AsOfDate") > 1
).withColumn("DaysDiff", datediff("AsOfDateNext", "AsOfDate")) \
 .withColumn("EventComment", lit(None).cast("string")) \
 .withColumn("ErrorType", lit("GAP"))

# Optional: Show the result
df_gap.orderBy("IndexId", "CurrencyId", "AsOfDate")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

should_fill_gap = 1
# ------------------------------------------------------------------
# 6. Stop here if ShouldFillGap = 0
# ------------------------------------------------------------------
if should_fill_gap != 1:
    print("Detected gaps but instructed not to fill. Returning result.")
    display(df_results)
    # Optionally return df_results or save it
else:
    # Explode gaps into missing dates (excluding endpoints)
    def date_range(start, end):
        return [str(d) for d in pd.date_range(start=start, end=end, freq='D')][1:-1]  # exclude start and end

    @pandas_udf(ArrayType(StringType()))
    def generate_dates(start_series: pd.Series, end_series: pd.Series) -> pd.Series:
        return start_series.combine(end_series, date_range)

    gaps_with_dates = df_gap \
        .withColumn("MissingDates", generate_dates(col("AsOfDate"), col("AsOfDateNext"))) \
        .withColumn("MissingDate", explode(col("MissingDates")))

    # Load original stage again for reference IndexLevel
    stage_ref = df_stage

gaps = gaps_with_dates.alias("gaps")
stage = stage_ref.alias("stage")

plug_rows = gaps \
    .join(stage, 
        (gaps_with_dates.IndexId == stage_ref.IndexId) &
        (gaps_with_dates.CurrencyId == stage_ref.CurrencyId) &
        (gaps_with_dates.FrequencyId == stage_ref.FrequencyId) &
        (gaps_with_dates.AsOfDate == stage_ref.AsOfDate),
        how='left'
    ) \
    .select(
        col("gaps.IndexId"),
        col("gaps.FrequencyId"),
        col("MissingDate").cast("date").alias("AsOfDate"),
        col("IndexLevel"),
        lit(0).alias("IndexReturn"),
        col("VendorIndexReturnUnit"),
        col("RunPurpose"),
        col("Guid"),
        col("AdditionalParam"),
        col("gaps.CurrencyId")
    )
stage.show(10)
plug_rows.show(12)
df_union = stage.union(plug_rows).orderBy("IndexId", "CurrencyId", "FrequencyId", "AsOfDate")
df_union.show(14)

count_data = df_union.count()
print(f"Number of rows = : {count_data}")

df_stage = df_union

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# For 2/Monthlies, some values can have dates that are not month end.  For example HEDGNAV Index has a 5/30/2025 value, but, month end was 5/31/2025
# HMC specification is to move these month end dates
# xxx todo: move this to be after we compute custom indices

df_stage = df_stage.withColumn(
    "AsOfDate",
    when(col("FrequencyId") == 2, last_day(col("AsOfDate")))
    .otherwise(col("AsOfDate"))  # keep original value otherwise
)

count_data = df_stage.count()
print(f"Number of rows = : {count_data}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_debug = df_stage.filter((col("IndexId") == "65c2359b-a371-4d10-8715-08ddfc66a532") & (col("CurrencyId") == 3) & (col("FrequencyId") == 8)).orderBy(col("AsOfDate").asc())
df_debug.show(7)



raise SystemExit("xxx")


# final step: write out to file that next notebook will read
df_stage.write.mode("overwrite").parquet( f"{curated_lh_id}/Files/BloombergIndexReturnGapsFilled")

print(f"Done")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
