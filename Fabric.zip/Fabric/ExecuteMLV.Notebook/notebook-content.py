# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import json
from delta.tables import DeltaTable
from datetime import datetime, timezone, date, timedelta
from pyspark.sql.functions import lit
from pyspark.sql.utils import AnalysisException
from collections import defaultdict
from notebookutils import fs
import re
from pyspark.sql.functions import col, coalesce
from pyspark.sql.types import TimestampType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

TaskList = ''
BronzeLhId = ''
CuratedLhId = ''
WorkspaceId = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Convert JSON String to list
tasklist = json.loads(TaskList)
# Set watermark
etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#If custom sourcesql exists, proceed, otherwise faile
    #If customsourcesql starts with CREATE MATERIALIZED LAKEVIEW, execute the whole if not,
    #Build CREATE MLV Script from custom sourcesql query as

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

return_value = []

def process_task(task):
    try:
        # Build paths
        source_path = f"{bronze_lh_basepath}/Tables/Bronze/{task['SourceTableName']}"
        print(f"Reading: {source_path}")
        target_table = task['SinkTableName']
        target_path = f"{silver_lh_basepath}/Tables/{task['SinkSchemaName']}/{target_table}"
        hwm_column = task['SinkWatermarkColumn']
        primary_column = task['PrimaryKeyColumnList']
        method = task['SinkLoadMethod']

        # Custom transformations - small transformation tasks from ETL table
        source_where_clause = task['SourceWhereClause']
        sourcesqlcode = task['CustomSQLSourceQuery']

        #  HANDLE MATERIALIZED LAKE VIEW CASES
        if (
            sourcesqlcode is not None
            and str(sourcesqlcode).strip() != ""
            and str(sourcesqlcode).strip().upper() != "NULL"
        ):
            raw_sql = sourcesqlcode.strip()
            upper_sql = raw_sql.upper()

            ddl_path = f"{silver_lh_basepath}/Files/DDLScripts/{task['SinkSchemaName']}"
            execute_ddl(target_table, ddl_path)  # safe even if no DDL exists

            # CASE A: User wrote full CREATE MATERIALIZED LAKE VIEW
            if upper_sql.startswith("CREATE MATERIALIZED LAKE VIEW"):
                print("[MLV DETECTED] Executing given MLV:")
                print(raw_sql)

                spark.sql(raw_sql)

                print("[MLV DONE] Returning with no ETL processing.")
                return {
                    "RowsRead": 0,
                    "RowsInserted": 0,
                    "RowsUpdated": 0,
                    "RowsDeleted": 0
                }

            # CASE B: Create MLV automatically
            mlv_sql = f"""
                CREATE MATERIALIZED LAKE VIEW {task['SinkSchemaName']}.{target_table}_View AS
                {sourcesqlcode}
            """

            print("[MLV AUTO-GENERATED] Executing:")
            print(mlv_sql)

            spark.sql(mlv_sql)

            print("[MLV DONE] Returning with no ETL processing.")
            return {
                "RowsRead": 0,
                "RowsInserted": 0,
                "RowsUpdated": 0,
                "RowsDeleted": 0
            }


    except Exception as e:
        raise RuntimeError(f"Task {task['TaskKey']} failed: {str(e)}") from e
 

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([BronzeLhId, CuratedLhId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLhId)
        silver_lh_basepath = get_basepath(WorkspaceId, CuratedLhId)

        # Process the task
        result = process_task(task_item)

    
    except Exception as e:
        print(f"Error processing task: {e}")
        raise Exception


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
