import sys
import os
import json
from pathlib import Path
from azure.identity import AzureCliCredential
from fabric_cicd import FabricWorkspace, publish_all_items, unpublish_all_orphan_items, change_log_level, constants

# Force unbuffered output like `python -u`
sys.stdout.reconfigure(line_buffering=True, write_through=True)
sys.stderr.reconfigure(line_buffering=True, write_through=True)

# Enable debugging if defined in Azure DevOps pipeline
# if os.getenv("SYSTEM_DEBUG", "false").lower() == "true":
#change_log_level("DEBUG")

# Load environment variables
workspace_id = os.environ.get("WORKSPACE_ID")
repo_directory = os.environ.get("REPO_DIRECTORY")
item_types_settings = os.environ.get("ITEM_TYPES")
item_types = json.loads(item_types_settings)
token_credential = AzureCliCredential()
environment = os.environ.get("ENVIRONMENT")

if not workspace_id:
    raise ValueError("Missing WORKSPACE_ID environment variable.")

print(f"workspace: {workspace_id}")
print(f"repo directory: {repo_directory}")

# Initialize the FabricWorkspace object with the required parameters
print("Initialize Deployment.")
target_workspace = FabricWorkspace(
    workspace_id=workspace_id,
    repository_directory=repo_directory,
    item_type_in_scope=item_types,
    environment=environment,
    token_credential=token_credential
)

# Publish all items defined in item_type_in_scope
publish_all_items(target_workspace)
print("Publish Completed.")

# Unpublish all items defined in item_type_in_scope not found in repository
unpublish_all_orphan_items(target_workspace)

print("Deployment completed successfully.")