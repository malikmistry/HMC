# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# ---------------------------------------------------------------------------
# | Scenario                     | Action                                   |
# |------------------------------|------------------------------------------|
# | First-time write/Overwrite   |  Full load (overwrite + overwriteSchema) |
# | New columns detected         |  Schema evolution (append + mergeSchema) |
# | Column data type change      |  MUST BE MANUALLY CASTED BEFORE WRITE    |
# | Rows exist but changed       |  MERGE updates changed rows              |
# | New rows added               |  MERGE inserts missing rows              |
# | All columns are primary keys |  Only updates HWM if data changed        |
# ---------------------------------------------------------------------------

#Note: Overwrite if CustomSQLSourceQuery exists is TRUNCATE + APPEND (to preserve schema)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import json
from delta.tables import DeltaTable
from datetime import datetime, timezone, date, timedelta
from pyspark.sql.functions import lit
from pyspark.sql.utils import AnalysisException
from pyspark.sql import SparkSession
from collections import defaultdict
from notebookutils import fs
import re
from pyspark.sql.functions import col, coalesce
from concurrent.futures import ThreadPoolExecutor, as_completed
import multiprocessing
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

TaskList = ''
BronzeLhId = ''
CuratedLhId = ''
WorkspaceId = ''
TaskAudit = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Convert JSON String to list
tasklist = json.loads(TaskList)
taskaudit_list = json.loads(TaskAudit)
# Set watermark
etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### **HIDDEN CELL BELOW, DON'T DELETE** _Functions for the main process_

# CELL ********************

# Clean column headers to save to Delta Table
def sanitize_column_names_with_mapping(df):
    rename_map = {}
    for col in df.columns:
        sanitized = col.replace("%", "Percentage")
        sanitized = re.sub(r"[^a-zA-Z0-9_]", "_", sanitized)
        sanitized = re.sub(r"_+", "_", sanitized).strip("_")
        
        if sanitized != col:
            df = df.withColumnRenamed(col, sanitized)
            rename_map[sanitized] = col  # store reverse mapping for restoring, not used in this code but for future development

    if rename_map:
        print(f"[i] Column rename mapping: {rename_map}")
    return df

def restore_original_column_names(df, rename_map):
    for sanitized, original in rename_map.items():
        df = df.withColumnRenamed(sanitized, original)
    return df

#Functions to make sure only one HWM column exists before merge
def unify_hwm_column(df, hwm_column):
    # Identify all columns with HWM name or variants like etlloaddatetime_1
    hwm_candidates = [c for c in df.columns if c == hwm_column or c.startswith(f"{hwm_column}_")]

    if len(hwm_candidates) > 1:
        print(f"Multiple HWM columns detected: {hwm_candidates}. Unifying into one '{hwm_column}'.")

        # Create unified column using coalesce (first non-null wins)
        df = df.withColumn(hwm_column, coalesce(*[col(c) for c in hwm_candidates]))

        # Drop all other variants except the unified one
        cols_to_drop = [c for c in hwm_candidates if c != hwm_column]
        df = df.drop(*cols_to_drop)

    return df

def replace_with_delta(sql, bronze_lh_basepath, silver_lh_basepath):
    # Replace Bronze.<table> only if it appears
    sql = re.sub(
        r"\bBronze\.([A-Za-z0-9_]+)", 
        lambda m: f"delta.`{bronze_lh_basepath}/Tables/Bronze/{m.group(1)}`", 
        sql
    )
    
    # Replace Silver.<table> only if it appears
    sql = re.sub(
        r"\bSilver\.([A-Za-z0-9_]+)", 
        lambda m: f"delta.`{silver_lh_basepath}/Tables/Silver/{m.group(1)}`", 
        sql
    )
    
    return sql


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

return_value = []

available_cores = 8
max_workers_nbr = min(available_cores, 15)


def process_task(task):
    try:
        print(f"Processing TaskKey: {task['TaskKey']} | Sink: {task['SinkTableName']}")

        # --- PARAMETERS ---
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLhId)
        silver_lh_basepath = get_basepath(WorkspaceId, CuratedLhId)
        source_path = f"{bronze_lh_basepath}/Tables/Bronze/{task['SourceTableName']}"
        target_table = task["SinkTableName"]
        target_path = f"{silver_lh_basepath}/Tables/{task['SinkSchemaName']}/{target_table}"
        hwm_column = task["SinkWatermarkColumn"]
        primary_column = task["PrimaryKeyColumnList"]
        method = task["SinkLoadMethod"]
        source_where_clause = task["SourceWhereClause"]
        sourcesqlcode = task["CustomSQLSourceQuery"]
        TaskAuditKey = next(
            (item["TaskAuditKey"] for item in taskaudit_list if item["TaskKey"] == task["TaskKey"]),
            None
        )

        #Read source
        if not sourcesqlcode or str(sourcesqlcode).strip().upper() in ["", "NULL"]:
            print(f"Using source path: {source_path}")
            df_temp = spark.read.format("delta").load(source_path)
        else:
            ddl_path = f"{silver_lh_basepath}/Files/DDLScripts"
            execute_ddl(target_table, ddl_path)
            sourcesqlcode_resolved = replace_with_delta(sourcesqlcode, bronze_lh_basepath, silver_lh_basepath)
            print(f"Using SQL as source: {sourcesqlcode_resolved}")
            df_temp = spark.sql(sourcesqlcode_resolved)

        #PK and clean up
        if not primary_column or str(primary_column).strip().upper() == "NULL":
            primary_keys = [col for col in df_temp.columns if col != hwm_column]
        else:
            primary_keys = [col.strip() for col in primary_column.split(",")]

        df_source = df_temp.dropDuplicates(primary_keys)
        df_source = sanitize_column_names_with_mapping(df_source)
        if "ETLLoadDateTime" in df_source.columns:
            df_source = df_source.drop("ETLLoadDateTime")

        df_source.createOrReplaceTempView("df_source_view")

        # if source is empty
        if df_source.rdd.isEmpty():
            print(f"Source {source_path} is empty. Skipping.")
            return_value.append({
                "TaskAuditKey": TaskAuditKey,
                "TaskKey": task["TaskKey"],
                "TaskType": "ETLProcess",
                "Message": "Skipped — source table is empty.",
                "Status": "Success",
                "Watermark": etlloadtime,
                "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "RowsRead": 0, "RowsInserted": 0, "RowsUpdated": 0, "RowsDeleted": 0, "VersionLoaded": None
            })
            return

        # filter
        if source_where_clause:
            df_source = df_source.filter(source_where_clause)
        else:
            print("No source where clause applied")

        # check if target exists
        try:
            df_target = spark.read.format("delta").load(target_path)
            table_exists = True
        except AnalysisException:
            table_exists = False

        RowsRead = df_source.count()

        # CASE 1: Target does not exist
        if not table_exists:
            print(f"Target table does not exist. Creating new at {target_path}")
            if hwm_column not in df_source.columns:
                df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast("timestamp"))
            df_source.write.format("delta").mode("overwrite").save(target_path)

            return_value.append({
                "TaskAuditKey": TaskAuditKey,
                "TaskKey": task["TaskKey"],
                "TaskType": "BronzeToSilver",
                "Message": "Full load performed (new table created).",
                "Status": "Success",
                "Watermark": etlloadtime,
                "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "RowsRead": RowsRead,
                "RowsInserted": RowsRead,
                "RowsUpdated": 0,
                "RowsDeleted": 0,
                "VersionLoaded": None
            })
            return

        # CASE 2: Overwrite or Append
        elif method == 'overwrite' and not (
            sourcesqlcode is None 
            or str(sourcesqlcode).strip() == "" 
            or str(sourcesqlcode).strip().upper() == "NULL"
        ):
            print(f"\nTruncating and reloading table at: {target_path}")

            if hwm_column not in df_source.columns:
                try:
                    df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast(TimestampType()))
                except Exception as e:
                    print(f"[ERROR] Failed to add watermark column '{hwm_column}': {e}")
                    raise

            # Truncate the target table using Spark SQL (preserves schema)
            truncateQuery = f"""
                TRUNCATE TABLE {task['SinkSchemaName']}.{task['SinkTableName']}
            """
            print(f"Executing truncate query")
            spark.sql(truncateQuery)

            # Append the new data
            df_source.write.format("delta").mode("append").save(target_path)

            RowsRead = df_source.count()
            RowsInserted = RowsRead
            RowsUpdated = 0
            RowsDeleted = 0

            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsInserted,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }
        elif method == 'overwrite' and (
            sourcesqlcode is None 
            or str(sourcesqlcode).strip() == "" 
            or str(sourcesqlcode).strip().upper() == "NULL"
            ):
        
            print(f"\nOverwriting existing table at: {target_path}")
            if hwm_column not in df_source.columns:
                try:
                    df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast(TimestampType()))
                except Exception as e:
                    print(f"[ERROR] Failed to add watermark column '{hwm_column}': {e}")
                    raise
            df_source.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(target_path)
            RowsRead = df_source.count()
            RowsInserted = df_source.count()
            RowsUpdated = 0
            RowsDeleted = 0
            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsInserted,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }

        elif method == "append":
            print(f"Appending data at {target_path}")
            if hwm_column not in df_source.columns:
                df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast("timestamp"))
            df_source.write.format("delta").mode("append").save(target_path)

            return_value.append({
                "TaskAuditKey": TaskAuditKey,
                "TaskKey": task["TaskKey"],
                "TaskType": "BronzeToSilver",
                "Message": "Append performed.",
                "Status": "Success",
                "Watermark": etlloadtime,
                "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "RowsRead": RowsRead,
                "RowsInserted": RowsRead,
                "RowsUpdated": 0,
                "RowsDeleted": 0,
                "VersionLoaded": None
            })
            return

        #CASE 3: Merge
        print(f"Performing merge on {target_table}")
        df_target = spark.read.format("delta").load(target_path)
        delta_table = DeltaTable.forPath(spark, target_path)

        columns = df_source.columns
        change_condition = " OR ".join([f"target.{c} IS DISTINCT FROM source.{c}" for c in columns if c not in primary_keys and c != hwm_column])

        merge_query = f"""
        MERGE INTO delta.`{target_path}` AS target
        USING df_source_view AS source
        ON ({' AND '.join([f"target.{col} = source.{col}" for col in primary_keys])})
        WHEN MATCHED AND ({change_condition})
        THEN UPDATE SET {', '.join([f"target.{col} = source.{col}" for col in columns if col != hwm_column])},
                        target.{hwm_column} = TIMESTAMP('{etlloadtime}')
        WHEN NOT MATCHED
        THEN INSERT ({', '.join(columns)}, {hwm_column})
             VALUES ({', '.join([f'source.{col}' for col in columns])}, TIMESTAMP('{etlloadtime}'));
        """

        spark.sql(merge_query)

        # --- Audit Merge Metrics ---
        history_df_audit = delta_table.history(1)
        operation_metrics = history_df_audit.select("operationMetrics").collect()[0][0]

        RowsInserted = int(operation_metrics.get("numOutputRows", 0))
        RowsUpdated = int(operation_metrics.get("numUpdatedRows", 0))
        RowsDeleted = int(operation_metrics.get("numDeletedRows", 0))

        return_value.append({
            "TaskAuditKey": TaskAuditKey,
            "TaskKey": task["TaskKey"],
            "TaskType": "BronzeToSilver",
            "Message": "Merge completed successfully.",
            "Status": "Success",
            "Watermark": etlloadtime,
            "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "RowsRead": RowsRead,
            "RowsInserted": RowsInserted,
            "RowsUpdated": RowsUpdated,
            "RowsDeleted": RowsDeleted,
            "VersionLoaded": None
        })

        print(f"[✓] COMPLETE Merge: {target_table}")

    except Exception as e:
        error_msg = str(e)[:400]
        print(f"ERROR TaskKey {task['TaskKey']}: {error_msg}")

        return_value.append({
            "TaskAuditKey": TaskAuditKey,
            "TaskKey": task["TaskKey"],
            "TaskType": "BronzeToSilver",
            "Message": f"Error: {error_msg}",
            "Status": "Failed",
            "Watermark": etlloadtime,
            "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "RowsRead": 0,
            "RowsInserted": 0,
            "RowsUpdated": 0,
            "RowsDeleted": 0,
            "VersionLoaded": None
        })


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def run_tasks_by_order(task_list, etlloadtime):
    task_groups = defaultdict(list)
    for task in task_list:
        task_groups[task["TaskRunOrderNbr"]].append(task)

    sorted_order_keys = sorted(task_groups.keys())

    for order_nbr in sorted_order_keys:
        print(f"\n Starting TaskRunOrderNbr: {order_nbr} with {max_workers_nbr} workers")

        with ThreadPoolExecutor(max_workers=max_workers_nbr) as executor:
            future_to_task = {executor.submit(process_task, task): task for task in task_groups[order_nbr]}

            for future in as_completed(future_to_task):
                result = future.result()

        print(f"Completed TaskRunOrderNbr: {order_nbr}\n")

    print("Process COMPLETE")

if __name__ == "__main__":
    try:
        run_tasks_by_order(tasklist, etlloadtime)
    except Exception as e:
        print(f"Execution Failed: {str(e)}")
        raise Exception


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# for task_item in tasklist:
#     try:
#         # Skip if any required ID is missing
#         if not all([BronzeLhId, CuratedLhId, WorkspaceId]):
#             print("Skipping due to missing required GUID(s)")
#             raise Exception
            
#         # Build paths
#         bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLhId)
#         silver_lh_basepath = get_basepath(WorkspaceId, CuratedLhId)

#         # Process the task
#         result = process_task(task_item)


#     except Exception as e:
#         print(f"Error processing task: {e}")
#         raise Exception


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# from datetime import datetime
# import re
# from notebookutils import mssparkutils  # Import Fabric-specific file system utilities

# # Archive path (already created earlier in the code)
# archive_path = f"{raw_lh_basepath}/Files/Archive"
# print(archive_path)

# def move_to_archive(file_path):
#     file_path = file_path.rstrip('/')  # Remove trailing slash
#     print(f"Processed file path: {file_path}")
    
#     # Get current date (year, month, day)
#     current_date = datetime.now()
#     year = current_date.year
#     month = current_date.strftime('%m')  # Zero-padded month
#     day = current_date.strftime('%d')   # Zero-padded day

#     # Extract folder name like "01Test" from the input file path
#     match = re.search(r'/Files/([^/]+)(?:/|$)', file_path)

#     print(f"Regex match result: {match}")
    
#     if not match:
#         print(" Unable to extract source folder (e.g., 01Test) from path.")
#         return
    
#     table_folder = match.group(1)
#     print(f"Extracted folder: {table_folder}")

#     # Construct full archive destination path
#     archive_dir = f"{archive_path}/{year}/{month}/{day}"
#     file_name = file_path.split('/')[-1]  # Extract the file name from the path
#     destination_path = f"{archive_dir}"

#     print(f"Moving to: {destination_path}")

#     try:
#         # Ensure the destination directory exists in Fabric (ADLS/OneLake)
#         # In Fabric, use mssparkutils.fs.mkdirs for directory creation (works with ADLS/OneLake)
#         mssparkutils.fs.mkdirs(archive_dir)

#         # Use mssparkutils.fs.mv() to move the file in Fabric
#         mssparkutils.fs.mv(file_path, destination_path)

#         print(f"File moved successfully to: {destination_path}")
#     except Exception as e:
#         print(f"Error occurred while moving file: {e}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# audit_result = {
#     "RowsCopied": result['RowsRead'],
#     "RowsInserted": result['RowsInserted'],
#     "RowsUpdated": result['RowsUpdated'],
#     "RowsDeleted": result['RowsDeleted']
# }
# Return JSON object
mssparkutils.notebook.exit(json.dumps(return_value))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# import multiprocessing
# from collections import defaultdict
# from concurrent.futures import ThreadPoolExecutor, as_completed
# from datetime import datetime, timezone
# from threading import Lock
# import queue
# import traceback

# # If using DeltaTable operations
# try:
#     from delta.tables import DeltaTable
# except Exception:
#     DeltaTable = None  # keep running if not available in environment

# # ---------- Configuration ----------
# available_cores = multiprocessing.cpu_count()
# # Be conservative: do not use all cores for threads (leave headroom for driver/jvm)
# max_workers_nbr = min(max(1, available_cores // 2), 15)

# # Global thread-safe result queue
# result_queue = queue.Queue()

# # Lock map to protect writes to the same target table
# _table_locks = defaultdict(Lock)

# # Optional global lock for any other global resource (if needed)
# global_lock = Lock()

# # --------- Helper: push audit result thread-safely ----------
# def push_audit_result(item):
#     result_queue.put(item)

# # --------- Safe unique temp view name ----------
# def _temp_view_name(task_key):
#     # use TaskKey + timestamp or random suffix if you prefer
#     return f"df_source_view_task_{task_key}"

# # --------- The worker function (thread-safe) ----------
# def process_task(task):
#     TaskAuditKey = None
#     try:
#         TaskAuditKey = next(
#             (item["TaskAuditKey"] for item in taskaudit_list if item["TaskKey"] == task["TaskKey"]),
#             None
#         )

#         task_key = task["TaskKey"]
#         print(f"Processing TaskKey: {task_key} | Sink: {task['SinkTableName']}")

#         # --- PARAMETERS (no global spark config changes) ---
#         bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLhId)
#         silver_lh_basepath = get_basepath(WorkspaceId, CuratedLhId)
#         source_path = f"{bronze_lh_basepath}/Tables/Bronze/{task['SourceTableName']}"
#         target_table = task["SinkTableName"]
#         target_path = f"{silver_lh_basepath}/Tables/Silver/{target_table}"
#         hwm_column = task["SinkWatermarkColumn"]
#         primary_column = task["PrimaryKeyColumnList"]
#         method = task["SinkLoadMethod"]
#         source_where_clause = task["SourceWhereClause"]
#         sourcesqlcode = task["CustomSQLSourceQuery"]

#         # --- Read source (either delta path or SQL) ---
#         if not sourcesqlcode or str(sourcesqlcode).strip().upper() in ["", "NULL"]:
#             print(f"Using source path: {source_path}")
#             df_temp = spark.read.format("delta").load(source_path)
#         else:
#             ddl_path = f"{silver_lh_basepath}/Files/DDLScripts"
#             execute_ddl(target_table, ddl_path)
#             sourcesqlcode_resolved = replace_with_delta(sourcesqlcode, bronze_lh_basepath, silver_lh_basepath)
#             print(f"Using SQL as source: {sourcesqlcode_resolved}")
#             df_temp = spark.sql(sourcesqlcode_resolved)

#         # --- Primary keys and cleanup ---
#         if not primary_column or str(primary_column).strip().upper() == "NULL":
#             primary_keys = [col for col in df_temp.columns if col != hwm_column]
#         else:
#             primary_keys = [col.strip() for col in primary_column.split(",")]

#         df_source = df_temp.dropDuplicates(primary_keys)
#         df_source = sanitize_column_names_with_mapping(df_source)
#         if "ETLLoadDateTime" in df_source.columns:
#             df_source = df_source.drop("ETLLoadDateTime")

#         # Unique temp view per task to avoid clobbering
#         temp_view = _temp_view_name(task_key)
#         df_source.createOrReplaceTempView(temp_view)

#         # if source is empty
#         if df_source.rdd.isEmpty():
#             print(f"Source {source_path} is empty. Skipping.")
#             push_audit_result({
#                 "TaskAuditKey": TaskAuditKey,
#                 "TaskKey": task_key,
#                 "TaskType": "ETLProcess",
#                 "Message": "Skipped — source table is empty.",
#                 "Status": "Success",
#                 "Watermark": etlloadtime,
#                 "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
#                 "RowsRead": 0, "RowsInserted": 0, "RowsUpdated": 0, "RowsDeleted": 0, "VersionLoaded": None
#             })
#             return

#         # filter
#         if source_where_clause:
#             df_source = df_source.filter(source_where_clause)
#         else:
#             print("No source where clause applied")

#         # check if target exists
#         try:
#             df_target = spark.read.format("delta").load(target_path)
#             table_exists = True
#         except Exception as e:
#             # AnalysisException imported? Using generic exception is safer in-thread
#             table_exists = False

#         RowsRead = df_source.count()

#         # Acquire per-target lock to protect truncates/overwrites/merges to same path
#         table_lock = _table_locks[target_path]

#         if not table_exists:
#             print(f"Target table does not exist. Creating new at {target_path}")
#             if hwm_column not in df_source.columns:
#                 df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast("timestamp"))

#             # creation doesn't conflict with other tasks if unique name; still lock for safety
#             with table_lock:
#                 df_source.write.format("delta").mode("overwrite").save(target_path)

#             push_audit_result({
#                 "TaskAuditKey": TaskAuditKey,
#                 "TaskKey": task_key,
#                 "TaskType": "BronzeToSilver",
#                 "Message": "Full load performed (new table created).",
#                 "Status": "Success",
#                 "Watermark": etlloadtime,
#                 "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
#                 "RowsRead": RowsRead,
#                 "RowsInserted": RowsRead,
#                 "RowsUpdated": 0,
#                 "RowsDeleted": 0,
#                 "VersionLoaded": None
#             })
#             return

#         # -------- Overwrite / Append logic ----------
#         # Note: use table_lock for operations that mutate the target
#         if method == 'overwrite' and not (
#             sourcesqlcode is None 
#             or str(sourcesqlcode).strip() == "" 
#             or str(sourcesqlcode).strip().upper() == "NULL"
#         ):
#             print(f"\nTruncating and reloading table at: {target_path}")

#             if hwm_column not in df_source.columns:
#                 try:
#                     df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast(TimestampType()))
#                 except Exception as e:
#                     raise

#             truncateQuery = f"TRUNCATE TABLE {task['SinkSchemaName']}.{task['SinkTableName']}"
#             with table_lock:
#                 print("Executing truncate query")
#                 spark.sql(truncateQuery)
#                 df_source.write.format("delta").mode("append").save(target_path)

#             RowsInserted = RowsRead
#             push_audit_result({
#                 "TaskAuditKey": TaskAuditKey,
#                 "TaskKey": task_key,
#                 "TaskType": "BronzeToSilver",
#                 "Message": "Truncate + reload performed.",
#                 "Status": "Success",
#                 "Watermark": etlloadtime,
#                 "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
#                 "RowsRead": RowsRead,
#                 "RowsInserted": RowsInserted,
#                 "RowsUpdated": 0,
#                 "RowsDeleted": 0,
#                 "VersionLoaded": None
#             })
#             return

#         if method == 'overwrite' and (
#             sourcesqlcode is None 
#             or str(sourcesqlcode).strip() == "" 
#             or str(sourcesqlcode).strip().upper() == "NULL"
#         ):
#             print(f"\nOverwriting existing table at: {target_path}")
#             if hwm_column not in df_source.columns:
#                 df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast(TimestampType()))

#             with table_lock:
#                 df_source.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(target_path)

#             push_audit_result({
#                 "TaskAuditKey": TaskAuditKey,
#                 "TaskKey": task_key,
#  "TaskType": "BronzeToSilver",
#                 "Message": "Overwrite performed.",
#                 "Status": "Success",
#                 "Watermark": etlloadtime,
#                 "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
#                 "RowsRead": RowsRead,
#                 "RowsInserted": RowsRead,
#                 "RowsUpdated": 0,
#                 "RowsDeleted": 0,
#                 "VersionLoaded": None
#             })
#             return

#         if method == "append":
#             print(f"Appending data at {target_path}")
#             if hwm_column not in df_source.columns:
#                 df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast("timestamp"))

#             with table_lock:
#                 df_source.write.format("delta").mode("append").save(target_path)

#             push_audit_result({
#                 "TaskAuditKey": TaskAuditKey,
#                 "TaskKey": task_key,
#                 "TaskType": "BronzeToSilver",
#                 "Message": "Append performed.",
#                 "Status": "Success",
#                 "Watermark": etlloadtime,
#                 "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
#                 "RowsRead": RowsRead,
#                 "RowsInserted": RowsRead,
#                 "RowsUpdated": 0,
#                 "RowsDeleted": 0,
#                 "VersionLoaded": None
#             })
#             return

#         # -------- Merge case ----------
#         print(f"Performing merge on {target_table}")
#         # Re-read target inside lock to avoid conflicts
#         with table_lock:
#             df_target = spark.read.format("delta").load(target_path)
#             if DeltaTable:
#                 delta_table = DeltaTable.forPath(spark, target_path)
#             else:
#                 delta_table = None

#             columns = df_source.columns
#             change_condition = " OR ".join([f"target.{c} IS DISTINCT FROM source.{c}" for c in columns if c not in primary_keys and c != hwm_column])

#             merge_query = f"""
#             MERGE INTO delta.`{target_path}` AS target
#             USING {temp_view} AS source
#             ON ({' AND '.join([f"target.{col} = source.{col}" for col in primary_keys])})
#             WHEN MATCHED AND ({change_condition})
#             THEN UPDATE SET {', '.join([f"target.{col} = source.{col}" for col in columns if col != hwm_column])},
#                             target.{hwm_column} = TIMESTAMP('{etlloadtime}')
#             WHEN NOT MATCHED
#             THEN INSERT ({', '.join(columns)}, {hwm_column})
#                  VALUES ({', '.join([f'source.{col}' for col in columns])}, TIMESTAMP('{etlloadtime}'));
#             """

#             spark.sql(merge_query)

#             # Audit metrics (if Delta available)
#             if delta_table:
#                 history_df_audit = delta_table.history(1)
#                 operation_metrics = history_df_audit.select("operationMetrics").collect()[0][0]

#                 RowsInserted = int(operation_metrics.get("numOutputRows", 0))
#                 RowsUpdated = int(operation_metrics.get("numUpdatedRows", 0))
#                 RowsDeleted = int(operation_metrics.get("numDeletedRows", 0))
#             else:
#                 # fallback if delta table API not available
#                 RowsInserted = RowsRead
#                 RowsUpdated = 0
#                 RowsDeleted = 0

#         push_audit_result({
#             "TaskAuditKey": TaskAuditKey,
#             "TaskKey": task_key,
#             "TaskType": "BronzeToSilver",
#             "Message": "Merge completed successfully.",
#             "Status": "Success",
#             "Watermark": etlloadtime,
#             "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
#             "RowsRead": RowsRead,
#             "RowsInserted": RowsInserted,
#             "RowsUpdated": RowsUpdated,
#             "RowsDeleted": RowsDeleted,
#             "VersionLoaded": None
#         })

#         print(f"[✓] COMPLETE Merge: {target_table}")

#     except Exception as e:
#         # Safe capture of traceback + trimmed message
#         tb = traceback.format_exc()
#         print(f"ERROR TaskKey {task.get('TaskKey')}: {str(e)}\n{tb}")

#         push_audit_result({
#             "TaskAuditKey": TaskAuditKey,
#             "TaskKey": task.get("TaskKey"),
#             "TaskType": "BronzeToSilver",
#             "Message": f"Error: {str(e)[:400]}",
#             "Status": "Failed",
#             "Watermark": etlloadtime,
#             "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
#             "RowsRead": 0,
#             "RowsInserted": 0,
#             "RowsUpdated": 0,
#             "RowsDeleted": 0,
#             "VersionLoaded": None
#         })

#     finally:
#         # cleanup temp view to avoid buildup (safe even if not exists)
#         try:
#             spark.catalog.dropTempView(temp_view)
#         except Exception:
#             pass

# # --------- Orchestrator: run tasks by order ----------
# def run_tasks_by_order(task_list, etlloadtime):
#     task_groups = defaultdict(list)
#     for task in task_list:
#         task_groups[task["TaskRunOrderNbr"]].append(task)

#     sorted_order_keys = sorted(task_groups.keys())

#     for order_nbr in sorted_order_keys:
#         group = task_groups[order_nbr]
#         print(f"\n Starting TaskRunOrderNbr: {order_nbr} with max_workers={max_workers_nbr} and group size={len(group)}")

#         futures = []
#         with ThreadPoolExecutor(max_workers=max_workers_nbr) as executor:
#             future_to_task = {executor.submit(process_task, task): task for task in group}

#             for future in as_completed(future_to_task):
#                 task = future_to_task[future]
#                 try:
#                     _ = future.result()  # result is None; audit results were pushed to queue
#                 except Exception as ex:
#                     # Shouldn't happen because process_task catches exceptions, but log defensively
#                     print(f"[ERROR] Unhandled exception for TaskKey {task.get('TaskKey')}: {ex}")

#         print(f"Completed TaskRunOrderNbr: {order_nbr}\n")

#     # Drain result queue into list (preserve order if needed)
#     results = []
#     while not result_queue.empty():
#         results.append(result_queue.get())

#     print("Process COMPLETE")
#     return results




# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
