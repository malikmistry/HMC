# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

import json
from delta.tables import DeltaTable
from datetime import datetime, timezone, date, timedelta
from pyspark.sql.functions import lit
from pyspark.sql.utils import AnalysisException
from pyspark.sql import SparkSession
from collections import defaultdict
from notebookutils import fs
import re
from pyspark.sql.functions import col, coalesce
from concurrent.futures import ThreadPoolExecutor, as_completed
import multiprocessing
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

TaskList = ''
BronzeLhId = ''
CuratedLhId = ''
RawLhId = ''
WorkspaceId = ''
TaskAudit = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Convert JSON String to list
tasklist = json.loads(TaskList)
taskaudit_list = json.loads(TaskAudit)
# Set watermark
etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

return_value = []

available_cores = 8
max_workers_nbr = min(available_cores, 15)


def process_task(task):
    try:
        print(f"Processing TaskKey: {task['TaskKey']} | Sink: {task['SinkTableName']}")

        # --- PARAMETERS ---
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLhId)
        raw_lh_basepath = get_basepath(WorkspaceId, RawLhId)
        source_path = f"{raw_lh_basepath}/{task['SourceType']}/{task['SourceTableName'].lower()}"
        target_table = task["SinkTableName"]
        target_path = f"{bronze_lh_basepath}/Tables/{task['SinkSchemaName']}/{target_table}"
        hwm_column = task["SinkWatermarkColumn"]
        primary_column = task["PrimaryKeyColumnList"]
        method = task["SinkLoadMethod"]
        source_where_clause = task["SourceWhereClause"]
        sourcesqlcode = task["CustomSQLSourceQuery"]
        TaskAuditKey = next(
            (item["TaskAuditKey"] for item in taskaudit_list if item["TaskKey"] == task["TaskKey"]),
            None
        )

        #Read source and try to execute create table script
        if not sourcesqlcode or str(sourcesqlcode).strip().upper() in ["", "NULL"]:
            print(f"Using source path: {source_path}")
            try:
                if task['SourceType'] == "Files":
                    print(f"Reading Parquet source: {source_path}")
                    df_temp = spark.read.format("parquet").load(source_path)
                else:
                    print(f"Reading Delta source: {source_path}")
                    df_temp = spark.read.format("delta").load(source_path)
            except Exception as e:
                print(f"[ERROR] Reading source failed for {source_path}: {e}")
                raise
        else:
            # ddl_path = f"{silver_lh_basepath}/Files/DDLScripts"
            # execute_ddl(target_table, ddl_path)
            sourcesqlcode_resolved = replace_with_delta(sourcesqlcode, bronze_lh_basepath, silver_lh_basepath) # DEV NOT: Add raw basepath resolver
            print(f"Using SQL as source: {sourcesqlcode_resolved}")
            df_temp = spark.sql(sourcesqlcode_resolved)

        #PK and clean up
        if not primary_column or str(primary_column).strip().upper() == "NULL":
            primary_keys = [col for col in df_temp.columns if col != hwm_column]
        else:
            primary_keys = [col.strip() for col in primary_column.split(",")]

        df_source = df_temp.dropDuplicates(primary_keys)
        df_source = sanitize_column_names_with_mapping(df_source)
        if "ETLLoadDateTime" in df_source.columns:
            df_source = df_source.drop("ETLLoadDateTime")

        df_source.createOrReplaceTempView("df_source_view")

        # if source is empty
        if df_source.rdd.isEmpty():
            print(f"Source {source_path} is empty. Skipping.")
            return_value.append({
                "TaskAuditKey": TaskAuditKey,
                "TaskKey": task["TaskKey"],
                "TaskType": "ETLProcess",
                "Message": "Skipped — source table is empty.",
                "Status": "Success",
                "Watermark": etlloadtime,
                "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "RowsRead": 0, "RowsInserted": 0, "RowsUpdated": 0, "RowsDeleted": 0, "VersionLoaded": None
            })
            return

        # filter
        if source_where_clause:
            df_source = df_source.filter(source_where_clause)
        else:
            print("No source where clause applied")

        # check if target exists
        try:
            df_target = spark.read.format("delta").load(target_path)
            table_exists = True
        except AnalysisException:
            table_exists = False

        RowsRead = df_source.count()

        # CASE 1: Target does not exist
        if not table_exists:
            print(f"Target table does not exist. Creating new at {target_path}")
            if hwm_column not in df_source.columns:
                df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast("timestamp"))
            df_source.write.format("delta").mode("overwrite").save(target_path)

            return_value.append({
                "TaskAuditKey": TaskAuditKey,
                "TaskKey": task["TaskKey"],
                "TaskType": "BronzeToSilver",
                "Message": "Full load performed (new table created).",
                "Status": "Success",
                "Watermark": etlloadtime,
                "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "RowsRead": RowsRead,
                "RowsInserted": RowsRead,
                "RowsUpdated": 0,
                "RowsDeleted": 0,
                "VersionLoaded": None
            })
            return

        # CASE 2: Overwrite or Append
        elif method == 'overwrite' and not (
            sourcesqlcode is None 
            or str(sourcesqlcode).strip() == "" 
            or str(sourcesqlcode).strip().upper() == "NULL"
        ):
            print(f"\nTruncating and reloading table at: {target_path}")

            if hwm_column not in df_source.columns:
                try:
                    df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast(TimestampType()))
                except Exception as e:
                    print(f"[ERROR] Failed to add watermark column '{hwm_column}': {e}")
                    raise

            # Truncate the target table using Spark SQL (preserves schema)
            truncateQuery = f"""
                TRUNCATE TABLE {task['SinkSchemaName']}.{task['SinkTableName']}
            """
            print(f"Executing truncate query")
            spark.sql(truncateQuery)

            # Append the new data
            df_source.write.format("delta").mode("append").save(target_path)

            RowsRead = df_source.count()
            RowsInserted = RowsRead
            RowsUpdated = 0
            RowsDeleted = 0

            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsInserted,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }
        elif method == 'overwrite' and (
            sourcesqlcode is None 
            or str(sourcesqlcode).strip() == "" 
            or str(sourcesqlcode).strip().upper() == "NULL"
            ):
        
            print(f"\nOverwriting existing table at: {target_path}")
            if hwm_column not in df_source.columns:
                try:
                    df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast(TimestampType()))
                except Exception as e:
                    print(f"[ERROR] Failed to add watermark column '{hwm_column}': {e}")
                    raise
            df_source.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(target_path)
            RowsRead = df_source.count()
            RowsInserted = df_source.count()
            RowsUpdated = 0
            RowsDeleted = 0
            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsInserted,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }

        elif method == "append":
            print(f"Appending data at {target_path}")
            if hwm_column not in df_source.columns:
                df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast("timestamp"))
            df_source.write.format("delta").mode("append").save(target_path)

            return_value.append({
                "TaskAuditKey": TaskAuditKey,
                "TaskKey": task["TaskKey"],
                "TaskType": "BronzeToSilver",
                "Message": "Append performed.",
                "Status": "Success",
                "Watermark": etlloadtime,
                "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "RowsRead": RowsRead,
                "RowsInserted": RowsRead,
                "RowsUpdated": 0,
                "RowsDeleted": 0,
                "VersionLoaded": None
            })
            return

        #CASE 3: Merge
        print(f"Performing merge on {target_table}")
        df_target = spark.read.format("delta").load(target_path)
        delta_table = DeltaTable.forPath(spark, target_path)

        columns = df_source.columns
        change_condition = " OR ".join([f"target.{c} IS DISTINCT FROM source.{c}" for c in columns if c not in primary_keys and c != hwm_column])

        merge_query = f"""
        MERGE INTO delta.`{target_path}` AS target
        USING df_source_view AS source
        ON ({' AND '.join([f"target.{col} = source.{col}" for col in primary_keys])})
        WHEN MATCHED AND ({change_condition})
        THEN UPDATE SET {', '.join([f"target.{col} = source.{col}" for col in columns if col != hwm_column])},
                        target.{hwm_column} = TIMESTAMP('{etlloadtime}')
        WHEN NOT MATCHED
        THEN INSERT ({', '.join(columns)}, {hwm_column})
             VALUES ({', '.join([f'source.{col}' for col in columns])}, TIMESTAMP('{etlloadtime}'));
        """

        spark.sql(merge_query)

        # --- Audit Merge Metrics ---
        history_df_audit = delta_table.history(1)
        operation_metrics = history_df_audit.select("operationMetrics").collect()[0][0]

        RowsInserted = int(operation_metrics.get("numOutputRows", 0))
        RowsUpdated = int(operation_metrics.get("numUpdatedRows", 0))
        RowsDeleted = int(operation_metrics.get("numDeletedRows", 0))

        return_value.append({
            "TaskAuditKey": TaskAuditKey,
            "TaskKey": task["TaskKey"],
            "TaskType": "BronzeToSilver",
            "Message": "Merge completed successfully.",
            "Status": "Success",
            "Watermark": etlloadtime,
            "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "RowsRead": RowsRead,
            "RowsInserted": RowsInserted,
            "RowsUpdated": RowsUpdated,
            "RowsDeleted": RowsDeleted,
            "VersionLoaded": None
        })

        print(f"[✓] COMPLETE Merge: {target_table}")

    except Exception as e:
        error_msg = str(e)[:400]
        print(f"ERROR TaskKey {task['TaskKey']}: {error_msg}")

        return_value.append({
            "TaskAuditKey": TaskAuditKey,
            "TaskKey": task["TaskKey"],
            "TaskType": "BronzeToSilver",
            "Message": f"Error: {error_msg}",
            "Status": "Failed",
            "Watermark": etlloadtime,
            "RequestedEndTime": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "RowsRead": 0,
            "RowsInserted": 0,
            "RowsUpdated": 0,
            "RowsDeleted": 0,
            "VersionLoaded": None
        })


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def run_tasks_by_order(task_list, etlloadtime):
    task_groups = defaultdict(list)
    for task in task_list:
        task_groups[task["TaskRunOrderNbr"]].append(task)

    sorted_order_keys = sorted(task_groups.keys())

    for order_nbr in sorted_order_keys:
        print(f"\n Starting TaskRunOrderNbr: {order_nbr} with {max_workers_nbr} workers")

        with ThreadPoolExecutor(max_workers=max_workers_nbr) as executor:
            future_to_task = {executor.submit(process_task, task): task for task in task_groups[order_nbr]}

            for future in as_completed(future_to_task):
                result = future.result()

        print(f"Completed TaskRunOrderNbr: {order_nbr}\n")

    print("Process COMPLETE")

if __name__ == "__main__":
    try:
        run_tasks_by_order(tasklist, etlloadtime)
    except Exception as e:
        print(f"Execution Failed: {str(e)}")
        raise Exception


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
