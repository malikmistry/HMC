# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC SELECT * FROM (
# MAGIC 	SELECT 
# MAGIC 	tp.Description TimeLabel
# MAGIC     ,FundId
# MAGIC 	,'1' AS FundBenchmarkTrackRecordTypeId
# MAGIC 	,fst.IndexId AS IndexId
# MAGIC 	,Alpha
# MAGIC from Bronze.CrimsonXFundStatistics fs
# MAGIC LEFT JOIN Bronze.CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
# MAGIC LEFT JOIN Bronze.FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
# MAGIC WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
# MAGIC AND UPPER(FundId) = '8DF820F1-0527-4BA0-B519-00692DBFF5F7'
# MAGIC ) PIVOT (
# MAGIC 	FIRST( Alpha ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS 1Year, '3 Year' AS 3Year, '5 Year' AS 5Year, '7Year' AS 7Year, '10 Year' AS 10Year)
# MAGIC )
# MAGIC 
# MAGIC UNION ALL
# MAGIC 
# MAGIC SELECT * FROM (
# MAGIC 	SELECT 
# MAGIC 	tp.Description TimeLabel
# MAGIC     ,FundId
# MAGIC 	,'2' AS FundBenchmarkTrackRecordTypeId
# MAGIC 	,fst.IndexId AS IndexId
# MAGIC 	,GrossReturn
# MAGIC from Bronze.CrimsonXFundStatistics fs
# MAGIC LEFT JOIN Bronze.CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
# MAGIC LEFT JOIN Bronze.FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
# MAGIC WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
# MAGIC AND UPPER(FundId) = '8DF820F1-0527-4BA0-B519-00692DBFF5F7'
# MAGIC ) PIVOT (
# MAGIC 	FIRST( GrossReturn ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS 1Year, '3 Year' AS 3Year, '5 Year' AS 5Year, '7Year' AS 7Year, '10 Year' AS 10Year)
# MAGIC )
# MAGIC 
# MAGIC UNION ALL
# MAGIC 
# MAGIC SELECT * FROM (
# MAGIC 	SELECT 
# MAGIC 	tp.Description TimeLabel
# MAGIC     ,FundId
# MAGIC 	,'3' AS FundBenchmarkTrackRecordTypeId
# MAGIC 	,fst.IndexId AS IndexId
# MAGIC 	,StandardDeviation
# MAGIC from Bronze.CrimsonXFundStatistics fs
# MAGIC LEFT JOIN Bronze.CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
# MAGIC LEFT JOIN Bronze.FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
# MAGIC WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
# MAGIC AND UPPER(FundId) = '8DF820F1-0527-4BA0-B519-00692DBFF5F7'
# MAGIC ) PIVOT (
# MAGIC 	FIRST( StandardDeviation ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS 1Year, '3 Year' AS 3Year, '5 Year' AS 5Year, '7Year' AS 7Year, '10 Year' AS 10Year)
# MAGIC )
# MAGIC 
# MAGIC UNION ALL
# MAGIC 
# MAGIC SELECT * FROM (
# MAGIC 	SELECT 
# MAGIC 	tp.Description TimeLabel
# MAGIC     ,FundId
# MAGIC 	,'4' AS FundBenchmarkTrackRecordTypeId
# MAGIC 	,fst.IndexId AS IndexId
# MAGIC 	,SharpeRatio
# MAGIC from Bronze.CrimsonXFundStatistics fs
# MAGIC LEFT JOIN Bronze.CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
# MAGIC LEFT JOIN Bronze.FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
# MAGIC WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
# MAGIC AND UPPER(FundId) = '8DF820F1-0527-4BA0-B519-00692DBFF5F7'
# MAGIC ) PIVOT (
# MAGIC 	FIRST( SharpeRatio ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS 1Year, '3 Year' AS 3Year, '5 Year' AS 5Year, '7Year' AS 7Year, '10 Year' AS 10Year)
# MAGIC )
# MAGIC 
# MAGIC UNION ALL
# MAGIC 
# MAGIC SELECT * FROM (
# MAGIC 	SELECT 
# MAGIC 	tp.Description TimeLabel
# MAGIC     ,FundId
# MAGIC 	,'5' AS FundBenchmarkTrackRecordTypeId
# MAGIC 	,fst.IndexId AS IndexId
# MAGIC 	,MaxDrawdown
# MAGIC from Bronze.CrimsonXFundStatistics fs
# MAGIC LEFT JOIN Bronze.CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
# MAGIC LEFT JOIN Bronze.FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
# MAGIC WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
# MAGIC AND UPPER(FundId) = '8DF820F1-0527-4BA0-B519-00692DBFF5F7'
# MAGIC ) PIVOT (
# MAGIC 	FIRST( MaxDrawdown ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS 1Year, '3 Year' AS 3Year, '5 Year' AS 5Year, '7Year' AS 7Year, '10 Year' AS 10Year)
# MAGIC )
# MAGIC 
# MAGIC UNION ALL
# MAGIC 
# MAGIC SELECT * FROM (
# MAGIC 	SELECT 
# MAGIC 	tp.Description TimeLabel
# MAGIC     ,FundId
# MAGIC 	,'6' AS FundBenchmarkTrackRecordTypeId
# MAGIC 	,fst.IndexId AS IndexId
# MAGIC 	,Beta
# MAGIC from Bronze.CrimsonXFundStatistics fs
# MAGIC LEFT JOIN Bronze.CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
# MAGIC LEFT JOIN Bronze.FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
# MAGIC WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
# MAGIC AND UPPER(FundId) = '8DF820F1-0527-4BA0-B519-00692DBFF5F7'
# MAGIC ) PIVOT (
# MAGIC 	FIRST( Beta ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS 1Year, '3 Year' AS 3Year, '5 Year' AS 5Year, '7Year' AS 7Year, '10 Year' AS 10Year)
# MAGIC )
# MAGIC 
# MAGIC UNION ALL
# MAGIC 
# MAGIC SELECT * FROM (
# MAGIC 	SELECT 
# MAGIC 	tp.Description TimeLabel
# MAGIC     ,FundId
# MAGIC 	,'7' AS FundBenchmarkTrackRecordTypeId
# MAGIC 	,fst.IndexId AS IndexId
# MAGIC 	,Correlation
# MAGIC from Bronze.CrimsonXFundStatistics fs
# MAGIC LEFT JOIN Bronze.CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
# MAGIC LEFT JOIN Bronze.FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
# MAGIC WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
# MAGIC AND UPPER(FundId) = '8DF820F1-0527-4BA0-B519-00692DBFF5F7'
# MAGIC ) PIVOT (
# MAGIC 	FIRST( Correlation ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS 1Year, '3 Year' AS 3Year, '5 Year' AS 5Year, '7Year' AS 7Year, '10 Year' AS 10Year)
# MAGIC )
# MAGIC 
# MAGIC UNION ALL
# MAGIC 
# MAGIC SELECT * FROM (
# MAGIC 	SELECT 
# MAGIC 	tp.Description TimeLabel
# MAGIC     ,FundId
# MAGIC 	,'8' AS FundBenchmarkTrackRecordTypeId
# MAGIC 	,fst.IndexId AS IndexId
# MAGIC 	,InformationRatio
# MAGIC from Bronze.CrimsonXFundStatistics fs
# MAGIC LEFT JOIN Bronze.CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
# MAGIC LEFT JOIN Bronze.FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
# MAGIC WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
# MAGIC AND UPPER(FundId) = '8DF820F1-0527-4BA0-B519-00692DBFF5F7'
# MAGIC ) PIVOT (
# MAGIC 	FIRST( InformationRatio ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS 1Year, '3 Year' AS 3Year, '5 Year' AS 5Year, '7Year' AS 7Year, '10 Year' AS 10Year)
# MAGIC )
# MAGIC 
# MAGIC UNION ALL
# MAGIC 
# MAGIC SELECT * FROM (
# MAGIC 	SELECT 
# MAGIC 	tp.Description TimeLabel
# MAGIC     ,FundId
# MAGIC 	,'9' AS FundBenchmarkTrackRecordTypeId
# MAGIC 	,fst.IndexId AS IndexId
# MAGIC 	,TrackingError
# MAGIC from Bronze.CrimsonXFundStatistics fs
# MAGIC LEFT JOIN Bronze.CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
# MAGIC LEFT JOIN Bronze.FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
# MAGIC WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
# MAGIC AND UPPER(FundId) = '8DF820F1-0527-4BA0-B519-00692DBFF5F7'
# MAGIC ) PIVOT (
# MAGIC 	FIRST( TrackingError ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS 1Year, '3 Year' AS 3Year, '5 Year' AS 5Year, '7Year' AS 7Year, '10 Year' AS 10Year)
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
