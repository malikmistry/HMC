# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# Reference (As of Nov 11, 2025: https://learn.microsoft.com/en-us/fabric/data-engineering/materialized-lake-views/overview-materialized-lake-view)

# CELL ********************

spark.conf.set("spark.sql.caseSensitive","true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ##### **LIMITATIONS Overview**
# 
# - Declarative syntax support for PySpark. You can use Spark SQL syntax to create and refresh materialized lake views.
# - Cross-lakehouse lineage and execution features.

# MARKDOWN ********************

# # **SYNTAX**
# 
# ```
# CREATE MATERIALIZED LAKE VIEW [IF NOT EXISTS][workspace.lakehouse.schema].MLV_Identifier 
# [( 
#     CONSTRAINT constraint_name1 CHECK (condition expression1)[ON MISMATCH DROP | FAIL],  
#     CONSTRAINT constraint_name2 CHECK (condition expression2)[ON MISMATCH DROP | FAIL] 
# )] 
# [PARTITIONED BY (col1, col2, ... )] 
# [COMMENT "description or comment"] 
# [TBLPROPERTIES ("key1"="val1", "key2"="val2", ... )] 
# AS select_statement
# ```

# MARKDOWN ********************

# | Parameter        | Description                                                                                                                       |
# |------------------|-----------------------------------------------------------------------------------------------------------------------------------|
# | MLV_Identifier   | Name of the materialized lake view.                                                                                               |
# | CONSTRAINT       | Keyword to define a data quality constraint, followed by a user-defined name. The constraint applies at the level of the MLV.     |
# | CHECK            | Parameter for enforcing a condition based on certain column values. Mandatory when defining a constraint.                         |
# | ON MISMATCH      | Parameter for specifying the action to take if the constraint is violated. Possible actions: DROP and FAIL. Defaults to FAIL.     |
# | PARTITIONED BY   | Parameter for creating partitions based on the specified column(s).                                                                |
# | TBLPROPERTIES    | List of key/value pairs for tagging the definition of the materialized lake view.                                                 |
# | COMMENT          | Statement to describe the materialized lake view.                                                                                 |
# | AS select_statement | Query used to populate the materialized lake view by using a SELECT statement.                                                 |


# MARKDOWN ********************

# ##### **EXAMPLES BELOW**

# CELL ********************

target = 'lh_curated.Silver.UserRating_View'
spark.sql(f"""
CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS {target} AS 
SELECT
    CAST(cer.EntityId AS STRING) AS EntityId,
    CAST(cer.EffectiveDate AS DATE) AS EffectiveDate,
    CAST(cer.RatedByUserId AS STRING) AS RatedByUserId,

    CAST(
        CASE 
            WHEN cer.EffectiveDate = MAX(cer.EffectiveDate) OVER (
                PARTITION BY cer.RatedByUserId, cer.EntityId
            )
            THEN TRUE ELSE FALSE
        END AS BOOLEAN
    ) AS IsLatest,

    CAST(cer.InvestmentEdgeRating AS DECIMAL(38,2)) AS InvestmentEdgeRating,
    CAST(cer.OrganizationalEdgeRating AS DECIMAL(38,2)) AS OrganizationalEdgeRating,
    CAST(cer.TrackRecordRating AS DECIMAL(38,2)) AS TrackRecordRating,

    CAST(
        (cer.InvestmentEdgeRating * 0.4 
        + cer.OrganizationalEdgeRating * 0.3 
        + cer.TrackRecordRating * 0.3)
        AS DECIMAL(38,2)
    ) AS OverallRating,

    CAST(NULL AS DECIMAL(38,2)) AS NormalizedOverallRating,
    CAST(NULL AS DECIMAL(38,6)) AS Percentile,
    CURRENT_TIMESTAMP() AS ETLLoadDateTime

FROM lh_bronze.Bronze.CrimsonXEntityRating AS cer""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS lh_curated.Silver.FXRate_View AS 
# MAGIC SELECT *
# MAGIC FROM lh_bronze.Bronze.FXRate
# MAGIC WHERE USD_Ask > 0.0 

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS lh_curated.Gold.FXRate_View 
# MAGIC (CONSTRAINT FXDate_NotNull CHECK (FXDate is not null) on MISMATCH DROP)
# MAGIC AS 
# MAGIC SELECT *
# MAGIC FROM lh_curated.Silver.FXRate

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS lh_curated.Gold.FXRate_View2
# MAGIC (
# MAGIC     CONSTRAINT FXDate_NotNull 
# MAGIC     CHECK (FXDate < DATE '2025-11-01') 
# MAGIC     ON MISMATCH DROP
# MAGIC )
# MAGIC AS
# MAGIC SELECT *
# MAGIC FROM lh_curated.Silver.FXRate;


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS lh_bronze.Bronze.FundType_Bronze_View
# MAGIC AS 
# MAGIC SELECT *
# MAGIC FROM lh_bronze.Bronze.FundType_Test

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS lh_curated.Silver.FundType_Silver_View
# MAGIC AS 
# MAGIC SELECT *
# MAGIC FROM lh_bronze.Bronze.FundType_Test

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # 
# # **IMPLEMENT DATA QUALITY**
# 
# When you transform data, it becomes important to compose precise queries to exclude poor quality data from the source tables, which increases processing time and occasionally causes the whole pipeline to fail because of minor data issues.
# 
# Data quality is maintained by setting constraints when defining the MLVs. The materialized views within Fabric provide an approach to implement checks for data quality management efficiently.
# 
# The following actions can be implemented when constraints are specified.
# 
# - **FAIL** – This action stops refreshing an MLV if any constraint is violated, halting at the first instance. It's the default behavior, even without specifying the FAIL keyword.
# 
# - **DROP** – This action processes the MLV and removes records that don't meet the specified constraint. It also provides the count of removed records in the lineage view.

# MARKDOWN ********************

# ##### **LIMITATIONS**
# 
# - Updating data quality constraints after creating an MLV isn't supported. To update the data quality constraints, you must recreate the MLV.
# - Use of functions and pattern search with operators such as LIKE or regex in constraint condition is restricted.

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS lh_curated.Silver.FXRate_View_Constraint
# MAGIC (CONSTRAINT ISO_NotNull CHECK (ISO is not null) on MISMATCH DROP) -- You cannot add this after MLV has been created, MLV needs to be recreated
# MAGIC AS 
# MAGIC SELECT *
# MAGIC FROM lh_bronze.Bronze.FXRate


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC SHOW MATERIALIZED LAKE VIEWS IN Silver;

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC SHOW CREATE MATERIALIZED LAKE VIEW lh_curated.Silver.UserRating_View; -- show how an MLV is created

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # **REFRESH MLV**
# ##### _Important:_
# ##### For incremental refresh to take effect, it is required to set delta CDF property to delta.enableChangeDataFeed=true for the sources referenced in the materialized lake views definition.
# 
# 
# | Refresh Policy       | Description                                                                                                      |
# |---------------------|------------------------------------------------------------------------------------------------------------------|
# | Incremental refresh  | An incremental refresh only processes the changed data in the sources referenced in the materialized lake view. |
# | No refresh           | If the source remains unchanged (i.e., no change detected in delta commits), the service skips the refresh.     |
# | Full refresh         | A full refresh involves assessing the entire dataset of dependent sources whenever any modification is made.    |


# CELL ********************

# MAGIC %%sql
# MAGIC REFRESH MATERIALIZED LAKE VIEW [workspace.lakehouse.schema.Table/view].MLV_Identifier FULL -- full refresh

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC -- to determine the refresh policy under optimal refresh mode, you can query the sys_dq_metrics table
# MAGIC SELECT 
# MAGIC     MLVName,
# MAGIC     refreshPolicy 
# MAGIC FROM  
# MAGIC     dbo.sys_dq_metrics 
# MAGIC WHERE
# MAGIC     MLVName = '<materialized_lake_view_name>'

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
