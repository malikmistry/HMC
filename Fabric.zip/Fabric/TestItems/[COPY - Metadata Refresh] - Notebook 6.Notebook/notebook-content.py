# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# %pip install --upgrade msal requests

import os, time, json, requests, msal
# ⬇️ paste the *secret value* (not Secret ID) for your service principal
os.environ["FABRIC_CLIENT_SECRET"] = "6kc8Q~qXvruacZqlKnZP06WRAXh~BB60BfxC5aMo"

# optional: if your SP client id isn't the one in the notebook, set it too:
os.environ["FABRIC_CLIENT_ID"] = "f674b3b2-ff4c-4272-b60d-a2acfeafca3f"

os.environ["FABRIC_SQL_ENDPOINT_ID"] = "aef35469-ca5b-4ff6-9544-a57182d98333"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

TENANT_ID    = "385f9270-6e2d-44ab-8297-02cf20fd17ce"
WORKSPACE_ID = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"

# --- READ the env vars into the variables you actually use ---
CLIENT_ID     = os.environ.get("FABRIC_CLIENT_ID")
CLIENT_SECRET = os.environ.get("FABRIC_CLIENT_SECRET")
SQL_ENDPOINT_ID = os.environ.get("FABRIC_SQL_ENDPOINT_ID")  # optional; if not set we'll list & pick

if not CLIENT_ID or not CLIENT_SECRET:
    raise RuntimeError("Missing FABRIC_CLIENT_ID and/or FABRIC_CLIENT_SECRET environment variables.")

# --- get a Fabric token as the service principal ---
AUTHORITY = f"https://login.microsoftonline.com/{TENANT_ID}"
SCOPE     = ["https://api.fabric.microsoft.com/.default"]

app = msal.ConfidentialClientApplication(CLIENT_ID, authority=AUTHORITY, client_credential=CLIENT_SECRET)
tok = app.acquire_token_for_client(scopes=SCOPE)
if "access_token" not in tok:
    raise RuntimeError(f"MSAL token error: {tok.get('error')} | {tok.get('error_description')} (corr={tok.get('correlation_id')})")

AT = tok["access_token"]
H  = {"Authorization": f"Bearer {AT}"}
HJ = {"Authorization": f"Bearer {AT}", "Content-Type": "application/json"}

# 1) List semantic models in the workspace and pick the right one
sm_url = f"https://api.fabric.microsoft.com/v1/workspaces/{WORKSPACE_ID}/semanticModels"
sm = requests.get(sm_url, headers=H)
sm.raise_for_status()
models = sm.json().get("value", [])
print("Semantic models in workspace:")
for m in models:
    print(" -", m["displayName"], m["id"])


# --- choose SQL Endpoint: use the one you provided; otherwise list & pick the first ---
if not SQL_ENDPOINT_ID:
    ep_resp = requests.get(f"https://api.fabric.microsoft.com/v1/workspaces/{WORKSPACE_ID}/sqlEndpoints", headers=H)
    if ep_resp.status_code == 403:
        raise RuntimeError("403 listing SQL endpoints. Ask the Fabric admin to enable 'Service principals can call Fabric public APIs' and allow-list this SP; ensure the SP has at least Viewer on the workspace.")
    ep_resp.raise_for_status()
    endpoints = ep_resp.json().get("value", [])
    if not endpoints:
        raise RuntimeError("No SQL Endpoints found in the workspace.")
    if len(endpoints) > 1:
        print("Multiple SQL Endpoints available:")
        for e in endpoints:
            print(" -", e.get("displayName"), e.get("id"))
    SQL_ENDPOINT_ID = endpoints[0]["id"]

print("Refreshing SQL Endpoint:", SQL_ENDPOINT_ID)

# --- refresh Lakehouse (SQL Endpoint metadata) ---
meta_url = f"https://api.fabric.microsoft.com/v1/workspaces/{WORKSPACE_ID}/sqlEndpoints/{SQL_ENDPOINT_ID}/refreshMetadata"
m = requests.post(meta_url, headers=HJ, json={"timeout": {"timeUnit": "Minutes", "value": 5}})
print("refreshMetadata HTTP:", m.status_code)

if m.status_code == 202:
    loc = m.headers.get("Location"); retry = int(m.headers.get("Retry-After", "5"))
    print("Polling:", loc, "every", retry, "sec …")
    while True:
        time.sleep(retry)
        pr = requests.get(loc, headers=H)
        if pr.status_code == 200:
            res = pr.json()
            print("Metadata refresh complete. Showing a few table results:")
            print(json.dumps(res.get("value", [])[:5], indent=2))
            break
        elif pr.status_code in (202, 204):
            continue
        else:
            raise RuntimeError(f"Metadata refresh failed: {pr.status_code} {pr.text}")
elif m.status_code == 200:
    print("Metadata refresh completed immediately:", m.text[:400])
    print("Metadata refresh completed immediately:", m.text)
else:
    raise RuntimeError(f"Metadata refresh call failed: {m.status_code} {m.text}")

# # --- 2) Trigger semantic model (dataset) refresh ---
# DATASET_ID = "8fabbcf8-4b95-4e43-b274-dd2cc06fe89a"

# ds_url = f"https://api.fabric.microsoft.com/v1/workspaces/{WORKSPACE_ID}/datasets/{DATASET_ID}/refreshes"
# print(ds_url)
# # Default refresh (no body):
# # resp = requests.post(ds_url, headers=HJ)

# # Enhanced refresh (lets you tune behavior):
# payload = {
#     "type": "Full",                 # or "automatic"
#     "commitMode": "transactional",  # or "partialBatch"
#     "maxParallelism": 10,
#     "retryCount": 2
# }
# resp = requests.post(ds_url, headers=HJ, json=payload)

# print("Dataset refresh HTTP:", resp.status_code)
# print("Location:", resp.headers.get("Location"))
# print(resp.text[:400])

# # (Optional) Poll latest refresh record (handy when you don't have a Location):
# hist = requests.get(ds_url, headers=H, params={"$top": 1})
# print("Latest refresh record:", hist.status_code, hist.text[:500])


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

##TEST ONLY

from pyspark.sql.functions import col
from datetime import datetime,date
dfCrimsonXShareClass  =  spark.sql("""SELECT ShareClassId, FundId FROM Bronze.CrimsonXShareClass LIMIT 5
""")
dfCrimsonXShareClass.createOrReplaceTempView("dfCrimsonXShareClass")

# newDF = spark.sql(f"""
# MERGE INTO Bronze.TestMetadataRefresh AS target
# USING dfCrimsonXShareClass AS source
# ON target.ShareClassId = source.ShareClassId
# WHEN MATCHED THEN
#   UPDATE SET target.FundId = source.FundId
# WHEN NOT MATCHED THEN
#   INSERT (ShareClassId, FundId) VALUES (source.ShareClassId, source.FundId)
# """)


dfCrimsonXShareClass.write.format("delta").mode("overwrite")\
    .save("abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/TestMetadataRefresh")

# dfCrimsonXShareClass.write.format("delta").mode("append")\
#     .save("abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/TestMetadataRefresh")


df_source = spark.read.format("delta").load("abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/TestMetadataRefresh")
df_source.count()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_source = spark.read.format("delta").load("abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/TestMetadataRefresh")
df_source.show(10)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dftest  =  spark.sql("""SELECT ShareClassId, FundId FROM Bronze.TestMetadataRefresh
""")
dftest.show(10)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC SELECT * FROM Bronze.TestMetadataRefresh

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
