# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS Silver.Transaction(
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	ExposureDate date NOT NULL,
# MAGIC 	TransactionTypeId int NOT NULL,
# MAGIC 	TransactionSubTypeId int NOT NULL,
# MAGIC 	TransactionAmountInLocal decimal(38, 2),
# MAGIC 	TransactionAmountInUSD decimal(38, 2),
# MAGIC 	TransactionAmountOutLocal decimal(38, 2),
# MAGIC 	TransactionAmountOutUSD decimal(38, 2),
# MAGIC 	TransactionAmountLocal decimal(38, 2),
# MAGIC 	TransactionAmountUSD decimal(38, 2),
# MAGIC 	TransactionCount bigint,
# MAGIC 	ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC SELECT DISTINCT CAST(`DATE` AS TIMESTAMP)
# MAGIC FROM lh_bronze.Bronze.SolovisCommitments
# MAGIC --WHERE CAST(`DATE` AS TIMESTAMP) >= CAST('7/1/2020' AS TIMESTAMP)
# MAGIC ORDER BY `DATE`

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE Silver.Transaction(
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	AsOfDate date NOT NULL,
# MAGIC 	TransactionTypeId int NOT NULL,
# MAGIC 	TransactionSubTypeId int NOT NULL,
# MAGIC 	TransactionAmountInLocal decimal(38, 2),
# MAGIC 	TransactionAmountInUSD decimal(38, 2),
# MAGIC 	TransactionAmountOutLocal decimal(38, 2),
# MAGIC 	TransactionAmountOutUSD decimal(38, 2),
# MAGIC 	TransactionAmountLocal decimal(38, 2),
# MAGIC 	TransactionAmountUSD decimal(38, 2),
# MAGIC 	TransactionCount bigint,
# MAGIC 	ETLLoadDateTime varchar(8000) NOT NULL
# MAGIC )
# MAGIC 


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC SELECT * FROM Silver.UniversityTransaction LIMIT 5


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE Silver.ShareClass(
# MAGIC 	ShareClassId varchar(36) NOT,
# MAGIC 	FundId varchar(36) NOT,
# MAGIC 	ShareClassName varchar(8000) NOT,
# MAGIC 	EffectiveDate date,
# MAGIC 	IsDefault boolean,
# MAGIC 	IlliquidPct decimal(14, 8),
# MAGIC 	ETLLoadDateTime TIMESTAMP NOT
# MAGIC ) 

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

query = f"""
            SELECT 
            	CAST(ShareClassId AS VARCHAR(36)) ShareClassId,
                CAST(FundId AS VARCHAR(36)) FundId,
                ShareClassName,
                EffectiveDate,
                IsDefault,
                IlliquidPct,
                CAST(ETLLoadDateTime AS TIMESTAMP) ETLLoadDateTime
             FROM Silver.ShareClassBackup

            """
result_df = spark.sql(query)
#result_df.show(5)
# Write the result as a Delta table
result_df.write.format("delta").mode("append").save("abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465/Tables/Silver/ShareClass")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC DESCRIBE TABLE Silver.UniversityTransaction

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC DESCRIBE HISTORY Bronze.CrimsonXFund

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
