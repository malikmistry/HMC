# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

#import sempy.fabric as fabric
import notebookutils
import json
import notebookutils
import json
from pyspark.sql import SparkSession
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
import msal, requests

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

WORKSPACE_ID = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
LAKEHOUSE_ID = 'e9fc4e80-ff69-4d45-bbdd-892592889465'
TenantId = '385f9270-6e2d-44ab-8297-02cf20fd17ce'
KeyVaultName = 'kv-dc1dev-adf'
SecretName= 'crimsonservice-dev-client-secret'
ClientId = 'f674b3b2-ff4c-4272-b60d-a2acfeafca3f'

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

try:
    # ------------------------------------------------------------
    # 1. Initialize Spark session
    # ------------------------------------------------------------
    spark = SparkSession.builder.getOrCreate()

    # ------------------------------------------------------------
    # 2. Retrieve credentials securely from Azure Key Vault
    # ------------------------------------------------------------
    key_vault_url = f"https://{KeyVaultName}.vault.azure.net/"
    credential = DefaultAzureCredential()
    SecretValue = notebookutils.credentials.getSecret(key_vault_url,SecretName)
    print(SecretValue)
except Exception as e:
    raise e

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

app = msal.ConfidentialClientApplication(
    ClientId,
    authority=f"https://login.microsoftonline.com/{TenantId}",
    client_credential=SecretValue
)

token = app.acquire_token_for_client(scopes=["https://api.fabric.microsoft.com/.default"])
access_token = token["access_token"]

#headers = {"Authorization": f"Bearer {access_token}"}

# url = f"https://api.fabric.microsoft.com/v1/workspaces/{WORKSPACE_ID}/lakehouses/{LAKEHOUSE_ID}/jobs/instances?jobType=RefreshMaterializedLakeViewss"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # 2. Ask for delegated Fabric scopes (user signs in)
# scopes = ["https://api.fabric.microsoft.com/Lakehouse.Execute.All"]

# # Try silent first (if you’ve logged in before)
# accounts = app.get_accounts()
# if accounts:
#     result = app.acquire_token_silent(scopes=scopes, account=accounts[0])
# else:
#     result = None

# if not result:
#     # Device code flow for interactive sign-in in console
#     flow = app.initiate_device_flow(scopes=scopes)
#     if "user_code" not in flow:
#         raise RuntimeError("Failed to create device flow")
#     print("Go to:", flow["verification_uri"])
#     print("Enter code:", flow["user_code"])
#     result = app.acquire_token_by_device_flow(flow)

# if "access_token" not in result:
#     raise RuntimeError(f"Failed to obtain token: {result}")

# access_token = result["access_token"]


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# 3. Call the Fabric API
headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

url = (
    f"https://api.fabric.microsoft.com/v1/"
    f"workspaces/{WORKSPACE_ID}/lakehouses/{LAKEHOUSE_ID}/jobs/instances"
    f"?jobType=RefreshMaterializedLakeViews"
)

response = requests.post(url, headers=headers)

print("Status:", response.status_code)
print("Body:", response.text)

if response.status_code == 202:
    # On success, you get a Location + Retry-After header
    location = response.headers.get("Location")
    retry_after = response.headers.get("Retry-After")
    print("Job accepted.")
    print("Location:", location)
    print("Retry-After (seconds):", retry_after)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

status_url = location

job_status = requests.get(status_url, headers=headers)
print(job_status.json())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC SHOW MATERIALIZED LAKE VIEWS IN Silver;

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#GET https://api.fabric.microsoft.com/v1/workspaces/{WORKSPACE_ID}/lakehouses/{LAKEHOUSE_ID}/jobs/RefreshMaterializedLakeViews/instances
headers2 = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}
url2 = 'https://api.fabric.microsoft.com/v1/workspaces/{WORKSPACE_ID}/lakehouses/{LAKEHOUSE_ID}/jobs/RefreshMaterializedLakeViews/instances'
response2 = requests.get(url2, headers=headers2)
print(response2.json())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
