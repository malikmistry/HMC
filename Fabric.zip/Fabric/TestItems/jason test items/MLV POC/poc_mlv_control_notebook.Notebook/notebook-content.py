# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Create empty Bronze.MLVPOC1
spark.sql("""
CREATE TABLE IF NOT EXISTS Bronze.TEST_MLVPOC1 (
    Id INT,
    Name STRING,
    Amount DOUBLE
)
""")

# Create empty Bronze.MLVPOC2
spark.sql("""
CREATE TABLE IF NOT EXISTS Bronze.TEST_MLVPOC2 (
    ItemId INT,
    Color STRING,
    Category STRING
)
""")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS Gold.Transaction AS 
# MAGIC SELECT * FROM Silver.Transaction

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Data for Bronze.MLVPOC1
df1 = spark.createDataFrame([
    (1, "Alpha", 10.5),
    (2, "Bravo", 20.0),
    (3, "Charlie", 30.75),
    (4, "Delta", 40.25),
    (5, "Echo", 50.0)
], ["Id", "Name", "Amount"])

df1.write.mode("overwrite").format("delta").saveAsTable("Bronze.TEST_MLVPOC1")


# Data for Bronze.MLVPOC2
df2 = spark.createDataFrame([
    (101, "Red", "CategoryA"),
    (102, "Blue", "CategoryB"),
    (103, "Green", "CategoryA"),
    (104, "Yellow", "CategoryC"),
    (105, "Purple", "CategoryB"),
    (106, "Pink", "CategoryD"),
    (106, "Magenta", "CategoryD")


], ["ItemId", "Color", "Category"])

df2.write.mode("overwrite").format("delta").saveAsTable("Bronze.TEST_MLVPOC2")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("SELECT * FROM Bronze.TEST_MLVPOC1").show()
spark.sql("SELECT * FROM Bronze.TEST_MLVPOC2").show()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("SELECT * FROM lh_curated.Silver.TEST_MLVPOC1_view").show()
spark.sql("SELECT * FROM lh_curated.Silver.TEST_MLVPOC2_view").show()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.conf.set("spark.sql.caseSensitive","true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS lh_curated.Silver.TEST_MLVPOC1_view AS 
# MAGIC SELECT *
# MAGIC FROM lh_bronze.Bronze.TEST_MLVPOC1
# MAGIC WHERE Id > 3

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS lh_curated.Gold.vwFundBenchmarkTrackRecord AS 
# MAGIC SELECT a.*,b.Description FROM lh_curated.Gold.FundBenchmarkTrackRecord a
# MAGIC LEFT JOIN lh_bronze.Bronze.FundBenchmarkTrackRecordType b
# MAGIC     ON a.FundBenchmarkTrackRecordTypeId = b.Id

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC SELECT a.*,b.Description FROM lh_curated.Gold.FundBenchmarkTrackRecord a
# MAGIC LEFT JOIN lh_bronze.Bronze.FundBenchmarkTrackRecordType b
# MAGIC     ON a.FundBenchmarkTrackRecordTypeId = b.Id

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS lh_curated.Silver.TEST_MLVPOC2_view AS 
# MAGIC SELECT *
# MAGIC FROM lh_bronze.Bronze.TEST_MLVPOC2
# MAGIC WHERE ItemId >= 103

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC REFRESH MATERIALIZED LAKE VIEW lh_curated.Silver.TEST_MLVPOC2_view

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
