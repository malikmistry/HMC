# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

tablelist = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
tablelist = "[{\"SinkSchemaName\":\"Gold\",\"SinkTableName\":\"vwUniverse\",\"CustomSQLSourceQuery\":\"CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS Gold.vwUniverse AS \\r\\nSELECT * FROM Silver.Universe\"},{\"SinkSchemaName\":\"Gold\",\"SinkTableName\":\"vwIndex\",\"CustomSQLSourceQuery\":\"CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS Gold.vwIndex AS \\r\\nSELECT * FROM Silver.Index\"},{\"SinkSchemaName\":\"Gold\",\"SinkTableName\":\"vwPrivateFeeTiers\",\"CustomSQLSourceQuery\":\"CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS Gold.vwPrivateFeeTiers AS \\r\\nSELECT * FROM Silver.PrivateFeeTiers\"},{\"SinkSchemaName\":\"Gold\",\"SinkTableName\":\"vwPrivateFees\",\"CustomSQLSourceQuery\":\"CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS Gold.vwPrivateFees AS \\r\\nSELECT * FROM Silver.PrivateFees\"},{\"SinkSchemaName\":\"Gold\",\"SinkTableName\":\"vwFirm\",\"CustomSQLSourceQuery\":\"CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS Gold.vwFirm AS \\r\\nSELECT * FROM Silver.Firm\"},{\"SinkSchemaName\":\"Gold\",\"SinkTableName\":\"vwTransaction\",\"CustomSQLSourceQuery\":\"CREATE MATERIALIZED LAKE VIEW IF NOT EXISTS Gold.vwTransaction AS   SELECT * FROM Silver.Transaction\"}]"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tasklist = json.loads(f"{tablelist}")
print(tasklist)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Parameters / config

# If you want FULL refresh instead of optimal/incremental, set this to True
use_full_refresh = True

# Max parallel refreshes to run concurrently
max_parallel_jobs = 2


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pyspark.sql.types import StructType, StructField, StringType, BooleanType


# Convert dicts → "schema.table"
raw_list = [
    f"{item['SinkSchemaName']}.{item['SinkTableName']}"
    for item in tasklist
]

# Deduplicate
mlv_list = list(dict.fromkeys(raw_list))

print("MLV LIST:", mlv_list)
print("COUNT:", len(mlv_list))


def create_mlv_if_needed(item: dict):
    sql_text = item.get("CustomSQLSourceQuery")

    if sql_text and sql_text.strip() != "":
        print(f"\n[CREATE] Executing CREATE MATERIALIZED LAKE VIEW for: {item['SinkSchemaName']}.{item['SinkTableName']}")
        try:
            spark.sql(sql_text)
            print("[CREATE] Success")
        except Exception as e:
            print(f"[CREATE] FAILED for {item['SinkSchemaName']}.{item['SinkTableName']} -> {str(e)}")

# Run creation once per item
for item in tasklist:
    create_mlv_if_needed(item)


def refresh_mlv(mlv_name: str, full: bool = False) -> dict:
    start_time = datetime.utcnow()
    sql_suffix = " FULL" if full else ""
    sql_stmt = f"REFRESH MATERIALIZED LAKE VIEW {mlv_name}{sql_suffix}"

    print(f"[{start_time.isoformat()}] Starting refresh for: {mlv_name} (FULL={full})")

    try:
        spark.sql(sql_stmt)
        status = "Succeeded"
        error_msg = None
        print(f"[{datetime.utcnow().isoformat()}] Finished refresh for: {mlv_name}")
    except Exception as e:
        status = "Failed"
        error_msg = str(e)
        print(f"[{datetime.utcnow().isoformat()}] FAILED refresh for: {mlv_name} -> {error_msg}")

    end_time = datetime.utcnow()

    return {
        "MLVName": mlv_name,
        "FullRefresh": full,
        "Status": status,
        "StartTimeUtc": start_time.isoformat(),
        "EndTimeUtc": end_time.isoformat(),
        "ErrorMessage": error_msg
    }

results = []
if not mlv_list:
    #raise ValueError("mlv_list is empty. Populate it with at least one MLV name.")
    print("No MLV")

else:
    max_workers = min(max_parallel_jobs, len(mlv_list))
    results = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {
            executor.submit(refresh_mlv, mlv_name, use_full_refresh): mlv_name
            for mlv_name in mlv_list
        }

        for future in as_completed(future_map):
            results.append(future.result())


if results:
    rows = [
        (
            r["MLVName"],
            r["FullRefresh"],
            r["Status"],
            r["StartTimeUtc"],
            r["EndTimeUtc"],
            r["ErrorMessage"]
        )
        for r in results
    ]

    schema = StructType([
        StructField("MLVName",       StringType(),  True),
        StructField("FullRefresh",   BooleanType(), True),
        StructField("Status",        StringType(),  True),
        StructField("StartTimeUtc",  StringType(),  True),
        StructField("EndTimeUtc",    StringType(),  True),
        StructField("ErrorMessage",  StringType(),  True),
    ])

    df_results = spark.createDataFrame(rows, schema=schema)
    df_results.show(truncate=False)
else:
    print("No results returned from refresh_mlv tasks.")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# from concurrent.futures import ThreadPoolExecutor, as_completed
# from datetime import datetime
# from pyspark.sql.types import StructType, StructField, StringType, BooleanType

# def refresh_mlv(mlv_name: str, full: bool = False) -> dict:
#     """
#     Runs REFRESH MATERIALIZED LAKE VIEW for a single MLV.
#     Returns a dict with status info for logging.
#     """
#     start_time = datetime.utcnow()
#     sql_suffix = " FULL" if full else ""
#     sql_stmt = f"REFRESH MATERIALIZED LAKE VIEW lh_curated.{mlv_name}{sql_suffix}"

#     print(f"[{start_time.isoformat()}] Starting refresh for: {mlv_name} (FULL={full})")
#     try:
#         spark.sql(sql_stmt)
#         status = "Succeeded"
#         error_msg = None
#         print(f"[{datetime.utcnow().isoformat()}] Finished refresh for: {mlv_name}")
#     except Exception as e:
#         status = "Failed"
#         error_msg = str(e)
#         print(f"[{datetime.utcnow().isoformat()}] FAILED refresh for: {mlv_name} -> {error_msg}")

#     end_time = datetime.utcnow()

#     return {
#         "MLVName": mlv_name,
#         "FullRefresh": full,
#         "Status": status,
#         "StartTimeUtc": start_time.isoformat(),
#         "EndTimeUtc": end_time.isoformat(),
#         "ErrorMessage": error_msg
#     }

# # ---- Run all MLV refreshes in parallel ----

# if not mlv_list:
#     raise ValueError("mlv_list is empty. Please populate it with at least one MLV name.")

# max_workers = min(max_parallel_jobs, len(mlv_list))
# results = []

# with ThreadPoolExecutor(max_workers=max_workers) as executor:
#     future_map = {
#         executor.submit(refresh_mlv, mlv_name, use_full_refresh): mlv_name
#         for mlv_name in mlv_list
#     }

#     for future in as_completed(future_map):
#         result = future.result()
#         results.append(result)

# # Only build a DataFrame if we actually have results
# if results:
#     # Convert list[dict] → list[tuple]
#     rows = [
#         (
#             r["MLVName"],
#             r["FullRefresh"],
#             r["Status"],
#             r["StartTimeUtc"],
#             r["EndTimeUtc"],
#             r["ErrorMessage"]
#         )
#         for r in results
#     ]

#     schema = StructType([
#         StructField("MLVName",       StringType(),  True),
#         StructField("FullRefresh",   BooleanType(), True),
#         StructField("Status",        StringType(),  True),
#         StructField("StartTimeUtc",  StringType(),  True),
#         StructField("EndTimeUtc",    StringType(),  True),
#         StructField("ErrorMessage",  StringType(),  True),
#     ])

#     df_results = spark.createDataFrame(rows, schema=schema)
#     df_results.show(truncate=False)
# else:
#     print("No results returned from refresh_mlv tasks.")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
