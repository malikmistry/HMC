# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# %%configure
# {
#   "defaultLakehouse": {
#     "name": { "parameterName": "LakehouseName", "defaultValue": "lh_bronze" },
#     "id":   { "parameterName": "LHId",   "defaultValue": "13ef97da-5da2-466d-8c5f-2a70572c6558" },
#     "workspaceId": { "parameterName": "WorkspaceId", "defaultValue": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced" }
#   }
# }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType, StringType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
LHId = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(WorkspaceId)
print(LHId)
print(LakehouseName)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# %%configure
# {
#   "defaultLakehouse": {
#     "name": { "parameterName": "LakehouseName", "defaultValue": "lh_curated" },
#     "id":   { "parameterName": "LHId",   "defaultValue": "e9fc4e80-ff69-4d45-bbdd-892592889465" },
#     "workspaceId": { "parameterName": "WorkspaceId", "defaultValue": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced" }
#   }
# }


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# %%configure
# {
#   "defaultLakehouse": {
#     "name": "lh_curated",
#     "id": "e9fc4e80-ff69-4d45-bbdd-892592889465",
#     "workspaceId": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
#   }
# }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE lh_curated.Silver.BetaSummaryFundDetail 
# MAGIC AS
# MAGIC with max_asof AS (
# MAGIC SELECT MAX(AsOfDt) dt FROM lh_bronze.Bronze.HMCDataMartInvestmentBetaAnalyticSummary      
# MAGIC WHERE RiskApproved = 1 
# MAGIC )
# MAGIC 
# MAGIC SELECT
# MAGIC AsofDt AS AsofDate
# MAGIC ,FundId AS FundId
# MAGIC ,ValuationPlusCashflowsAmt AS ValuationPlusCashflowsAmt
# MAGIC ,ValuationAmt AS ValuationAmt
# MAGIC ,ValuationDt AS ValuationDate
# MAGIC ,CashflowsIn1stHalfAmt AS CashflowsIn1stHalfAmt
# MAGIC ,CashflowsIn2ndHalfAmt AS CashflowsIn2ndHalfAmt
# MAGIC ,T0Nav AS T0Nav
# MAGIC ,T1Nav AS T1Nav
# MAGIC ,EquityBetaCashflow1Amt AS EquityBetaCashflow1Amt
# MAGIC ,CreditBetaCashflow1Amt AS CreditBetaCashflow1Amt
# MAGIC ,NominalBondBetaCashflow1Amt AS NominalBondBetaCashflow1Amt
# MAGIC ,TIPSBetaCashflow1Amt AS TIPSBetaCashflow1Amt
# MAGIC ,RABetaCashflow1Amt AS RABetaCashflow1Amt
# MAGIC ,EquityBetaCashflow2Amt AS EquityBetaCashflow2Amt
# MAGIC ,CreditBetaCashflow2Amt AS CreditBetaCashflow2Amt
# MAGIC ,NominalBondBetaCashflow2Amt AS NominalBondBetaCashflow2Amt
# MAGIC ,TIPSBetaCashflow2Amt AS TIPSBetaCashflow2Amt
# MAGIC ,RABetaCashflow2Amt AS RABetaCashflow2Amt
# MAGIC ,EquityLongRiskBenchmarkNm AS EquityLongRiskBenchmarkName
# MAGIC ,EquityLongBetaMultiplierNum AS EquityLongBetaMultiplierNumber
# MAGIC ,EquityShortRiskBenchmarkNm AS EquityShortRiskBenchmarkName
# MAGIC ,EquityShortBetaMultiplierNum AS EquityShortBetaMultiplierNumber
# MAGIC ,CorporateCreditLongRiskBenchmarkNm AS CorporateCreditLongRiskBenchmarkName
# MAGIC ,CorporateCreditLongBetaMultiplierNum AS CorporateCreditLongBetaMultiplierNumber
# MAGIC ,CorporateCreditShortRiskBenchmarkNm AS CorporateCreditShortRiskBenchmarkName
# MAGIC ,CorporateCreditShortBetaMultiplierNum AS CorporateCreditShortBetaMultiplierNumber
# MAGIC ,NominalBondsRiskBenchmarkNm AS NominalBondsRiskBenchmarkName
# MAGIC ,NominalBondsBetaMultiplierNum AS NominalBondsBetaMultiplierNumber
# MAGIC ,InflationLinkedBondsRiskBenchmarkNm AS InflationLinkedBondsRiskBenchmarkName
# MAGIC ,InflationLinkedBondsBetaMultiplierNum AS InflationLinkedBondsBetaMultiplierNumber
# MAGIC ,RealAssetsRiskBenchmarkNm AS RealAssetsRiskBenchmarkName
# MAGIC ,RealAssetsBetaMultiplierNum AS RealAssetsBetaMultiplierNumber
# MAGIC ,T0EquityBetaAmt AS T0EquityBetaAmt
# MAGIC ,T0CreditBetaAmt AS T0CreditBetaAmt
# MAGIC ,T0NominalBondBetaAmt AS T0NominalBondBetaAmt
# MAGIC ,T0TIPSBetaAmt AS T0TIPSBetaAmt
# MAGIC ,T0RealAssetsBetaAmt AS T0RealAssetsBetaAmt
# MAGIC ,EquityLongExposureBenchmarkNm AS EquityLongExposureBenchmarkName
# MAGIC ,EquityLongExposurePct AS EquityLongExposurePercent
# MAGIC ,EquityShortExposureBenchmarkNm AS EquityShortExposureBenchmarkName
# MAGIC ,EquityShortExposurePct AS EquityShortExposurePercent
# MAGIC ,CorporateCreditLongExposureBenchmarkNm AS CorporateCreditLongExposureBenchmarkName
# MAGIC ,CorporateCreditLongExposurePct AS CorporateCreditLongExposurePercent
# MAGIC ,CorporateCreditShortExposureBenchmarkNm AS CorporateCreditShortExposureBenchmarkName
# MAGIC ,CorporateCreditShortExposurePct AS CorporateCreditShortExposurePercent
# MAGIC ,NominalBondsExposureBenchmarkNm AS NominalBondsExposureBenchmarkName
# MAGIC ,NominalBondsExposurePct AS NominalBondsExposurePercent
# MAGIC ,InflationBondsExposureBenchmarkNm AS InflationBondsExposureBenchmarkName
# MAGIC ,InflationBondsExposurePct AS InflationBondsExposurePercent
# MAGIC ,RealAssetsExposureBenchmarkNm AS RealAssetsExposureBenchmarkName
# MAGIC ,RealAssetsExposurePct AS RealAssetsExposurePercent
# MAGIC ,T1EquityBetaAmt AS T1EquityBetaAmt
# MAGIC ,T1CreditBetaAmt AS T1CreditBetaAmt
# MAGIC ,T1NominalBondBetaAmt AS T1NominalBondBetaAmt
# MAGIC ,T1TIPSBetaAmt AS T1TIPSBetaAmt
# MAGIC ,T1RealAssetsBetaAmt AS T1RealAssetsBetaAmt
# MAGIC ,EquityBetaPnLAmt AS EquityBetaPnLAmt
# MAGIC ,CreditBetaPnLAmt AS CreditBetaPnLAmt
# MAGIC ,NominalBetaBetaPnLAmt AS NominalBetaBetaPnLAmt
# MAGIC ,TIPSBetaPnLAmt AS TIPSBetaPnLAmt
# MAGIC ,RealAssetBetaPnLAmt AS RealAssetBetaPnLAmt
# MAGIC ,T1EquityAmericasDevelopedAmt AS T1EquityAmericasDevelopedAmt
# MAGIC ,T1EquityAmericasEMAmt AS T1EquityAmericasEMAmt
# MAGIC ,T1EquityBrazilAmt AS T1EquityBrazilAmt
# MAGIC ,T1EquityChinaHKAmt AS T1EquityChinaHKAmt
# MAGIC ,T1EquityIndiaAmt AS T1EquityIndiaAmt
# MAGIC ,T1EquityAsiaExAmt AS T1EquityAsiaExAmt
# MAGIC ,T1EquityEuropeDevelopedAmt AS T1EquityEuropeDevelopedAmt
# MAGIC ,T1EquityEuropeEMAmt AS T1EquityEuropeEMAmt
# MAGIC ,T1EquityJapanAmt AS T1EquityJapanAmt
# MAGIC ,T1CreditAmericasDevelopedAmt AS T1CreditAmericasDevelopedAmt
# MAGIC ,T1CreditAmericasEMAmt AS T1CreditAmericasEMAmt
# MAGIC ,T1CreditBrazilAmt AS T1CreditBrazilAmt
# MAGIC ,T1CreditChinaHKAmt AS T1CreditChinaHKAmt
# MAGIC ,T1CreditIndiaAmt AS T1CreditIndiaAmt
# MAGIC ,T1CreditAsiaExAmt AS T1CreditAsiaExAmt
# MAGIC ,T1CreditEuropeDevelopedAmt AS T1CreditEuropeDevelopedAmt
# MAGIC ,T1CreditEuropeEMAmt AS T1CreditEuropeEMAmt
# MAGIC ,T1CreditJapanAmt AS T1CreditJapanAmt
# MAGIC ,T1NominalBondAmericasDevelopedAmt AS T1NominalBondAmericasDevelopedAmt
# MAGIC ,T1NominalBondAmericasEMAmt AS T1NominalBondAmericasEMAmt
# MAGIC ,T1NominalBrazilAmt AS T1NominalBrazilAmt
# MAGIC ,T1NominalBondChinaHKAmt AS T1NominalBondChinaHKAmt
# MAGIC ,T1NominalBondIndiaAmt AS T1NominalBondIndiaAmt
# MAGIC ,T1NominalBondAsiaExAmt AS T1NominalBondAsiaExAmt
# MAGIC ,T1NominalBondEuropeDevelopedAmt AS T1NominalBondEuropeDevelopedAmt
# MAGIC ,T1NominalBondEuropeEMAmt AS T1NominalBondEuropeEMAmt
# MAGIC ,T1NominalBondJapanAmt AS T1NominalBondJapanAmt
# MAGIC ,T1TIPSAmericasDevelopedAmt AS T1TIPSAmericasDevelopedAmt
# MAGIC ,T1TIPSAmericasEMAmt AS T1TIPSAmericasEMAmt
# MAGIC ,T1TIPSBrazilAmt AS T1TIPSBrazilAmt
# MAGIC ,T1TIPSChinaHKAmt AS T1TIPSChinaHKAmt
# MAGIC ,T1TIPSIndiaAmt AS T1TIPSIndiaAmt
# MAGIC ,T1TIPSAsiaExAmt AS T1TIPSAsiaExAmt
# MAGIC ,T1TIPSEuropeDevelopedAmt AS T1TIPSEuropeDevelopedAmt
# MAGIC ,T1TIPSEuropeEMAmt AS T1TIPSEuropeEMAmt
# MAGIC ,T1TIPSJapanAmt AS T1TIPSJapanAmt
# MAGIC ,T1RealAssetsAmericasDevelopedAmt AS T1RealAssetsAmericasDevelopedAmt
# MAGIC ,T1RealAssetsAmericasEMAmt AS T1RealAssetsAmericasEMAmt
# MAGIC ,T1RealAssetsBrazilAmt AS T1RealAssetsBrazilAmt
# MAGIC ,T1RealAssetsChinaHKAmt AS T1RealAssetsChinaHKAmt
# MAGIC ,T1RealAssetsIndiaAmt AS T1RealAssetsIndiaAmt
# MAGIC ,T1RealAssetsAsiaExAmt AS T1RealAssetsAsiaExAmt
# MAGIC ,T1RealAssetsEuropeDevelopedAmt AS T1RealAssetsEuropeDevelopedAmt
# MAGIC ,T1RealAssetsEuropeEMAmt AS T1RealAssetsEuropeEMAmt
# MAGIC ,T1RealAssetsJapanAmt AS T1RealAssetsJapanAmt
# MAGIC ,T1AmericasDevelopedAmt AS T1AmericasDevelopedAmt
# MAGIC ,T1AmericasEMAmt AS T1AmericasEMAmt
# MAGIC ,T1BrazilAmt AS T1BrazilAmt
# MAGIC ,T1ChinaHKAmt AS T1ChinaHKAmt
# MAGIC ,T1IndiaAmt AS T1IndiaAmt
# MAGIC ,T1AsiaExAmt AS T1AsiaExAmt
# MAGIC ,T1EuropeDevelopedAmt AS T1EuropeDevelopedAmt
# MAGIC ,T1EuropeEMAmt AS T1EuropeEMAmt
# MAGIC ,T1JapanAmt AS T1JapanAmt
# MAGIC ,UpdateTimestamp AS UpdateTimestamp
# MAGIC ,UpdateHMCUserId AS UpdateHMCUserId
# MAGIC ,CASE WHEN AsofDt = (SELECT dt FROM max_asof)          
# MAGIC THEN CAST(1 AS BOOLEAN)          
# MAGIC ELSE CAST(0 AS BOOLEAN)      
# MAGIC END AS IsLatestApproved 
# MAGIC ,CAST(current_timestamp() AS TIMESTAMP) AS ETLLoadDateTime
# MAGIC FROM lh_bronze.Bronze.HMCDataMartInvestmentFundBetaSummaryLog

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC -- Create (or replace) the HMCCalendar table in Gold
# MAGIC CREATE OR REPLACE TABLE lh_curated.Gold.HMCCalendar
# MAGIC USING DELTA
# MAGIC AS
# MAGIC WITH bounds AS (
# MAGIC     -- 1: Start at 6/30/1985
# MAGIC     SELECT
# MAGIC         to_date('1985-06-30') AS StartDate,
# MAGIC         -- 2: End on 12/31/(current year + 20)
# MAGIC         to_date(
# MAGIC             concat(
# MAGIC                 year(current_date()) + 20,
# MAGIC                 '-12-31'
# MAGIC             )
# MAGIC         ) AS EndDate
# MAGIC ),
# MAGIC dates AS (
# MAGIC     -- Generate one row per calendar date
# MAGIC     SELECT explode(sequence(StartDate, EndDate, interval 1 day)) AS Date
# MAGIC     FROM bounds
# MAGIC )
# MAGIC SELECT
# MAGIC     Date                                                     AS Date,
# MAGIC     -- 5: FiscalYear (FY starts July 1, ends June 30 of the named year)
# MAGIC     year(add_months(Date, 6))                                AS FiscalYear,
# MAGIC     -- 6: CalendarYear
# MAGIC     year(Date)                                               AS CalendarYear,
# MAGIC     -- 3: MonthEnd = last day of the month of Date
# MAGIC     last_day(Date)                                           AS MonthEnd,
# MAGIC     -- 4: QuarterEnd = last day of the quarter of Date
# MAGIC     last_day(add_months(trunc(Date, 'QUARTER'), 2))          AS QuarterEnd
# MAGIC FROM dates
# MAGIC ORDER BY Date;


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC WITH bounds AS (
# MAGIC     -- 1: Start at 6/30/1985
# MAGIC     SELECT
# MAGIC         to_date('1985-06-30') AS StartDate,
# MAGIC         -- 2: End on 12/31/(current year + 20)
# MAGIC         to_date(
# MAGIC             concat(
# MAGIC                 year(current_date()) + 20,
# MAGIC                 '-12-31'
# MAGIC             )
# MAGIC         ) AS EndDate
# MAGIC ),
# MAGIC dates AS (
# MAGIC     -- Generate one row per calendar date
# MAGIC     SELECT explode(sequence(StartDate, EndDate, interval 1 day)) AS Date
# MAGIC     FROM bounds
# MAGIC )
# MAGIC SELECT
# MAGIC     Date                                                     AS Date,
# MAGIC     -- 5: FiscalYear (FY starts July 1, ends June 30 of the named year)
# MAGIC     year(add_months(Date, 6))                                AS FiscalYear,
# MAGIC     -- 6: CalendarYear
# MAGIC     year(Date)                                               AS CalendarYear,
# MAGIC     -- 3: MonthEnd = last day of the month of Date
# MAGIC     last_day(Date)                                           AS MonthEnd,
# MAGIC     -- 4: QuarterEnd = last day of the quarter of Date
# MAGIC     last_day(add_months(trunc(Date, 'QUARTER'), 2))          AS QuarterEnd
# MAGIC FROM dates
# MAGIC ORDER BY Date;

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC DESCRIBE TABLE Bronze.HMCDataMartInvestmentFundBetaSummaryLog;

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
# WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
# BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
# CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
# TaskList = "[{\"JobAuditKey\":537,\"TaskKey\":116,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"SolovisEntities\",\"SinkTableName\":\"FundLiquidityTerms\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"14\",\"NotebookName\":\"FundLiquidityTermsSilver\",\"SinkLakehouseName\":\"lh_curated\"}]"
# NotebookName = "FundLiquidityTermsSilver"
# LakehouseName = "lh_curated"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Fabric Lakehouse diagnostics: detect default LH, list schemas & tablesfrom notebookutils import mssparkutils

def println(msg=""): 
    print(msg, flush=True)

has_default = False
try:
    has_default = mssparkutils.fs.exists("Tables/")
except Exception as e:
    println(f"FS check error: {e}")

if not has_default:
    println("No default Lakehouse detected for this Spark session (relative path 'Tables/' not found).")
    println("Tip: ensure you attached a Lakehouse via UI or `%%configure` before running.")
else:
    println("Default Lakehouse is attached (relative path 'Tables/' is available).")


    try:
        schemas = [e.name.strip("/").strip() for e in mssparkutils.fs.ls("Tables/") if e.isDir]
        println(f"Schemas found under Tables/: {schemas if schemas else '(none)'}")
    except Exception as e:
        println(f"Couldn't list schemas from Filesystem: {e}")
        schemas = []


    try:
        current_db = spark.sql("SELECT current_database()").collect()[0][0]
        println(f"Current Spark database: {current_db}")
    except Exception as e:
        println(f"Couldn't get current Spark database: {e}")

    try:
        println("SHOW SCHEMAS (Spark):")
        spark.sql("SHOW SCHEMAS").show(200, truncate=False)
    except Exception as e:
        println(f"SHOW SCHEMAS failed: {e}")


    try:
        candidates = list(dict.fromkeys((schemas or []) + ["Bronze","Silver","Gold","dbo"]))
        for sch in candidates:
            try:
                println(f"\nSHOW TABLES IN `{sch}`:")
                spark.sql(f"SHOW TABLES IN `{sch}`").show(200, truncate=False)
            except Exception as inner:
                println(f"(skip `{sch}`) {inner}")
    except Exception as e:
        println(f"Table listing failed: {e}")


    try:
        rows = spark.sql(f"DESCRIBE DATABASE EXTENDED `{current_db}`").collect()
        loc = next((r.data_type for r in rows if r.col_name.lower() == "location"), None)
        println(f"\nOneLake location for `{current_db}`: {loc}")
    except Exception as e:
        println(f"Couldn't DESCRIBE DATABASE EXTENDED: {e}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
