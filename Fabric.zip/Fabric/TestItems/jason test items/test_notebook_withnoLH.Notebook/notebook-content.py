# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

# MAGIC %%configure
# MAGIC {
# MAGIC   "defaultLakehouse": {
# MAGIC     "name": { "parameterName": "LakehouseName", "defaultValue": "lh_bronze" },
# MAGIC     "id":   { "parameterName": "LHId",   "defaultValue": "13ef97da-5da2-466d-8c5f-2a70572c6558" },
# MAGIC     "workspaceId": { "parameterName": "WorkspaceId", "defaultValue": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced" }
# MAGIC   }
# MAGIC }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
LHId = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(WorkspaceId)
print(LHId)
print(LakehouseName)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Fabric Lakehouse diagnostics: detect default LH, list schemas & tablesfrom notebookutils import mssparkutils

def println(msg=""): 
    print(msg, flush=True)

has_default = False
try:
    has_default = mssparkutils.fs.exists("Tables/")
except Exception as e:
    println(f"FS check error: {e}")

if not has_default:
    println("No default Lakehouse detected for this Spark session (relative path 'Tables/' not found).")
    println("Tip: ensure you attached a Lakehouse via UI or `%%configure` before running.")
else:
    println("Default Lakehouse is attached (relative path 'Tables/' is available).")


    try:
        schemas = [e.name.strip("/").strip() for e in mssparkutils.fs.ls("Tables/") if e.isDir]
        println(f"Schemas found under Tables/: {schemas if schemas else '(none)'}")
    except Exception as e:
        println(f"Couldn't list schemas from Filesystem: {e}")
        schemas = []


    try:
        current_db = spark.sql("SELECT current_database()").collect()[0][0]
        println(f"Current Spark database: {current_db}")
    except Exception as e:
        println(f"Couldn't get current Spark database: {e}")

    try:
        println("SHOW SCHEMAS (Spark):")
        spark.sql("SHOW SCHEMAS").show(200, truncate=False)
    except Exception as e:
        println(f"SHOW SCHEMAS failed: {e}")


    try:
        candidates = list(dict.fromkeys((schemas or []) + ["Bronze","Silver","Gold"]))
        for sch in candidates:
            try:
                println(f"\nSHOW TABLES IN `{sch}`:")
                spark.sql(f"SHOW TABLES IN `{sch}`").show(200, truncate=False)
            except Exception as inner:
                println(f"(skip `{sch}`) {inner}")
    except Exception as e:
        println(f"Table listing failed: {e}")


    try:
        rows = spark.sql(f"DESCRIBE DATABASE EXTENDED `{current_db}`").collect()
        loc = next((r.data_type for r in rows if r.col_name.lower() == "location"), None)
        println(f"\nOneLake location for `{current_db}`: {loc}")
    except Exception as e:
        println(f"Couldn't DESCRIBE DATABASE EXTENDED: {e}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.sql("SELECT * FROM lh_curated.Silver.FirmReturn LIMIT 1000")
display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC SELECT * FROM lh_curated.Silver.FirmReturn LIMIT 1000

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
