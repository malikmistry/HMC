# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql.functions import col, lit, coalesce
# dfblah = spark.sql("""
#     SELECT ResourceId
#            , ValueTypeId
#            , CurrencyId
#            , last_day(MvDate)
#            , TotalValue
#            , IsNew
#     FROM CurrentMarketValues
# """)

# dfblah = 

display(dfCurrentHoldings.filter((col("FundId") == "3851b853-442a-488c-a29a-dd5f60814408") & (col("ShareClassId") == "48b4b5b1-5d22-ea11-8133-0050569a56ba")))
#display(dfblah)
#display(dfSolovisMV)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col, lit, coalesce

dfSolovisMVHistory = spark.sql("""
SELECT smvh.ResourceId
		, smvh.ValueTypeId
		, smvh.CurrencyId
		, smvh.MvDate
		, smvh.TotalValue
        , 0 as IsNew
FROM Bronze.SolovisMarketValueHistory smvh
	    -- Get the priority market value type to ensure the proper actual or estimate vaue is chosen
		JOIN (SELECT smvh.ResourceId
			   , smvh.MvDate
			   , smvh.CurrencyId
			   , ABS(MAX(CASE WHEN smvh.ValueTypeId not in (127, 64, 16) THEN smvh.ValueTypeId * -1
						      ELSE smvh.ValueTypeId END)) AS ValueTypeId
		-- Get the max MvDate for each resource id and vaule type id
		FROM (SELECT smvh.ResourceId
					 , smvh.CurrencyId
					 , MONTH(smvh.MvDate)
					 , YEAR(smvh.MvDate)
			   		 , MAX(smvh.MvDate) as MvDate					 
			  FROM Bronze.SolovisMarketValueHistory smvh
			  GROUP BY smvh.ResourceId
					   , smvh.CurrencyId
					   , MONTH(smvh.MvDate)
					   , YEAR(smvh.MvDate)) rsmvh
			  JOIN Bronze.SolovisMarketValueHistory smvh ON rsmvh.ResourceId = smvh.ResourceId
			  													AND rsmvh.CurrencyId = smvh.CurrencyId
																AND rsmvh.MvDate = smvh.MvDate
		GROUP BY smvh.ResourceId
				 , smvh.MvDate
				 , smvh.CurrencyId) csmvh ON csmvh.ResourceId = smvh.ResourceId
													AND csmvh.ValueTypeId = smvh.ValueTypeId
													AND csmvh.CurrencyId = smvh.CurrencyId
													AND csmvh.MvDate = smvh.MvDate
""")

display(dfSolovisMVHistory.count())

dfSolovisMV = spark.sql("""
SELECT smv.ResourceId
		, smv.ValueTypeId
		, smv.CurrencyId
		, to_date(smv.MvDate, "MM/dd/yyyy") AS MvDate
		, smv.TotalValue
        , 1 as IsNew
FROM Bronze.SolovisMarketValues smv
	    -- Get the priority market value type to ensure the proper actual or estimate vaue is chosen
		JOIN (SELECT smv.ResourceId
			   , smv.MvDate
			   , smv.CurrencyId
			   , ABS(MAX(CASE WHEN smv.ValueTypeId not in (127, 64, 16) THEN smv.ValueTypeId * -1
						      ELSE smv.ValueTypeId END)) AS ValueTypeId
		-- Get the max MvDate for each resource id and vaule type id
		FROM (SELECT smv.ResourceId
					 , smv.CurrencyId
					 , MONTH(smv.MvDate)
					 , YEAR(smv.MvDate)
			   		 , MAX(smv.MvDate) as MvDate					 
			  FROM Bronze.SolovisMarketValues smv
			  GROUP BY smv.ResourceId
					   , smv.CurrencyId
					   , MONTH(smv.MvDate)
					   , YEAR(smv.MvDate)) rsmv
			  JOIN Bronze.SolovisMarketValues smv ON rsmv.ResourceId = smv.ResourceId
			  													AND rsmv.CurrencyId = smv.CurrencyId
																AND rsmv.MvDate = smv.MvDate
		GROUP BY smv.ResourceId
				 , smv.MvDate
				 , smv.CurrencyId) csmv ON csmv.ResourceId = smv.ResourceId
													AND csmv.ValueTypeId = smv.ValueTypeId
													AND csmv.CurrencyId = smv.CurrencyId
													AND csmv.MvDate = smv.MvDate
""")

display(dfSolovisMV.count())

dfMarketValues = dfSolovisMVHistory.union(dfSolovisMV)
dfMarketValues.createOrReplaceTempView("SolovisMV")

dfCurrentMV = spark.sql("""
SELECT smv.ResourceId
		, smv.ValueTypeId
		, smv.CurrencyId
		, smv.MvDate
		, smv.TotalValue
        , 1 as IsNew
FROM SolovisMV smv
	    -- Get the priority market value type to ensure the proper actual or estimate vaue is chosen
		JOIN (SELECT smv.ResourceId
			   , smv.MvDate
			   , smv.CurrencyId
			   , ABS(MAX(CASE WHEN smv.ValueTypeId not in (127, 64, 16) THEN smv.ValueTypeId * -1
						      ELSE smv.ValueTypeId END)) AS ValueTypeId
		-- Get the max MvDate for each resource id and vaule type id
		FROM (SELECT smv.ResourceId
					 , smv.CurrencyId
					 , MONTH(smv.MvDate)
					 , YEAR(smv.MvDate)
			   		 , MAX(smv.MvDate) as MvDate					 
			  FROM SolovisMV smv
			  GROUP BY smv.ResourceId
					   , smv.CurrencyId
					   , MONTH(smv.MvDate)
					   , YEAR(smv.MvDate)) rsmv
			  JOIN SolovisMV smv ON rsmv.ResourceId = smv.ResourceId
			  													AND rsmv.CurrencyId = smv.CurrencyId
																AND rsmv.MvDate = smv.MvDate
		GROUP BY smv.ResourceId
				 , smv.MvDate
				 , smv.CurrencyId) csmv ON csmv.ResourceId = smv.ResourceId
													AND csmv.ValueTypeId = smv.ValueTypeId
													AND csmv.CurrencyId = smv.CurrencyId
													AND csmv.MvDate = smv.MvDate
""")

display(dfCurrentMV.count())

# dfSolovisMV = spark.sql("""
# SELECT smv.ResourceId
# 		, smv.ValueTypeId
# 		, smv.CurrencyId
# 		, to_date(smv.MvDate, "MM/dd/yyyy") AS MvDate
# 		, smv.TotalValue
#         , 1 as IsNew
# FROM Bronze.SolovisMarketValues smv
# 	    -- Get the priority market value type to ensure the proper actual or estimate vaue is chosen
# 		JOIN (SELECT smv.ResourceId
# 			   , smv.ValueTypeId
# 			   , smv.CurrencyId
# 			   , MAX(smv.MvDate) as MvDate
# 		-- Get the max MvDate for each resource id and vaule type id
# 		FROM (SELECT smv.ResourceId
# 					 , to_date(smv.MvDate, "MM/dd/yyyy") AS MvDate
# 					 , smv.CurrencyId
# 					 , ABS(MAX(CASE WHEN smv.ValueTypeId not in (127, 64, 16) THEN smv.ValueTypeId * -1
# 									ELSE smv.ValueTypeId END)) AS ValueTypeId
# 			  FROM Bronze.SolovisMarketValues smv
# 			  WHERE to_date(smv.MvDate, 'MM/dd/yyyy') <= current_date()
              
# 			  GROUP BY smv.ResourceId
# 					   , to_date(smv.MvDate, "MM/dd/yyyy")
# 					   , smv.CurrencyId) smv
# 		GROUP BY smv.ResourceId
# 				 , smv.ValueTypeId
# 				 , smv.CurrencyId) csmv ON csmv.ResourceId = smv.ResourceId
# 													AND csmv.ValueTypeId = smv.ValueTypeId
# 													AND csmv.CurrencyId = smv.CurrencyId
# 													AND csmv.MvDate = to_date(smv.MvDate, "MM/dd/yyyy")
# """)

# display(dfSolovisMV.count())

# dfMarketValues = dfSolovisMVHistory.union(dfSolovisMV)

# display(dfMarketValues.count())

# dfMarketValues.createOrReplaceTempView("SolovisMV")


# dfCurrentMV = spark.sql("""SELECT smv.ResourceId
# 		, smv.ValueTypeId
# 		, smv.CurrencyId
# 		, smv.MvDate
# 		, smv.TotalValue
#         , smv.IsNew
# FROM SolovisMV smv
# 	    -- Get the max MvDate for each resource id and vaule type id
# 		JOIN (SELECT smv.ResourceId
# 			   , smv.ValueTypeId
# 			   , smv.CurrencyId
# 			   , MAX(smv.MvDate) as MvDate
# 		-- Get the priority market value type to ensure the proper actual or estimate vaue is chosen
# 		FROM (SELECT smv.ResourceId
# 					 , smv.MvDate
# 					 , smv.CurrencyId
# 					 , ABS(MAX(CASE WHEN smv.ValueTypeId not in (127, 64, 16) THEN smv.ValueTypeId * -1
# 									ELSE smv.ValueTypeId END)) AS ValueTypeId
# 			  FROM SolovisMV smv
# 			  GROUP BY smv.ResourceId
# 					   , smv.MvDate
# 					   , smv.CurrencyId) smv
# 		GROUP BY smv.ResourceId
# 				 , smv.ValueTypeId
# 				 , smv.CurrencyId) csmv ON csmv.ResourceId = smv.ResourceId
# 													AND csmv.ValueTypeId = smv.ValueTypeId
# 													AND csmv.CurrencyId = smv.CurrencyId
# 													AND csmv.MvDate = smv.MvDate""")

# display(dfCurrentMV.count())

# dfCurrentMV.createOrReplaceTempView("CurrentMarketValues")

# dfCurrentHoldings = spark.sql("""
#     SELECT abfm.FundId
#            , abfm.ShareClassId
#            , last_day(cmv.MvDate) AS NAVDate
# --           , cmv.MvDate
# 		   , CASE WHEN si.OwnerId = 1 THEN 0
# 				  WHEN si.OwnerId = 2 THEN 2
# 				  ELSE 4 END AS PortfolioTypeId           
#            , c.CurrencyId
#            , SUM(cmv.TotalValue) as EndBalance
#     FROM CurrentMarketValues cmv
#             JOIN lh_bronze.Bronze.SolovisActiveBookFundMapping abfm ON cmv.ResourceId = abfm.InvestmentResourceId
# 			JOIN lh_bronze.Bronze.HMCDataWarehouseSolovisCurrency scur ON scur.Id = cmv.CurrencyId
# 			JOIN lh_bronze.Bronze.CrimsonXCurrency c ON c.ISOCode = scur.Code
# 			JOIN lh_bronze.Bronze.SolovisInvestments si ON si.ResourceId = cmv.ResourceId            
#             JOIN (
#                 SELECT DISTINCT abfm.FundId
#                          		, abfm.ShareClassId
# 								, cmv.CurrencyId
# 								, cmv.MvDate
#                   FROM CurrentMarketValues cmv
#                         JOIN lh_bronze.Bronze.SolovisActiveBookFundMapping abfm ON cmv.ResourceId = abfm.InvestmentResourceId
#                   WHERE cmv.IsNew = 1
#                   ) actives ON abfm.FundId = actives.FundId
#                                 AND abfm.ShareClassId = actives.ShareClassId
# 								AND cmv.CurrencyId = actives.CurrencyId
# 								AND last_day(cmv.MvDate) = last_day(actives.MvDate)
#     GROUP BY abfm.FundId
#            , abfm.ShareClassId
#            , last_day(cmv.MvDate)
# --            , cmv.MvDate
# 		   , CASE WHEN si.OwnerId = 1 THEN 0
# 				  WHEN si.OwnerId = 2 THEN 2
# 				  ELSE 4 END
#            , c.CurrencyId
# """)
# display(dfCurrentHoldings.count())

# dfCurrentHoldings.createOrReplaceTempView("CurrentHoldings")

# dfFinal = spark.sql("""
# 	WITH HoldingsHistory AS (
# 		SELECT FundId,
# 			ShareClassId,
# 			to_date(NAVDate, 'MM/dd/yyyy') AS NAVDate,
# 			PortfolioTypeId,
# 			CurrencyId,
# 			EndBalance,
# 			LAG(CAST(EndBalance AS DECIMAL(35,2))) OVER (
# 				PARTITION BY FundId, ShareClassId, PortfolioTypeId, CurrencyId
# 				ORDER BY to_date(NAVDate, 'MM/dd/yyyy')
# 			) AS PreviousEndBalance,
# 			LAG(to_date(NAVDate, 'MM/dd/yyyy')) OVER (
# 				PARTITION BY FundId, ShareClassId, PortfolioTypeId, CurrencyId
# 				ORDER BY to_date(NAVDate, 'MM/dd/yyyy')
# 			) AS PreviousNAVDate
# 		FROM lh_bronze.Bronze.CrimsonXHoldingsHistory
# 		WHERE EndDate = '9999-12-31'
# 	)
#     SELECT *
#     FROM CurrentHoldings ch
#         LEFT JOIN HoldingsHistory hh ON hh.FundId = ch.FundId
#                                     AND hh.ShareClassId = ch.ShareClassId
#                                     AND hh.NAVDate = ch.NAVDate
#                                     AND hh.PortfolioTypeId = ch.PortfolioTypeId
#                                     AND hh.CurrencyId = ch.CurrencyId
# 	ORDER BY ch.FundId, ch.ShareClassId, ch.CurrencyId, ch.NAVDate
    
    
# """)

# display(dfFinal.count())

# display(dfFinal)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Write data out to lh_curated.Review.CashflowTransactionDetail
from delta.tables import DeltaTable
from pyspark.sql import Window
from pyspark.sql.types import DecimalType, IntegerType, DateType, BooleanType, LongType, TimestampType, ShortType, StringType
from pyspark.sql import functions as F

max_id = 0
window_spec = Window.orderBy(F.lit(1))

spark.sql("REFRESH TABLE lh_bronze.Bronze.CrimsonXCurrencyRate")

dfCurrencyRate = spark.table("lh_bronze.Bronze.CrimsonXCurrencyRate")

dfCurrencyRate = dfCurrencyRate \
    .select("CurrencyId","CurrencyRateDate","CurrencyRate") \
    .withColumnRenamed("CurrencyRate", "FXRate") \
    .withColumnRenamed("CurrencyRateDate", "FXDate") \
    .withColumn("FXRateId",(F.row_number().over(window_spec) + max_id).cast(IntegerType()))


dfCurrencyRate = dfCurrencyRate \
    .withColumn("FXRate", F.col("FXRate").cast(DecimalType(38, 15))) \
    .withColumn("FXDate", F.col("FXDate").cast(DateType())) \
    .withColumn("CurrencyId", F.col("CurrencyId").cast(LongType())) 

    # .withColumnRenamed("CurrencyRateDate", "FXDate") \
    # .withColumnRenamed("CurrencyRate", "FXRate")
    # .withColumn(
    #     "FXRateId",(F.row_number().over(window_spec) + max_id).cast(IntegerType()))
display(dfCurrencyRate.filter(F.col("FXDate") == "2025-07-01"))

dtFXRate = DeltaTable.forPath(spark, "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465/Tables/Silver/FXRate")
dtFXRate.alias("target").merge(
    dfCurrencyRate.alias("source"),
    """target.CurrencyId = source.CurrencyId
            AND target.FXDate = source.FXDate""") \
    .whenMatchedUpdateAll() \
    .whenNotMatchedInsertAll() \
    .execute()

dfFXRate = spark.table("lh_curated.Silver.FXRate")

display(dfFXRate.filter(F.col("FXDate") == "2025-07-01").orderBy("FXDate"))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dfFXRate = spark.sql("""
     MERGE INTO lh_curated.Silver.CashflowTransactionDetail AS cft
USING lh_curated.Silver.FXRate AS fx
	ON cft.CurrencyId = fx.CurrencyId
			AND cft.ExposureDate = fx.FXDate
WHEN MATCHED THEN UPDATE SET
					TransactionAmountInUSD = cft.TransactionAmountInLocal * fx.FXRate
					, TransactionAmountOutUSD = cft.TransactionAmountOutLocal * fx.FXRate
					, ReturnedAmountUSD = cft.ReturnedAmountLocal * fx.FXRate
					, UnfundedAdjustmentUSD = cft.UnfundedAdjustmentLocal * fx.FXRate
					, RecallableAmountUSD = cft.RecallableAmountLocal * fx.FXRate;
 """)


# dfCashflows = dfCashflows.join(dfFXRate, (dfCashflows["CurrencyId"] == dfFXRate["FXCurrencyId"]) & (dfCashflows["ExposureDate"] == dfFXRate["FXDate"]), "inner")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
MERGE INTO lh_curated.Review.CashflowTransactionDetail as target
USING (SELECT CashflowTransactionDetailId
		   , (MarketValueEffectLocal * FXRate) as MarketValueEffectUSD
	   FROM lh_curated.Review.CashflowTransactionDetail
	   WHERE COALESCE(MarketValueEffectLocal, 0) <>= 0
			   AND COALESCE(MarketValueEffectUSD, 0) = 0
			   AND COALESCE(FXRate, 0) != 0) as source
ON (target.CashflowTransactionDetailId = source.CashflowTransactionDetailId)
WHEN MATCHED THEN
	UPDATE SET
	target.MarketValueEffectUSD = source.MarketValueEffectUSD
""")



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
INSERT INTO lh_curated.Review.CashflowTransactionDetail
SELECT cctd.*
FROM lh_bronze.Bronze.CrimsonXCashflowTransactionDetail cctd
		LEFT JOIN lh_curated.Review.CashflowTransactionDetail rctd ON cctd.TransactionIdSource = rctd.TransactionIdSource
																		AND cctd.TransactionTypeIdSource = rctd.TransactionTypeIdSource
WHERE cctd.TransactionAmountInLocal = 0
		AND cctd.TransactionAmountOutLocal = 0
		AND cctd.RecallableAmountLocal = 0
		AND cctd.UnfundedAdjustmentLocal != 0
		AND rctd.FundId IS NULL
		AND cctd.TransactionIdSource IS NOT NULL
		AND cctd.TransactionIdSource != -999
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""MERGE INTO lh_curated.Review.CashflowTransactionDetail as target
USING (SELECT *
FROM (
SELECT LAG(rctd.CashflowTransactionDetailId) OVER (PARTITION BY rctd.TransactionIdSource ORDER BY rctd.UpdateTimeStamp) as CashflowTransactionDetailId
       , LAG(rctd.CashflowTransactionDetailId) OVER (PARTITION BY rctd.TransactionIdSource ORDER BY rctd.UpdateTimeStamp) as CashflowTransactionId
	   , rctd.FundId
	   , rctd.ShareClassId
	   , rctd.PortfolioTypeId
	   , rctd.CashflowTransactionTypeId
	   , rctd.CashflowTransactionSubtypeId
	   , LAG(rctd.StartDate) OVER (PARTITION BY rctd.TransactionIdSource ORDER BY rctd.UpdateTimeStamp) as StartDate
       , LAG(rctd.EndDate) OVER (PARTITION BY rctd.TransactionIdSource ORDER BY rctd.UpdateTimeStamp) as EndDate
	   , rctd.TransactionAmountInLocal
	   , rctd.TransactionAmountInUSD
	   , rctd.TransactionAmountOutLocal
	   , rctd.TransactionAmountOutUSD
	   , rctd.CommitmentEffectLocal
	   , rctd.MarketValueEffectLocal
	   , rctd.BookStartOfDay
	   , rctd.ExposureDate
	   , rctd.TradeDate
	   , rctd.SettleDate
	   , rctd.CurrencyId
	   , rctd.FXRate
	   , rctd.ReturnedAmountLocal
	   , rctd.ReturnedAmountUSD
	   , rctd.UnfundedAdjustmentLocal
	   , rctd.UnfundedAdjustmentUSD
	   , rctd.FundedAmountLocal
	   , rctd.FundedAmountUSD
	   , rctd.RecallableAmountLocal
	   , rctd.RecallableAmountUSD
	   , rctd.FundedXCommitAmtLocal
	   , rctd.FundedXCommitAmtUSD
	   , rctd.ReturnedXCommitAmtLocal
	   , rctd.ReturnedXCommitAmtUSD
	   , rctd.UpdateTimeStamp
	   , rctd.TransactionTypeIdSource
	   , rctd.TransactionIdSource
	   , rctd.CommitmentEffectUSD
	   , rctd.MarketValueEffectUSD
	   , rctd.TransactionTag
FROM lh_curated.Review.CashflowTransactionDetail as rctd
		JOIN(
			SELECT TransactionIdSource, ExposureDate
			FROM lh_curated.Review.CashflowTransactionDetail
			WHERE to_date(ExposureDate, "MM/dd/yyyy") > to_date('06/30/2020', "MM/dd/yyyy")
					AND TransactionIdSource IS NOT NULL		
			GROUP BY TransactionIdSource
					 , ExposureDate
			HAVING COUNT(*) > 1) pop ON rctd.TransactionIdSource = pop.TransactionIdSource
														AND rctd.ExposureDate = pop.ExposureDate
		LEFT JOIN
			(SELECT rctd.TransactionIdSource, rctd.ExposureDate, MIN(rctd.UpdateTimeStamp) as UpdateTimeStamp
			FROM lh_curated.Review.CashflowTransactionDetail as rctd
					JOIN (
			SELECT TransactionIdSource
			FROM lh_curated.Review.CashflowTransactionDetail
			WHERE to_date(ExposureDate, "MM/dd/yyyy") > to_date('06/30/2020', "MM/dd/yyyy")
					AND TransactionIdSource IS NOT NULL		
			GROUP BY TransactionIdSource
			HAVING COUNT(*) > 1) dups ON rctd.TransactionIdSource = dups.TransactionIdSource
			WHERE to_date(ExposureDate, "MM/dd/yyyy") > to_date('06/30/2020', "MM/dd/yyyy")
			GROUP BY rctd.TransactionIdSource
					 , rctd.ExposureDate) as dups ON rctd.TransactionIdSource = dups.TransactionIdSource
														AND rctd.ExposureDate = dups.ExposureDate
														AND rctd.UpdateTimeStamp = dups.UpdateTimeStamp
			LEFT JOIN (
				SELECT rctd.TransactionIdSource, rctd.ExposureDate, MAX(rctd.UpdateTimeStamp) as UpdateTimeStamp
				FROM lh_curated.Review.CashflowTransactionDetail as rctd
						JOIN (
				SELECT TransactionIdSource
				FROM lh_curated.Review.CashflowTransactionDetail
				WHERE to_date(ExposureDate, "MM/dd/yyyy") > to_date('06/30/2020', "MM/dd/yyyy")
						AND TransactionIdSource IS NOT NULL		
				GROUP BY TransactionIdSource
				HAVING COUNT(*) > 1) as dups ON rctd.TransactionIdSource = dups.TransactionIdSource
				WHERE to_date(ExposureDate, "MM/dd/yyyy") > to_date('06/30/2020', "MM/dd/yyyy")
				GROUP BY rctd.TransactionIdSource
						 , rctd.ExposureDate
			) recent ON recent.TransactionIdSource = rctd.TransactionIdSource
							AND recent.ExposureDate = rctd.ExposureDate
							AND recent.UpdateTimeStamp = rctd.UpdateTimeStamp) rctd
WHERE rctd.CashflowTransactionDetailId IS NOT NULL) as source
ON (target.CashflowTransactionDetailId = source.CashflowTransactionDetailId)
WHEN MATCHED THEN 
	UPDATE SET target.CashflowTransactionTypeId = source.CashflowTransactionTypeId
			 , target.CashflowTransactionSubtypeId = source.CashflowTransactionSubtypeId
			 , target.TransactionAmountInLocal = source.TransactionAmountInLocal
		     , target.TransactionAmountInUSD = source.TransactionAmountInUSD
			 , target.TransactionAmountOutLocal = source.TransactionAmountOutLocal
			 , target.TransactionAmountOutUSD =	source.TransactionAmountOutUSD
			 , target.MarketValueEffectLocal = source.MarketValueEffectLocal
			 , target.BookStartOfDay = source.BookStartOfDay
  		     , target.TradeDate = source.TradeDate
			 , target.SettleDate = source.SettleDate
			 , target.CurrencyId = source.CurrencyId
 		     , target.ReturnedAmountLocal = source.ReturnedAmountLocal
			 , target.ReturnedAmountUSD = source.ReturnedAmountUSD
			 , target.UnfundedAdjustmentLocal = source.UnfundedAdjustmentLocal
			 , target.UnfundedAdjustmentUSD = source.UnfundedAdjustmentUSD 
			 , target.FundedAmountLocal = source.FundedAmountLocal
			 , target.FundedAmountUSD = source.FundedAmountUSD 
			 , target.RecallableAmountLocal = source.RecallableAmountLocal 
			 , target.RecallableAmountUSD = source.RecallableAmountUSD 
			 , target.FundedXCommitAmtLocal = source.FundedXCommitAmtLocal 
			 , target.FundedXCommitAmtUSD = source.FundedXCommitAmtUSD 
			 , target.ReturnedXCommitAmtLocal = source.ReturnedXCommitAmtLocal 
			 , target.ReturnedXCommitAmtUSD = source.ReturnedXCommitAmtUSD 
			 , target.UpdateTimeStamp = source.UpdateTimeStamp 
			 , target.TransactionTypeIdSource = source.TransactionTypeIdSource 
			 , target.CommitmentEffectUSD = source.CommitmentEffectUSD 
			 , target.MarketValueEffectUSD = source.MarketValueEffectUSD""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Backup CashflowTransactionDetail and then write review data to silver
dfReviewCashflowDetail = spark.table("lh_curated.Review.CashflowTransactionDetail")
dCashflowDetailBackup = spark.table("lh_curated.Silver.CashflowTransactionDetail")

# Save this off to the side in case something goes wrong
dCashflowDetailBackup.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("lh_bronze.Bronze.CrimsonXCashflowTransactionDetailBackUp")

dfReviewCashflowDetail.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("lh_curated.Silver.CashflowTransactionDetail")

spark.sql("REFRESH TABLE lh_curated.Silver.CashflowTransactionDetail")
spark.sql("SELECT COUNT(*) FROM lh_curated.Silver.CashflowTransactionDetail").show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dfFXRate = spark.sql("""
     MERGE INTO lh_bronze.Bronze.CrimsonXCashflowTransactionDetail AS cft
USING (SELECT DISTINCT FXDate, CurrencyId, FXRate FROM lh_curated.Silver.FXRate) AS fx
	ON cft.CurrencyId = fx.CurrencyId
			AND cft.ExposureDate = fx.FXDate
WHEN MATCHED THEN UPDATE SET
					TransactionAmountInUSD = cft.TransactionAmountInLocal * fx.FXRate
					, TransactionAmountOutUSD = cft.TransactionAmountOutLocal * fx.FXRate
					, ReturnedAmountUSD = cft.ReturnedAmountLocal * fx.FXRate
					, UnfundedAdjustmentUSD = cft.UnfundedAdjustmentLocal * fx.FXRate
					, RecallableAmountUSD = cft.RecallableAmountLocal * fx.FXRate
                    , MarketValueEffectUSD = cft.MarketValueEffectLocal * fx.FXRate;
 """)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dfFXRate = spark.sql("""
     MERGE INTO lh_curated.Review.CashflowTransactionDetail AS cft
USING (SELECT DISTINCT FXDate, CurrencyId, FXRate FROM lh_curated.Silver.FXRate) AS fx
	ON cft.CurrencyId = fx.CurrencyId
			AND cft.ExposureDate = fx.FXDate
WHEN MATCHED THEN UPDATE SET
					TransactionAmountInUSD = cft.TransactionAmountInLocal * fx.FXRate
					, TransactionAmountOutUSD = cft.TransactionAmountOutLocal * fx.FXRate
					, ReturnedAmountUSD = cft.ReturnedAmountLocal * fx.FXRate
					, UnfundedAdjustmentUSD = cft.UnfundedAdjustmentLocal * fx.FXRate
					, RecallableAmountUSD = cft.RecallableAmountLocal * fx.FXRate
                    , MarketValueEffectUSD = cft.MarketValueEffectLocal * fx.FXRate;
 """)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
INSERT INTO lh_bronze.Bronze.CrimsonXHoldingsHistory
SELECT abfm.FundId
       , abfm.ShareClassId
	   , to_date('2025/07/31', "yyyy/MM/dd") as NAVDate
	   , to_date('12/31/9999', "yyyy/MM/dd") as LotDate
	   , CASE WHEN si.OwnerId = 1 THEN 0
		      WHEN si.OwnerId = 2 THEN 2
			  ELSE 4 END AS PortfolioTypeId   
	   , to_date('2025/07/01', "yyyy/MM/dd") as StartDate
	   , to_date('9999/12/31', "yyyy/MM/dd") as EndDate
	   , c.CurrencyId	   
	   , SUM(smvh.TotalValue) as OpenBalance
	   , SUM(smvh.TotalValue) as EndBalance
	   , current_timestamp as UpdateTimestamp
	   , 'systemaccount' as UpdateByHMCUserId
	   , SUM(smvh.TotalValue) * fx.FXRate as OpenBalance
	   , SUM(smvh.TotalValue) * fx.FXRate as EndBalance
	   , current_timestamp as ETLLoadDateTime
FROM lh_bronze.Bronze.SolovisMarketValueHistory smvh
		JOIN lh_bronze.Bronze.SolovisActiveBookFundMapping abfm ON abfm.InvestmentResourceId = smvh.ResourceId
	    -- Get the priority market value type to ensure the proper actual or estimate vaue is chosen
		JOIN (SELECT smvh.ResourceId
			   , smvh.MvDate
			   , smvh.CurrencyId
			   , ABS(MAX(CASE WHEN smvh.ValueTypeId not in (127, 64, 16) THEN smvh.ValueTypeId * -1
						      ELSE smvh.ValueTypeId END)) AS ValueTypeId
		-- Get the max MvDate for each resource id and vaule type id
		FROM (SELECT smvh.ResourceId
					 , smvh.CurrencyId
--					 , MONTH(smvh.MvDate)
--					 , YEAR(smvh.MvDate)
			   		 , MAX(smvh.MvDate) as MvDate					 
			  FROM lh_bronze.Bronze.SolovisMarketValueHistory smvh
			  WHERE smvh.MvDate >= to_date('2025/07/01', "yyyy/MM/dd")
						AND smvh.MvDate <= to_date('2025/07/31', "yyyy/MM/dd")
			  GROUP BY smvh.ResourceId
					   , smvh.CurrencyId
					   , MONTH(smvh.MvDate)
					   , YEAR(smvh.MvDate)) rsmvh
			JOIN lh_bronze.Bronze.SolovisMarketValueHistory smvh ON rsmvh.ResourceId = smvh.ResourceId
			  															AND rsmvh.CurrencyId = smvh.CurrencyId
																		AND rsmvh.MvDate = smvh.MvDate         
		GROUP BY smvh.ResourceId
				 , smvh.MvDate
				 , smvh.CurrencyId) csmvh ON csmvh.ResourceId = smvh.ResourceId
													AND csmvh.ValueTypeId = smvh.ValueTypeId
													AND csmvh.CurrencyId = smvh.CurrencyId
													AND csmvh.MvDate = smvh.MvDate
		JOIN lh_bronze.Bronze.HMCDataWarehouseSolovisCurrency scur ON scur.Id = smvh.CurrencyId
		JOIN lh_bronze.Bronze.CrimsonXCurrency c ON c.ISOCode = scur.Code
		JOIN lh_bronze.Bronze.SolovisInvestments si ON si.ResourceId = smvh.ResourceId   
		JOIN lh_curated.Silver.FXRate fx ON fx.FXDate = current_date
												AND fx.CurrencyId = c.CurrencyId
		LEFT JOIN lh_bronze.Bronze.CrimsonXHoldingsHistory chh ON chh.FundId = abfm.FundId
																	AND chh.ShareClassId = abfm.ShareClassId
																	AND chh.PortfolioTypeId = CASE WHEN si.OwnerId = 1 THEN 0
																								   WHEN si.OwnerId = 2 THEN 2
																								   ELSE 4 END
																	AND chh.CurrencyId = c.CurrencyId
																	AND chh.NAVDate = to_date('2025/07/31', "yyyy/MM/dd")
																	AND chh.EndDate = to_date('9999/12/31', "yyyy/MM/dd")
WHERE chh.FundId IS NULL
GROUP BY abfm.FundId
       , abfm.ShareClassId
	   , CASE WHEN si.OwnerId = 1 THEN 0
		      WHEN si.OwnerId = 2 THEN 2
			  ELSE 4 END
	   , c.CurrencyId
	   , last_day(smvh.MvDate)
	   , fx.FXRate""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
INSERT INTO lh_bronze.Bronze.CrimsonXHoldingsHistory
SELECT abfm.FundId
       , abfm.ShareClassId
	   , current_date as NAVDate
	   , to_date('12/31/9999', "yyyy/MM/dd") as LotDate
	   , CASE WHEN si.OwnerId = 1 THEN 0
		      WHEN si.OwnerId = 2 THEN 2
			  ELSE 4 END AS PortfolioTypeId   
	   , to_date('2025/07/01', "yyyy/MM/dd") as StartDate
	   , to_date('9999/12/31', "yyyy/MM/dd") as EndDate
	   , c.CurrencyId	   
	   , SUM(smvh.TotalValue) as OpenBalance
	   , SUM(smvh.TotalValue) as EndBalance
	   , current_timestamp as UpdateTimestamp
	   , 'systemaccount' as UpdateByHMCUserId
	   , SUM(smvh.TotalValue) * fx.FXRate as OpenBalance
	   , SUM(smvh.TotalValue) * fx.FXRate as EndBalance
	   , current_timestamp as ETLLoadDateTime
FROM lh_bronze.Bronze.SolovisMarketValueHistory smvh
		JOIN lh_bronze.Bronze.SolovisActiveBookFundMapping abfm ON abfm.InvestmentResourceId = smvh.ResourceId
	    -- Get the priority market value type to ensure the proper actual or estimate vaue is chosen
		JOIN (SELECT smvh.ResourceId
			   , smvh.MvDate
			   , smvh.CurrencyId
			   , ABS(MAX(CASE WHEN smvh.ValueTypeId not in (127, 64, 16) THEN smvh.ValueTypeId * -1
						      ELSE smvh.ValueTypeId END)) AS ValueTypeId
		-- Get the max MvDate for each resource id and vaule type id
		FROM (SELECT smvh.ResourceId
					 , smvh.CurrencyId
--					 , MONTH(smvh.MvDate)
--					 , YEAR(smvh.MvDate)
			   		 , MAX(smvh.MvDate) as MvDate					 
			  FROM lh_bronze.Bronze.SolovisMarketValueHistory smvh
			  WHERE smvh.MvDate >= to_date('2025/07/01', "yyyy/MM/dd")
						AND smvh.MvDate <= to_date('2025/07/31', "yyyy/MM/dd")
			  GROUP BY smvh.ResourceId
					   , smvh.CurrencyId
					   , MONTH(smvh.MvDate)
					   , YEAR(smvh.MvDate)) rsmvh
			JOIN lh_bronze.Bronze.SolovisMarketValueHistory smvh ON rsmvh.ResourceId = smvh.ResourceId
			  															AND rsmvh.CurrencyId = smvh.CurrencyId
																		AND rsmvh.MvDate = smvh.MvDate         
		GROUP BY smvh.ResourceId
				 , smvh.MvDate
				 , smvh.CurrencyId) csmvh ON csmvh.ResourceId = smvh.ResourceId
													AND csmvh.ValueTypeId = smvh.ValueTypeId
													AND csmvh.CurrencyId = smvh.CurrencyId
													AND csmvh.MvDate = smvh.MvDate
		JOIN lh_bronze.Bronze.HMCDataWarehouseSolovisCurrency scur ON scur.Id = smvh.CurrencyId
		JOIN lh_bronze.Bronze.CrimsonXCurrency c ON c.ISOCode = scur.Code
		JOIN lh_bronze.Bronze.SolovisInvestments si ON si.ResourceId = smvh.ResourceId   
		JOIN lh_curated.Silver.FXRate fx ON fx.FXDate = current_date
												AND fx.CurrencyId = c.CurrencyId
		LEFT JOIN lh_bronze.Bronze.CrimsonXHoldingsHistory chh ON chh.FundId = abfm.FundId
																	AND chh.ShareClassId = abfm.ShareClassId
																	AND chh.PortfolioTypeId = CASE WHEN si.OwnerId = 1 THEN 0
																								   WHEN si.OwnerId = 2 THEN 2
																								   ELSE 4 END
																	AND chh.CurrencyId = c.CurrencyId
																	AND chh.NAVDate = to_date('2025/07/31', "yyyy/MM/dd")
																	AND chh.EndDate = to_date('9999/12/31', "yyyy/MM/dd")
WHERE chh.FundId IS NULL
GROUP BY abfm.FundId
       , abfm.ShareClassId
	   , CASE WHEN si.OwnerId = 1 THEN 0
		      WHEN si.OwnerId = 2 THEN 2
			  ELSE 4 END
	   , c.CurrencyId
	   , last_day(smvh.MvDate)
	   , fx.FXRate""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#spark.sql("""DELETE FROM lh_bronze.Bronze.CrimsonXHoldingsHistory WHERE NAVDate = '2025-8-31' AND OpenBalance = EndBalance AND EndBalance = 0 and to_date(UpdateTimestamp, "M/d/yyyy") = '2025-8-21'""")
spark.sql("""DELETE FROM lh_curated.Silver.FundMarketValue WHERE NAVDate = '2025-8-31' AND OpenBalance = EndBalance AND EndBalance = 0""")
df = spark.sql("""SELECT * FROM lh_curated.Silver.FundMarketValue WHERE NAVDate = '2025-8-31' AND OpenBalance = EndBalance AND EndBalance = 0""")
display(df.count())


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dfMV = spark.sql("""
     MERGE INTO lh_curated.Silver.FundMarketValue AS fmv
USING (select fmv.FundId
	   , fmv.NAVDate
	   , fmv.CurrencyId
	   , fmv.OpenBalance
	   , fmv.EndBalance
	   , fmv.OpenBalance * fx.FXRate as OpenBalanceUSD
	   , fmv.EndBalance * fx.FXRate as EndBalanceUSD
from lh_curated.Silver.FundMarketValue fmv
		JOIN (SELECT fx.CurrencyId
		             , fx.FXRate
		      FROM lh_curated.Silver.FXRate fx
					JOIN (SELECT CurrencyId
		                         , MAX(FXDate) as FXDate
			              FROM lh_curated.Silver.FXRate
			              GROUP BY CurrencyId) cfx ON fx.CurrencyId = cfx.CurrencyId
														AND fx.FXDate = cfx.FXDate) fx ON fmv.CurrencyId = fx.CurrencyId
where EndBalanceUSD IS NULL) AS umv
	ON fmv.FundId = umv.FundId
            AND  fmv.CurrencyId = umv.CurrencyId
			AND fmv.NAVDate = umv.NAVDate
WHEN MATCHED THEN UPDATE SET
					OpenBalanceUSD = umv.OpenBalanceUSD
					, EndBalanceUSD = umv.EndBalanceUSD
 """)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dfTransactions = spark.sql("""
    SELECT 	lower(FundId) as FundId
        , AsOfDate
		, TransactionTypeId
	    , TransactionSubtypeId
	    , TransactionAmountInLocal
 	    , TransactionAmountInUSD
	    , TransactionAmountOutLocal
		, TransactionAmountOutUSD
	    , TransactionAmountLocal
		, TransactionAmountUSD
		, TransactionCount
FROM lh_curated.Silver.Transaction
   
 """)

display(dfTransactions)

dfTransactions.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("lh_curated.Silver.Transactions1")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.sql("""DELETE FROM lh_curated.Silver.FXRate WHERE ETLLoadDateTime = '2025-09-11 17:18:33.358681'""")
display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
INSERT INTO lh_curated.Silver.ShareClass
(ShareClassId, FundId, ShareClassName, EffectiveDate, IsDefault, IlliquidPct, ETLLoadDateTime)
SELECT abfm.ShareClassId
	   , abfm.FundId
	   , si.Label
	   , NULL as EffectiveDate
	   , CAST(0 as BOOLEAN) AS  IsDefault
       , NULL AS  IlliquidPct
	   , CURRENT_TIMESTAMP
FROM lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.SolovisActiveBookFundMapping abfm ON si.ResourceId = abfm.InvestmentResourceId
where si.ResourceId in (730395, 727002)
""")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# spark.sql("""TRUNCATE TABLE lh_curated.Silver.FXRate""")

spark.sql("""
insert into lh_curated.Silver.FXRate
(FXRateId, CurrencyId, FXDate, FXRate, ETLLoadDateTime, IsLatest)
select CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) as int)  as FXRateId
	   , CAST(CurrencyId as int) as CurrencyId
	   , CAST(CurrencyRateDate as date) as FXDate
	   , CAST(CurrencyRate as DECIMAL(38, 15)) as FXRate
	   , CURRENT_TIMESTAMP as ETLLoadDateTime
	   , CAST(IsLast as int) as IsLatest
from lh_bronze.Bronze.HMCDataWarehouseCurrencyRate
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select count(*) from (
# MAGIC WITH SolovisRecs AS (
# MAGIC 
# MAGIC SELECT  
# MAGIC 
# MAGIC     abfm.FundId,
# MAGIC 
# MAGIC 	c.CurrencyId,
# MAGIC 
# MAGIC    	to_date(sc.Date, 'M/d/yyyy')	 AS CommitmentDate,
# MAGIC 
# MAGIC     SUM(CAST(sc.DeltaValue AS DECIMAL(38,2))) AS CommitmentAmount,
# MAGIC 
# MAGIC     sc.ETLLoadDateTime
# MAGIC 
# MAGIC   FROM lh_bronze.Bronze.SolovisCommitments sc
# MAGIC 
# MAGIC   INNER JOIN lh_bronze.Bronze.SolovisActiveBookFundMapping abfm
# MAGIC 
# MAGIC     ON sc.InvestmentResourceId = abfm.InvestmentResourceId
# MAGIC 
# MAGIC   INNER JOIN lh_bronze.Bronze.SolovisInvestments si ON si.ResourceId = abfm.InvestmentResourceId
# MAGIC 
# MAGIC   INNER JOIN lh_bronze.Bronze.SolovisCurrency scur ON scur.Id = si.LocalCurrencyId
# MAGIC 
# MAGIC   INNER JOIN lh_bronze.Bronze.CrimsonXCurrency c ON c.ISOCode = scur.Code
# MAGIC 
# MAGIC   WHERE to_date(sc.Date, 'M/d/yyyy')  >= '2020-07-01'
# MAGIC 
# MAGIC GROUP BY abfm.FundId, c.CurrencyId , sc.ETLLoadDateTime , sc.Date	)
# MAGIC 
# MAGIC , CrimsonRecs AS (
# MAGIC 
# MAGIC     SELECT
# MAGIC 
# MAGIC        FundId
# MAGIC 
# MAGIC       ,ExposureDate as CommitmentDate
# MAGIC 
# MAGIC 	  ,currencyid AS CurrencyId
# MAGIC 
# MAGIC 	  ,SUM(CommitmentEffectLocal) AS CommitmentAmount
# MAGIC 
# MAGIC 	   --,CashflowTransactionTypeId
# MAGIC 
# MAGIC       ,ETLLoadDateTime
# MAGIC 
# MAGIC FROM lh_bronze.Bronze.CrimsonXCashflowTransaction
# MAGIC 
# MAGIC WHERE 
# MAGIC 
# MAGIC     cast(ExposureDate as date)<'2020-07-01'
# MAGIC 
# MAGIC 	AND cast(EndDate as date) = '9999-12-31'
# MAGIC 
# MAGIC     AND CashflowTransactionTypeId in (5, 13, 14, 15) 
# MAGIC 
# MAGIC    GROUP BY FundId,ExposureDate ,currencyid ,ETLLoadDateTime  
# MAGIC  
# MAGIC )
# MAGIC  
# MAGIC SELECT 
# MAGIC 
# MAGIC   FundId, 
# MAGIC 
# MAGIC   CommitmentDate,
# MAGIC 
# MAGIC   CurrencyId,
# MAGIC 
# MAGIC   cast(CommitmentAmount as Decimal(38,2)) as CommitmentAmount, 
# MAGIC 
# MAGIC   CASE WHEN CommitmentAmount < 0 THEN 13 ELSE 5 END AS CashflowTransactionTypeId, 
# MAGIC 
# MAGIC   ETLLoadDateTime
# MAGIC 
# MAGIC FROM SolovisRecs s
# MAGIC 
# MAGIC where CommitmentAmount != 0
# MAGIC 
# MAGIC UNION
# MAGIC 
# MAGIC SELECT
# MAGIC 
# MAGIC   FundId, 
# MAGIC 
# MAGIC   CommitmentDate,
# MAGIC 
# MAGIC   CurrencyId,
# MAGIC 
# MAGIC   cast(CommitmentAmount as Decimal(38,2)) as CommitmentAmount, 
# MAGIC 
# MAGIC   CASE WHEN CommitmentAmount < 0 THEN 13 ELSE 5 END AS CashflowTransactionTypeId, 
# MAGIC 
# MAGIC   ETLLoadDateTime
# MAGIC 
# MAGIC FROM CrimsonRecs c
# MAGIC 
# MAGIC where CommitmentAmount != 0)
# MAGIC  

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC 
# MAGIC     SELECT
# MAGIC     count(*)
# MAGIC 
# MAGIC     --    FundId
# MAGIC 
# MAGIC     --   ,ExposureDate as CommitmentDate
# MAGIC 
# MAGIC 	--   ,currencyid AS CurrencyId
# MAGIC 
# MAGIC 	--   ,SUM(CommitmentEffectLocal) AS CommitmentAmount
# MAGIC 
# MAGIC 	--    --,CashflowTransactionTypeId
# MAGIC 
# MAGIC     --   ,ETLLoadDateTime
# MAGIC     --   , EndDate
# MAGIC 
# MAGIC FROM lh_bronze.Bronze.CrimsonXCashflowTransaction
# MAGIC 
# MAGIC WHERE 
# MAGIC 
# MAGIC     cast(ExposureDate as date)<'2020-07-01'
# MAGIC 
# MAGIC 	AND cast(EndDate as date) = '9999-12-31'
# MAGIC 
# MAGIC     AND CashflowTransactionTypeId in (5, 13, 14, 15) 
# MAGIC 
# MAGIC    --GROUP BY FundId,ExposureDate ,currencyid ,ETLLoadDateTime  , EndDate


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC SELECT  count(*)
# MAGIC 
# MAGIC   --   abfm.FundId,
# MAGIC 
# MAGIC 	-- c.CurrencyId,
# MAGIC 
# MAGIC   --  	to_date(sc.Date, 'M/d/yyyy')	 AS CommitmentDate,
# MAGIC 
# MAGIC   --   SUM(CAST(sc.DeltaValue AS DECIMAL(38,2))) AS CommitmentAmount,
# MAGIC 
# MAGIC   --   sc.ETLLoadDateTime
# MAGIC 
# MAGIC   FROM lh_bronze.Bronze.SolovisCommitments sc
# MAGIC 
# MAGIC   INNER JOIN lh_bronze.Bronze.SolovisActiveBookFundMapping abfm
# MAGIC 
# MAGIC     ON sc.InvestmentResourceId = abfm.InvestmentResourceId
# MAGIC 
# MAGIC   INNER JOIN lh_bronze.Bronze.SolovisInvestments si ON si.ResourceId = abfm.InvestmentResourceId
# MAGIC 
# MAGIC   INNER JOIN lh_bronze.Bronze.SolovisCurrency scur ON scur.Id = si.LocalCurrencyId
# MAGIC 
# MAGIC   INNER JOIN lh_bronze.Bronze.CrimsonXCurrency c ON c.ISOCode = scur.Code
# MAGIC 
# MAGIC   WHERE to_date(sc.Date, 'M/d/yyyy')  >= '2020-07-01'
# MAGIC 
# MAGIC --GROUP BY abfm.FundId, c.CurrencyId , sc.ETLLoadDateTime , sc.Date

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC SELECT *
# MAGIC FROM lh_bronze.Bronze.CrimsonXCashflowTransactionDetail b
# MAGIC         JOIN lh_curated.Silver.CashflowTransactionDetail s ON b.CashflowTransactionDetailId = s.CashflowTransactionDetailId
# MAGIC WHERE to_date(b.ExposureDate, 'MM/dd/yyyy') <= to_date('06/30/2020', 'MM/dd/yyyy')
# MAGIC         AND (s.TransactionAmountInLocal != b.TransactionAmountInLocal
# MAGIC 				             OR s.TransactionAmountInUSD != b.TransactionAmountInUSD
# MAGIC                              OR s.TransactionAmountOutLocal != b.TransactionAmountOutLocal
# MAGIC                              OR s.TransactionAmountOutUSD != b.TransactionAmountOutUSD
# MAGIC                              OR s.CommitmentEffectLocal != b.CommitmentEffectLocal
# MAGIC                              OR s.MarketValueEffectLocal != b.MarketValueEffectLocal
# MAGIC                              OR s.ReturnedAmountLocal != b.ReturnedAmountLocal
# MAGIC                              OR s.ReturnedAmountUSD != b.ReturnedAmountUSD
# MAGIC                              OR s.UnfundedAdjustmentLocal != b.UnfundedAdjustmentLocal
# MAGIC                              OR s.UnfundedAdjustmentUSD != b.UnfundedAdjustmentUSD
# MAGIC                              OR s.FundedAmountLocal != b.FundedAmountLocal
# MAGIC                              OR s.FundedAmountUSD != b.FundedAmountUSD
# MAGIC                              OR s.RecallableAmountLocal != b.RecallableAmountLocal
# MAGIC                              OR s.RecallableAmountUSD != b.RecallableAmountUSD
# MAGIC                              OR s.CommitmentEffectUSD != b.CommitmentEffectUSD
# MAGIC                              OR s.MarketValueEffectUSD != b.MarketValueEffectUSD)
# MAGIC 
# MAGIC -- MERGE INTO lh_curated.Silver.CashflowTransactionDetail AS s
# MAGIC -- USING (SELECT * FROM lh_bronze.Bronze.CrimsonXCashflowTransactionDetail        
# MAGIC --        WHERE to_date(ExposureDate, 'MM/dd/yyyy') <= to_date('06/30/2020', 'MM/dd/yyyy')) AS b
# MAGIC -- 	ON b.CashflowTransactionDetailId = s.CashflowTransactionDetailId
# MAGIC -- WHEN MATCHED THEN UPDATE SET TransactionAmountInLocal = b.TransactionAmountInLocal
# MAGIC -- 				             , TransactionAmountInUSD = b.TransactionAmountInUSD
# MAGIC --                              , TransactionAmountOutLocal = b.TransactionAmountOutLocal
# MAGIC --                              , TransactionAmountOutUSD = b.TransactionAmountOutUSD
# MAGIC --                              , CommitmentEffectLocal = b.CommitmentEffectLocal
# MAGIC --                              , MarketValueEffectLocal = b.MarketValueEffectLocal
# MAGIC --                              , ReturnedAmountLocal = b.ReturnedAmountLocal
# MAGIC --                              , ReturnedAmountUSD = b.ReturnedAmountUSD
# MAGIC --                              , UnfundedAdjustmentLocal = b.UnfundedAdjustmentLocal
# MAGIC --                              , UnfundedAdjustmentUSD = b.UnfundedAdjustmentUSD
# MAGIC --                              , FundedAmountLocal = b.FundedAmountLocal
# MAGIC --                              , FundedAmountUSD = b.FundedAmountUSD
# MAGIC --                              , RecallableAmountLocal = b.RecallableAmountLocal
# MAGIC --                              , RecallableAmountUSD = b.RecallableAmountUSD
# MAGIC --                              , CommitmentEffectUSD = b.CommitmentEffectUSD
# MAGIC --                              , MarketValueEffectUSD = b.MarketValueEffectUSD


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC --DELETE FROM lh_bronze.Bronze.SolovisActiveBookFundMapping where InvestmentResourceId = 322281
# MAGIC 
# MAGIC SELECT si.ResourceId as InvestmentResourceId
# MAGIC 	   , si.Id as InvestmentId
# MAGIC 	   , '392a50f7-6a5a-410c-8e2d-5c77e02117c2' as FundId
# MAGIC 	   , '16022be1-2057-4f96-9b1c-f0c3c43b1231' as ShareClassId
# MAGIC FROM lh_bronze.Bronze.SolovisInvestments si
# MAGIC 		  JOIN lh_bronze.Bronze.SolovisEntities se ON si.HoldingId = se.Id
# MAGIC           JOIN lh_bronze.Bronze.SolovisTagsets tag ON tag.Category = 'Special Entity Type' -- AND Description LIKE '%Fund'
# MAGIC 												AND CASE WHEN se.SpecialEntityType = 'External Drawdown Fund' THEN 6
# MAGIC 												         WHEN se.SpecialEntityType = 'Public Equity' THEN 17
# MAGIC 														 WHEN se.SpecialEntityType = 'Outsider' THEN 16
# MAGIC 														 WHEN se.SpecialEntityType = 'External Managed Fund' THEN 11
# MAGIC 														 ELSE -999 END = tag.Id
# MAGIC where si.AssetClassGia = 'Private Equity Stock Dist.'

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC MERGE INTO lh_bronze.Bronze.CrimsonXHoldingsHistory AS hh
# MAGIC USING (select hh.FundId
# MAGIC 	   , hh.ShareClassId
# MAGIC 	   , hh.NAVDate
# MAGIC 	   , hh.CurrencyId
# MAGIC 	   , hh.PortfolioTypeId
# MAGIC 	   , hh.StartDate
# MAGIC 	   , hh.EndDate
# MAGIC 	   , hh.LotDate
# MAGIC 	   , hh.OpenBalance
# MAGIC 	   , hh.EndBalance
# MAGIC 	   , hh.OpenBalance * fx.FXRate as OpenBalanceUSD
# MAGIC 	   , hh.EndBalance * fx.FXRate as EndBalanceUSD
# MAGIC from lh_bronze.Bronze.CrimsonXHoldingsHistory hh
# MAGIC 		JOIN lh_curated.Silver.FXRate fx ON fx.CurrencyId = hh.CurrencyId
# MAGIC 												AND CASE WHEN hh.NAVDate == last_day(current_date) THEN DATEADD(DAY, -1, current_date) ELSE hh.NAVDate END = fx.FXDate) AS umv
# MAGIC 	ON hh.FundId = umv.FundId
# MAGIC 			AND hh.ShareClassId = umv.ShareClassId
# MAGIC             AND  hh.CurrencyId = umv.CurrencyId
# MAGIC 			AND hh.PortfolioTypeId = umv.PortfolioTypeId
# MAGIC 			AND hh.NAVDate = umv.NAVDate
# MAGIC 			AND hh.StartDate = umv.StartDate
# MAGIC 			AND hh.EndDate = umv.EndDate
# MAGIC 			AND hh.LotDate = umv.LotDate
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC 					OpenBalanceUSD = umv.OpenBalanceUSD
# MAGIC 					, EndBalanceUSD = umv.EndBalanceUSD

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(spark.sql("""
INSERT INTO lh_curated.Review.CashflowTransactionDetail
(CashflowTransactionDetailId,
	FundId,
	ShareClassId,
	CurrencyId,
	FXRate,
	PortfolioTypeId,
	CashflowTransactionTypeId,
	CashflowTransactionSubtypeId,
	TransactionAmountInLocal,
	TransactionAmountInUSD,
	TransactionAmountOutLocal,
	TransactionAmountOutUSD,
	CommitmentEffectLocal,
	MarketValueEffectLocal,
	BookStartOfDay,
	ExposureDate,
	TradeDate,
	SettleDate,
	ReturnedAmountLocal,
	ReturnedAmountUSD,
	UnfundedAdjustmentLocal,
	UnfundedAdjustmentUSD,
	FundedAmountLocal,
	FundedAmountUSD,
	RecallableAmountLocal,
	RecallableAmountUSD,
	TransactionTypeIdSource,
	TransactionIdSource,
	CommitmentEffectUSD,
	MarketValueEffectUSD,
	TransactionTag,
	ETLLoadDateTime)
SELECT
	CashflowTransactionDetailId,
	FundId,
	ShareClassId,
	ctd.CurrencyId,
	COALESCE(ctd.FXRate, COALESCE(fx.FXRate, 1)),
	PortfolioTypeId,
	CashflowTransactionTypeId,
	CashflowTransactionSubtypeId,
	TransactionAmountInLocal,
	TransactionAmountInUSD,
	TransactionAmountOutLocal,
	TransactionAmountOutUSD,
	CommitmentEffectLocal,
	MarketValueEffectLocal,
	CAST(BookStartOfDay as boolean) as BookStartOfDay,
	ExposureDate,
	TradeDate,
	SettleDate,
	COALESCE(ReturnedAmountLocal, 0) as ReturnedAmountLocal,
	COALESCE(ReturnedAmountUSD, 0) as ReturnedAmountUSD,
	COALESCE(UnfundedAdjustmentLocal, 0) as UnfundedAdjustmentLocal,
	COALESCE(UnfundedAdjustmentUSD, 0) as UnfundedAdjustmentUSD,
	COALESCE(FundedAmountLocal, 0) as FundedAmountLocal,
	COALESCE(FundedAmountUSD, 0) as FundedAmountUSD,
	COALESCE(RecallableAmountLocal, 0) as RecallableAmountLocal,
	COALESCE(RecallableAmountUSD, 0) as RecallableAmountUSD,
	TransactionTypeIdSource,
	TransactionIdSource,
	COALESCE(CommitmentEffectUSD, 0) as CommitmentEffectUSD,
	COALESCE(MarketValueEffectUSD, 0) as MarketValueEffectUSD,
	TransactionTag,
	CASE WHEN LEN(ctd.ETLLoadDateTime) = 0 THEN current_timestamp else CAST(ctd.ETLLoadDateTime as Timestamp) END as ETLLoadDateTime
FROM lh_curated.Silver.CashflowTransactionDetail ctd
		LEFT JOIN lh_curated.Silver.FXRate fx ON ctd.CurrencyId = fx.CurrencyId and ctd.ExposureDate = fx.FXDate""")
)





# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.conf.set('spark.sql.caseSensitive', True)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC DROP TABLE lh_curated.Review.CashflowTransactionDetail

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC --drop table lh_curated.Silver.CashflowTransactionDetail1
# MAGIC CREATE TABLE lh_curated.Review.CashflowTransactionDetail(
# MAGIC 	CashflowTransactionDetailId bigint NOT NULL,
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	ShareClassId varchar(36) NOT NULL,
# MAGIC 	CurrencyId int NOT NULL,
# MAGIC 	FXRate decimal(38, 15) NOT NULL,
# MAGIC 	PortfolioTypeId int NOT NULL,
# MAGIC 	CashflowTransactionTypeId int NOT NULL,
# MAGIC 	CashflowTransactionSubtypeId int NOT NULL,
# MAGIC 	TransactionAmountInLocal decimal(38, 2) NOT NULL,
# MAGIC 	TransactionAmountInUSD decimal(38, 2) NOT NULL,
# MAGIC 	TransactionAmountOutLocal decimal(38, 2) NOT NULL,
# MAGIC 	TransactionAmountOutUSD decimal(38, 2) NOT NULL,
# MAGIC 	CommitmentEffectLocal decimal(38, 2) NOT NULL,
# MAGIC 	MarketValueEffectLocal decimal(38, 2) NOT NULL,
# MAGIC 	BookStartOfDay boolean NOT NULL,
# MAGIC 	ExposureDate date NOT NULL,
# MAGIC 	TradeDate date,
# MAGIC 	SettleDate date,
# MAGIC 	ReturnedAmountLocal decimal(38, 2) NOT NULL,
# MAGIC 	ReturnedAmountUSD decimal(38, 2) NOT NULL,
# MAGIC 	UnfundedAdjustmentLocal decimal(38, 2) NOT NULL,
# MAGIC 	UnfundedAdjustmentUSD decimal(38, 2) NOT NULL,
# MAGIC 	FundedAmountLocal decimal(38, 2) NOT NULL,
# MAGIC 	FundedAmountUSD decimal(38, 2) NOT NULL,
# MAGIC 	RecallableAmountLocal decimal(38, 2) NOT NULL,
# MAGIC 	RecallableAmountUSD decimal(38, 2) NOT NULL,
# MAGIC 	TransactionTypeIdSource int,
# MAGIC 	TransactionIdSource int,
# MAGIC 	CommitmentEffectUSD decimal(38, 2) NOT NULL,
# MAGIC 	MarketValueEffectUSD decimal(38, 2) NOT NULL,
# MAGIC 	TransactionTag varchar(8000),
# MAGIC 	ETLLoadDateTime Timestamp NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC delete
# MAGIC from lh_curated.Silver.CashflowTransactionDetail
# MAGIC where CashflowTransactionTypeId in (5,13)

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.sql("""SELECT * FROM lh_curated.Silver.CashflowTransactionDetail""")
df.printSchema()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
INSERT INTO lh_curated.Silver.FundReturn
(FundId, ReturnTypeId, ReturnSourceId, FrequencyId, EndDate, ReturnValue, AsOfDate, ETLLoadDateTime)
select fr.FundId
	   , fr.ReturnTypeId
	   , fr.ReturnSourceId
	   , fr.FrequencyId
	   , fr.ReturnDate
	   , fr.ReturnValue
	   , current_date as AsOfDate
	   , current_timestamp as ETLLoadDateTime
from lh_bronze.Bronze.CrimsonXFundReturn fr
		JOIN lh_bronze.Bronze.CrimsonXFund f ON fr.FundId = f.FundId
where fr.ReturnSourceId = 2
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
