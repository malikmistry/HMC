# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     },
# META     "environment": {
# META       "environmentId": "0a2e55e8-f579-b73b-4a24-a95f3abe0690",
# META       "workspaceId": "00000000-0000-0000-0000-000000000000"
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql.functions import col, lit, coalesce
from pyspark.sql import functions as F
from delta.tables import DeltaTable

spark.conf.set('spark.sql.caseSensitive', True)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# WorkspaceId = ""
# BronzeLHId = ""
# CuratedLHId = ""

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Build paths
bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# **Create the table below and seed from Bronze if it doesn't exist for use downstream.**
#  

# CELL ********************

create_sql = f"""
CREATE TABLE IF NOT EXISTS lh_curated.Silver.FundCommitment
USING DELTA
AS
WITH fundcomprep AS (
SELECT  
	abfm.FundId
	,cast(sc.Date as date) as CommitmentDate
    ,SUM(CAST (sc.DeltaValue as decimal(18,2))) as CommitmentAmount
    ,sc.ETLLoadDateTime 	
FROM Bronze.SolovisCommitments sc
INNER JOIN Bronze.SolovisActiveBookFundMapping abfm
ON sc.InvestmentResourceId = abfm.InvestmentResourceId	
GROUP BY abfm.FundId, sc.Date, sc.ETLLoadDateTime)
SELECT 
	FundId, 
	CommitmentDate,
	CommitmentAmount, 
	CASE WHEN CommitmentAmount < 0  
		THEN 13 ELSE 5
	END AS CashflowTransactionTypeId, 
	ETLLoadDateTime
FROM fundcomprep
WHERE 1 = 2

"""

spark.sql(create_sql)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.sql("SELECT * FROM lh_curated.Silver.FundCommitment LIMIT 1000")
display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# **Dropping & Recreate previous backup and work tables**


# CELL ********************

drop_workingtable_sql = f"""
DROP TABLE IF EXISTS lh_curated.Review.FundValuation
"""
create_workingtable_sql = f"""
CREATE TABLE IF NOT EXISTS lh_curated.Review.FundValuation
USING DELTA
AS
SELECT FundValuationId
      ,FundId
      ,ShareClassId
      ,PortfolioTypeId
      ,NavDate
      ,ValuationDate
      ,ValuationAmt
      ,CurrencyId
      ,ValuationTypeId
      ,FrequencyId
      ,ETLLoadDateTime
  FROM lh_curated.Silver.FundValuation
"""

spark.sql(drop_workingtable_sql)
spark.sql(create_workingtable_sql)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

drop_backuptable_sql = f"""
DROP TABLE IF EXISTS lh_bronze.Bronze.FundValuationSilverBackup
"""
create_backuptable_sql = f"""
CREATE TABLE IF NOT EXISTS lh_bronze.Bronze.FundValuationSilverBackup
USING DELTA
AS
SELECT FundValuationId
      ,FundId
      ,ShareClassId
      ,PortfolioTypeId
      ,NavDate
      ,ValuationDate
      ,ValuationAmt
      ,CurrencyId
      ,ValuationTypeId
      ,FrequencyId
      ,ETLLoadDateTime
  FROM lh_curated.Silver.FundValuation
 
"""

spark.sql(drop_backuptable_sql)
spark.sql(create_backuptable_sql)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC --
# MAGIC 
# MAGIC select * from vwSolovisMV
# MAGIC where ResourceId = 587398
# MAGIC  limit 100

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC select * from CurrentMarketValues --SolovisActiveBookFundMapping 
# MAGIC where Resource
# MAGIC where FundId ='c682e4bd-febe-4b98-8fa8-132946c9b7fc'

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC select * from vwSolovisMV limit 5

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Load and register required Bronze tables
# spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisMarketValues").createOrReplaceTempView("smv")
# spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisMarketValueHistory").createOrReplaceTempView("smvh")
# spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisActiveBookFundMapping").createOrReplaceTempView("abfm")
# spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisInvestments").createOrReplaceTempView("si")
# spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/HMCDataWarehouseSolovisCurrency").createOrReplaceTempView("scur")
# spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/CrimsonXCurrency").createOrReplaceTempView("CrimsonXCurrency")
# spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/CrimsonXHoldingsHistory").createOrReplaceTempView("h")


# spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisMarketValues").filter("ValueTypeId IN (64, 127)").createOrReplaceTempView("smv")




# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# =========================================
# Step 5) Holdings-like rollup to NAV level
#   (expects existing views/tables: abfm, scur, c, si)
# =========================================
spark.sql("""
CREATE OR REPLACE TEMP VIEW CurrentHoldings AS

with actives as (
  SELECT DISTINCT
    abfm.FundId,
    abfm.ShareClassId,
    cmv.CurrencyId,
    cmv.MvDate
  FROM CurrentMarketValues cmv
  JOIN SolovisActiveBookFundMapping abfm ON cmv.ResourceId = abfm.InvestmentResourceId
)

SELECT
  abfm.FundId,
  abfm.ShareClassId,
  last_day( to_date(cmv.MvDate, 'M/d/yyyy') ) AS NAVDate,
  CASE
    WHEN si.OwnerId = 1 THEN 0
    WHEN si.OwnerId = 2 THEN 2
    ELSE 4
  END AS PortfolioTypeId,
  cur.CurrencyId,
  SUM(cmv.TotalValue) AS EndBalance
FROM CurrentMarketValues cmv
JOIN SolovisActiveBookFundMapping abfm ON cmv.ResourceId = abfm.InvestmentResourceId
JOIN SolovisCurrency scur ON scur.Id = cmv.CurrencyId
JOIN CrimsonXCurrency cur ON cur.ISOCode = scur.Code
JOIN SolovisInvestments si ON si.ResourceId = cmv.ResourceId
JOIN actives
  ON abfm.FundId      = actives.FundId
 AND abfm.ShareClassId= actives.ShareClassId
 AND cmv.CurrencyId   = actives.CurrencyId
 AND last_day(to_date(cmv.MvDate, 'M/d/yyyy')) = last_day(to_date(actives.MvDate, 'M/d/yyyy'))
GROUP BY
  abfm.FundId,
  abfm.ShareClassId,
  last_day(to_date(cmv.MvDate, 'M/d/yyyy')),
  CASE
    WHEN si.OwnerId = 1 THEN 0
    WHEN si.OwnerId = 2 THEN 2
    ELSE 4
  END,
  cur.CurrencyId
""")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""

CREATE OR REPLACE  TEMP VIEW fundvaluation AS
select * from lh_curated.Review.FundValuation""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC select *  FROM CurrentMarketValues
# MAGIC where FundId = 'c682e4bd-febe-4b98-8fa8-132946c9b7fc'

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC SELECT
# MAGIC     CAST(FundId         AS STRING)                         AS FundId,
# MAGIC     CAST(ShareClassId   AS STRING)                         AS ShareClassId,
# MAGIC     CAST(PortfolioTypeId AS INT)                           AS PortfolioTypeId,
# MAGIC     to_date(NavDate,        'M/d/yyyy')                    AS NavDate,
# MAGIC     to_date(ValuationDate,  'M/d/yyyy')                    AS ValuationDate,
# MAGIC     CAST(ValuationAmt    AS DECIMAL(35, 2))                AS ValuationAmt,
# MAGIC     CAST(CurrencyId      AS INT)                           AS CurrencyId,
# MAGIC     CAST(ValuationTypeID     AS INT)                       AS ValuationTypeId,
# MAGIC     CAST(FrequencyId     AS INT)                           AS FrequencyId,
# MAGIC     to_timestamp(ETLLoadDateTime, 'yyyy-MM-dd HH:mm:ss.SSSSSS') AS ETLLoadDateTime
# MAGIC   FROM CurrentMarketValues
# MAGIC   WHERE to_date(ValuationDate, 'M/d/yyyy') <= current_date()

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC 
# MAGIC MERGE INTO lh_curated.Review.FundValuation AS fv
# MAGIC USING (
# MAGIC   -- Normalize types & dates ONCE here
# MAGIC   SELECT
# MAGIC     CAST(FundId         AS STRING)                         AS FundId,
# MAGIC     CAST(ShareClassId   AS STRING)                         AS ShareClassId,
# MAGIC     CAST(PortfolioTypeId AS INT)                           AS PortfolioTypeId,
# MAGIC     to_date(NavDate,        'M/d/yyyy')                    AS NavDate,
# MAGIC     to_date(ValuationDate,  'M/d/yyyy')                    AS ValuationDate,
# MAGIC     CAST(ValuationAmt    AS DECIMAL(35, 2))                AS ValuationAmt,
# MAGIC     CAST(CurrencyId      AS INT)                           AS CurrencyId,
# MAGIC     CAST(ValuationTypeID     AS INT)                       AS ValuationTypeId,
# MAGIC     CAST(FrequencyId     AS INT)                           AS FrequencyId,
# MAGIC     to_timestamp(ETLLoadDateTime, 'yyyy-MM-dd HH:mm:ss.SSSSSS') AS ETLLoadDateTime
# MAGIC   FROM CurrentMarketValues
# MAGIC   WHERE to_date(ValuationDate, 'M/d/yyyy') <= current_date()
# MAGIC ) AS cmv
# MAGIC ON  fv.FundId        = cmv.FundId
# MAGIC AND fv.ShareClassId  = cmv.ShareClassId
# MAGIC AND fv.CurrencyId    = cmv.CurrencyId
# MAGIC AND fv.ValuationTypeId   = cmv.ValuationTypeId
# MAGIC AND fv.NavDate       = cmv.NavDate
# MAGIC 
# MAGIC WHEN MATCHED THEN UPDATE SET
# MAGIC     fv.ValuationDate      = cmv.ValuationDate,
# MAGIC     fv.PortfolioTypeId    = cmv.PortfolioTypeId,
# MAGIC     fv.ValuationAmt       = cmv.ValuationAmt,
# MAGIC     fv.FrequencyId        = cmv.FrequencyId,
# MAGIC     fv.ETLLoadDateTime    = cmv.ETLLoadDateTime
# MAGIC 
# MAGIC WHEN NOT MATCHED THEN INSERT (
# MAGIC     FundId, ShareClassId, PortfolioTypeId, NavDate, ValuationDate, ValuationAmt,
# MAGIC     CurrencyId, ValuationTypeId , FrequencyId, ETLLoadDateTime
# MAGIC )
# MAGIC VALUES (
# MAGIC     cmv.FundId, cmv.ShareClassId, cmv.PortfolioTypeId, cmv.NavDate, cmv.ValuationDate, cmv.ValuationAmt,
# MAGIC     cmv.CurrencyId, cmv.ValuationTypeId, cmv.FrequencyId, cmv.ETLLoadDateTime  -- or current_timestamp()
# MAGIC );


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# This is the main table I am modifying ---- modify for fund valuation.


# MARKDOWN ********************

# # Build out Solovis Market Value history which includes new changes
# # Get history of market values
# dfSolovisMVHistory = spark.sql("""
# SELECT smvh.ResourceId
# 		, smvh.ValueTypeId
# 		, smvh.CurrencyId
# 		, to_date(smvh.MvDate, "M/d/yyyy") as MvDate
# 		, smvh.TotalValue
#         , 0 as IsNew
# FROM smvh
# 	    -- Get the priority market value type to ensure the proper actual or estimate vaue is chosen
# 		JOIN (SELECT smvh.ResourceId
# 			   , to_date(smvh.MvDate, "M/d/yyyy") as MvDate
# 			   , smvh.CurrencyId
# 			   , ABS(MAX(CASE WHEN smvh.ValueTypeId not in (127, 64, 16) THEN smvh.ValueTypeId * -1
# 						      ELSE smvh.ValueTypeId END)) AS ValueTypeId
# 		-- Get the max MvDate for each resource id and vaule type id
# 		FROM (SELECT smvh.ResourceId
# 					 , smvh.CurrencyId
# 					 -- , MONTH(smvh.MvDate)
# 					 -- , YEAR(smvh.MvDate)
# 			   		 , MAX(to_date(smvh.MvDate, "M/d/yyyy")) as MvDate					 
# 			  FROM smvh
# 			  GROUP BY smvh.ResourceId
# 					   , smvh.CurrencyId
# 					   , MONTH(smvh.MvDate)
# 					   , YEAR(smvh.MvDate)) rsmvh
# 			  JOIN smvh ON rsmvh.ResourceId = smvh.ResourceId
# 								AND rsmvh.CurrencyId = smvh.CurrencyId
# 								AND rsmvh.MvDate = to_date(smvh.MvDate, "M/d/yyyy")
# 		GROUP BY smvh.ResourceId
# 				 , smvh.MvDate
# 				 , smvh.CurrencyId) csmvh ON csmvh.ResourceId = smvh.ResourceId
# 													AND csmvh.ValueTypeId = smvh.ValueTypeId
# 													AND csmvh.CurrencyId = smvh.CurrencyId
# 													AND csmvh.MvDate = to_date(smvh.MvDate, "M/d/yyyy")
# """)
# 
# display(dfSolovisMVHistory.count())
# 
# # Get latest updates
# dfLatestSolovisMV = spark.sql("""
# SELECT smv.ResourceId
# 		, smv.ValueTypeId
# 		, smv.CurrencyId
# 		, to_date(smv.MvDate, "M/d/yyyy") AS MvDate
# 		, smv.TotalValue
#         , 1 as IsNew
# FROM smv
# 	    -- Get the priority market value type to ensure the proper actual or estimate vaue is chosen
# 		JOIN (SELECT smv.ResourceId
# 			   , to_date(smv.MvDate, "M/d/yyyy") as MvDate
# 			   , smv.CurrencyId
# 			   , ABS(MAX(CASE WHEN smv.ValueTypeId not in (127, 64, 16) THEN smv.ValueTypeId * -1
# 						      ELSE smv.ValueTypeId END)) AS ValueTypeId
# 		-- Get the max MvDate for each resource id and vaule type id
# 		FROM (SELECT smv.ResourceId
# 					 , smv.CurrencyId
# 			   		 , MAX(to_date(smv.MvDate, "M/d/yyyy")) as MvDate					 
# 			  FROM smv
#               WHERE to_date(smv.MvDate, "M/d/yyyy") <= current_date
# 			  GROUP BY smv.ResourceId
# 					   , smv.CurrencyId
# 					   , MONTH(to_date(smv.MvDate, "M/d/yyyy"))
# 					   , YEAR(to_date(smv.MvDate, "M/d/yyyy"))) rsmv
# 			  JOIN smv ON rsmv.ResourceId = smv.ResourceId
# 			  													AND rsmv.CurrencyId = smv.CurrencyId
# 																AND rsmv.MvDate = to_date(smv.MvDate, "M/d/yyyy")
# 		GROUP BY smv.ResourceId
# 				 , smv.MvDate
# 				 , smv.CurrencyId) csmv ON csmv.ResourceId = smv.ResourceId
# 													AND csmv.ValueTypeId = smv.ValueTypeId
# 													AND csmv.CurrencyId = smv.CurrencyId
# 													AND csmv.MvDate = to_date(smv.MvDate, "M/d/yyyy")
#         LEFT JOIN smvh ON smv.ResourceId = smvh.ResourceId
#                              AND smv.ValueTypeId = smvh.ValueTypeId
#                              AND smv.CurrencyId = smvh.CurrencyId
#                              AND to_date(smv.MvDate, "M/d/yyyy") = to_date(smvh.MvDate, "M/d/yyyy")
#                              AND smv.TotalValue = smvh.TotalValue
#  WHERE smvh.ResourceId IS NULL
# """)
# 
# display(dfLatestSolovisMV.count())
# 
# # Union both dataframes to get the complete market value view between history and updates
# dfSolovisMarketValues = dfSolovisMVHistory.union(dfLatestSolovisMV)
# dfSolovisMarketValues.createOrReplaceTempView("SolovisMV")
# 
# display(dfSolovisMarketValues.count())
# 
# # Get the prioritized valuetype between history and changes.  actuals, estimates, computed estimates, and the rest is the priority for ValueTypeId
# dfCurrentMV = spark.sql("""
# SELECT DISTINCT smv.ResourceId
# 		, smv.ValueTypeId
# 		, smv.CurrencyId
# 		, smv.MvDate
# 		, smv.TotalValue
# FROM SolovisMV smv
# 	    -- Get the priority market value type to ensure the proper actual or estimate vaue is chosen
# 		JOIN (SELECT smv.ResourceId
# 			   , smv.MvDate
# 			   , smv.CurrencyId
# 			   , ABS(MAX(CASE WHEN smv.ValueTypeId not in (127, 64, 16) THEN smv.ValueTypeId * -1
# 						      ELSE smv.ValueTypeId END)) AS ValueTypeId
# 		-- Get the max MvDate for each resource id and vaule type id
# 		FROM (SELECT smv.ResourceId
# 					 , smv.CurrencyId
# 					 --, MONTH(smv.MvDate)
# 					 --, YEAR(smv.MvDate)
# 			   		 , MAX(smv.MvDate) as MvDate					 
# 			  FROM SolovisMV smv
#               WHERE smv.IsNew = 1
# 			  GROUP BY smv.ResourceId
# 					   , smv.CurrencyId
# 					   , MONTH(smv.MvDate)
# 					   , YEAR(smv.MvDate)) rsmv
# 			  JOIN SolovisMV smv ON rsmv.ResourceId = smv.ResourceId
# 			  													AND rsmv.CurrencyId = smv.CurrencyId
# 																AND rsmv.MvDate = smv.MvDate
# 		GROUP BY smv.ResourceId
# 				 , smv.MvDate
# 				 , smv.CurrencyId) csmv ON csmv.ResourceId = smv.ResourceId
# 													AND csmv.ValueTypeId = smv.ValueTypeId
# 													AND csmv.CurrencyId = smv.CurrencyId
# 													AND csmv.MvDate = smv.MvDate
# """)
# 
# display(dfCurrentMV.count())
# 
# dfCurrentMV.createOrReplaceTempView("CurrentMarketValues")
# 
# # Convert the solovis market values to resemble holdings, sum up the totals and convert to NAVDate
# dfCurrentHoldings = spark.sql("""
#     SELECT abfm.FundId
#            , abfm.ShareClassId
#            , last_day(cmv.MvDate) AS NAVDate
# 		   , CASE WHEN si.OwnerId = 1 THEN 0
# 				  WHEN si.OwnerId = 2 THEN 2
# 				  ELSE 4 END AS PortfolioTypeId           
#            , c.CurrencyId
#            , SUM(cmv.TotalValue) as EndBalance
#     FROM CurrentMarketValues cmv
#             JOIN abfm ON cmv.ResourceId = abfm.InvestmentResourceId
# 			JOIN scur ON scur.Id = cmv.CurrencyId
# 			JOIN c ON c.ISOCode = scur.Code
# 			JOIN si ON si.ResourceId = cmv.ResourceId            
#             JOIN (
#                 SELECT DISTINCT abfm.FundId
#                          		, abfm.ShareClassId
# 								, cmv.CurrencyId
# 								, cmv.MvDate
#                   FROM CurrentMarketValues cmv
#                         JOIN abfm ON cmv.ResourceId = abfm.InvestmentResourceId
#                   ) actives ON abfm.FundId = actives.FundId
#                                 AND abfm.ShareClassId = actives.ShareClassId
# 								AND cmv.CurrencyId = actives.CurrencyId
# 								AND last_day(cmv.MvDate) = last_day(actives.MvDate)
#     GROUP BY abfm.FundId
#            , abfm.ShareClassId
#            , last_day(cmv.MvDate)
# 		   , CASE WHEN si.OwnerId = 1 THEN 0
# 				  WHEN si.OwnerId = 2 THEN 2
# 				  ELSE 4 END
#            , c.CurrencyId
# """)
# 
# dfCurrentHoldings.createOrReplaceTempView("CurrentHoldings")
# 
# display(dfCurrentHoldings.count())


# CELL ********************

# MAGIC %%sql
# MAGIC 


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#display(dfLatestSolovisMV)
#display(dfSolovisMVHistory.filter(col("ResourceId") == 702297))
#display(dfLatestSolovisMV.filter(col("ResourceId") == 702297))
#display(dfSolovisMarketValues.filter(col("ResourceId") == 702297))
#display(dfCurrentMV)
#display(dfCurrentHoldings)
#display(dfSolovisMarketValues)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Main SQL Query
dfMarketValues = spark.sql("""
	WITH HoldingsHistory AS (
		SELECT FundId,
			ShareClassId,
			to_date(NAVDate, 'MM/dd/yyyy') AS NAVDate,
			PortfolioTypeId,
			CurrencyId,
			EndBalance,
			LAG(CAST(EndBalance AS DECIMAL(35,2))) OVER (
				PARTITION BY FundId, ShareClassId, PortfolioTypeId, CurrencyId
				ORDER BY to_date(NAVDate, 'MM/dd/yyyy')
			) AS PreviousEndBalance,
			LAG(to_date(NAVDate, 'MM/dd/yyyy')) OVER (
				PARTITION BY FundId, ShareClassId, PortfolioTypeId, CurrencyId
				ORDER BY to_date(NAVDate, 'MM/dd/yyyy')
			) AS PreviousNAVDate
		FROM HoldingsHistory h
		WHERE EndDate = '9999-12-31'
	)

	SELECT ch.FundId,
		ch.ShareClassId,
		ch.NAVDate,
		'9999-12-31' AS LotDate,
		ch.PortfolioTypeId,
		current_date() AS StartDate,
		to_date('12/31/9999', 'MM/dd/yyyy') AS EndDate,
		ch.CurrencyId,
		CAST('0' AS DECIMAL(35,2)) AS OpenBalance,
		SUM(CAST(ch.EndBalance AS DECIMAL(35,2))) AS EndBalance,
		current_timestamp() AS UpdateTimestamp,
		'systemaccount' AS UpdateByHMCUserId,
		CAST(NULL AS DECIMAL(35,2)) AS OpenBalanceUSD,
		CAST(NULL AS DECIMAL(35,2)) AS EndBalanceUSD,
		current_timestamp() AS ETLLoadDateTime,
		CAST(hh.PreviousEndBalance AS DECIMAL(35,2)) AS PreviousEndBalance,
		hh.PreviousNAVDate,
		coalesce(CAST(hh.EndBalance AS DECIMAL(35,2)), 0) AS CurrentEndBalance
	FROM CurrentHoldings ch
		LEFT JOIN HoldingsHistory hh ON hh.FundId = ch.FundId
									AND hh.ShareClassId = ch.ShareClassId
									AND hh.NAVDate = ch.NAVDate
									AND hh.PortfolioTypeId = ch.PortfolioTypeId
									AND hh.CurrencyId = ch.CurrencyId

	GROUP BY ch.FundId,
			ch.ShareClassId,
			ch.NAVDate,
			ch.PortfolioTypeId,
			ch.CurrencyId,
			hh.PreviousEndBalance,
			hh.PreviousNAVDate,
			hh.EndBalance
	""")

#display(dfMarketValues.count())
#dfBlah = dfMarketValues

# Filter out unchanged rows
dfMarketValues = dfMarketValues.filter(
    col("EndBalance") != coalesce(col("CurrentEndBalance"), lit(0.0))
)

display(dfMarketValues.count())


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC     SELECT FundId
# MAGIC 	   , ShareClassId
# MAGIC 	   , NAVDate
# MAGIC 	   , LotDate
# MAGIC 	   , PortfolioTypeId
# MAGIC 	   , StartDate
# MAGIC 	   , EndDate
# MAGIC        , 
# MAGIC 	   , CurrencyId
# MAGIC 	   , OpenBalance
# MAGIC 	   , EndBalance
# MAGIC 	   , UpdateTimestamp
# MAGIC 	   , UpdateByHMCUserId
# MAGIC 	   , OpenBalanceUSD
# MAGIC 	   , EndBalanceUSD
# MAGIC 	   , ETLLoadDateTime
# MAGIC 	   , PreviousEndBalance
# MAGIC 	   , PreviousNAVDate
# MAGIC 	   , CurrentEndBalance
# MAGIC        , LAG(CAST(EndBalance AS DECIMAL(35,2))) 
# MAGIC                                         OVER (PARTITION BY FundId, ShareClassId, PortfolioTypeId, CurrencyId
# MAGIC                                         ORDER BY to_date(NAVDate, 'MM/dd/yyyy')) as CurrentPreviousEndBalance
# MAGIC        , LAG(to_date(NAVDate, 'MM/dd/yyyy')) 
# MAGIC                             OVER (PARTITION BY FundId, ShareClassId, PortfolioTypeId, CurrencyId
# MAGIC                             ORDER BY to_date(NAVDate, 'MM/dd/yyyy')) as CurrentPreviousNAVDate       
# MAGIC     FROM FundMarketValues

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Set the opening date
dfMarketValues.createOrReplaceTempView("FundMarketValues")

dfMarketValues = spark.sql("""
    SELECT FundId
	   , ShareClassId
	   , NAVDate
	   , LotDate
	   , PortfolioTypeId
	   , StartDate
	   , EndDate
	   , CurrencyId
	   , OpenBalance
	   , EndBalance
	   , UpdateTimestamp
	   , UpdateByHMCUserId
	   , OpenBalanceUSD
	   , EndBalanceUSD
	   , ETLLoadDateTime
	   , PreviousEndBalance
	   , PreviousNAVDate
	   , CurrentEndBalance
       , LAG(CAST(EndBalance AS DECIMAL(35,2))) 
                                        OVER (PARTITION BY FundId, ShareClassId, PortfolioTypeId, CurrencyId
                                        ORDER BY to_date(NAVDate, 'MM/dd/yyyy')) as CurrentPreviousEndBalance
       , LAG(to_date(NAVDate, 'MM/dd/yyyy')) 
                            OVER (PARTITION BY FundId, ShareClassId, PortfolioTypeId, CurrencyId
                            ORDER BY to_date(NAVDate, 'MM/dd/yyyy')) as CurrentPreviousNAVDate       
    FROM FundMarketValues
""")

dfMarketValues = dfMarketValues \
    .withColumn("OpenBalance", F.when(col("CurrentPreviousEndBalance").isNotNull(), col("CurrentPreviousEndBalance"))
        .when(col("PreviousEndBalance").isNotNull(), col("PreviousEndBalance"))
        .otherwise(F.lit(0))) \
    .select("FundId"
	   , "ShareClassId"
	   , "NAVDate"
	   , "LotDate"
	   , "PortfolioTypeId"
	   , "StartDate"
	   , "EndDate"
	   , "CurrencyId"
	   , "OpenBalance"
	   , "EndBalance"
	   , "UpdateTimestamp"
	   , "UpdateByHMCUserId"
	   , "OpenBalanceUSD"
	   , "EndBalanceUSD"
	   , "ETLLoadDateTime"
    )

display(dfMarketValues.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(dfMarketValues)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisMarketValues").createOrReplaceTempView("cmv")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisMarketValueHistory").createOrReplaceTempView("smvh")

spark.sql("""
--    MERGE INTO lh_curated.Review.HoldingsHistory AS chh
    MERGE INTO smvh
    USING (SELECT * FROM CurrentMarketValues cmv WHERE to_date(cmv.MvDate, "M/d/yyyy") <= current_date) as cmv
        ON smvh.ResourceId = CAST(cmv.ResourceId AS BIGINT)
            AND smvh.MvDate = to_date(cmv.MvDate, "M/d/yyyy")
            AND smvh.ValueTypeId = CAST(cmv.ValueTypeId AS INT)
            AND smvh.CurrencyId = CAST(cmv.CurrencyId AS INT)
    WHEN MATCHED THEN 
        UPDATE SET
            smvh.UnitPrice = CAST(cmv.UnitPrice AS DECIMAL(38, 10))
            , smvh.Units = CAST(cmv.Units AS DECIMAL(38, 10))
            , smvh.TotalValue = CAST(cmv.TotalValue AS DECIMAL(38, 10))
            , smvh.UpdatedBy = CAST(cmv.UpdatedBy AS INT)
            , smvh.UpdatedAtTimestamp = to_timestamp(cmv.UpdatedAtTimestamp, "yyyy-MM-dd HH:mm:ss.SSSSSS")
    WHEN NOT MATCHED THEN
        INSERT
        (ResourceId, MvDate, UnitPrice, Units, TotalValue, ValueTypeId, UpdatedBy, UpdatedAtTimestamp, CurrencyId)
        VALUES(CAST(cmv.ResourceId AS BIGINT), to_date(cmv.MvDate, "M/d/yyyy"), CAST(cmv.UnitPrice AS DECIMAL(38, 10)), CAST(cmv.Units AS DECIMAL(38, 10)), CAST(cmv.TotalValue AS DECIMAL(38, 10)), CAST(cmv.ValueTypeId AS INT), CAST(cmv.UpdatedBy AS INT), to_timestamp(cmv.UpdatedAtTimestamp, "yyyy-MM-dd HH:mm:ss.SSSSSS"), CAST(cmv.CurrencyId AS INT))
""")

dfsmvh = spark.sql("""SELECT * FROM smvh""")

# Save this off to be SolovisMarketValueHistory
# dfsmvh.write.format("delta") \
#     .mode("overwrite") \
#     .option("overwriteSchema", "true") \
#     .save(f"{bronze_lh_basepath}/Tables/Bronze/SolovisMarketValueHistory")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Write data out to history review table
# Register required Delta tables as temp views using ABFSS paths
#spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Review/HoldingsHistory").createOrReplaceTempView("chh")
#spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Silver/FXRate").createOrReplaceTempView("fx")

dfMarketValues.createOrReplaceTempView("FundMarketValues")

display(dfMarketValues.count())

# Close out all the holdings that will have new values
spark.sql("""
    MERGE INTO lh_curated.Review.FundValuation as chh
    USING FundMarketValues AS fmv
        ON chh.FundId = fmv.FundId
            AND chh.ShareClassId = fmv.ShareClassId
            AND chh.NAVDate = fmv.NAVDate
            AND chh.PortfolioTypeId = fmv.PortfolioTypeId
            AND chh.CurrencyId = fmv.CurrencyId
            AND chh.ValuationDate = DATE('9999-12-31')
            AND chh.NAVDate > DATE('2020-06-30')
    WHEN MATCHED THEN 
        UPDATE SET
        chh.EndDate = fmv.StartDate,
        chh.UpdateTimestamp = fmv.UpdateTimestamp,
        chh.UpdateByHMCUserId = fmv.UpdateByHMCUserId
""")

# Add the new entries
# Kate 3Cloud: I am trying to change IO operations to shift to ABFSS path, this part needs to be rewritten. We cant use abfss with Insert Into
spark.sql("""
INSERT INTO lh_curated.Review.HoldingsHistory
(FundId, ShareClassId, NAVDate, LotDate, PortfolioTypeId, StartDate
	, EndDate, CurrencyId, OpenBalance, EndBalance, UpdateTimestamp
	, UpdateByHMCUserId, OpenBalanceUSD, EndBalanceUSD, ETLLoadDateTime)
SELECT FundId
       , ShareClassId
       , NAVDate
       , LotDate
       , PortfolioTypeId
       , StartDate
	   , EndDate
       , CurrencyId
       , OpenBalance
       , EndBalance
       , UpdateTimestamp
	   , UpdateByHMCUserId
       , OpenBalanceUSD
       , EndBalanceUSD
       , ETLLoadDateTime
FROM FundMarketValues
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Write out the results to Review
spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Review/HoldingsHistory").createOrReplaceTempView("chh")
spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Silver/FXRate").createOrReplaceTempView("fx")

# spark.sql("""DELETE FROM lh_curated.Review.FundMarketValue""")

# spark.sql("""
#     INSERT INTO lh_curated.Review.FundMarketValue
#     (FundId, NAVDate, CurrencyId, OpenBalance, EndBalance, OpenBalanceUSD, EndBalanceUSD)
#     SELECT ch.FundId
#         , ch.NAVDate
#         , ch.CurrencyId
#         , SUM(COALESCE(ch.OpenBalance, 0)) OpenBalance
#         , SUM(COALESCE(ch.EndBalance, 0)) EndBalance
#         , SUM(COALESCE(ch.OpenBalance, 0) * COALESCE(fx.FXRate, fxc.FXRate)) OpenBalanceUSD
#         , SUM(COALESCE(ch.EndBalance, 0) * COALESCE(fx.FXRate, fxc.FXRate)) EndBalanceUSD
#     FROM lh_bronze.Bronze.CrimsonXHoldingsHistory ch
#             LEFT JOIN lh_curated.Silver.FXRate fx ON ch.CurrencyId = fx.CurrencyId
#                                                         AND ch.NAVDate = fx.FXDate
#             LEFT JOIN (SELECT fx1.CurrencyId
#                             , last_day(fx1.FXDate) FXDate
#                             , fx1.FXRate
#                     FROM lh_curated.Silver.FXRate fx1
#                                 JOIN (SELECT CurrencyId
#                                             , MAX(FXDate) FXDate
#                                     FROM lh_curated.Silver.FXRate
#                                     GROUP BY CurrencyId) fx2 ON fx1.CurrencyId = fx2.CurrencyId
#                                                                     AND fx1.FXDate = fx2.FXDate) fxc ON fxc.CurrencyId = ch.CurrencyId
#                                                                                                             AND fxc.FXDate = ch.NAVDate
#     WHERE ch.EndDate = to_date('12/31/9999', 'MM/dd/yyyy')
#     GROUP BY ch.FundId
#         , ch.NAVDate
#         , ch.CurrencyId
# """)


dfFundMV = spark.sql("""
    SELECT chh.FundId
        , chh.NAVDate
        , chh.CurrencyId
        , SUM(COALESCE(chh.OpenBalance, 0)) OpenBalance
        , SUM(COALESCE(chh.EndBalance, 0)) EndBalance
        , SUM(COALESCE(chh.OpenBalance, 0) * COALESCE(fx.FXRate, fxc.FXRate)) OpenBalanceUSD
        , SUM(COALESCE(chh.EndBalance, 0) * COALESCE(fx.FXRate, fxc.FXRate)) EndBalanceUSD
    FROM chh
            LEFT JOIN fx ON chh.CurrencyId = fx.CurrencyId
                          AND chh.NAVDate = fx.FXDate
            LEFT JOIN (
                SELECT fx1.CurrencyId
                     , last_day(fx1.FXDate) FXDate
                     , fx1.FXRate
                FROM fx fx1
                         JOIN (SELECT CurrencyId
                                     , MAX(FXDate) FXDate
                               FROM fx
                               GROUP BY CurrencyId) fx2 
                               ON fx1.CurrencyId = fx2.CurrencyId
                               AND fx1.FXDate = fx2.FXDate
            ) fxc ON fxc.CurrencyId = chh.CurrencyId
                  AND fxc.FXDate = chh.NAVDate
    WHERE chh.EndDate = to_date('12/31/9999', 'MM/dd/yyyy')
    GROUP BY chh.FundId
           , chh.NAVDate
           , chh.CurrencyId
""")

# Write to the same destination table
dfFundMV.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("lh_curated.Review.FundMarketValue")


# dfReview = spark.table("lh_curated.Review.FundMarketValue")

# display(dfReview.count())



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Write review data
# dfReviewMarketValue = spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Review/FundMarketValue")
# dfHoldingsHistory = spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Review/HoldingsHistory")
# dfReviewMarketValue = spark.table("lh_curated.Review.FundMarketValue")

# dfReviewMarketValue.write.format("delta") \
#     .mode("overwrite") \
#     .option("overwriteSchema", "true") \
#     .saveAsTable("lh_curated.Silver.FundMarketValue")

# spark.sql("REFRESH TABLE lh_curated.Silver.FundMarketValue")
# spark.sql("SELECT COUNT(*) FROM lh_curated.Silver.FundMarketValue").show()  

# dfHoldingsHistory = spark.table("lh_curated.Review.HoldingsHistory")

# dfHoldingsHistory.write.format("delta") \
#     .mode("overwrite") \
#     .option("overwriteSchema", "true") \
#     .saveAsTable("lh_bronze.Bronze.CrimsonXHoldingsHistory")    

# dfMarketValues.write.format("delta") \
#     .mode("overwrite") \
#     .option("overwriteSchema", "true") \
#     .saveAsTable("lh_bronze.Bronze.SolovisDailyLoadMarketValues")    

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# dtProcessFundChanges = DeltaTable.forPath(spark, f"{bronze_lh_basepath}/Tables/Bronze/ProcessFundChanges")

# dfMarketValues = spark.sql("select FundId, current_timestamp as ETLLoadDateTime from lh_bronze.Bronze.SolovisDailyLoadTransactions")

# dtProcessFundChanges.alias("target") \
#     .merge(dfMarketValues.select("FundId","ETLLoadDateTime").distinct().alias("source"), "target.FundId = source.FundId") \
#     .whenMatchedUpdateAll() \
#     .whenNotMatchedInsertAll() \
#     .execute()

# display(dfMarketValues.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# spark.sql(""" DROP TABLE lh_curated.Review.FundMarketValue """)

# spark.sql("""
#     CREATE TABLE lh_curated.Review.FundMarketValue (
#         FundId VARCHAR(36) NOT NULL
#         , NAVDate DATE NOT NULL
#         , CurrencyId INT NOT NULL
#         , OpenBalance DECIMAL(35, 2) NOT NULL
#         , EndBalance DECIMAL(35, 2) NOT NULL
#         , OpenBalanceUSD DECIMAL(35, 2) NOT NULL
#         , EndBalanceUSD DECIMAL(35, 2) NOT NULL
#     )
# """)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Maintain Holdings history
# spark.conf.set('spark.sql.caseSensitive', True)
# dfHoldings = spark.sql("""
#     SELECT FundId
# 	   , ShareClassId
# 	   , NAVDate
# 	   , LotDate
# 	   , PortfolioTypeId
# 	   , StartDate
# 	   , EndDate
# 	   , CurrencyId
# 	   , OpenBalance
# 	   , EndBalance
# 	   , UpdateTimestamp
# 	   , UpdateByHMCUserId
# 	   , OpenBalanceUSD
# 	   , EndBalanceUSD
# 	   , ETLLoadDateTime
#     FROM lh_bronze.Bronze.CrimsonXHoldings
# """)

# dfHoldings.write.format("delta") \
#     .mode("overwrite") \
#     .option("overwriteSchema", "true") \
#     .saveAsTable("lh_bronze.Bronze.CrimsonXHoldingsHistory")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # Initialize configurations

# from pyspark.sql import functions as F
# from pyspark.sql.types import DecimalType, IntegerType, DateType, BooleanType, LongType, TimestampType, ShortType, StringType
# from pyspark.sql import Window

# spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_bronze")

# spark.sql("SET spark.sql.caseSensitive = TRUE")


# # get the marketvalues and valuetype id based on the hierarchy actual,estimate,computed estimate
# market_value_df  = spark.sql("""WITH valuetype as (
#                                 SELECT * from (
#                                 SELECT ResourceId, ValueTypeId,to_date(MvDate,"M/d/yyyy") as MvDate ,TotalValue,CurrencyId,
#                                 DENSE_RANK() OVER(PARTITION BY ResourceId,to_date(MvDate,"M/d/yyyy")  ORDER BY to_date(MvDate,"M/d/yyyy") DESC,ValueTypeId DESC) as rn
#                                 FROM lh_bronze.Bronze.SolovisMarketValues
#                                 ) a
#                                 WHERE a.rn <= 3)
#                                 SELECT  ResourceId, MvDate,TotalValue,CurrencyId,lower(f.FundId) as FundId,fd.ShareClassId
#                                 CASE WHEN vt.ValueTypeId  = 127 THEN 127
#                                      WHEN vt.ValueTypeId  = 64  THEN 64
#                                      ELSE 16
#                                 END ValueTypeId  
#                                 FROM valuetype vt ,lh_bronze.Bronze.SolovisActiveBookFundMapping fd ,lh_bronze.Bronze.CrimsonXFund f
#                                 where vt.ResourceId = fd..InvestmentResourceId AND vt.rn=1  AND upper(fd.FundId) = upper(f.FundId) 
#                                """)

# market_value_df = market_value_df.filter(
#     (F.to_date(F.col("MvDate"), "M/d/yyyy") >= F.trunc(F.current_date(), "month")) &
#     (F.to_date(F.col("MvDate"), "M/d/yyyy") <= F.last_day(F.current_date()))
# )
                     



# # Get Holdings data

# holdings_df = spark.sql("""SELECT lower(h.FundId) as FundId,PortfolioTypeId,OpenBalance,EndBalance,NAVDate,StartDate
#                       FROM  lh_curated.Silver.FundMarketValues h
#                       WHERE NAVDate > '2020-05-31' order by FundId,NAVDate desc""").filter( F.col("NAVDate") > F.trunc(F.add_months(F.current_date(), -1), "month"))

# #display(holdings_df)

# holdings_df = holdings_df.join(market_value_df,on="FundId", how = "inner" )

                   
# windowClause = Window.partitionBy("FundId","ShareClassId","ResourceId" ).orderBy("NAVDate")



# # Add open balance and end balance column to funds - Inter-month:

# #Update old record for inter-month (between second day of the month and less than or equal to last day of the month) and endbalance !=Totalvalue

# holdings_inter_month_updated = holdings_df.withColumn(
#     "EndDate",
#     F.when(F.col("MvDate") <= (F.last_day(F.current_date() & F.col("EndBalance") != F.col("TotalValue") )), (F.current_date())
# )).filter(
#     (F.col("MvDate") <= F.last_day(F.current_date())) &
#     (F.col("MvDate") != F.trunc(F.col("MvDate"), "month"))
# )

# #display(holdings_inter_month_updated)

# # create new record

# holdings_inter_month = holdings_df.withColumn("OpenBalance",
#          F.when(F.col("MvDate") <= (F.last_day(F.current_date() & F.col("EndBalance") != F.col("TotalValue") )),
#          F.coalesce(F.lag("EndBalance").over(windowClause), F.lit(0))
#     )).filter(
#     (F.col("MvDate") <= F.last_day(F.current_date())) &
#     (F.col("MvDate") != F.trunc(F.col("MvDate"), "month")))

# holdings_inter_month = holdings_inter_month.withColumn("EndBalance",
#                                           F.when(F.col("MvDate") <= (F.last_day(F.current_date() & F.col("EndBalance") != F.col("TotalValue") )), 
#                                           F.coalesce(F.col("TotalValue"), F.lit(0)).cast(DecimalType(32, 2)))).filter(
#     (F.col("MvDate") <= F.last_day(F.current_date())) &
#     (F.col("MvDate") != F.trunc(F.col("MvDate"), "month"))
# )

# holdings_inter_month = holdings_inter_month.withColumn("StartDate",F.when(F.col("MvDate") <= (F.last_day(F.current_date() & F.col("EndBalance") != F.col("TotalValue") )), 
#  F.lit( F.current_date()))).filter(
#     (F.col("MvDate") < F.last_day(F.current_date())) &
#     (F.col("MvDate") != F.trunc(F.col("MvDate"), "month"))
# )
# holdings_inter_month = holdings_inter_month.withColumn("EndDate",F.when(F.col("MvDate") <= (F.last_day(F.current_date() & F.col("EndBalance") != F.col("TotalValue") )),
#  F.lit("9999-12-31"))).filter(
#     (F.col("MvDate") <= F.last_day(F.current_date())) &
#     (F.col("MvDate") != F.trunc(F.col("MvDate"), "month"))
# )


# if holdings_inter_month.count > 0:

#     holdings_inter_month = holdings_inter_month.filter(F.col("OpenBalance") > 0)

#     holdings_inter_month = holdings_inter_month.unionByName(holdings_inter_month_updated)


# #display(holdings_inter_month)


# # Add open balance and end balance column to funds - New month:

# holdings_new_month = holdings_df.withColumn(
#         "OpenBalance",
#         F.coalesce(F.lag("EndBalance").over(windowClause), F.lit(0))
#     ).filter(F.col("MvDate") ==  F.trunc(F.current_date(), "month"))


# holdings_new_month = holdings_new_month.withColumn("EndBalance", F.coalesce(F.col("TotalValue"), F.lit(0)).cast(DecimalType(32, 2))).filter(F.col("MvDate") ==  F.trunc(F.current_date(), "month"))

# holdings_new_month = holdings_new_month.withColumn(
#         "StartDate", F.lit( F.trunc(F.current_date(), "month"))).filter(F.col("MvDate") == F.trunc(F.current_date(), "month"))

# holdings_new_month = holdings_new_month.withColumn(
#         "EndDate", F.lit("9999-12-31")).filter(F.col("MvDate") ==  F.trunc(F.current_date(), "month"))


   

# #display(holdings_new_month)

# if holdings_inter_month.count > 0 or holdings_new_month.count > 0:

#     holdings_merge_df = holdings_inter_month.unionByName(holdings_new_month)


#     # display(holdings_inter_month)

#     fxrate_df =  spark.sql(""" select CurrencyId,FXRate 
#                             from lh_curated.Silver.FXRate
#                             where FXDate = (select max(FXDate) from lh_curated.Silver.FXRate )  """)

#     holdings_merge_df = holdings_merge_df.join(fxrate_df,on="CurrencyId", how = "left" ).select(*holdings_merge_df.columns,fxrate_df.FXRate)                           

#     holdings_merge_df = holdings_merge_df.withColumn(
#         "OpenBalanceUSD",
#         F.col("OpenBalance") * F.col("FXRate"))\
#     .withColumn(
#         "EndBalanceUSD",
#         F.col("EndBalance") * F.col("FXRate"))



#     holdings_merge_df = holdings_merge_df.drop("MvDate","TotalValue","ValueTypeId","InvestmentId","ResourceId","FXRate")
        
#     #display(holdings_inter_month)


#     # aggregate openbalance,endbalance for the NavDate

#     holdings_merge_df = holdings_merge_df.groupBy(["FundId","ShareClassId","NAVDate","PortfolioTypeId","CurrencyId"]).agg(
#         F.sum("OpenBalance").alias("OpenBalance"),
#         F.sum("EndBalance").alias("EndBalance"),
#         F.sum("OpenBalanceUSD").alias("OpenBalanceUSD"),
#         F.sum("EndBalanceUSD").alias("EndBalanceUSD")
#     )

#     holdings_merge_df = holdings_merge_df.withColumn("LotDate", F.lit(F.last_day(F.current_date()))) \
#                                         .withColumn("NAVDate", F.lit(F.last_day(F.current_date()))) \
#                                                 .withColumn("UpdateTimestamp", F.lit(F.current_timestamp()))\
#                                                 .withColumn("UpdateByHMCUserId", F.lit("EMS SYSTEM"))\
#                                                 .withColumn("ETLLoadDateTime", F.lit(F.current_timestamp()))

#     display(holdings_merge_df )


#     # Merge into holdings table
#     holdings = spark.table("lh_curated.Silver.Holdings")

#     holdings.alias("target").merge(
#         holdings_merge_df.alias("source"),
#         """target.FundId = source.FundId
#                 AND target.ShareClassId = source.ShareClassId
#                 AND target.NAVDate = source.NAVDate""") \
#         .whenMatchedUpdateAll() \
#         .whenNotMatchedInsertAll() \
#         .execute()




# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_bronze")
# spark.sql("SET spark.sql.caseSensitive = TRUE")


# df = spark.sql("""SELECT *
#                       FROM  lh_bronze.Bronze.CrimsonXHoldings """)

# lakehousePath = "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465"
# tableName = "FundMarketValues" 

# deltaTablePath = f"{lakehousePath}/Tables/Silver/{tableName}" 

# df.write.format("delta").mode("overwrite").save(deltaTablePath)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
