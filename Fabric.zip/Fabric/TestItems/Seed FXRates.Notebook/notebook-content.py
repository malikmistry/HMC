# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from delta.tables import DeltaTable
from pyspark.sql import functions as F
from pyspark.sql.types import DecimalType, IntegerType, DateType, BooleanType, LongType, TimestampType, ShortType, StringType
from pyspark.sql import Window

# Get the max CashflowTransactionDetailId
max_id_df = spark.sql("SELECT MAX(FXRateId) AS max_id FROM lh_curated.Silver.FXRate")
max_id = max_id_df.collect()[0]["max_id"]
max_id = max_id if max_id is not None else 0  # Default to 0 if table is empty
window_spec = Window.orderBy(F.lit(1))
dtFXRate = DeltaTable.forPath(spark, "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465/Tables/Silver/FXRate")

dfCurrencyRate = spark.table("lh_bronze.Bronze.CrimsonXCurrencyRate") \
    .withColumn(
            "CurrencyRateId",
            (F.row_number().over(window_spec) + max_id).cast(LongType())) \
    .select("CurrencyRateId","CurrencyId","CurrencyRateDate","CurrencyRate")

dfCurrencyRate = dfCurrencyRate \
    .withColumnRenamed("CurrencyRateId", "FXRateId") \
    .withColumnRenamed("CurrencyRateDate", "FXDate") \
    .withColumnRenamed("CurrencyRate", "FXRate") \
    .withColumn("ETLLoadDateTime", F.current_timestamp())

#display(dfCurrencyRate)
display(dfCurrencyRate.count())

dtFXRate.alias("target").merge(
    dfCurrencyRate.alias("source"),
    """target.CurrencyId = source.CurrencyId
            AND target.FXDate = source.FXDate""") \
    .whenMatchedUpdateAll() \
    .whenNotMatchedInsertAll() \
    .execute()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from delta.tables import DeltaTable
from pyspark.sql import functions as F
from pyspark.sql.types import DecimalType, IntegerType, DateType, BooleanType, LongType, TimestampType, ShortType, StringType
from pyspark.sql import Window

dfRecentFXRate = spark.sql("""SELECT * FROM lh_curated.Silver.FXRate WHERE FXDate = '2025-09-11'""")
dfRecentFXRate = dfRecentFXRate \
    .withColumn("FXDate", F.to_date(F.lit("2025-09-13")))

display(dfRecentFXRate)

# # Get the max FXRate
# max_id_df = spark.sql("SELECT MAX(FXRateId) AS max_id FROM lh_curated.Silver.FXRate")
# max_id = max_id_df.collect()[0]["max_id"]
# max_id = max_id if max_id is not None else 0  # Default to 0 if table is empty
# window_spec = Window.orderBy(F.lit(1))
dtFXRate = DeltaTable.forPath(spark, "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465/Tables/Silver/FXRate")

# dfCurrencyRate = spark.table("lh_bronze.Bronze.CrimsonXCurrencyRate") \
#     .withColumn(
#             "CurrencyRateId",
#             (F.row_number().over(window_spec) + max_id).cast(LongType())) \
#     .select("CurrencyRateId","CurrencyId","CurrencyRateDate","CurrencyRate")

# dfCurrencyRate = dfCurrencyRate \
#     .withColumnRenamed("CurrencyRateId", "FXRateId") \
#     .withColumnRenamed("CurrencyRateDate", "FXDate") \
#     .withColumnRenamed("CurrencyRate", "FXRate") \
#     .withColumn("ETLLoadDateTime", F.current_timestamp())

# #display(dfCurrencyRate)
# display(dfCurrencyRate.count())

dtFXRate.alias("target").merge(
    dfRecentFXRate.alias("source"),
    """target.CurrencyId = source.CurrencyId
            AND target.FXDate = source.FXDate""") \
    .whenMatchedUpdateAll() \
    .whenNotMatchedInsertAll() \
    .execute()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
