# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

# tasklist = json.loads(f"[{TaskList}]")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

lh_bronze_basepath = get_basepath(WorkspaceId, BronzeLHId)
lh_curated_basepath = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # SQL query
# def process_task(task):
#   df  = spark.sql("""
#   SELECT DISTINCT f.FundId, f.FundClassificationId as ClassificationId
#         , c.Description AS AssetClass
#         , c1.Description AS Strategy
#         , c2.Description AS SubStrategy
#   FROM (
#       SELECT f.FundId
#             , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN fcm.Level1ClassificationId ELSE ecm.Level1ClassificationId END AS Level1ClassificationId
#             , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN fcm.Level2ClassificationId ELSE ecm.Level2ClassificationId END AS Level2ClassificationId
#             , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN fcm.Level3ClassificationId ELSE ecm.Level3ClassificationId END AS Level3ClassificationId
#             , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN coalesce(fcm.Level3ClassificationId, coalesce(fcm.Level2ClassificationId, fcm.Level1ClassificationId))
#                     ELSE coalesce(ecm.Level3ClassificationId, coalesce(ecm.Level2ClassificationId, ecm.Level1ClassificationId)) END AS FundClassificationId
#       FROM Bronze.CrimsonXFund f
#           JOIN Bronze.CrimsonXClassificationMap AS ecm
#             ON f.EntityId = ecm.HMCObjectId AND ecm.EndDate IS NULL
#           LEFT JOIN Bronze.CrimsonXClassificationMap AS fcm
#             ON f.FundId = fcm.HMCObjectId AND fcm.EndDate IS NULL
#   ) f
#   JOIN lh_bronze.Bronze.CrimsonXClassification AS c
#     ON c.ClassificationId = f.Level1ClassificationId
#   LEFT JOIN lh_bronze.Bronze.CrimsonXClassification AS c1
#     ON c1.ClassificationId = f.Level2ClassificationId
#   LEFT JOIN lh_bronze.Bronze.CrimsonXClassification AS c2
#     ON c2.ClassificationId = f.Level3ClassificationId
#   """)

#   # lakehousePath = "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465"
#   # tableName = "Classification" 
#   target_table = task['SinkTableName']

#   deltaTablePath = f"{lh_curated_basepath}/Tables/Silver/{target_table}" 

#   df.write.format("delta").mode("overwrite").save(deltaTablePath)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def process_task():
    df = spark.sql(f"""
    WITH FundWithClassification AS (
        SELECT f.FundId
            , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN fcm.Level1ClassificationId ELSE ecm.Level1ClassificationId END AS Level1ClassificationId
            , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN fcm.Level2ClassificationId ELSE ecm.Level2ClassificationId END AS Level2ClassificationId
            , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN fcm.Level3ClassificationId ELSE ecm.Level3ClassificationId END AS Level3ClassificationId
            , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN coalesce(fcm.Level3ClassificationId, coalesce(fcm.Level2ClassificationId, fcm.Level1ClassificationId))
                    ELSE coalesce(ecm.Level3ClassificationId, coalesce(ecm.Level2ClassificationId, ecm.Level1ClassificationId)) END AS FundClassificationId
        FROM delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXFund` f
        JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXClassificationMap` AS ecm
          ON f.EntityId = ecm.HMCObjectId AND ecm.EndDate IS NULL
        LEFT JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXClassificationMap` AS fcm
          ON f.FundId = fcm.HMCObjectId AND fcm.EndDate IS NULL
    ),
    ClassificationDescriptions AS (
        SELECT c.ClassificationId, c.Description AS AssetClass
        FROM delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXClassification` c
    ),
    BudgetStrategyMap AS (
        SELECT DISTINCT
            bcm.BudgetStrategyId,
            CASE 
              WHEN cst.ParentClassificationId = 0 AND cst.ClassificationLevelId = 1 THEN cst.Description
              ELSE cac.Description 
            END AS AssetClass,
            CASE 
              WHEN cac.ParentClassificationId IS NULL AND cac.ClassificationLevelId IS NULL THEN NULL
              ELSE cst.Description
            END AS Strategy
        FROM delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXBudgetStrategyClassificationMap` bcm
        LEFT JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXClassification` cst ON cst.ClassificationId = bcm.ClassificationId
        LEFT JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXClassification` cac ON cac.ClassificationId = cst.ParentClassificationId AND cac.ClassificationLevelId > 0
    )

    SELECT DISTINCT
        f.FundId,
        f.FundClassificationId AS ClassificationId,
        ac.AssetClass,
        st.AssetClass AS Strategy,
        ss.AssetClass AS SubStrategy,
        CASE 
            WHEN bs.IsCoinvest = true THEN CASE 
                WHEN bsm.BudgetStrategyId = 3 THEN 4
                WHEN bsm.BudgetStrategyId = 5 THEN 6
                WHEN bsm.BudgetStrategyId IN (9,10) THEN 14
                WHEN bsm.BudgetStrategyId = 11 THEN 15
                WHEN bsm.BudgetStrategyId = 16 THEN 18
                WHEN bsm.BudgetStrategyId = 17 THEN 22
                WHEN bsm.BudgetStrategyId = 20 THEN 21
                ELSE bsm.BudgetStrategyId
            END
            ELSE bsm.BudgetStrategyId
        END AS BudgetStrategyId,
        CASE 
            WHEN bs.IsCoinvest = true THEN CASE 
                WHEN bsm.BudgetStrategyId = 3 THEN 'PE, Buyout Coinvest'
                WHEN bsm.BudgetStrategyId = 5 THEN 'PE, Venture Coinvest'
                WHEN bsm.BudgetStrategyId IN (9,10) THEN 'RE, Coinvest'
                WHEN bsm.BudgetStrategyId = 11 THEN 'Energy Co-invest'
                WHEN bsm.BudgetStrategyId = 16 THEN 'PE, Growth Coinvest'
                WHEN bsm.BudgetStrategyId = 17 THEN 'PE Growth Venture Coinvest'
                WHEN bsm.BudgetStrategyId = 20 THEN 'Climate Transition Coinvest'
                ELSE bs.Description
            END
            ELSE bs.Description
        END AS BudgetStrategy
    FROM FundWithClassification f
    LEFT JOIN ClassificationDescriptions ac ON ac.ClassificationId = f.Level1ClassificationId
    LEFT JOIN ClassificationDescriptions st ON st.ClassificationId = f.Level2ClassificationId
    LEFT JOIN ClassificationDescriptions ss ON ss.ClassificationId = f.Level3ClassificationId
    LEFT JOIN BudgetStrategyMap bsm 
        ON ac.AssetClass = bsm.AssetClass AND (bsm.Strategy IS NULL OR COALESCE(bsm.Strategy, '') = COALESCE(st.AssetClass, ''))
    LEFT JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXBudgetStrategy` bs ON bs.BudgetStrategyId = bsm.BudgetStrategyId
    JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXFund` fnd ON fnd.FundId = f.FundId
    WHERE fnd.FundStructureId <> 0
    """)

    df = df.withColumn("ETLLoadDataTime", F.lit(etlloadtime))
    print(df.count())

    # target_table = task['SinkTableName']
    target_table = 'Classification'
    deltaTablePath = f"{lh_curated_basepath}/Tables/Silver/{target_table}"
    df.write.format("delta").mode("overwrite").save(deltaTablePath)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

result = process_task()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# for task_item in tasklist:
#     result = process_task(task_item)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#----------- Set the namespace for the Lakehouse
# spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_curated")
# #-----------
# spark.sql("SET spark.sql.caseSensitive = TRUE")
# spark.sql("drop table  lh_curated.Silver.Classification")
# spark.sql("Create table lh_curated.Silver.Classification(FundId VARCHAR(5000),ClassificationId INTEGER,AssetClass VARCHAR(5000),Strategy VARCHAR(5000),SubStrategy VARCHAR(5000)) ")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
