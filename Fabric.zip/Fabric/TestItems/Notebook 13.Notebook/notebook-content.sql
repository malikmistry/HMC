-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "synapse_pyspark"
-- META   },
-- META   "dependencies": {
-- META     "lakehouse": {
-- META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
-- META       "default_lakehouse_name": "lh_curated",
-- META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
-- META       "known_lakehouses": [
-- META         {
-- META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
-- META         },
-- META         {
-- META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- CELL ********************

---GET NB READY


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--Fund Valuation Active Book

WITH 
ActiveBookFundMapping (FundId, ActiveBookType) as (
    select FundId, ActiveBookType from lh_bronze.Bronze.SolovisActiveBookFundMapping
    group by FundId, ActiveBookType
),
LatestValuation AS (
  SELECT
    FundId,
    NAVDate,
    ValuationDate,
    ValuationTypeId,
    ValuationAmountUSD,
    ROW_NUMBER() OVER (
      PARTITION BY FundId
      ORDER BY NAVDate DESC, ValuationDate DESC
    ) AS rn
  FROM lh_curated.Review.FundValuation
),
AggregateValuationUSD AS (
  SELECT
    FundId,
    SUM(ValuationAmountUSD) AS ValuationAmountUSD,
    ValuationDate,
    ValuationTypeId
  FROM LatestValuation
  WHERE rn = 1
  GROUP BY FundId, ValuationDate, ValuationTypeId
),
AssetClassGIAMatch AS (
  SELECT
    ActiveBookType,
    sea.FundIdCrimsonX AS FundId,
    FundName,
    Asset,
    SUM(CAST(ivb.Total_Value as DECIMAL(38,2))) AS SolovisValuationAmount,
    SUM(CAST(ValuationAmountUSD AS DECIMAL(38,2))) AS HMCValuationAmount
  FROM lh_bronze.Bronze.SolovisInternalValuationBaskets ivb
  JOIN lh_bronze.Bronze.SolovisExternalActiveBook sea
    ON UPPER(sea.AssetClassGIA) = UPPER(ivb.Asset)
  JOIN lh_curated.Silver.Fund f
    ON f.FundId = sea.FundIdCrimsonX
  JOIN AggregateValuationUSD fv
    ON fv.FundId = sea.FundIdCrimsonX
  JOIN ActiveBookFundMapping abfm on abfm.FundId = f.FundId
  WHERE CAST(ivb.Total_Value as DECIMAL(38,2)) <> 0
    AND ivb.Date = (select max(Date) from lh_bronze.Bronze.SolovisInternalValuationBaskets)
  GROUP BY FundIdCrimsonX, FundName, Asset, ActiveBookType
), 
FundNameMatch AS (
  SELECT
    ActiveBookType,
    f.FundId,
    FundName,
    ivb.Asset,
    ivb.Total_Value as SolovisValuationAmount,
    ValuationAmountUSD AS HMCValuationAmount
  FROM lh_bronze.Bronze.SolovisInternalValuationBaskets ivb
  JOIN lh_curated.Silver.Fund f
    ON UPPER(ivb.Asset) = UPPER(f.FundName)
    AND f.FundId NOT IN (SELECT FundId FROM AssetClassGIAMatch)
  JOIN AggregateValuationUSD fv
    ON fv.FundId = f.FundId
  JOIN ActiveBookFundMapping abfm on abfm.FundId = f.FundId
  WHERE CAST(ivb.Total_Value as DECIMAL(38,2)) <> 0
    AND fv.ValuationTypeId IN (1,2)
    AND ivb.Date = (select max(Date) from lh_bronze.Bronze.SolovisInternalValuationBaskets)
),
Mismatch AS (
  SELECT
    'Not in Crimson' AS ActiveBookType,
    NULL AS FundId,
    'Missing' AS FundName,
    ivb.Asset,
    ivb.Total_Value as SolovisValuationAmount,
    NULL AS HMCValuationAmount
  FROM lh_bronze.Bronze.SolovisInternalValuationBaskets ivb
  LEFT JOIN FundNameMatch fnm ON ivb.Asset = fnm.Asset
  LEFT JOIN AssetClassGIAMatch acgm ON acgm.Asset = ivb.Asset
  WHERE fnm.Asset IS NULL
    AND acgm.Asset IS NULL
    AND ivb.Asset NOT LIKE '%Offset%'
    AND ivb.Asset NOT LIKE '%(Fin. Costs)%'
    AND CAST(ivb.Total_Value as DECIMAL(38,2)) <> 0
    AND Cast(ivb.Date as date) = cast('2025-10-16' as date)
), final as (
select 'Fund Valuation Active Book' as Recon, *, SolovisValuationAmount - HMCValuationAmount as Diff from FundNameMatch
UNION
select 'Fund Valuation Active Book' as Recon, *, SolovisValuationAmount - HMCValuationAmount as Diff from AssetClassGIAMatch
UNION
select 'Fund Valuation Active Book' as Recon, *, SolovisValuationAmount as Diff from Mismatch)
SELECT
    CAST(Recon AS String) as Recon,
    CAST(ActiveBookType AS String) as ActiveBookType,
    CAST(lower(FundId) as String) as FundId,
    CAST(FundName as String) as FundName,
    CAST(Asset as String) as Asset,
    CAST(SolovisValuationAmount  as DECIMAL(38,2)) as SolovisValuationAmount,
    CAST(HMCValuationAmount as DECIMAL(38,2)) as HMCValuationAmount,
    CAST(Diff as DECIMAL(38,2)) as Diff
From final 



-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

CREATE TABLE IF NOT EXISTS lh_curated.Review.ReconFundValuationActiveBook (
Recon String,
ActiveBookType String,
FundId String,
FundName String,
Asset String,
SolovisValuationAmount Decimal(38,2),
HMCValuationAmount Decimal(38,2),
Diff  Decimal(38,12),
ETLLoadDateTime TIMESTAMP NOT NULL
)



-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT
    CAST(fc.FundId AS STRING) AS FundId,
    CAST(cr.Entity_Import_Code AS STRING) AS EntityImportCode,
    CAST(fc.NAVDate AS DATE) AS NAVDate,
    CAST(cr.Total_Value AS DECIMAL(38, 11)) AS SolovisMarketValue,
    CAST(fc.EndBalance AS DECIMAL(38, 11)) AS CrimsonMarketValue,
    CAST(cr.Total_Value AS DECIMAL(38, 11)) - CAST(fc.EndBalance AS DECIMAL(38, 11)) AS Difference
FROM
    Bronze.SolovisReconGIAHoldings AS cr
    JOIN Bronze.SolovisEntities AS se
        ON se.ImportCode = cr.Entity_Import_Code
    LEFT JOIN Review.FundMarketValue AS fc
        ON LOWER(fc.FundId) = LOWER(se.CrimsonFundId)
        AND CAST(fc.NAVDate AS DATE) = LAST_DAY(CURRENT_DATE())
WHERE
    COALESCE(cr.Entity_Import_Code, '') <> ''
    AND (
        (fc.FundId IS NULL AND CAST(cr.Total_Value AS DECIMAL(38, 11)) <> 0)
        OR ABS(
            CAST(cr.Total_Value AS DECIMAL(38, 11)) - CAST(fc.EndBalance AS DECIMAL(38, 11))
        ) > 1
    )
    AND cr.Entity_Import_Code RLIKE '^[0-9]+$';




-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

-- ReconFundMarketValue

SELECT
    CAST(fc.FundId AS STRING) AS FundId,
    CAST(cr.Entity_Import_Code AS STRING) AS EntityImportCode,
    CAST(fc.NAVDate AS DATE) AS NAVDate,
    CAST(cr.Total_Value AS DECIMAL(38,11)) AS SolovisMarketValue,
    CAST(fc.EndBalance AS DECIMAL(38,11)) AS CrimsonMarketValue,
    CAST(cr.Total_Value AS DECIMAL(38,11)) - CAST(fc.EndBalance AS DECIMAL(38,11)) AS Difference
FROM
    lh_bronze.Bronze.SolovisReconGIAHoldings cr
    JOIN lh_bronze.Bronze.SolovisEntities se
        ON se.ImportCode = cr.Entity_Import_Code
    LEFT JOIN lh_curated.Review.FundMarketValue fc
        ON LOWER(fc.FundId) = LOWER(se.CrimsonFundId)
        AND CAST(fc.NAVDate AS DATE) = LAST_DAY(CURRENT_DATE())
WHERE
    COALESCE(cr.Entity_Import_Code, '') <> ''
    AND (
        (fc.FundId IS NULL AND CAST(cr.Total_Value AS DECIMAL(38,11)) <> 0)
        OR ABS(
            CAST(cr.Total_Value AS DECIMAL(38,11)) - CAST(fc.EndBalance AS DECIMAL(38,11))
        ) > 1
    )
    AND cr.Entity_Import_Code RLIKE '^[0-9]+$'


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }
