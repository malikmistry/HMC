-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "synapse_pyspark"
-- META   },
-- META   "dependencies": {
-- META     "lakehouse": {
-- META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
-- META       "default_lakehouse_name": "lh_curated",
-- META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
-- META       "known_lakehouses": [
-- META         {
-- META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
-- META         },
-- META         {
-- META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- CELL ********************



CREATE TABLE IF NOT EXISTS lh_curated.Silver.HMCFinancial (
 FirmId varchar(144) not null,
 TotalAUMUSD decimal(38,2) not null,
 TotalCashUSD decimal(38,2) not null,
 AsOfDate date not null,
 ETLLoadDateTime TIMESTAMP not NULL
);


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

       with cte as (
         SELECT
                                FundId,
                                RedemptionDate,
                                NoticeDate,
                                ContractualRedemptionFrequencyTypeId,
                                SUM(RedemptionAmountLocal) AS RedemptionAmountLocal,
                                SUM(RedemptionAmountUSD) AS RedemptionAmountUSD,
                                CurrencyId,
                                LiquidityOptionId,
                                ReceiptDate,
                                MAX(Comment) AS Comment,
                                MAX(ETLLoadDateTime) AS ETLLoadDateTime
                            FROM
                                Silver.ShareClassLiquidityTermSchedule
                            GROUP BY
                                FundId,
                                RedemptionDate,
                                NoticeDate,
                                ContractualRedemptionFrequencyTypeId,
                                CurrencyId,
                                LiquidityOptionId,
                                ReceiptDate )

                                

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


                SELECT ftty.Description AS FundTradeType
                       ,fts.Description AS FundTradeStatus
                       ,ft.VerbalCommitmentDate
                       ,ft.CommitmentDate
                       ,CAST(ft.TradeAmountLocal * 1000000 AS DECIMAL(38,2)) AS TradeAmountLocal
                       ,CAST((CAST(ft.TradeAmountLocal * 1000000 AS DECIMAL(38,2)) * fx.FXRate) AS DECIMAL(38,2)) AS TradeAmountUSD
                       ,C.CurrencyId
                       ,ft.CompletedDate
                       ,ft.IsFullRedemption
                       ,ftexe.SignoffHMCUserId AS ExecutiveSignoffHMCUserId
                       ,ehu.DisplayName as ExecutiveSignoff
                       ,ehu.Initials as ExecutiveSignoffInitials                       
                       ,ftexe.SignoffDate AS ExecutiveSignoffDate
                       ,ftidd.SignoffHMCUserId AS InvestmentSignoffHMCUserId
	                   ,ihu.DisplayName as InvestmentSignoff
	                   ,ihu.Initials as InvestmentSignoffInitials                       
                       ,ftidd.SignoffDate AS InvestmentSignoffDate
                       ,ftodd.SignoffHMCUserId AS ODDSignoffHMCUserId
	                   ,ohu.DisplayName as ODDSignoff
	                   ,ohu.Initials as ODDSignoffInitials
                       ,ftodd.SignoffDate AS ODDSignoffDate
                       ,ftldd.SignoffHMCUserId AS LegalSignoffHMCUserId
                       ,lhu.DisplayName as LegalSignoff
                       ,lhu.Initials as LegalSignoffInitials
                       ,ftldd.SignoffDate AS LegalSignoffDate
                       ,ftops.SignoffHMCUserId AS FinalOperationsSignoffHMCUserId
                       ,fthu.DisplayName as FinalOperationsSignoff
                       ,fthu.Initials as FinalOperationsSignoffInitials
                       ,ftops.SignoffDate AS FinalOperationsSignoffDate
                       ,CAST(ft.FundTradeId AS VARCHAR(36)) AS FundTradeId, CAST(ft.FundId AS VARCHAR(36)) AS FundId
                       ,ft.FundTradeStatusId
                       ,current_timestamp AS ETLLoadDateTime
                FROM lh_bronze.Bronze.CrimsonXFundTrade ft
                        LEFT JOIN lh_bronze.Bronze.CrimsonXFundTradeStatus fts ON fts.FundTradeStatusId = ft.FundTradeStatusId
                        LEFT JOIN lh_bronze.Bronze.CrimsonXFundTradeType ftty ON ftty.FundTradeTypeId = ft.FundTradeTypeId
                        JOIN lh_bronze.Bronze.CrimsonXFund F ON F.FundId = ft.FundId
                        JOIN lh_bronze.Bronze.CrimsonXCurrency C ON C.CurrencyId = ft.CurrencyId
                        JOIN lh_curated.Silver.FXRate fx ON fx.CurrencyId = C.CurrencyId AND fx.IsLatest = 1
                        LEFT OUTER join lh_bronze.Bronze.CrimsonXFundTradeApproval AS ftexe ON ftexe.FundTradeId = ft.FundTradeId AND ftexe.FundTradeApprovalTypeId = 1
                        LEFT OUTER join lh_bronze.Bronze.CrimsonXFundTradeApproval AS ftidd ON ftidd.FundTradeId = ft.FundTradeId AND ftidd.FundTradeApprovalTypeId = 2
                        LEFT OUTER join lh_bronze.Bronze.CrimsonXFundTradeApproval AS ftodd ON ftodd.FundTradeId = ft.FundTradeId AND ftodd.FundTradeApprovalTypeId = 3
                        LEFT OUTER join lh_bronze.Bronze.CrimsonXFundTradeApproval AS ftldd ON ftldd.FundTradeId = ft.FundTradeId AND ftldd.FundTradeApprovalTypeId = 4
                        LEFT OUTER join lh_bronze.Bronze.CrimsonXFundTradeApproval AS ftops ON ftops.FundTradeId = ft.FundTradeId AND ftops.FundTradeApprovalTypeId = 5
                        LEFT JOIN lh_curated.Silver.HMCUser ehu ON ehu.HMCUserId = ftexe.SignoffHMCUserId
                        LEFT JOIN lh_curated.Silver.HMCUser ihu ON ihu.HMCUserId = ftidd.SignoffHMCUserId
                        LEFT JOIN lh_curated.Silver.HMCUser ohu ON ohu.HMCUserId = ftodd.SignoffHMCUserId
                        LEFT JOIN lh_curated.Silver.HMCUser lhu ON lhu.HMCUserId = ftldd.SignoffHMCUserId
                        LEFT JOIN lh_curated.Silver.HMCUser fthu ON fthu.HMCUserId = ftops.SignoffHMCUserId                        
                WHERE ft.IsDeleted = 0

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT CAST(f.FundId AS VARCHAR(36)) As FundId
       , f.FundName
       , CAST(f.EntityId AS VARCHAR(36))
       , f.FundStructureId 
	   , fs.Description as FundStructure
       , f.PipelineStatusId as FundStatusId
	   , ps.Description as FundStatus
       , f.InvestmentFormId
	   , cif.Description as InvestmentForm
	   , CASE WHEN fs.Description = 'Drawdown' THEN 'Private'
		      ELSE 'Public' END as MarketClassification
       , f.VintageYear
--	   , abfm.ActiveBookType as FundType
       , f.IsFundShorted 
       , f.CalculationMethodologyId
       , (coinv.FundId IS NOT NULL) AS IsCoInvest  
       , f.PeriodEndValuationsFrequencyId AS FundValuationFrequency
       , f.CurrencyId as FundCurrencyId
       , f.HasSideLetter
       , CAST(f.ExposureIndexId as VARCHAR(36)) as PerformanceIndexId
       , CAST(expdate.FirstCashflowDate AS DATE) FirstCashflowDate
       , CAST(expdate.LastCashflowDate AS DATE) LastCashflowDate            
       , CAST(managerdate.FirstManagerReturnDate AS DATE) FirstManagerReturnDate 
       , CAST(valdate.FirstValuationDate AS DATE) FirstValuationDate
       , CAST(valdate.LastValuationDate AS DATE) LastValuationDate
       , CASE WHEN expdate.FirstCashflowDate < valdate.FirstValuationDate THEN 
				CASE WHEN DAY(DATEADD(DAY,1,expdate.FirstCashflowDate)) = 1 THEN CAST(DATEADD(DAY,1,expdate.FirstCashflowDate) AS DATE) 
					 ELSE CAST(expdate.FirstCashflowDate AS DATE) END
			  ELSE
				CASE WHEN DAY(DATEADD(DAY,1,valdate.FirstValuationDate)) = 1 THEN CAST(DATEADD(DAY,1,valdate.FirstValuationDate) AS DATE) 
					 ELSE CAST(valdate.FirstValuationDate AS DATE) END
		 END AS HMCInceptionDate      
	   , com.FirstCommitmentDate
	   , com.LastCommitmentDate
	   , CASE WHEN active.FundId IS NULL THEN FALSE ELSE TRUE END as IsActive
       , current_timestamp() AS ETLLoadDateTime       
FROM  lh_bronze.Bronze.CrimsonXFund f
		JOIN lh_bronze.Bronze.CrimsonXFundStructure fs ON f.FundStructureId = fs.FundStructureId
		JOIN lh_bronze.Bronze.CrimsonXPipelineStatus ps ON ps.PipelineStatusId = f.PipelineStatusId
        LEFT JOIN lh_bronze.Bronze.CrimsonXInvestmentForm cif ON cif.InvestmentFormId = f.InvestmentFormId

 		LEFT JOIN (SELECT DISTINCT f.FundId 
 				   FROM lh_bronze.Bronze.CrimsonXTagMaster tm
 							JOIN lh_bronze.Bronze.CrimsonXTag t ON t.TagId = tm.TagId
 							JOIN lh_bronze.Bronze.CrimsonXFund f ON f.FundId = tm.HMCObjectId
 				   WHERE tm.TagId = 7) coinv ON f.FundId = coinv.FundId           
		LEFT JOIN (select FundId, min(ExposureDate) as FirstCashflowDate, max(ExposureDate) as LastCashflowDate 
				   from lh_curated.Silver.CashflowTransactionDetail
				   where CashflowTransactionTypeId not in (5,18,13)
							AND (TransactionAmountInLocal != 0
										or TransactionAmountOutLocal != 0
										or MarketValueEffectLocal != 0
										or CommitmentEffectLocal != 0
										or ReturnedAmountLocal != 0
										or UnfundedAdjustmentLocal != 0
										or FundedAmountLocal != 0
										or RecallableAmountLocal != 0) 
			       group by FundId) expdate ON f.FundId = expdate.FundId
		LEFT JOIN (select FundId, min(EndDate) as FirstManagerReturnDate 
				   from lh_curated.Silver.FundReturn
				   where ReturnSourceId = 2
				   group by FundId) managerdate ON f.FundId = managerdate.FundId
		LEFT JOIN (select FundId,min(ValuationDate) as FirstValuationDate, max(ValuationDate) as LastValuationDate 
				   from lh_curated.Silver.FundValuation
				   group by FundId) valdate ON f.FundId = valdate.FundId  
		LEFT JOIN (select FundId, min(CommitmentDate) as FirstCommitmentDate, max(CommitmentDate) as LastCommitmentDate
			       from lh_curated.Silver.FundCommitment
				   group by FundId) com ON com.FundId = f.FundId
		LEFT JOIN (select distinct f.FundId
			       from lh_bronze.Bronze.CrimsonXFund f 
							LEFT JOIN (SELECT FundId, EndBalance 
								       FROM lh_curated.Silver.FundMarketValue
									   WHERE NAVDate = (SELECT MAX(NAVDate) FROM lh_curated.Silver.FundMarketValue)) fmv ON fmv.FundId = f.FundId
						    LEFT JOIN (SELECT FundId, UnfundedAmountLocal
									   FROM lh_curated.Gold.DrawdownFundAnalytic
									   WHERE AsOfDate = (SELECT MAX(AsOfDate) FROM lh_curated.Gold.DrawdownFundAnalytic)) dfa ON f.FundId = dfa.FundId
				   where fmv.EndBalance != 0
							OR (f.FundStructureId = 1 AND dfa.UnfundedAmountLocal != 0)) active ON active.FundId = f.FundId




-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

-- MAGIC %%pyspark
-- MAGIC df = spark.sql("SELECT * FROM lh_curated.Silver.FundMarketValue LIMIT 1000")
-- MAGIC display(df)

-- METADATA ********************

-- META {
-- META   "language": "python",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

-- MAGIC %%pyspark
-- MAGIC df = spark.sql("SELECT * FROM lh_bronze.Bronze.CrimsonXFundStructure LIMIT 1000")
-- MAGIC display(df)

-- METADATA ********************

-- META {
-- META   "language": "python",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

---GET NB READY


select fa.FirmId,TotalAUM as TotalAUMUSD,TotalCash as TotalCashUSD,StartDate as AsOfDate,fa.UpdateTimeStamp as ETLLoadDateTime from lh_bronze.Bronze.CrimsonXFirmAttribute fa
join lh_bronze.Bronze.CrimsonXFirm f on f.FirmId = fa.FirmId and f.FirmName = 'Harvard Management Company'
where StartDate < '2020-07-01' 



-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--Fund Valuation Active Book

WITH 
ActiveBookFundMapping (FundId, ActiveBookType) as (
    select FundId, ActiveBookType from lh_bronze.Bronze.SolovisActiveBookFundMapping
    group by FundId, ActiveBookType
),
LatestValuation AS (
  SELECT
    FundId,
    NAVDate,
    ValuationDate,
    ValuationTypeId,
    ValuationAmountUSD,
    ROW_NUMBER() OVER (
      PARTITION BY FundId
      ORDER BY NAVDate DESC, ValuationDate DESC
    ) AS rn
  FROM lh_curated.Review.FundValuation
),
AggregateValuationUSD AS (
  SELECT
    FundId,
    SUM(ValuationAmountUSD) AS ValuationAmountUSD,
    ValuationDate,
    ValuationTypeId
  FROM LatestValuation
  WHERE rn = 1
  GROUP BY FundId, ValuationDate, ValuationTypeId
),
AssetClassGIAMatch AS (
  SELECT
    ActiveBookType,
    sea.FundIdCrimsonX AS FundId,
    FundName,
    Asset,
    SUM(CAST(ivb.Total_Value as DECIMAL(38,2))) AS SolovisValuationAmount,
    SUM(CAST(ValuationAmountUSD AS DECIMAL(38,2))) AS HMCValuationAmount
  FROM lh_bronze.Bronze.SolovisInternalValuationBaskets ivb
  JOIN lh_bronze.Bronze.SolovisExternalActiveBook sea
    ON UPPER(sea.AssetClassGIA) = UPPER(ivb.Asset)
  JOIN lh_curated.Silver.Fund f
    ON f.FundId = sea.FundIdCrimsonX
  JOIN AggregateValuationUSD fv
    ON fv.FundId = sea.FundIdCrimsonX
  JOIN ActiveBookFundMapping abfm on abfm.FundId = f.FundId
  WHERE CAST(ivb.Total_Value as DECIMAL(38,2)) <> 0
    AND ivb.Date = (select max(Date) from lh_bronze.Bronze.SolovisInternalValuationBaskets)
  GROUP BY FundIdCrimsonX, FundName, Asset, ActiveBookType
), 
FundNameMatch AS (
  SELECT
    ActiveBookType,
    f.FundId,
    FundName,
    ivb.Asset,
    ivb.Total_Value as SolovisValuationAmount,
    ValuationAmountUSD AS HMCValuationAmount
  FROM lh_bronze.Bronze.SolovisInternalValuationBaskets ivb
  JOIN lh_curated.Silver.Fund f
    ON UPPER(ivb.Asset) = UPPER(f.FundName)
    AND f.FundId NOT IN (SELECT FundId FROM AssetClassGIAMatch)
  JOIN AggregateValuationUSD fv
    ON fv.FundId = f.FundId
  JOIN ActiveBookFundMapping abfm on abfm.FundId = f.FundId
  WHERE CAST(ivb.Total_Value as DECIMAL(38,2)) <> 0
    AND fv.ValuationTypeId IN (1,2)
    AND ivb.Date = (select max(Date) from lh_bronze.Bronze.SolovisInternalValuationBaskets)
),
Mismatch AS (
  SELECT
    'Not in Crimson' AS ActiveBookType,
    NULL AS FundId,
    'Missing' AS FundName,
    ivb.Asset,
    ivb.Total_Value as SolovisValuationAmount,
    NULL AS HMCValuationAmount
  FROM lh_bronze.Bronze.SolovisInternalValuationBaskets ivb
  LEFT JOIN FundNameMatch fnm ON ivb.Asset = fnm.Asset
  LEFT JOIN AssetClassGIAMatch acgm ON acgm.Asset = ivb.Asset
  WHERE fnm.Asset IS NULL
    AND acgm.Asset IS NULL
    AND ivb.Asset NOT LIKE '%Offset%'
    AND ivb.Asset NOT LIKE '%(Fin. Costs)%'
    AND CAST(ivb.Total_Value as DECIMAL(38,2)) <> 0
    AND Cast(ivb.Date as date) = cast('2025-10-16' as date)
), final as (
select 'Fund Valuation Active Book' as Recon, *, SolovisValuationAmount - HMCValuationAmount as Diff from FundNameMatch
UNION
select 'Fund Valuation Active Book' as Recon, *, SolovisValuationAmount - HMCValuationAmount as Diff from AssetClassGIAMatch
UNION
select 'Fund Valuation Active Book' as Recon, *, SolovisValuationAmount as Diff from Mismatch)
SELECT
    CAST(Recon AS String) as Recon,
    CAST(ActiveBookType AS String) as ActiveBookType,
    CAST(lower(FundId) as String) as FundId,
    CAST(FundName as String) as FundName,
    CAST(Asset as String) as Asset,
    CAST(SolovisValuationAmount  as DECIMAL(38,2)) as SolovisValuationAmount,
    CAST(HMCValuationAmount as DECIMAL(38,2)) as HMCValuationAmount,
    CAST(Diff as DECIMAL(38,2)) as Diff
From final 



-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

CREATE TABLE IF NOT EXISTS lh_curated.Review.ReconFundValuationActiveBook (
Recon String,
ActiveBookType String,
FundId String,
FundName String,
Asset String,
SolovisValuationAmount Decimal(38,2),
HMCValuationAmount Decimal(38,2),
Diff  Decimal(38,12),
ETLLoadDateTime TIMESTAMP NOT NULL
)



-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT
    CAST(fc.FundId AS STRING) AS FundId,
    CAST(cr.Entity_Import_Code AS STRING) AS EntityImportCode,
    CAST(fc.NAVDate AS DATE) AS NAVDate,
    CAST(cr.Total_Value AS DECIMAL(38, 11)) AS SolovisMarketValue,
    CAST(fc.EndBalance AS DECIMAL(38, 11)) AS CrimsonMarketValue,
    CAST(cr.Total_Value AS DECIMAL(38, 11)) - CAST(fc.EndBalance AS DECIMAL(38, 11)) AS Difference
FROM
    Bronze.SolovisReconGIAHoldings AS cr
    JOIN Bronze.SolovisEntities AS se
        ON se.ImportCode = cr.Entity_Import_Code
    LEFT JOIN Review.FundMarketValue AS fc
        ON LOWER(fc.FundId) = LOWER(se.CrimsonFundId)
        AND CAST(fc.NAVDate AS DATE) = LAST_DAY(CURRENT_DATE())
WHERE
    COALESCE(cr.Entity_Import_Code, '') <> ''
    AND (
        (fc.FundId IS NULL AND CAST(cr.Total_Value AS DECIMAL(38, 11)) <> 0)
        OR ABS(
            CAST(cr.Total_Value AS DECIMAL(38, 11)) - CAST(fc.EndBalance AS DECIMAL(38, 11))
        ) > 1
    )
    AND cr.Entity_Import_Code RLIKE '^[0-9]+$';




-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

-- ReconFundMarketValue

SELECT
    CAST(fc.FundId AS STRING) AS FundId,
    CAST(cr.Entity_Import_Code AS STRING) AS EntityImportCode,
    CAST(fc.NAVDate AS DATE) AS NAVDate,
    CAST(cr.Total_Value AS DECIMAL(38,11)) AS SolovisMarketValue,
    CAST(fc.EndBalance AS DECIMAL(38,11)) AS CrimsonMarketValue,
    CAST(cr.Total_Value AS DECIMAL(38,11)) - CAST(fc.EndBalance AS DECIMAL(38,11)) AS Difference
FROM
    lh_bronze.Bronze.SolovisReconGIAHoldings cr
    JOIN lh_bronze.Bronze.SolovisEntities se
        ON se.ImportCode = cr.Entity_Import_Code
    LEFT JOIN lh_curated.Review.FundMarketValue fc
        ON LOWER(fc.FundId) = LOWER(se.CrimsonFundId)
        AND CAST(fc.NAVDate AS DATE) = LAST_DAY(CURRENT_DATE())
WHERE
    COALESCE(cr.Entity_Import_Code, '') <> ''
    AND (
        (fc.FundId IS NULL AND CAST(cr.Total_Value AS DECIMAL(38,11)) <> 0)
        OR ABS(
            CAST(cr.Total_Value AS DECIMAL(38,11)) - CAST(fc.EndBalance AS DECIMAL(38,11))
        ) > 1
    )
    AND cr.Entity_Import_Code RLIKE '^[0-9]+$'


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }
