# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# --- Function to Traverse Cash Directory to get all other cash accounts
from pyspark.sql.functions import col
from datetime import datetime,date

spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_bronze")
spark.sql("SET spark.sql.caseSensitive = TRUE")

def getCashAccounts():
    dfCashTag = spark.sql("""SELECT TagSetId, Category TagSetCategory, Id TagId, ParentId TagIdParent, Description TagDescription
                            FROM lh_bronze.Bronze.SolovisTagsets
                            WHERE Category = 'Asset Class - GIA'
                            AND   Description = 'Net Cash'  """)  # -- id = 11 

    dfAllTags = spark.sql("""SELECT TagSetId, Category TagSetCategory, Id TagId, ParentId TagIdParent, Description TagDescription
                            FROM lh_bronze.Bronze.SolovisTagsets tsi
                            WHERE tsi.Category = 'Asset Class - GIA' 
                            and   tsi.Description != 'HMC Internal - House'
                            and   NOT(tsi.Description LIKE 'HMC Internal%Offset%' OR tsi.Description LIKE 'HMC Internal%Fin. Costs%')
                            and   not tsi.Description = 'HMC Internal - SUS (Fin. Costs)'  """)  # -- id = 11 

    dfAll = dfAllTags.alias("AllTags")
    BaseTagLevel = dfCashTag.alias("base")
    # base = dfCashTag
    dfAllCashTags = BaseTagLevel
    PrevTagLevel = BaseTagLevel

    # Iteratively find indirect reports
    while True:
        prev_alias = PrevTagLevel.alias("prev")

        NextTagLevel = dfAll.join(
            prev_alias,
            col("AllTags.TagIdParent") == col("prev.TagId"),
            "inner"
        ).select(
            col("AllTags.TagSetId"),
            col("AllTags.TagSetCategory"),
            col("AllTags.TagId"),
            col("AllTags.TagIdParent"),
            col("AllTags.TagDescription")
        )
        
        NewTagRows = NextTagLevel.subtract(dfAllCashTags)  # prevent duplicates
        if NewTagRows.count() == 0:
            break
        dfAllCashTags = dfAllCashTags.union(NewTagRows)
        PrevTagLevel = NewTagRows

    return dfAllCashTags


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Gather all the active book mappings

# Internal ActiveBook
dfInternalActiveBook =  spark.sql("""SELECT 
    si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, f.FundId
	, sc.ShareClassId
    , 'Internal ActiveBook' ActiveBookType
FROM   lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.CrimsonXFund f ON upper(si.AssetClassGia) = upper(f.FundName)
		JOIN lh_bronze.Bronze.CrimsonXShareClass sc ON upper(f.FundId) = upper(sc.FundId)
WHERE  (si.AssetClassGia LIKE 'HMC Internal%')
			and   NOT(si.AssetClassGia LIKE 'HMC Internal%Offset%' OR si.AssetClassGia LIKE 'HMC Internal%Fin. Costs%' or si.AssetClassGia like 'HMC Internal - SUS (Notional Adj)' or si.AssetClassGia = 'HMC Internal - SUS (Fin. Costs)')
		AND    sc.IsDefault = 1
UNION ALL
SELECT 
    si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, f.FundId
	, sc.ShareClassId
    , 'Internal ActiveBook' ActiveBookType
FROM   lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.CrimsonXFund f ON f.FundName ='HMC Internal - SUS'
		JOIN lh_bronze.Bronze.CrimsonXShareClass sc ON upper(f.FundId) = upper(sc.FundId)
WHERE  (si.AssetClassGia = 'HMC Internal - SUS (Fin. Costs)' 
			or si.AssetClassGia = 'HMC Internal - SUS (Notional Adj)')
		AND    sc.IsDefault = 1
		""")

# General Expenses
dfGeneralExpenses =  spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, f.FundId
	, sc.ShareClassId
	, 'General Expenses' ActiveBookType
FROM   lh_bronze.Bronze.SolovisInvestments si 
			JOIN lh_bronze.Bronze.SolovisEntities se ON si.HoldingId = se.Id
			JOIN lh_bronze.Bronze.CrimsonXFund f ON se.Label = f.FundName
			JOIN lh_bronze.Bronze.CrimsonXShareClass sc ON f.FundId = sc.FundId
WHERE  se.Label = 'General Expense - Absolute Return'
		AND    sc.IsDefault = 1
		""")

# External ActiveBook
dfExternalActiveBook =  spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, xref.FundIdCrimsonX FundId
	, xref.ShareClassIdCrimsonX ShareClassId
	, 'External ActiveBook' ActiveBookType 
FROM   lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.HMCDataWarehouseExternalActiveBook xref ON  xref.XrefType   = 'External Active Book'
			AND xref.StartDate <= CURRENT_TIMESTAMP
			AND xref.EndDate   >= CURRENT_TIMESTAMP
			AND upper(xref.AssetClassGIA) = upper(si.AssetClassGia)
			AND xref.ActionType = 'INCLUDE' 
		JOIN lh_bronze.Bronze.CrimsonXFund f ON UPPER(f.FundId) = UPPER(xref.FundIdCrimsonX)
""")

# Cash Offsets
dfCashOffset =  spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, '6dd56666-f892-4148-b62a-d7a150ae4053' FundId
	, '79834536-1fd2-47d1-b296-aba5ebf6163a' ShareClassId
	, 'Cash Offsets' ActiveBookType
FROM lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.CrimsonXShareClass sc ON upper(sc.ShareClassId) = '79834536-1FD2-47D1-B296-ABA5EBF6163A'
WHERE  (si.AssetClassGia LIKE 'HMC Internal%Offset%' OR si.AssetClassGia LIKE 'HMC Internal%Fin. Costs%')
		AND NOT si.AssetClassGia = 'HMC Internal - SUS (Fin. Costs)'
		""")

# Cash Accounts
dfCashAccounts = getCashAccounts()
dfCashAccounts.createOrReplaceTempView("CashTags")

dfCashOther = spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, '6dd56666-f892-4148-b62a-d7a150ae4053' FundId
	, '52542eee-1eed-4192-a24d-bb6ded34ef14' ShareClassId
	, 'Cash' ActiveBookType	   
FROM CashTags ct
		JOIN lh_bronze.Bronze.SolovisInvestments si ON ct.TagId = si.AssetClassGiaTagId
		JOIN lh_bronze.Bronze.CrimsonXFund f ON f.FundName ='HMC Internal - SUS'
WHERE
	-- Keep the original roots
	ct.TagDescription = 'Net Cash'
	OR (
		-- Include all except undesired internal entries
		ct.TagDescription != 'HMC Internal - House'
		AND NOT (
			ct.TagDescription LIKE 'HMC Internal%Offset%' 
			OR ct.TagDescription LIKE 'HMC Internal%Fin. Costs%'
		)
		AND ct.TagDescription != 'HMC Internal - SUS (Fin. Costs)'
	)
""")

# Funds
dfFunds =  spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, lower(xf.HMCObjectIdCrimsonX) FundId
	, lower(xsc.HMCObjectIdCrimsonX) ShareClassId
	, 'Fund' ActiveBookType
FROM lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.SolovisEntities se ON si.HoldingId = se.Id
		JOIN lh_bronze.Bronze.HMCDataWarehousevwSourceReferenceFlatten_CrimsonX xsc ON xsc.ReferenceId = si.ResourceId
																		AND xsc.HMCObjectType = 'Share Class'
		JOIN lh_bronze.Bronze.HMCDataWarehousevwSourceReferenceFlatten_CrimsonX xf ON xf.ReferenceId = si.HoldingId
																		AND xf.HMCObjectType = 'Fund'
""")

dfActiveBook = dfInternalActiveBook \
	.union(dfGeneralExpenses) \
	.union(dfExternalActiveBook) \
	.union(dfCashOffset) \
	.union(dfCashOther)

# Remove the duplicate active book records to only get funds
dfFunds = dfFunds.join(dfActiveBook, on=['InvestmentResourceId', 'InvestmentId'], how='left_anti')

dfActiveBookFundMapping = dfActiveBook \
    .union(dfFunds)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Persist the Active Book and Fund Mappings in Bronze
dfActiveBookFundMapping.write.format("delta") \
    .mode("overwrite") \
    .saveAsTable("lh_bronze.Bronze.SolovisActiveBookFundMapping")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create or clear the ProcessFundChanges table to be used by the calculator
from pyspark.sql.types import StructType, StructField, StringType, TimestampType
from pyspark.sql.functions import lit, current_timestamp

# Define schema explicitly
schema = StructType([
    StructField("FundId", StringType(), False),
    StructField("ETLLoadDateTime", TimestampType(), False)
])

# Create empty DataFrame with schema
dfProcessFundChanges = spark.createDataFrame([], schema)

# Write to table (will create the table even though it's empty)
dfProcessFundChanges.write.format("delta").mode("overwrite").saveAsTable("Bronze.ProcessFundChanges")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
