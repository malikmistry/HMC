-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "sqldatawarehouse"
-- META   },
-- META   "dependencies": {
-- META     "warehouse": {
-- META       "default_warehouse": "8e5f9d96-43c6-4ec5-90ab-906ec130fd98",
-- META       "known_warehouses": [
-- META         {
-- META           "id": "8e5f9d96-43c6-4ec5-90ab-906ec130fd98",
-- META           "type": "Lakewarehouse"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- CELL ********************

-- Welcome to your new notebook
-- Type here in the cell editor to add code!

SELECT top 500  * from lh_curated.Silver.Fund;
SELECT  * from lh_curated.Silver.ShareClass

-- METADATA ********************

-- META {
-- META   "language": "sql",
-- META   "language_group": "sqldatawarehouse"
-- META }
