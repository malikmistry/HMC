# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     },
# META     "warehouse": {
# META       "default_warehouse": "aef35469-ca5b-4ff6-9544-a57182d98333",
# META       "known_warehouses": [
# META         {
# META           "id": "8e5f9d96-43c6-4ec5-90ab-906ec130fd98",
# META           "type": "Lakewarehouse"
# META         },
# META         {
# META           "id": "aef35469-ca5b-4ff6-9544-a57182d98333",
# META           "type": "Lakewarehouse"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

df= spark.sql("""WITH Base AS (
    SELECT
          ch.FundId
        , ch.ShareClassId
        , f.FundName
        , ch.EndBalanceUSD * coalesce(sc.IlliquidPct,0.00)                      AS SidePocketUSD
        , ch.EndBalance  * coalesce(sc.IlliquidPct,0.00)                        AS SidePocketLocal
        , ch.EndBalance
        , ch.NAVDate                             AS AsOfDate
        , MAX(ch.NAVDate) OVER (PARTITION BY ch.FundId) AS MaxNAVDate
      FROM delta.`abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXHoldingsHistory` AS ch
    JOIN delta.`abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465/Tables/Silver/ShareClass`             AS sc ON sc.ShareClassId = ch.ShareClassId
    JOIN delta.`abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXFund`            AS f  ON f.FundId       = ch.FundId
    WHERE ch.EndDate = '9999-12-31' ),
Fund AS (
    -- Keep only the most recent NAVDate per FundId (avoids correlated subquery)
    SELECT
          FundId
        , ShareClassId
        , FundName
        , SidePocketUSD
        , SidePocketLocal
        , EndBalance
        , AsOfDate
    FROM Base
    WHERE AsOfDate = MaxNAVDate
),
AllShares AS (
    -- Match original intent: exclude equal locals/usd and USD=0
    SELECT
          FundId
         , FundName
        , CAST(SUM(SidePocketUSD) AS Decimal(38,11)) as SidePocketUSD
        , CAST(SUM(SidePocketLocal) AS Decimal(38,11)) as SidePocketLocal
        , CAST(SUM(EndBalance) AS Decimal(38,11)) as EndBalance
        , AsOfDate
    FROM Fund
    GROUP BY FundId,FundName,AsOfDate
    HAVING SUM(SidePocketLocal)  <> 0
)
SELECT
      a.FundId
  --  , a.ShareClassId
    , a.FundName
    , SidePocketUSD
    , SidePocketLocal
    , CAST(a.AsOfDate AS DATE) AS AsOfDate
    , EndBalance                                     AS FundTotalLocal
    , CAST(SidePocketLocal/EndBalance as Decimal(38,11)) AS SidePocketPercent
FROM AllShares AS a""")

# METADATA ********************

# META {
# META   "language": "sql",
# META   "language_group": "sqldatawarehouse"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.sql("""
 WITH Base AS (
    SELECT
          ch.FundId
        , ch.ShareClassId
        , f.FundName
        , ch.EndBalanceUSD * coalesce(sc.IlliquidPct,0.00)                      AS SidePocketUSD
        , ch.EndBalance  * coalesce(sc.IlliquidPct,0.00)                        AS SidePocketLocal
        , ch.EndBalance
        , ch.NAVDate                             AS AsOfDate
        , MAX(ch.NAVDate) OVER (PARTITION BY ch.FundId) AS MaxNAVDate
      FROM delta.`abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXHoldingsHistory` AS ch
    JOIN delta.`abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465/Tables/Silver/ShareClass`             AS sc ON sc.ShareClassId = ch.ShareClassId
    JOIN delta.`abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXFund`            AS f  ON f.FundId       = ch.FundId
    WHERE ch.EndDate = '9999-12-31' ),
Fund AS (
    -- Keep only the most recent NAVDate per FundId (avoids correlated subquery)
    SELECT
          FundId
        , ShareClassId
        , FundName
        , SidePocketUSD
        , SidePocketLocal
        , EndBalance
        , AsOfDate
    FROM Base
    WHERE AsOfDate = MaxNAVDate
),
AllShares AS (
    -- Match original intent: exclude equal locals/usd and USD=0
    SELECT
          FundId
         , FundName
        , CAST(SUM(SidePocketUSD) AS Decimal(38,11)) as SidePocketUSD
        , CAST(SUM(SidePocketLocal) AS Decimal(38,11)) as SidePocketLocal
        , CAST(SUM(EndBalance) AS Decimal(38,11)) as EndBalance
        , AsOfDate
    FROM Fund
    GROUP BY FundId,FundName,AsOfDate
    HAVING SUM(SidePocketLocal)  <> 0
)
SELECT
      a.FundId
  --  , a.ShareClassId
    , a.FundName
    , SidePocketUSD
    , SidePocketLocal
    , CAST(a.AsOfDate AS TimeStamp) AS AsOfDate
    , EndBalance                                     AS FundTotalLocal
    , CAST(SidePocketLocal/EndBalance as Decimal(38,11)) AS SidePocketPercent
FROM AllShares AS a
""")
df.show


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df.show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

