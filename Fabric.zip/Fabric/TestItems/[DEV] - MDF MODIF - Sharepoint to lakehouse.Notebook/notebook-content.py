# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "920a12cc-7104-4013-a2a3-d7baa57e9e3f",
# META       "default_lakehouse_name": "lh_raw",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "920a12cc-7104-4013-a2a3-d7baa57e9e3f"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import requests
from pyspark.sql import SparkSession
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from urllib.parse import quote
import re
import os
import json

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

# ------------------------------------------------------------
# ENVIRONMENT VARIABLES
# ------------------------------------------------------------
key_vault_name = ""
secret_name = ""
tenant_id     = ""
client_id     = ""
WorkspaceId = ""
BronzeLHId = ""
RawLHId = ""

# ------------------------------------------------------------
# ETL TABLE PROPERTIES
# ------------------------------------------------------------
TaskList = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
TaskList = "{\"JobAuditKey\":1463,\"TaskKey\":5003,\"TaskType\":\"FileTask\",\"SourceName\":\"ManualBenchmark\",\"SourceType\":\"SharepointFile\",\"FileType\":\"delimited\",\"SourceWildcardFolderPath\":\"FileDrop/ManualBenchmark/processed\",\"SourceWildcardFileName\":\"(?i)^manual.*\",\"SourceDataSet\":\"sharepoint_site_host:hmcharvard.sharepoint.com|site_path:/teams/InvestmentOperations|library_name:Data\"}"
key_vault_name = "kv-dc1prd-adf"
secret_name = "SharePointOnlineSiteAccess-Fabric"
tenant_id     = "385f9270-6e2d-44ab-8297-02cf20fd17ce"
client_id     = "d9d77d0f-c67c-4576-9255-005292dfabbf"
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
RawLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Convert JSON String to list
tasklist = [json.loads(TaskList)]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ------------------------------------------------------------
# ASSIGN PARAMETERS TO VARIABLES
# ------------------------------------------------------------
segments = tasklist[0]['SourceDataSet'].split("|")

# Initialize dictionary
sharepointDetails = {}

for segment in segments:
    if ":" in segment:
        key, value = segment.split(":", 1)
        sharepointDetails[key.strip()] = value.strip()

sharepoint_site_host = sharepointDetails['sharepoint_site_host'] #SourceDataSet
site_path = sharepointDetails['site_path'] #SourceDataSet
library_name = sharepointDetails['library_name'] #SourceDataSet

# Wildcards/regex can appear in ANY segment here:
folder_path_wild = tasklist[0]['SourceWildcardFolderPath'] #SourceWildcardFolderPath
file_name_wild   = tasklist[0]['SourceWildcardFileName'] #SourceWildcardFileName

print(sharepoint_site_host)
print(site_path)
print(library_name)
print(folder_path_wild)
print(file_name_wild)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

try:
    # ------------------------------------------------------------
    # 1. Initialize Spark session
    # ------------------------------------------------------------
    spark = SparkSession.builder.getOrCreate()

    # ------------------------------------------------------------
    # 2. Retrieve credentials securely from Azure Key Vault
    # ------------------------------------------------------------
    #key_vault_name = "kv-dc1prd-adf"   
    key_vault_url = f"https://{key_vault_name}.vault.azure.net/"
    #secret_name = "SharePointOnlineSiteAccess-Fabric"

    # Use managed identity or service principal (DefaultAzureCredential works in Fabric)
    credential = DefaultAzureCredential()
    #secret_client = SecretClient(vault_url=key_vault_url, credential=credential)
    secret_client = notebookutils.credentials.getSecret(key_vault_url,secret_name)

    #tenant_id     = "385f9270-6e2d-44ab-8297-02cf20fd17ce"
    #client_id     = "d9d77d0f-c67c-4576-9255-005292dfabbf"
    #client_secret = secret_client.get_secret("SharePointOnlineSiteAccess-Fabric").value
except Exception as e:
    raise RuntimeError(f"Task {tasklist['TaskKey']} failed: {str(e)}") from e


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

try:
    # ------------------------ CONFIG ------------------------
    # Token (you already have tenant_id/client_id/client_secret)
    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    token_data = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": secret_client,               # make sure this is the *secret value*
        "scope": "https://graph.microsoft.com/.default"
    }
    token_response = requests.post(token_url, data=token_data)
    token_response.raise_for_status()
    access_token = token_response.json()["access_token"]
    headers = {"Authorization": f"Bearer {access_token}"}

    #sharepoint_site_host = "hmcharvard.sharepoint.com"
    #site_path = "/teams/InvestmentOperations"
    #library_name = "Data"

    # Wildcards/regex can appear in ANY segment here:
    #folder_path_wild = r"FileDrop/ManualBenchmark/processed"   # e.g., r"File.*/Manual.*/proc.*"
    #file_name_wild   = r"(?i)^manual.*"                  # case-insensitive: manual*.xlsx

    # Lakehouse destination base (we will append the matched path)
    lakehouse_base = "Files/SharepointRawDump"

    # --------------------- RESOLVE SITE & DRIVE ---------------------
    site = requests.get(f"https://graph.microsoft.com/v1.0/sites/{sharepoint_site_host}:{site_path}",
                        headers=headers)
    site.raise_for_status()
    site_id = site.json()["id"]

    drives = requests.get(f"https://graph.microsoft.com/v1.0/sites/{site_id}/drives",
                        headers=headers)
    drives.raise_for_status()
    drive = next((d for d in drives.json()["value"] if d["name"].lower() == library_name.lower()), None)
    if not drive:
        raise RuntimeError(f"Document library '{library_name}' not found.")
    drive_id = drive["id"]

    # ----------------- HELPERS: SEGMENT WALKER (REGEX AWARE) -----------------
    regex_chars = r"[.*+?[\]{}()|^$\\]"  # characters that imply regex

    def children_of(item_id):
        url = f"https://graph.microsoft.com/v1.0/drives/{drive_id}/items/{item_id}/children"
        resp = requests.get(url, headers=headers); resp.raise_for_status()
        return resp.json().get("value", [])

    def is_regex_segment(seg: str) -> bool:
        return bool(re.search(regex_chars, seg))

    def get_root():
        r = requests.get(f"https://graph.microsoft.com/v1.0/drives/{drive_id}/root", headers=headers)
        r.raise_for_status()
        return r.json()

    # Walk each segment; carry multiple branches as (item_json, matched_path_str)
    segments = [s for s in folder_path_wild.split("/") if s]
    branches = [(get_root(), "")]  # start at drive root

    for seg in segments:
        next_branches = []
        seg_regex = is_regex_segment(seg)
        pattern = re.compile(seg, re.IGNORECASE) if seg_regex else None

        for item, path_so_far in branches:
            kids = children_of(item["id"])
            if seg_regex:
                matches = [k for k in kids if "folder" in k and pattern.match(k["name"])]
            else:
                matches = [k for k in kids if "folder" in k and k["name"].lower() == seg.lower()]

            for m in matches:
                new_path = f"{path_so_far}/{m['name']}" if path_so_far else m["name"]
                next_branches.append((m, new_path))

        branches = next_branches

    if not branches:
        raise RuntimeError(f"No folder matched the wildcard path: {folder_path_wild}")

    print("Matched folder paths:")
    for _, p in branches:
        print(" -", p)

    # -------------------- LIST FILES, FILTER & SAVE --------------------
    file_pat = re.compile(file_name_wild)  # already (?i) in pattern; add re.I if needed

    for folder_item, matched_rel_path in branches:
        # List files under this matched folder
        kids = children_of(folder_item["id"])
        files = [k for k in kids if "file" in k and file_pat.match(k["name"])]

        if not files:
            print(f"No files matched '{file_name_wild}' in '{matched_rel_path}'")
            continue

        # Ensure full original path is preserved in Lakehouse
        dest_dir = f"/lakehouse/default/{lakehouse_base}{site_path}/{matched_rel_path}"
        os.makedirs(dest_dir, exist_ok=True)

        for fitem in files:
            name = fitem["name"]
            dl = fitem.get("@microsoft.graph.downloadUrl")
            if not dl:
                # fallback to API content endpoint if presigned URL missing
                path_for_api = f"{matched_rel_path}/{name}"
                url = f"https://graph.microsoft.com/v1.0/drives/{drive_id}/root:/{quote(path_for_api)}:/content"
                resp = requests.get(url, headers=headers); resp.raise_for_status()
                content = resp.content
            else:
                resp = requests.get(dl); resp.raise_for_status()
                content = resp.content

            dest_path = f"{dest_dir}/{name}"
            with open(dest_path, "wb") as f:
                f.write(content)
            print(f"Saved {name} → {dest_path}")
except Exception as e:
    raise RuntimeError(f"Task {tasklist['TaskKey']} failed: {str(e)}") from e


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
