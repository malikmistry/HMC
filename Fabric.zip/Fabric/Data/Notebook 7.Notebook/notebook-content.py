# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************


spark.sql("DROP TABLE IF EXISTS lh_curated.Silver.FundValuation")


create_sql = f"""
CREATE TABLE IF NOT EXISTS lh_curated.Silver.FundValuation
USING DELTA
AS
FundId,
        CAST(ExposureDate AS DATE) AS CommitmentDate,   -- stored as DATE
        CAST(CommitmentEffectLocal AS DECIMAL(15,2)) AS CommitmentAmount, -- trillions with 2 decimals
        CAST(CashflowTransactionTypeId AS INT) AS CashflowTransactionTypeId,
        FIRST_VALUE(CAST(CommitmentEffectLocal AS DECIMAL(15,2))) 
            OVER (PARTITION BY FundId ORDER BY ExposureDate ASC) AS FirstCommitmentAmount
    FROM Silver.CashflowTransactionDetail
    where 1=2

"""

spark.sql(create_sql)




lh_curated.Silver.CashflowTransactionDetail


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
