CREATE TABLE [etl].[Notebook] (

	[NotebookKey] bigint NOT NULL, 
	[NotebookName] varchar(100) NOT NULL, 
	[NotebookDescription] varchar(4000) NULL
);