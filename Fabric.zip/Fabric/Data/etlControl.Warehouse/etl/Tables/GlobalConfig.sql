CREATE TABLE [etl].[GlobalConfig] (

	[ConfigKey] varchar(200) NOT NULL, 
	[ConfigValue] varchar(2000) NOT NULL
);