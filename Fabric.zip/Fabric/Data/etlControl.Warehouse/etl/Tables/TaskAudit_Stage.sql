CREATE TABLE [etl].[TaskAudit_Stage] (

	[JobAuditKey] bigint NULL, 
	[TaskAuditKey] bigint NULL, 
	[TaskKey] varchar(100) NULL, 
	[TaskType] varchar(100) NULL, 
	[Message] varchar(4000) NULL, 
	[Status] varchar(50) NULL, 
	[RequestedEndTime] varchar(30) NULL, 
	[RowsRead] bigint NULL, 
	[RowsInserted] bigint NULL, 
	[RowsUpdated] bigint NULL, 
	[RowsDeleted] bigint NULL, 
	[LastUpdated] varchar(30) NULL
);