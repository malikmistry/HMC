CREATE TABLE [etl].[TriggerHistory] (

	[TriggerFileName] varchar(256) NOT NULL
);