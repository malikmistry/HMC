CREATE   PROCEDURE [etl].[TaskAuditBatchUpdate]
(
    @JobAuditKey BIGINT,          -- pass JobAuditKey directly
    @AuditJson NVARCHAR(MAX)
)
AS
BEGIN
    SET NOCOUNT ON;

    ---------------------------------------------------------------------------
    -- Step 1: Load JSON data into staging
    ---------------------------------------------------------------------------
    DELETE FROM etl.TaskAudit_Stage;  -- clear previous batch

    INSERT INTO etl.TaskAudit_Stage (
        JobAuditKey, TaskAuditKey, TaskKey, TaskType,
        Message, Status, RequestedEndTime,
        RowsRead, RowsInserted, RowsUpdated, RowsDeleted
    )
    SELECT
        @JobAuditKey,  -- use the passed-in JobAuditKey
        TRY_CAST(JSON_VALUE(value, '$.TaskAuditKey') AS BIGINT),
        JSON_VALUE(value, '$.TaskKey'),
        JSON_VALUE(value, '$.TaskType'),
        JSON_VALUE(value, '$.Message'),
        JSON_VALUE(value, '$.Status'),
        JSON_VALUE(value, '$.RequestedEndTime'),  -- store as string (Fabric-friendly)
        TRY_CAST(JSON_VALUE(value, '$.RowsRead') AS BIGINT),
        TRY_CAST(JSON_VALUE(value, '$.RowsInserted') AS BIGINT),
        TRY_CAST(JSON_VALUE(value, '$.RowsUpdated') AS BIGINT),
        TRY_CAST(JSON_VALUE(value, '$.RowsDeleted') AS BIGINT)
    FROM OPENJSON(@AuditJson);

    ---------------------------------------------------------------------------
    -- Step 2: Upsert into main TaskAudit
    ---------------------------------------------------------------------------
    MERGE etl.TaskAudit AS tgt
    USING etl.TaskAudit_Stage AS src
        ON tgt.JobAuditKey = src.JobAuditKey
       AND tgt.TaskAuditKey = src.TaskAuditKey
    WHEN MATCHED THEN
        UPDATE SET
            tgt.TaskKey      = src.TaskKey,
            tgt.TaskType     = src.TaskType,
            tgt.DebugString  = src.Message,
            tgt.Status       = src.Status,
            tgt.EndTime      = src.RequestedEndTime,
            tgt.RowsRead     = src.RowsRead,
            tgt.RowsInserted = src.RowsInserted,
            tgt.RowsUpdated  = src.RowsUpdated,
            tgt.RowsDeleted  = src.RowsDeleted,
            tgt.LastUpdated  = SYSUTCDATETIME()
    WHEN NOT MATCHED BY TARGET THEN
        INSERT (
            JobAuditKey, TaskAuditKey, TaskKey, TaskType,
            DebugString, Status, EndTime,
            RowsRead, RowsInserted, RowsUpdated, RowsDeleted, LastUpdated
        )
        VALUES (
            src.JobAuditKey, src.TaskAuditKey, src.TaskKey, src.TaskType,
            src.Message, src.Status, src.RequestedEndTime,
            src.RowsRead, src.RowsInserted, src.RowsUpdated, src.RowsDeleted, SYSUTCDATETIME()
        );

    ---------------------------------------------------------------------------
    -- Step 3: Return summary
    ---------------------------------------------------------------------------
    SELECT COUNT(*) AS RecordsProcessed
    FROM etl.TaskAudit_Stage;
END;