CREATE      PROCEDURE [etl].[JobAuditFailure] (
	@JobAuditKey BIGINT
)
AS

DECLARE @CurrentUTCDateTime DATETIME 
--DECLARE @Message NVARCHAR(4000)
SET @CurrentUTCDateTime = GETUTCDATE()
--SET @Message = 'Job Failed. Status Updated by JobAuditFailure. Possibly uncaught Task Failure.'

UPDATE etl.JobAudit
SET 
	Status = 'Failed',
	EndTime = @CurrentUTCDateTime
WHERE JobAuditKey = @JobAuditKey

-- DevNote 11/27/26: Add if there are uncaught Task failures which should not be
--UPDATE etl.TaskAudit
--SET 
--	IsRunning = 0,
--	Status = 'Failed',
--	LastUpdated = COALESCE(LastUpdated, @CurrentUTCDateTime),
--	EndTime = COALESCE(EndTime, @CurrentUTCDateTime),
--	DebugString = COALESCE(LastUpdated, @Message)
--WHERE JobAuditKey = @JobAuditKey