CREATE   PROCEDURE [etl].[TaskAuditStartBatch]
(
    @JobAuditKey BIGINT
)
AS
/******************************************************************************
Fabric Data Warehouse–compatible version.
Starts all TaskAudit records under a given JobAuditKey in a set-based manner.
******************************************************************************/
BEGIN
    SET NOCOUNT ON;

    DECLARE @CurrentUTCDateTime DATETIME = GETUTCDATE();

    ----------------------------------------------------------------------------
    -- 1. Log any tasks already running
    ----------------------------------------------------------------------------
    IF EXISTS (
        SELECT 1
        FROM etl.TaskAudit
        WHERE JobAuditKey = @JobAuditKey
          AND IsRunning = 1
    )
    BEGIN
        DECLARE @AlreadyRunningCount INT =
            (SELECT COUNT(*) FROM etl.TaskAudit WHERE JobAuditKey = @JobAuditKey AND IsRunning = 1);

        DECLARE @Warn NVARCHAR(4000) =
            'Warning: ' + CAST(@AlreadyRunningCount AS NVARCHAR(10)) +
            ' task(s) already marked as running for JobAuditKey ' +
            CAST(@JobAuditKey AS NVARCHAR(20)) + '.';

        EXEC etl.LogMessage 
            @JobAuditKey = @JobAuditKey,
            @TaskAuditKey = NULL,
            @PipelineRunID = NULL,
            @Message = @Warn;
    END;

    ----------------------------------------------------------------------------
    -- 2. Update all tasks that are NOT running
    ----------------------------------------------------------------------------
    UPDATE etl.TaskAudit
    SET
        IsRunning = 1,
        StartTime = @CurrentUTCDateTime,
        Status = 'Execution started',
        DebugString = NULL,
        LastUpdated = @CurrentUTCDateTime
    WHERE JobAuditKey = @JobAuditKey
      AND (IsRunning IS NULL OR IsRunning = 0);

    ----------------------------------------------------------------------------
    -- 3. Insert log entries for all newly started tasks
    ----------------------------------------------------------------------------
    DECLARE @NextLogKey BIGINT;

    SELECT @NextLogKey = ISNULL(MAX(LogKey), 0) + 1
    FROM etl.Log;

    INSERT INTO etl.Log (LogKey, JobAuditKey, TaskAuditKey, Message, LogDatetime)
    SELECT
        @NextLogKey + ROW_NUMBER() OVER (ORDER BY ta.TaskAuditKey) - 1 AS LogKey,
        ta.JobAuditKey,
        ta.TaskAuditKey,
        'Task execution started for ' + ta.TaskType + ' ' + CAST(ta.TaskKey AS NVARCHAR(10)),
        @CurrentUTCDateTime
    FROM etl.TaskAudit ta
    WHERE ta.JobAuditKey = @JobAuditKey
      AND ta.IsRunning = 1
      AND ta.StartTime >= DATEADD(SECOND, -5, @CurrentUTCDateTime);

    ----------------------------------------------------------------------------
    -- 4. Return summary + MAX(TaskRunOrderNbr)
    ----------------------------------------------------------------------------
    DECLARE @MaxTaskRunOrderNbr INT;

    SELECT @MaxTaskRunOrderNbr = MAX(TaskRunOrderNbr)
    FROM etl.TaskAudit
    WHERE JobAuditKey = @JobAuditKey;

    SELECT
        ta.TaskAuditKey,
        ta.TaskKey,
        ta.TaskType,
        ta.TaskRunOrderNbr,
        CASE WHEN ta.IsRunning = 1 THEN 'Started/Running' ELSE 'Skipped' END AS TaskStatus,
        @MaxTaskRunOrderNbr AS MaxTaskRunOrderNbr
    FROM etl.TaskAudit ta
    WHERE ta.JobAuditKey = @JobAuditKey
      AND ta.TaskAuditKey IS NOT NULL
    ORDER BY ta.TaskRunOrderNbr ASC, ta.TaskAuditKey ASC;
END;