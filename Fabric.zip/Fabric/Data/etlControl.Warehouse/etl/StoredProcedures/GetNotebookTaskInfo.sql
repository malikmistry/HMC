CREATE   PROCEDURE [etl].[GetNotebookTaskInfo] 
	@TaskAuditKey BIGINT
AS
BEGIN
/******************************************************************************
PURPOSE: this proc will retrieves and generates various metadata to pass
to Data factory pipeline to use as dynamic parameters in pipeline functionality
******************************************************************************/
SET NOCOUNT ON;

-- utility variables
DECLARE @LogMessage NVARCHAR(4000)
DECLARE @errorMessage NVARCHAR(2048) -- just declare this here. there are several spots later where we may attempt to use this
DECLARE @TaskKey INT;
DECLARE @JobAuditKey INT;
DECLARE @TaskType NVARCHAR(20);

DECLARE @SinkSchemaName NVARCHAR(2000)
DECLARE @SinkTableName NVARCHAR(2000)
DECLARE @SinkLakehouseName NVARCHAR(2000)

-- declare the additional metadata
DECLARE @SourceSchemaName NVARCHAR(200)
DECLARE @SourceTableName NVARCHAR(200)
DECLARE @NotebookKey NVARCHAR(200);
DECLARE @NotebookName NVARCHAR(200);
DECLARE @RawStoragePath NVARCHAR(200);
DECLARE @RawStorageFileName NVARCHAR(200);
DECLARE @RelativeUrl NVARCHAR(MAX);



-- validate TaskAuditKey and throw error if invalid as rest of proc will not work properly
IF NOT EXISTS (SELECT TOP 1 TaskKey FROM etl.TaskAudit WHERE TaskAuditKey = @TaskAuditKey)
BEGIN
	SET @errorMessage =  'Error: Lookup to etl.TaskAudit failed for TaskAuditKey: "' + ISNULL(CONVERT(VARCHAR(20), @TaskAuditKey), 'NULL') + '" Please verify the TaskAuditKey parameter passed to proc etl.GetNotebookTaskInfo.';
	THROW 50000, @errorMessage, 1;
END

SELECT 
	@TaskKey = TaskKey,
	@TaskType = TaskType,
	@JobAuditKey = JobAuditKey
FROM etl.TaskAudit
WHERE TaskAuditKey = @TaskAuditKey

-- get Source and Notebook Task info
SELECT TOP 1
	@SourceSchemaName = NotebookTask.SourceSchemaName
	,@SourceTableName = NotebookTask.SourceTableName
    ,@SinkTableName = NotebookTask.SinkTableName
	,@SinkSchemaName = NotebookTask.SinkSchemaName
	,@SinkLakehouseName = NotebookTask.SinkLakehouseName

	,@NotebookKey = NotebookTask.NotebookKey
	,@NotebookName = Notebook.NotebookName
	,@RawStoragePath = NotebookTask.RawStoragePath
	,@RawStorageFileName = NotebookTask.RawStorageFileName
	,@RelativeUrl = NotebookTask.RelativeUrl

FROM etl.Task as NotebookTask
LEFT JOIN etl.Notebook as Notebook ON NotebookTask.NotebookKey = Notebook.NotebookKey
WHERE NotebookTask.TaskKey = @TaskKey
;


BEGIN
	SET @LogMessage = 'From etl.GetDatabaseTaskInfo: SourceSchemaName = "' + ISNULL(@SourceSchemaName, '(NULL') + '"'
	EXEC etl.LogMessage @JobAuditKey = NULL, @TaskAuditKey = @TaskAuditKey, @Message = @LogMessage
	SET @LogMessage = 'From etl.GetDatabaseTaskInfo: SourceTableName = "' + ISNULL(@SourceTableName, '(NULL)') + '"'
	EXEC etl.LogMessage @JobAuditKey = NULL, @TaskAuditKey = @TaskAuditKey, @Message = @LogMessage
	SET @LogMessage = 'From etl.GetDatabaseTaskInfo: SinkSchemaName = "' + ISNULL(@SinkSchemaName, '(NULL)') + '"'
	EXEC etl.LogMessage @JobAuditKey = NULL, @TaskAuditKey = @TaskAuditKey, @Message = @LogMessage
	SET @LogMessage = 'From etl.GetDatabaseTaskInfo: SinkTableName = "' +  ISNULL(@SinkTableName, '(NULL)') + '"'
	EXEC etl.LogMessage @JobAuditKey = NULL, @TaskAuditKey = @TaskAuditKey, @Message = @LogMessage
	SET @LogMessage = 'From etl.GetDatabaseTaskInfo: NotebookKey = "' +  ISNULL(@NotebookKey, '(NULL)') + '"'
	EXEC etl.LogMessage @JobAuditKey = NULL, @TaskAuditKey = @TaskAuditKey, @Message = @LogMessage
	SET @LogMessage = 'From etl.GetDatabaseTaskInfo: NotebookName = "' +  ISNULL(@NotebookName, '(NULL)') + '"'
	EXEC etl.LogMessage @JobAuditKey = NULL, @TaskAuditKey = @TaskAuditKey, @Message = @LogMessage
END

-- now return the metadata
SELECT
@JobAuditKey as JobAuditKey
,@TaskKey AS TaskKey
,@TaskType as TaskType
,@SourceSchemaName AS SourceSchemaName
,@SourceTableName AS SourceTableName
,@SinkTableName AS SinkTableName
,@SinkSchemaName AS SinkSchemaName
,@NotebookKey AS NotebookKeyNotebookKey
,@NotebookName AS NotebookName
,@SinkLakehouseName AS SinkLakehouseName
,@RawStoragePath AS RawStoragePath
,@RawStorageFileName AS RawStorageFileName
,@RelativeUrl AS RelativeUrl
END