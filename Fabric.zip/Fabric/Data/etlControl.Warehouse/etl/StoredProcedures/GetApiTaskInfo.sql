CREATE    PROCEDURE [etl].[GetApiTaskInfo]
(
	@TaskKey INT, @TaskAuditKey BIGINT
)
AS
BEGIN
/******************************************************************************
PURPOSE: This procedure is to gather and generate metadata to be used in 
Data Factory data pipeline as dynamic parameters to processing API data ingestion
******************************************************************************/

SET NOCOUNT ON
DECLARE @JobAuditKey BIGINT
DECLARE @TaskType NVARCHAR(40)
DECLARE @ParentSourceName NVARCHAR(200)
DECLARE @SourceName NVARCHAR(200)
DECLARE @ApiTaskName NVARCHAR(2000)
DECLARE @PrimaryKeyColumnList  NVARCHAR(1000)
DECLARE @IsWatermarkEnabledFlag BIT -- (optional) enables incremental-loading functionality

DECLARE @RawStoragePath NVARCHAR(2000)
DECLARE @RawStorageFileName NVARCHAR(2000)
DECLARE @SourceConnectionName NVARCHAR(2000)
DECLARE @RelativeUrl NVARCHAR(MAX)



-- vars not returned
DECLARE @LogMessage NVARCHAR(4000)
DECLARE @errorMessage NVARCHAR(2048) 

-- Get TaskAudit info
-- Note: limits are already set in SetLimitAuditInfo proc called in pipeline before this proc
SELECT 
    @TaskType = TaskType,
    @JobAuditKey = JobAuditKey
FROM etl.TaskAudit
WHERE TaskAuditKey = @TaskAuditKey;

SELECT TOP 1
     @ParentSourceName = ApiTask.ParentSourceName
    ,@SourceName = ApiTask.SourceName
    ,@ApiTaskName = ApiTask.TaskName
    ,@PrimaryKeyColumnList = ApiTask.PrimaryKeyColumnList
    ,@RawStoragePath = ApiTask.RawStoragePath
    ,@RawStorageFileName = ApiTask.RawStorageFileName
    ,@SourceConnectionName = ApiTask.SourceConnectionName
    ,@RelativeUrl = ApiTask.RelativeUrl

FROM etl.Task as ApiTask
WHERE ApiTask.TaskKey = @TaskKey;

-- convert incremental limit datatypes to standard DATETIME to return to pipeline
-- these may be used by notebook and should all be the same format for ease of use


SET @LogMessage = 'From etl.GetApiTaskInfo: ParentSourceName = "' + ISNULL(@ParentSourceName, '(NULL)') + '"'
EXEC etl.LogMessage @JobAuditKey = NULL, @TaskAuditKey = @TaskAuditKey, @Message = @LogMessage
SET @LogMessage = 'From etl.GetApiTaskInfo: SourceName = "' + ISNULL(@SourceName, '(NULL)') + '"'
EXEC etl.LogMessage @JobAuditKey = NULL, @TaskAuditKey = @TaskAuditKey, @Message = @LogMessage
SET @LogMessage = 'From etl.GetApiTaskInfo: ApiTaskName = "' + ISNULL(@ApiTaskName, '(NULL)') + '"'
EXEC etl.LogMessage @JobAuditKey = NULL, @TaskAuditKey = @TaskAuditKey, @Message = @LogMessage
SET @LogMessage = 'From etl.GetApiTaskInfo: TaskType = "' + ISNULL(@TaskType, '(NULL)') + '"'
EXEC etl.LogMessage @JobAuditKey = NULL, @TaskAuditKey = @TaskAuditKey, @Message = @LogMessage
SET @LogMessage = 'From etl.GetApiTaskInfo: PrimaryKeyColumnList = "' + ISNULL(@PrimaryKeyColumnList, '(NULL)') + '"'
EXEC etl.LogMessage @JobAuditKey = NULL, @TaskAuditKey = @TaskAuditKey, @Message = @LogMessage
-- raw logs
SET @LogMessage = 'From etl.GetApiTaskInfo: RawStoragePath = "' + ISNULL(@RawStoragePath, '(NULL)') + '"'
EXEC etl.LogMessage @JobAuditKey = NULL, @TaskAuditKey = @TaskAuditKey, @Message = @LogMessage
SET @LogMessage = 'From etl.GetApiTaskInfo: RawStorageFileName = "' + ISNULL(@RawStorageFileName, '(NULL)') + '"'
EXEC etl.LogMessage @JobAuditKey = NULL, @TaskAuditKey = @TaskAuditKey, @Message = @LogMessage




	-- Return metadata
	SELECT
        @JobAuditKey as JobAuditKey,
        @TaskKey as TaskKey,
        @TaskType as TaskType,
        @ParentSourceName as ParentSourceName,
       	@SourceName as SourceName,
        @ApiTaskName as ApiTaskName,
        @RawStoragePath as RawStoragePath,
        @RawStorageFileName as RawStorageFileName,
        @RelativeUrl as RelativeUrl,
        @SourceConnectionName as SourceConnectionName

END