CREATE     PROCEDURE [etl].[GetMLVlist] 
(
	@JobAuditKey INT
)
AS

--ORIGINAL QUERY
SELECT SinkSchemaName,SinkTableName,CustomSQLSourceQuery FROM etl.Task
WHERE TaskKey IN (
SELECT 
	TaskKey
FROM etl.TaskAudit
WHERE JobAuditKey = @JobAuditKey
AND ISNULL(IsRunning, 0) = 0
AND ISNULL(Status, '') != 'Success'
AND TaskType = 'MLV'
)

--POC QUERY ONLY
--SELECT SinkSchemaName,SinkTableName,CustomSQLSourceQuery FROM etl.Task
--WHERE TaskType = 'MLV'