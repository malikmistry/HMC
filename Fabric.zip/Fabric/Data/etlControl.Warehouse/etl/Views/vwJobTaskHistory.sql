-- Auto Generated (Do not modify) 9013D323F613A82D144DF2F99D490423553231735B51FD7B7D29C4E31E146E32

CREATE VIEW etl.vwJobTaskHistory
AS

SELECT
    SourceTable     = 'etl.Task ',
    j.JobName,
    t.TaskName,
    ta.TaskKey,
    ta.TaskAuditKey,
    ta.PipelineRunID,
    ta.TaskType,
    ta.TaskRunOrderNbr,
    EffectiveStatus = CASE WHEN ta.IsRunning = 1 THEN 'Running' ELSE ta.Status END,
    ta.IsRunning,
    ta.StartTime,
    ta.EndTime,
    DurationSeconds = DATEDIFF(SECOND, ta.StartTime, COALESCE(ta.EndTime, SYSDATETIME())),
	DurationHHMMSS = 	CASE
							WHEN ta.StartTime IS NULL THEN NULL
							WHEN COALESCE(ta.EndTime, SYSUTCDATETIME()) < ta.StartTime THEN '00:00:00'
							ELSE
							  -- compute seconds once, then format as HH:MM:SS
							  CONCAT(
							    CASE WHEN DATEDIFF_BIG(SECOND, ta.StartTime, COALESCE(ta.EndTime, SYSUTCDATETIME()))/3600 < 10
							         THEN '0' ELSE '' END,
							    CAST(DATEDIFF_BIG(SECOND, ta.StartTime, COALESCE(ta.EndTime, SYSUTCDATETIME()))/3600 AS varchar(20)),
							    ':',
							    RIGHT('00' + CAST( (DATEDIFF_BIG(SECOND, ta.StartTime, COALESCE(ta.EndTime, SYSUTCDATETIME()))/60) % 60 AS varchar(2)), 2),
							    ':',
							    RIGHT('00' + CAST(  DATEDIFF_BIG(SECOND, ta.StartTime, COALESCE(ta.EndTime, SYSUTCDATETIME()))     % 60 AS varchar(2)), 2)
    )
END,
    ta.RowsRead, ta.RowsCopied, ta.RowsInserted, ta.RowsUpdated, ta.RowsDeleted, ta.RowsSkipped,
    ta.DebugString,
    ta.LastUpdated
FROM etl.TaskAudit AS ta
JOIN etl.Task     AS t ON t.TaskKey = ta.TaskKey
JOIN etl.Job      AS j ON j.JobKey  = t.JobKey

UNION ALL

SELECT
    SourceTable     = 'etl.FileTask',
    j.JobName,
    ft.TaskName,
    ta.TaskKey,                      -- equals FileTaskKey
    ta.TaskAuditKey,
    ta.PipelineRunID,
    ta.TaskType,
    ta.TaskRunOrderNbr,
    EffectiveStatus = CASE WHEN ta.IsRunning = 1 THEN 'Running' ELSE ta.Status END,
    ta.IsRunning,
    ta.StartTime,
    ta.EndTime,
    DurationSeconds = DATEDIFF(SECOND, ta.StartTime, COALESCE(ta.EndTime, SYSDATETIME())),
	DurationHHMMSS = CASE
						  WHEN ta.StartTime IS NULL THEN NULL
						  WHEN COALESCE(ta.EndTime, SYSUTCDATETIME()) < ta.StartTime THEN '00:00:00'
						  ELSE
						    -- compute seconds once, then format as HH:MM:SS
						    CONCAT(
						      CASE WHEN DATEDIFF_BIG(SECOND, ta.StartTime, COALESCE(ta.EndTime, SYSUTCDATETIME()))/3600 < 10
						           THEN '0' ELSE '' END,
						      CAST(DATEDIFF_BIG(SECOND, ta.StartTime, COALESCE(ta.EndTime, SYSUTCDATETIME()))/3600 AS varchar(20)),
						      ':',
						      RIGHT('00' + CAST( (DATEDIFF_BIG(SECOND, ta.StartTime, COALESCE(ta.EndTime, SYSUTCDATETIME()))/60) % 60 AS varchar(2)), 2),
						      ':',
						      RIGHT('00' + CAST(  DATEDIFF_BIG(SECOND, ta.StartTime, COALESCE(ta.EndTime, SYSUTCDATETIME()))     % 60 AS varchar(2)), 2)
						    )
						END,

    ta.RowsRead, ta.RowsCopied, ta.RowsInserted, ta.RowsUpdated, ta.RowsDeleted, ta.RowsSkipped,
    ta.DebugString,
    ta.LastUpdated
FROM etl.TaskAudit AS ta
JOIN etl.FileTask AS ft ON ft.FileTaskKey = ta.TaskKey
JOIN etl.Job      AS j  ON j.JobKey       = ft.JobKey