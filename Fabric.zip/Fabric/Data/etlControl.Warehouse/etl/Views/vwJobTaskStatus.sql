-- Auto Generated (Do not modify) C0B131A8A4A263AA2AE42DA7FC9125BD5455EE5A6B6B99328C69A141D60087DF


CREATE VIEW etl.vwJobTaskStatus 
as

WITH RankedTaskRuns AS (
    SELECT
        src      = 'Task',
        ta.TaskAuditKey,
        ta.TaskKey,
        ta.JobAuditKey,
        ta.TaskType,
        ta.TaskRunOrderNbr,
        ta.Status,
        ta.IsRunning,
        ta.StartTime,
        ta.EndTime,
        ta.RowsRead, ta.RowsCopied, ta.RowsSkipped, ta.RowsInserted, ta.RowsUpdated, ta.RowsDeleted,
        ta.DebugString, ta.PipelineRunID, ta.LastUpdated,
        t.TaskName,
        t.JobKey,
        j.JobName,
        ROW_NUMBER() OVER (
            PARTITION BY ta.TaskKey
            ORDER BY COALESCE(ta.EndTime, ta.StartTime, ta.LastUpdated) DESC, ta.TaskAuditKey DESC
        ) AS rn
    FROM etl.TaskAudit AS ta
    JOIN etl.Task      AS t ON t.TaskKey = ta.TaskKey
    JOIN etl.Job       AS j ON j.JobKey  = t.JobKey
),
RankedFileTaskRuns AS (
    SELECT
        src      = 'FileTask',
        ta.TaskAuditKey,
        TaskKey        = ta.TaskKey,              -- equals FileTaskKey
        ta.JobAuditKey,
        ta.TaskType,
        ta.TaskRunOrderNbr,
        ta.Status,
        ta.IsRunning,
        ta.StartTime,
        ta.EndTime,
        ta.RowsRead, ta.RowsCopied, ta.RowsSkipped, ta.RowsInserted, ta.RowsUpdated, ta.RowsDeleted,
        ta.DebugString, ta.PipelineRunID, ta.LastUpdated,
        TaskName       = ft.TaskName,
        JobKey         = ft.JobKey,
        JobName        = j.JobName,
        ROW_NUMBER() OVER (
            PARTITION BY ta.TaskKey
            ORDER BY COALESCE(ta.EndTime, ta.StartTime, ta.LastUpdated) DESC, ta.TaskAuditKey DESC
        ) AS rn
    FROM etl.TaskAudit AS ta
    JOIN etl.FileTask AS ft ON ft.FileTaskKey = ta.TaskKey
    JOIN etl.Job      AS j  ON j.JobKey       = ft.JobKey
)
SELECT
    SourceTable       = r.src,
    r.JobName,
    r.TaskName,
    r.TaskKey,
    r.TaskAuditKey,
    r.PipelineRunID,
    r.TaskType,
    r.TaskRunOrderNbr,
    EffectiveStatus   = CASE WHEN r.IsRunning = 1 THEN 'Running' ELSE r.Status END,
    r.IsRunning,
    r.StartTime,
    r.EndTime,
    DurationSeconds   = DATEDIFF(SECOND, r.StartTime, COALESCE(r.EndTime, SYSDATETIME())),
    r.RowsRead,
    r.RowsCopied,
    r.RowsInserted,
    r.RowsUpdated,
    r.RowsDeleted,
    r.RowsSkipped,
    r.DebugString,
    r.LastUpdated
FROM (
    SELECT * FROM RankedTaskRuns     WHERE rn = 1
    UNION ALL
    SELECT * FROM RankedFileTaskRuns WHERE rn = 1
) AS r