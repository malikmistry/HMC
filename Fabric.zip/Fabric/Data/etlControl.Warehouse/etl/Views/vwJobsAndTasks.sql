-- Auto Generated (Do not modify) 5B62F3482214FBEB3CF886AB946BF7AE50E97F958E3E557E444D6DBBA4DA56E8


-- DROP vieW [dbo].[vwJobsAndTasks] 

CREATE VIEW [etl].[vwJobsAndTasks] AS


SELECT j.JobKey, t.TaskKey, j.JobName, t.TaskRunOrderNbr, t.TaskName, t.TaskType, t.TaskTableName, t.NotebookKey,  nb.NotebookName
FROM etl.Job j
JOIN (
    SELECT JobKey, TaskKey, TaskName, TaskType, TaskRunOrderNbr, 'Task' as 'TaskTableName', NotebookKey FROM etl.Task
    UNION ALL
    SELECT JobKey, FileTaskKey as TaskKey, TaskName, TaskType, TaskRunOrderNbr, 'FileTask' as 'TaskTableName', NotebookKey FROM etl.FileTask
) AS t ON j.JobKey = t.JobKey
LEFT JOIN etl.Notebook nb on nb.NotebookKey = t.NotebookKey