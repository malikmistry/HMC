--DROP TABLE IF EXISTS etl.FileTask
--DROP TABLE IF EXISTS etl.Job
--DROP TABLE IF EXISTS etl.Task
--DROP TABLE IF EXISTS etl.Watermark
--DROP TABLE IF EXISTS etl.NotebookKey

-- ***** Script to update the table: etlControl.etl.Job *****
-- ===== UPDATE EXISTING ROWS =====
WITH source (JobName, JobKey, JobDescription, IsActiveFlag) AS (
SELECT 'AivyChatHistorySilver', 37, 'This job loads AivyChatHistory from bronze to silver', 1
UNION ALL
SELECT 'CrimsonXGold', 32, 'Populate data to gold tables', 1
UNION ALL
SELECT 'FactsetSilver', 36, 'Factset to Silver', 1
UNION ALL
SELECT 'AivyEvalsBronze', 38, 'This job loads Aivy Evaluation by API calls and saving Bronze Lakehouse', 1
UNION ALL
SELECT 'AivyEvalsSilver', 39, 'This job loads Aivy Evaluation from and Bronze to Silver', 1
UNION ALL
SELECT 'CrimsonXStaticDataBronze', 34, 'Copying tables that have static data from sql server to bronze', 1
UNION ALL
SELECT 'FundLevelCalcRaw', 25, 'This job handles loading from source API to raw', 1
UNION ALL
SELECT 'FactsetBronze', 4, 'This job handles ETL operations for Factset source data processing to raw (parquet)', 1
UNION ALL
SELECT 'SilverToGold', 33, 'This generic job moves tables from Silver to Gold', 1
UNION ALL
SELECT 'Flatten Classification', 28, 'This job handles flatten classification', 1
UNION ALL
SELECT 'EntraSilver', 18, 'Entra Silver Transformations', 1
UNION ALL
SELECT 'NotesOrchestration', 24, 'Notes Tables from Raw to Silver', 1
UNION ALL
SELECT 'ExcelFileTask', 30, 'This job ingests excel files to raw as parquet', 1
UNION ALL
SELECT 'IndexReturn Bronze', 7, 'process Index Return Data', 1
UNION ALL
SELECT 'BottomUpToSilver', 26, 'This job handles loading API data from FundLevelCalc and FundLevelCalcMonthly to Silver tables', 1
UNION ALL
SELECT 'BottomUpBronze', 23, 'This job handles processing for BottomUp API data to Bronze', 1
UNION ALL
SELECT 'HMCDataMartInvestmentBronze', 22, 'Ingest data from HMCDataMartInvestment to Bronze', 1
UNION ALL
SELECT 'CrimsonXStaticDataSilver', 35, 'Copying tables static bronze to silver', 1
UNION ALL
SELECT 'FundTradeSilver', 19, 'Transform FundTrade data', 1
UNION ALL
SELECT 'EntraBronze', 13, 'Copying Entra/Active Directory data to Raw/bronze', 1
UNION ALL
SELECT 'FXRate', 12, 'This job handles processing for Reuters FXRates to Bronze', 1
UNION ALL
SELECT 'ChatHistoryRawBronze', 29, 'Get Chat History from CosmosDB', 1
UNION ALL
SELECT 'IndexReturnSilver', 21, 'IndexReturn to Silver', 1
UNION ALL
SELECT 'CyberSecurityDataSilver', 31, 'Transforms CyberSecurity Dashboard data for reporting tables', 1
UNION ALL
SELECT 'SpyCloudBronze', 15, 'Ingest SpyCloud csv file to bronze', 1
UNION ALL
SELECT 'CyberSecurityDataBronze', 9, 'Ingests data for CyberSecurity Dashboard metrics', 1
UNION ALL
SELECT 'SolovisSilver', 20, 'Transforms solovis bronze data into silver', 1
UNION ALL
SELECT 'ManualExceptionBronze', 14, 'Ingest Manual Exception csv file to bronze', 1
UNION ALL
SELECT 'BronzeToSilver', 2, 'Job for transforming data from bronze to silver', 1
UNION ALL
SELECT 'MimecastBronze', 16, 'Ingest Mimecast csv file to bronze', 1
UNION ALL
SELECT 'SilverTransformations', 10, 'Runs transformations for Silver tables', 1
UNION ALL
SELECT 'AbnormalBronze', 17, 'Ingest Abnormal csv file to bronze', 1
UNION ALL
SELECT 'CrimsonXSilver', 11, 'Move transformed crimsonx data to Silver', 1
UNION ALL
SELECT 'TestCSVLoad2', 3, 'Test Pipeline', 1
UNION ALL
SELECT 'Solovis Bronze', 6, 'Solovis flat files load from Blob>Raw>Bronze', 1
UNION ALL
SELECT 'Office365UserBronze', 8, 'Copy Office 365 User Data to Bronze', 1
UNION ALL
SELECT 'Test', 1, 'Test Pipeline', 1
UNION ALL
SELECT 'CrimsonXBronze', 5, 'Copying tables from sql server to parquet files', 1
UNION ALL
SELECT 'FundLevelCalcMonthlyRaw', 27, 'This job handles loading API data from FundLevelCalcMonthly API to raw', 1
)
UPDATE target
SET
    target.JobName = source.JobName,
    target.JobDescription = source.JobDescription,
    target.IsActiveFlag = source.IsActiveFlag
FROM etlControl.etl.Job AS target
JOIN source
    ON target.JobKey = source.JobKey;

-- ===== INSERT NEW ROWS =====
WITH source (JobName, JobKey, JobDescription, IsActiveFlag) AS (
SELECT 'AivyChatHistorySilver', 37, 'This job loads AivyChatHistory from bronze to silver', 1
UNION ALL
SELECT 'CrimsonXGold', 32, 'Populate data to gold tables', 1
UNION ALL
SELECT 'FactsetSilver', 36, 'Factset to Silver', 1
UNION ALL
SELECT 'AivyEvalsBronze', 38, 'This job loads Aivy Evaluation by API calls and saving Bronze Lakehouse', 1
UNION ALL
SELECT 'AivyEvalsSilver', 39, 'This job loads Aivy Evaluation from and Bronze to Silver', 1
UNION ALL
SELECT 'CrimsonXStaticDataBronze', 34, 'Copying tables that have static data from sql server to bronze', 1
UNION ALL
SELECT 'FundLevelCalcRaw', 25, 'This job handles loading from source API to raw', 1
UNION ALL
SELECT 'FactsetBronze', 4, 'This job handles ETL operations for Factset source data processing to raw (parquet)', 1
UNION ALL
SELECT 'SilverToGold', 33, 'This generic job moves tables from Silver to Gold', 1
UNION ALL
SELECT 'Flatten Classification', 28, 'This job handles flatten classification', 1
UNION ALL
SELECT 'EntraSilver', 18, 'Entra Silver Transformations', 1
UNION ALL
SELECT 'NotesOrchestration', 24, 'Notes Tables from Raw to Silver', 1
UNION ALL
SELECT 'ExcelFileTask', 30, 'This job ingests excel files to raw as parquet', 1
UNION ALL
SELECT 'IndexReturn Bronze', 7, 'process Index Return Data', 1
UNION ALL
SELECT 'BottomUpToSilver', 26, 'This job handles loading API data from FundLevelCalc and FundLevelCalcMonthly to Silver tables', 1
UNION ALL
SELECT 'BottomUpBronze', 23, 'This job handles processing for BottomUp API data to Bronze', 1
UNION ALL
SELECT 'HMCDataMartInvestmentBronze', 22, 'Ingest data from HMCDataMartInvestment to Bronze', 1
UNION ALL
SELECT 'CrimsonXStaticDataSilver', 35, 'Copying tables static bronze to silver', 1
UNION ALL
SELECT 'FundTradeSilver', 19, 'Transform FundTrade data', 1
UNION ALL
SELECT 'EntraBronze', 13, 'Copying Entra/Active Directory data to Raw/bronze', 1
UNION ALL
SELECT 'FXRate', 12, 'This job handles processing for Reuters FXRates to Bronze', 1
UNION ALL
SELECT 'ChatHistoryRawBronze', 29, 'Get Chat History from CosmosDB', 1
UNION ALL
SELECT 'IndexReturnSilver', 21, 'IndexReturn to Silver', 1
UNION ALL
SELECT 'CyberSecurityDataSilver', 31, 'Transforms CyberSecurity Dashboard data for reporting tables', 1
UNION ALL
SELECT 'SpyCloudBronze', 15, 'Ingest SpyCloud csv file to bronze', 1
UNION ALL
SELECT 'CyberSecurityDataBronze', 9, 'Ingests data for CyberSecurity Dashboard metrics', 1
UNION ALL
SELECT 'SolovisSilver', 20, 'Transforms solovis bronze data into silver', 1
UNION ALL
SELECT 'ManualExceptionBronze', 14, 'Ingest Manual Exception csv file to bronze', 1
UNION ALL
SELECT 'BronzeToSilver', 2, 'Job for transforming data from bronze to silver', 1
UNION ALL
SELECT 'MimecastBronze', 16, 'Ingest Mimecast csv file to bronze', 1
UNION ALL
SELECT 'SilverTransformations', 10, 'Runs transformations for Silver tables', 1
UNION ALL
SELECT 'AbnormalBronze', 17, 'Ingest Abnormal csv file to bronze', 1
UNION ALL
SELECT 'CrimsonXSilver', 11, 'Move transformed crimsonx data to Silver', 1
UNION ALL
SELECT 'TestCSVLoad2', 3, 'Test Pipeline', 1
UNION ALL
SELECT 'Solovis Bronze', 6, 'Solovis flat files load from Blob>Raw>Bronze', 1
UNION ALL
SELECT 'Office365UserBronze', 8, 'Copy Office 365 User Data to Bronze', 1
UNION ALL
SELECT 'Test', 1, 'Test Pipeline', 1
UNION ALL
SELECT 'CrimsonXBronze', 5, 'Copying tables from sql server to parquet files', 1
UNION ALL
SELECT 'FundLevelCalcMonthlyRaw', 27, 'This job handles loading API data from FundLevelCalcMonthly API to raw', 1
)
INSERT INTO etlControl.etl.Job (JobName, JobKey, JobDescription, IsActiveFlag)
SELECT source.JobName, source.JobKey, source.JobDescription, source.IsActiveFlag
FROM source
WHERE NOT EXISTS (
    SELECT 1
    FROM etlControl.etl.Job AS target
    WHERE target.JobKey = source.JobKey
);


-- ***** Script to update the table: etlControl.etl.Notebook *****
-- ===== UPDATE EXISTING ROWS =====
WITH source (NotebookName, NotebookKey, NotebookDescription) AS (
SELECT 'AivyEvalsBronzeToSilver', 49, 'Load Aivy Evaluation from Bronze to Silver'
UNION ALL
SELECT 'LiquidityTermScheduleSilver', 7, 'Transform Liquidity terms to LiquidityTermSchedule'
UNION ALL
SELECT 'AivyChatHistoryToSilver', 47, 'Load AivyChatHistory from bronze to silver'
UNION ALL
SELECT 'SolovisValuationsSilver', 46, 'Loads the current valuations'
UNION ALL
SELECT 'FundPerformanceGold', 45, 'Calculate FundPerformance to Gold'
UNION ALL
SELECT 'FundProjectedAnalyticsGold', 41, 'Populate data to FundProjectedAnalytics in Gold'
UNION ALL
SELECT 'DeptRiskData', 34, 'Write DeptRiskData to Silver.CybersecurityDeptRisk'
UNION ALL
SELECT 'UserRiskData', 32, 'Write UserRiskData to Silver.CyberSecurityUserRiskData'
UNION ALL
SELECT 'AivyEvalsAPIToBronze', 48, 'Calling Aivy chat evalations and uploading to Bronze'
UNION ALL
SELECT 'KnowBe4DataToSilver', 30, 'Write KnowBe4Date to Silver.CyberSecurityKnowBe4Data'
UNION ALL
SELECT 'SplunkData', 28, 'Write Splunkdata to Bronze.CyberDashboard.Splunk'
UNION ALL
SELECT 'FundBenchmarkTrackRecordGold', 43, 'Populate data to FundBenchmarkTrackRecord in Gold'
UNION ALL
SELECT 'FlattenClassificationsSilver', 23, 'Flatten the classification structure to Silver'
UNION ALL
SELECT 'IndexReturnStep2ComputeLevelsSilver_11', 16, 'IndexReturn Compute Levels'
UNION ALL
SELECT 'APIBottomUpBronze', 19, 'Create bronze tables for Bottom Up'
UNION ALL
SELECT 'UserRiskArea', 36, 'Write UserRiskArea to Silver.CyberSecurityUserRiskArea tables'
UNION ALL
SELECT 'CalculateFundReturnsSilver', 27, 'Calculate net and gross return streams and horizons for funds'
UNION ALL
SELECT 'CustomRiskBenchmarkGold', 44, 'Calculate CustomRiskBenchmark to Gold'
UNION ALL
SELECT 'ManualDataToSilver', 31, 'Write ManualDataToSilver to Silver.CyberSecurityManualUpdates'
UNION ALL
SELECT 'FailureRatesData', 37, 'Write FailureRatesData to Silver.CyberSecurityFailureRatesData'
UNION ALL
SELECT 'CalculateFundAlphasSilver', 39, 'Calculate gross alpha, gross manager alpha, gross strategy alpha and net alpha return horizons for funds'
UNION ALL
SELECT 'UserRiskLevels', 33, 'Write UserRiskLevels to Silver.CyberSecurityUserRiskLevels'
UNION ALL
SELECT 'IndexReturnStep4FrequencyPromotionSilver_06', 17, 'IndexReturn Frequency Promotiion'
UNION ALL
SELECT 'UniverseSilver', 3, 'Tranform Universe data to Silver'
UNION ALL
SELECT 'ForecastedCashflowSilver', 12, 'Load ForecastedCashflowSilver from bronze to silver'
UNION ALL
SELECT 'SolovisTransactionsCashflowTransactionDetailSilver', 11, 'Load solovis transactions into cashflowtransactiondetail'
UNION ALL
SELECT 'KnowBe4Users', 25, 'Write the users data from KnowBe4 to a parquet file'
UNION ALL
SELECT 'FXRateSilver', 4, 'Custom load process of FxRate to Silver'
UNION ALL
SELECT 'IndexReturnStep1GapFillSilver_7', 15, 'IndexReturn Gap Filler'
UNION ALL
SELECT 'OverallScoreData', 35, 'Write OverallScoreData to Silver.CyberSecurityOverallScore'
UNION ALL
SELECT 'IndexReturnStep3ComputedBenchmarksSilver_06', 24, 'IndexReturn Computed Benchmarks'
UNION ALL
SELECT 'DrawdownFundAnalyticsGold', 42, 'Calculate drawdonfundanalytic gold'
UNION ALL
SELECT 'APIBottomUpSilver', 22, 'Silver transformations for Bottom up tables'
UNION ALL
SELECT 'SpyCloudData', 26, 'Wrtie the SpyCloud data to  Bronze.CyberDashboardSpyCloud table'
UNION ALL
SELECT 'CalculateFundRiskBenchmarkSilver', 38, 'Calculate risk benchmark return horizons for funds'
UNION ALL
SELECT 'SolovisMarketValueSilver', 20, 'Loads solovis market values into holdingshistory and FundMarketValues'
UNION ALL
SELECT 'FundSilver', 18, 'Load FundSilver from bronze to silver'
UNION ALL
SELECT 'UpdateCashflowTransactionDetailsUSDAmountsBronze', 21, 'Updates the USD with the correct FX rate for Bronze.CrimsonXCashflowTransactionDetail'
UNION ALL
SELECT 'PhishingTestsSummaryData', 29, 'Write KnowBe4Phishing Test Summary to Silver.CyberSecurityPhishingTestsSummary'
UNION ALL
SELECT 'CalculateFundStatisticsCleanupSilver', 40, 'Cleanup after calculating fund statistics'
UNION ALL
SELECT 'NotesSilver', 8, 'Silver Transformations to create Note, NoteLink,NoteAttachments'
UNION ALL
SELECT 'EntraHMCUserSilver', 9, 'Silver Entra Users'
UNION ALL
SELECT 'ForecastedTransactionSilver', 13, 'Load ForecastedTransactionSilver from bronze to silver'
UNION ALL
SELECT 'KnowBe4PhishingData', 1, 'Ingests various Phishing Test Datasets'
UNION ALL
SELECT 'Bronze Build ActiveBook and Fund Mappings', 10, 'Builds the ActiveBook and Fund mappings from solovis to Crimson'
UNION ALL
SELECT 'Factset_IndexRegionCountryExposure_Silver', 2, 'Runs transformation for IndexCountryExposure table in Silver'
UNION ALL
SELECT 'Factset_IndexRegionExposure_Silver', 5, 'Runs transformation for IndexRegionExposure table in Silver'
UNION ALL
SELECT 'FundTradeSilver', 14, 'Load FundTradeSilver from bronze to silver'
UNION ALL
SELECT 'Factset_IndexSectorIndustryExposure_Silver', 6, 'Runs transformation for IndeSectorIndustryExposure table in Silver'
)
UPDATE target
SET
    target.NotebookName = source.NotebookName,
    target.NotebookDescription = source.NotebookDescription
FROM etlControl.etl.Notebook AS target
JOIN source
    ON target.NotebookKey = source.NotebookKey;

-- ===== INSERT NEW ROWS =====
WITH source (NotebookName, NotebookKey, NotebookDescription) AS (
SELECT 'AivyEvalsBronzeToSilver', 49, 'Load Aivy Evaluation from Bronze to Silver'
UNION ALL
SELECT 'LiquidityTermScheduleSilver', 7, 'Transform Liquidity terms to LiquidityTermSchedule'
UNION ALL
SELECT 'AivyChatHistoryToSilver', 47, 'Load AivyChatHistory from bronze to silver'
UNION ALL
SELECT 'SolovisValuationsSilver', 46, 'Loads the current valuations'
UNION ALL
SELECT 'FundPerformanceGold', 45, 'Calculate FundPerformance to Gold'
UNION ALL
SELECT 'FundProjectedAnalyticsGold', 41, 'Populate data to FundProjectedAnalytics in Gold'
UNION ALL
SELECT 'DeptRiskData', 34, 'Write DeptRiskData to Silver.CybersecurityDeptRisk'
UNION ALL
SELECT 'UserRiskData', 32, 'Write UserRiskData to Silver.CyberSecurityUserRiskData'
UNION ALL
SELECT 'AivyEvalsAPIToBronze', 48, 'Calling Aivy chat evalations and uploading to Bronze'
UNION ALL
SELECT 'KnowBe4DataToSilver', 30, 'Write KnowBe4Date to Silver.CyberSecurityKnowBe4Data'
UNION ALL
SELECT 'SplunkData', 28, 'Write Splunkdata to Bronze.CyberDashboard.Splunk'
UNION ALL
SELECT 'FundBenchmarkTrackRecordGold', 43, 'Populate data to FundBenchmarkTrackRecord in Gold'
UNION ALL
SELECT 'FlattenClassificationsSilver', 23, 'Flatten the classification structure to Silver'
UNION ALL
SELECT 'IndexReturnStep2ComputeLevelsSilver_11', 16, 'IndexReturn Compute Levels'
UNION ALL
SELECT 'APIBottomUpBronze', 19, 'Create bronze tables for Bottom Up'
UNION ALL
SELECT 'UserRiskArea', 36, 'Write UserRiskArea to Silver.CyberSecurityUserRiskArea tables'
UNION ALL
SELECT 'CalculateFundReturnsSilver', 27, 'Calculate net and gross return streams and horizons for funds'
UNION ALL
SELECT 'CustomRiskBenchmarkGold', 44, 'Calculate CustomRiskBenchmark to Gold'
UNION ALL
SELECT 'ManualDataToSilver', 31, 'Write ManualDataToSilver to Silver.CyberSecurityManualUpdates'
UNION ALL
SELECT 'FailureRatesData', 37, 'Write FailureRatesData to Silver.CyberSecurityFailureRatesData'
UNION ALL
SELECT 'CalculateFundAlphasSilver', 39, 'Calculate gross alpha, gross manager alpha, gross strategy alpha and net alpha return horizons for funds'
UNION ALL
SELECT 'UserRiskLevels', 33, 'Write UserRiskLevels to Silver.CyberSecurityUserRiskLevels'
UNION ALL
SELECT 'IndexReturnStep4FrequencyPromotionSilver_06', 17, 'IndexReturn Frequency Promotiion'
UNION ALL
SELECT 'UniverseSilver', 3, 'Tranform Universe data to Silver'
UNION ALL
SELECT 'ForecastedCashflowSilver', 12, 'Load ForecastedCashflowSilver from bronze to silver'
UNION ALL
SELECT 'SolovisTransactionsCashflowTransactionDetailSilver', 11, 'Load solovis transactions into cashflowtransactiondetail'
UNION ALL
SELECT 'KnowBe4Users', 25, 'Write the users data from KnowBe4 to a parquet file'
UNION ALL
SELECT 'FXRateSilver', 4, 'Custom load process of FxRate to Silver'
UNION ALL
SELECT 'IndexReturnStep1GapFillSilver_7', 15, 'IndexReturn Gap Filler'
UNION ALL
SELECT 'OverallScoreData', 35, 'Write OverallScoreData to Silver.CyberSecurityOverallScore'
UNION ALL
SELECT 'IndexReturnStep3ComputedBenchmarksSilver_06', 24, 'IndexReturn Computed Benchmarks'
UNION ALL
SELECT 'DrawdownFundAnalyticsGold', 42, 'Calculate drawdonfundanalytic gold'
UNION ALL
SELECT 'APIBottomUpSilver', 22, 'Silver transformations for Bottom up tables'
UNION ALL
SELECT 'SpyCloudData', 26, 'Wrtie the SpyCloud data to  Bronze.CyberDashboardSpyCloud table'
UNION ALL
SELECT 'CalculateFundRiskBenchmarkSilver', 38, 'Calculate risk benchmark return horizons for funds'
UNION ALL
SELECT 'SolovisMarketValueSilver', 20, 'Loads solovis market values into holdingshistory and FundMarketValues'
UNION ALL
SELECT 'FundSilver', 18, 'Load FundSilver from bronze to silver'
UNION ALL
SELECT 'UpdateCashflowTransactionDetailsUSDAmountsBronze', 21, 'Updates the USD with the correct FX rate for Bronze.CrimsonXCashflowTransactionDetail'
UNION ALL
SELECT 'PhishingTestsSummaryData', 29, 'Write KnowBe4Phishing Test Summary to Silver.CyberSecurityPhishingTestsSummary'
UNION ALL
SELECT 'CalculateFundStatisticsCleanupSilver', 40, 'Cleanup after calculating fund statistics'
UNION ALL
SELECT 'NotesSilver', 8, 'Silver Transformations to create Note, NoteLink,NoteAttachments'
UNION ALL
SELECT 'EntraHMCUserSilver', 9, 'Silver Entra Users'
UNION ALL
SELECT 'ForecastedTransactionSilver', 13, 'Load ForecastedTransactionSilver from bronze to silver'
UNION ALL
SELECT 'KnowBe4PhishingData', 1, 'Ingests various Phishing Test Datasets'
UNION ALL
SELECT 'Bronze Build ActiveBook and Fund Mappings', 10, 'Builds the ActiveBook and Fund mappings from solovis to Crimson'
UNION ALL
SELECT 'Factset_IndexRegionCountryExposure_Silver', 2, 'Runs transformation for IndexCountryExposure table in Silver'
UNION ALL
SELECT 'Factset_IndexRegionExposure_Silver', 5, 'Runs transformation for IndexRegionExposure table in Silver'
UNION ALL
SELECT 'FundTradeSilver', 14, 'Load FundTradeSilver from bronze to silver'
UNION ALL
SELECT 'Factset_IndexSectorIndustryExposure_Silver', 6, 'Runs transformation for IndeSectorIndustryExposure table in Silver'
)
INSERT INTO etlControl.etl.Notebook (NotebookName, NotebookKey, NotebookDescription)
SELECT source.NotebookName, source.NotebookKey, source.NotebookDescription
FROM source
WHERE NOT EXISTS (
    SELECT 1
    FROM etlControl.etl.Notebook AS target
    WHERE target.NotebookKey = source.NotebookKey
);


-- ***** Script to update the table: etlControl.etl.FileTask *****
-- ===== UPDATE EXISTING ROWS =====
WITH source (SkipRows, SinkWarehouseName, IsActiveFlag, SinkTableName, RawLakehouseName, SinkWorkspaceName, SourceDataSet, SinkWatermarkColumn, LastModifiedFrom, SinkSchemaName, SinkObjectType, NotebookKey, Delimiter, SinkDataset, TaskType, RawStoragePath, SheetIndexArray, SinkLoadMethod, SourceName, TaskRunOrderNbr, SourceWildcardFileName, ETLWarehouseName, FileFilter, ParentSourceName, SourceType, TaskName, FileType, SinkLakehouseName, FileTaskKey, RawStorageFileName, PrimaryKeyColumnList, IsWatermarkEnabledFlag, SourceWildcardFolderPath, JobKey) AS (
SELECT 0, 'Bronze', 1, '02Test', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, 1, ',', '', 'FileTask', 'rawtest', NULL, 'overwrite', 'Test', 1, 'S&P500HistoricalData.csv', 'etlControl', NULL, 'Test', 'file', 'Test', 'delimited', 'lh_bronze', 5002, 'S&P500HistoricalData', 'Date', 0, 'IncomingFeed/test', 1
UNION ALL
SELECT 0, 'Bronze', 1, '01Test', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, 1, ',', '', 'FileTask', 'rawtest', NULL, 'overwrite', 'Test', 1, 'INDEX_US_DOW JONES GLOBAL_DJIA.csv', 'etlControl', NULL, 'Test', 'file', 'Test', 'delimited', 'lh_bronze', 5001, 'INDEX_US_DOW JONES GLOBAL_DJIA', 'Date', 0, 'IncomingFeed/test', 1
UNION ALL
SELECT 2, NULL, 1, 'FXRate', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, NULL, ',', NULL, 'FileTask', 'ReutersFX', NULL, 'append', 'ReutersFX', 1, '*.csv', 'etlControl', 'to_date(`"Date & Time"`, ''dd/MM/yyyy HH:mm'') = ''{yesterday}''', 'ReutersFX', 'ReutersFX', 'ReutersFXBronze', 'delimited', 'lh_bronze', 5003, 'FXRate', NULL, 0, 'proworkspace/ReutersFX', 12
UNION ALL
SELECT 0, NULL, 1, 'ExcelTest', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'ExcelTest', '0,1', 'overwrite', 'ExcelFile', 1, '*.xlsx', 'etlControl', NULL, 'ExcelFile', 'file', 'TextExcelMultipleSheets', 'xlsx', 'lh_bronze', 5027, 'excel_raw', NULL, 0, 'rawtest', 30
UNION ALL
SELECT 0, NULL, 1, 'SolovisInvestmentIgnoreList', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'SolovisInvestmentIgnoreList.csv', 'etlControl', NULL, 'Solovis', 'file', 'SolovisInvestmentIgnoreList', 'delimited', 'lh_bronze', 5017, 'SolovisInvestmentIgnoreList', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisEntityIgnoreList', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'SolovisEntityIgnoreList.csv', 'etlControl', NULL, 'Solovis', 'file', 'SolovisEntityIgnoreList', 'delimited', 'lh_bronze', 5016, 'SolovisEntityIgnoreList', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisMarketValues', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_market_values.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_market_values', 'delimited', 'lh_bronze', 5011, 'solovis_market_values', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisTransactions', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_transactions.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_transactions', 'delimited', 'lh_bronze', 5014, 'solovis_transactions', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisTransactionsMaterial', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_transactions_material.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_transactions_material', 'delimited', 'lh_bronze', 5015, 'solovis_transactions_material', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisTagsets', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_tagsets.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_tagsets', 'delimited', 'lh_bronze', 5013, 'solovis_tagsets', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisMarketValuesMaterial', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_market_values_material.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_market_values_material', 'delimited', 'lh_bronze', 5012, 'solovis_market_values_material', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisLiquidityTerms', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_liquidity_terms.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_liquidity_terms', 'delimited', 'lh_bronze', 5010, 'solovis_liquidity_terms', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisLiquiditySidePockets', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_liquidity_side_pockets.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_liquidity_side_pockets', 'delimited', 'lh_bronze', 5009, 'solovis_liquidity_side_pockets', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisLiquidityReceipts', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_liquidity_receipts.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_liquidity_receipts', 'delimited', 'lh_bronze', 5008, 'solovis_liquidity_receipts', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisEntities', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_entities.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_entities', 'delimited', 'lh_bronze', 5006, 'solovis_entities', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisInvestments', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_investments.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_investments', 'delimited', 'lh_bronze', 5007, 'solovis_investments', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisCommitments', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_commitments.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_commitments', 'delimited', 'lh_bronze', 5005, 'solovis_commitments', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 13, NULL, 1, 'BloombergIndexReturn', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'IndexReturn', NULL, 'overwrite', 'IndexReturn', 1, '*.txt', 'etlControl', NULL, 'IndexReturn', 'file', 'BloombergIndexReturn', 'delimited', 'lh_bronze', 5019, 'BloombergIndexReturn', NULL, 0, 'proworkspace/IndexReturn/Bloomberg/Nightly', 7
UNION ALL
SELECT NULL, NULL, 1, 'Note', 'lh_raw', 'Dev - Crimson', '', NULL, NULL, 'Bronze', NULL, NULL, NULL, NULL, 'FileTask', 'Notes', NULL, 'merge', 'Blob', 1, '{date.today():%Y%m}', 'etlControl', NULL, 'Blob', 'file', 'Notes to Bronze', 'json', 'lh_bronze', 5022, 'Notes', 'noteId', 0, 'proworkspace/Notes/MetaData', 24
UNION ALL
SELECT 0, NULL, 1, 'Mimecast', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'Mimecast', NULL, 'overwrite', 'Mimecast', 1, 'Mimecast*', 'etlControl', NULL, 'Mimecast', 'file', 'Mimecast', 'delimited', 'lh_bronze', 5023, 'Mimecast', NULL, 0, 'proworkspace/Mimecast', 16
UNION ALL
SELECT 0, NULL, 1, 'Abnormal', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'Abnormal', NULL, 'overwrite', 'Abnormal', 1, 'Abnormal_results.csv', 'etlControl', NULL, 'Abnormal', 'file', 'Abnormal', 'delimited', 'lh_bronze', 5024, 'Abnormal', NULL, 0, 'proworkspace/Abnormal', 17
UNION ALL
SELECT 0, NULL, 1, 'SpyCloud', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'SpyCloud', NULL, 'overwrite', 'SpyCloud', 1, 'SpyCloudData.csv', 'etlControl', NULL, 'SpyCloud', 'file', 'SpyCloud', 'delimited', 'lh_bronze', 5021, 'SpyCloud', NULL, 0, 'proworkspace/SpyCloud', 15
UNION ALL
SELECT 0, NULL, 1, 'KnowBe4Users', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ' ', NULL, 'FileTask', 'KnowBe4', NULL, 'merge', 'KnowBe4', 2, '*.parquet', 'etlControl', NULL, 'KnowBe4API', 'KnowBe4', 'KnowBe4Users', 'parquet', 'lh_bronze', 5025, 'knowbe4_users.parquet', NULL, 0, 'IncomingFeed/CyberSecurityDashboard/KnowBe4/knowbe4_users.parquet', 9
UNION ALL
SELECT 0, 'Bronze', 1, 'Factset', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, 1, '|', '', 'FileTask', 'Factset', NULL, 'overwrite', 'FactSet', 1, '*.txt', 'etlControl', NULL, 'FactSet', 'file', 'Factset Files', 'delimited', 'lh_bronze', 5004, 'Factset', '', 0, 'proworkspace/FactSet', 4
UNION ALL
SELECT 0, NULL, 1, 'TaxData', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'TaxDataRaw', '1', 'overwrite', 'ExcelFile', 1, '2019And2024TaxData.xlsx', 'etlControl', NULL, 'ExcelFile', 'file', 'TaxData2019And2024', 'xlsx', 'lh_bronze', 5028, 'TaxData2019and2024', NULL, 0, 'FileTax', 30
UNION ALL
SELECT 0, NULL, 1, 'KnowBe4PhishingTest', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, -1, '', '', 'FileTask', 'KnowBe4', NULL, 'merge', 'KnowBe4', 2, '*.parquet', 'etlControl', NULL, 'KnowBe4API', 'KnowBe4', 'KnowBe4PhishingTests', 'parquet', 'lh_bronze', 5018, 'knowbe4_data.parquet', 'pst_id,recipient_id', 0, 'IncomingFeed/CyberSecurityDashboard/KnowBe4/knowbe4_data.parquet', 9
UNION ALL
SELECT 0, NULL, 1, 'ManualExceptions', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'ManualExceptions', NULL, 'overwrite', 'ManualExceptions', 1, 'ManualExceptionsData.csv', 'etlControl', NULL, 'ManualExceptions', 'file', 'ManualExceptions', 'delimited', 'lh_bronze', 5020, 'ManualExceptions', NULL, 0, 'proworkspace/ManualExceptions', 14
)
UPDATE target
SET
    target.SkipRows = source.SkipRows,
    target.SinkWarehouseName = source.SinkWarehouseName,
    target.IsActiveFlag = source.IsActiveFlag,
    target.SinkTableName = source.SinkTableName,
    target.RawLakehouseName = source.RawLakehouseName,
    target.SinkWorkspaceName = source.SinkWorkspaceName,
    target.SourceDataSet = source.SourceDataSet,
    target.SinkWatermarkColumn = source.SinkWatermarkColumn,
    target.LastModifiedFrom = source.LastModifiedFrom,
    target.SinkSchemaName = source.SinkSchemaName,
    target.SinkObjectType = source.SinkObjectType,
    target.NotebookKey = source.NotebookKey,
    target.Delimiter = source.Delimiter,
    target.SinkDataset = source.SinkDataset,
    target.TaskType = source.TaskType,
    target.RawStoragePath = source.RawStoragePath,
    target.SheetIndexArray = source.SheetIndexArray,
    target.SinkLoadMethod = source.SinkLoadMethod,
    target.SourceName = source.SourceName,
    target.TaskRunOrderNbr = source.TaskRunOrderNbr,
    target.SourceWildcardFileName = source.SourceWildcardFileName,
    target.ETLWarehouseName = source.ETLWarehouseName,
    target.FileFilter = source.FileFilter,
    target.ParentSourceName = source.ParentSourceName,
    target.SourceType = source.SourceType,
    target.TaskName = source.TaskName,
    target.FileType = source.FileType,
    target.SinkLakehouseName = source.SinkLakehouseName,
    target.RawStorageFileName = source.RawStorageFileName,
    target.PrimaryKeyColumnList = source.PrimaryKeyColumnList,
    target.IsWatermarkEnabledFlag = source.IsWatermarkEnabledFlag,
    target.SourceWildcardFolderPath = source.SourceWildcardFolderPath,
    target.JobKey = source.JobKey
FROM etlControl.etl.FileTask AS target
JOIN source
    ON target.FileTaskKey = source.FileTaskKey;

-- ===== INSERT NEW ROWS =====
WITH source (SkipRows, SinkWarehouseName, IsActiveFlag, SinkTableName, RawLakehouseName, SinkWorkspaceName, SourceDataSet, SinkWatermarkColumn, LastModifiedFrom, SinkSchemaName, SinkObjectType, NotebookKey, Delimiter, SinkDataset, TaskType, RawStoragePath, SheetIndexArray, SinkLoadMethod, SourceName, TaskRunOrderNbr, SourceWildcardFileName, ETLWarehouseName, FileFilter, ParentSourceName, SourceType, TaskName, FileType, SinkLakehouseName, FileTaskKey, RawStorageFileName, PrimaryKeyColumnList, IsWatermarkEnabledFlag, SourceWildcardFolderPath, JobKey) AS (
SELECT 0, 'Bronze', 1, '02Test', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, 1, ',', '', 'FileTask', 'rawtest', NULL, 'overwrite', 'Test', 1, 'S&P500HistoricalData.csv', 'etlControl', NULL, 'Test', 'file', 'Test', 'delimited', 'lh_bronze', 5002, 'S&P500HistoricalData', 'Date', 0, 'IncomingFeed/test', 1
UNION ALL
SELECT 0, 'Bronze', 1, '01Test', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, 1, ',', '', 'FileTask', 'rawtest', NULL, 'overwrite', 'Test', 1, 'INDEX_US_DOW JONES GLOBAL_DJIA.csv', 'etlControl', NULL, 'Test', 'file', 'Test', 'delimited', 'lh_bronze', 5001, 'INDEX_US_DOW JONES GLOBAL_DJIA', 'Date', 0, 'IncomingFeed/test', 1
UNION ALL
SELECT 2, NULL, 1, 'FXRate', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, NULL, ',', NULL, 'FileTask', 'ReutersFX', NULL, 'append', 'ReutersFX', 1, '*.csv', 'etlControl', 'to_date(`"Date & Time"`, ''dd/MM/yyyy HH:mm'') = ''{yesterday}''', 'ReutersFX', 'ReutersFX', 'ReutersFXBronze', 'delimited', 'lh_bronze', 5003, 'FXRate', NULL, 0, 'proworkspace/ReutersFX', 12
UNION ALL
SELECT 0, NULL, 1, 'ExcelTest', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'ExcelTest', '0,1', 'overwrite', 'ExcelFile', 1, '*.xlsx', 'etlControl', NULL, 'ExcelFile', 'file', 'TextExcelMultipleSheets', 'xlsx', 'lh_bronze', 5027, 'excel_raw', NULL, 0, 'rawtest', 30
UNION ALL
SELECT 0, NULL, 1, 'SolovisInvestmentIgnoreList', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'SolovisInvestmentIgnoreList.csv', 'etlControl', NULL, 'Solovis', 'file', 'SolovisInvestmentIgnoreList', 'delimited', 'lh_bronze', 5017, 'SolovisInvestmentIgnoreList', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisEntityIgnoreList', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'SolovisEntityIgnoreList.csv', 'etlControl', NULL, 'Solovis', 'file', 'SolovisEntityIgnoreList', 'delimited', 'lh_bronze', 5016, 'SolovisEntityIgnoreList', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisMarketValues', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_market_values.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_market_values', 'delimited', 'lh_bronze', 5011, 'solovis_market_values', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisTransactions', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_transactions.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_transactions', 'delimited', 'lh_bronze', 5014, 'solovis_transactions', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisTransactionsMaterial', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_transactions_material.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_transactions_material', 'delimited', 'lh_bronze', 5015, 'solovis_transactions_material', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisTagsets', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_tagsets.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_tagsets', 'delimited', 'lh_bronze', 5013, 'solovis_tagsets', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisMarketValuesMaterial', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_market_values_material.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_market_values_material', 'delimited', 'lh_bronze', 5012, 'solovis_market_values_material', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisLiquidityTerms', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_liquidity_terms.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_liquidity_terms', 'delimited', 'lh_bronze', 5010, 'solovis_liquidity_terms', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisLiquiditySidePockets', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_liquidity_side_pockets.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_liquidity_side_pockets', 'delimited', 'lh_bronze', 5009, 'solovis_liquidity_side_pockets', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisLiquidityReceipts', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_liquidity_receipts.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_liquidity_receipts', 'delimited', 'lh_bronze', 5008, 'solovis_liquidity_receipts', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisEntities', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_entities.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_entities', 'delimited', 'lh_bronze', 5006, 'solovis_entities', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisInvestments', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_investments.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_investments', 'delimited', 'lh_bronze', 5007, 'solovis_investments', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisCommitments', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', NULL, 'overwrite', 'Solovis', 1, 'solovis_commitments.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_commitments', 'delimited', 'lh_bronze', 5005, 'solovis_commitments', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 13, NULL, 1, 'BloombergIndexReturn', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'IndexReturn', NULL, 'overwrite', 'IndexReturn', 1, '*.txt', 'etlControl', NULL, 'IndexReturn', 'file', 'BloombergIndexReturn', 'delimited', 'lh_bronze', 5019, 'BloombergIndexReturn', NULL, 0, 'proworkspace/IndexReturn/Bloomberg/Nightly', 7
UNION ALL
SELECT NULL, NULL, 1, 'Note', 'lh_raw', 'Dev - Crimson', '', NULL, NULL, 'Bronze', NULL, NULL, NULL, NULL, 'FileTask', 'Notes', NULL, 'merge', 'Blob', 1, '{date.today():%Y%m}', 'etlControl', NULL, 'Blob', 'file', 'Notes to Bronze', 'json', 'lh_bronze', 5022, 'Notes', 'noteId', 0, 'proworkspace/Notes/MetaData', 24
UNION ALL
SELECT 0, NULL, 1, 'Mimecast', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'Mimecast', NULL, 'overwrite', 'Mimecast', 1, 'Mimecast*', 'etlControl', NULL, 'Mimecast', 'file', 'Mimecast', 'delimited', 'lh_bronze', 5023, 'Mimecast', NULL, 0, 'proworkspace/Mimecast', 16
UNION ALL
SELECT 0, NULL, 1, 'Abnormal', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'Abnormal', NULL, 'overwrite', 'Abnormal', 1, 'Abnormal_results.csv', 'etlControl', NULL, 'Abnormal', 'file', 'Abnormal', 'delimited', 'lh_bronze', 5024, 'Abnormal', NULL, 0, 'proworkspace/Abnormal', 17
UNION ALL
SELECT 0, NULL, 1, 'SpyCloud', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'SpyCloud', NULL, 'overwrite', 'SpyCloud', 1, 'SpyCloudData.csv', 'etlControl', NULL, 'SpyCloud', 'file', 'SpyCloud', 'delimited', 'lh_bronze', 5021, 'SpyCloud', NULL, 0, 'proworkspace/SpyCloud', 15
UNION ALL
SELECT 0, NULL, 1, 'KnowBe4Users', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ' ', NULL, 'FileTask', 'KnowBe4', NULL, 'merge', 'KnowBe4', 2, '*.parquet', 'etlControl', NULL, 'KnowBe4API', 'KnowBe4', 'KnowBe4Users', 'parquet', 'lh_bronze', 5025, 'knowbe4_users.parquet', NULL, 0, 'IncomingFeed/CyberSecurityDashboard/KnowBe4/knowbe4_users.parquet', 9
UNION ALL
SELECT 0, 'Bronze', 1, 'Factset', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, 1, '|', '', 'FileTask', 'Factset', NULL, 'overwrite', 'FactSet', 1, '*.txt', 'etlControl', NULL, 'FactSet', 'file', 'Factset Files', 'delimited', 'lh_bronze', 5004, 'Factset', '', 0, 'proworkspace/FactSet', 4
UNION ALL
SELECT 0, NULL, 1, 'TaxData', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'TaxDataRaw', '1', 'overwrite', 'ExcelFile', 1, '2019And2024TaxData.xlsx', 'etlControl', NULL, 'ExcelFile', 'file', 'TaxData2019And2024', 'xlsx', 'lh_bronze', 5028, 'TaxData2019and2024', NULL, 0, 'FileTax', 30
UNION ALL
SELECT 0, NULL, 1, 'KnowBe4PhishingTest', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, -1, '', '', 'FileTask', 'KnowBe4', NULL, 'merge', 'KnowBe4', 2, '*.parquet', 'etlControl', NULL, 'KnowBe4API', 'KnowBe4', 'KnowBe4PhishingTests', 'parquet', 'lh_bronze', 5018, 'knowbe4_data.parquet', 'pst_id,recipient_id', 0, 'IncomingFeed/CyberSecurityDashboard/KnowBe4/knowbe4_data.parquet', 9
UNION ALL
SELECT 0, NULL, 1, 'ManualExceptions', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'ManualExceptions', NULL, 'overwrite', 'ManualExceptions', 1, 'ManualExceptionsData.csv', 'etlControl', NULL, 'ManualExceptions', 'file', 'ManualExceptions', 'delimited', 'lh_bronze', 5020, 'ManualExceptions', NULL, 0, 'proworkspace/ManualExceptions', 14
)
INSERT INTO etlControl.etl.FileTask (SkipRows, SinkWarehouseName, IsActiveFlag, SinkTableName, RawLakehouseName, SinkWorkspaceName, SourceDataSet, SinkWatermarkColumn, LastModifiedFrom, SinkSchemaName, SinkObjectType, NotebookKey, Delimiter, SinkDataset, TaskType, RawStoragePath, SheetIndexArray, SinkLoadMethod, SourceName, TaskRunOrderNbr, SourceWildcardFileName, ETLWarehouseName, FileFilter, ParentSourceName, SourceType, TaskName, FileType, SinkLakehouseName, FileTaskKey, RawStorageFileName, PrimaryKeyColumnList, IsWatermarkEnabledFlag, SourceWildcardFolderPath, JobKey)
SELECT source.SkipRows, source.SinkWarehouseName, source.IsActiveFlag, source.SinkTableName, source.RawLakehouseName, source.SinkWorkspaceName, source.SourceDataSet, source.SinkWatermarkColumn, source.LastModifiedFrom, source.SinkSchemaName, source.SinkObjectType, source.NotebookKey, source.Delimiter, source.SinkDataset, source.TaskType, source.RawStoragePath, source.SheetIndexArray, source.SinkLoadMethod, source.SourceName, source.TaskRunOrderNbr, source.SourceWildcardFileName, source.ETLWarehouseName, source.FileFilter, source.ParentSourceName, source.SourceType, source.TaskName, source.FileType, source.SinkLakehouseName, source.FileTaskKey, source.RawStorageFileName, source.PrimaryKeyColumnList, source.IsWatermarkEnabledFlag, source.SourceWildcardFolderPath, source.JobKey
FROM source
WHERE NOT EXISTS (
    SELECT 1
    FROM etlControl.etl.FileTask AS target
    WHERE target.FileTaskKey = source.FileTaskKey
);


-- ***** Script to update the table: etlControl.etl.Task *****
-- ===== UPDATE EXISTING ROWS =====
WITH source (SinkWarehouseName, CustomSQLSourceQuery, SinkLakehouseId, SourceWhereClause, IsActiveFlag, SourceWorkspaceName, SinkTableName, SinkWorkspaceName, SinkWatermarkColumn, SinkSchemaName, SourceWatermarkColumn, SourceFlatfileConnectionSettings, SourceConnectionName, NotebookKey, SinkWorkspaceId, ArchiveOriginalFilesFlag, TaskType, SourceDatabaseName, RawStoragePath, SinkLoadMethod, SourceName, TaskRunOrderNbr, RelativeUrl, TaskKey, SourceSchemaName, ParentSourceName, SourceTableName, SourceType, CustomPipelineCode, SourceExtractionMethod, SourceLakehouseName, TaskName, SinkLakehouseName, ArchiveStoragePath, SourceWarehouseName, RawStorageFileName, ArchiveStorageFileName, PrimaryKeyColumnList, IsWatermarkEnabledFlag, JobKey, OverrideQuery) AS (
SELECT NULL, 'SELECT
    CAST(PerformanceTypeId AS INT) AS PerformanceTypeId,
    CAST(StartDate AS DATE) AS StartDate,
    CAST(EndDate AS DATE) AS EndDate,
    CAST(AsOfDate AS DATE) AS AsOfDate,
    Level1,
    Level2,
    Level3,
    Level4,
    Level5,
    Level6,
    Level7,
    CAST(SortOrdinal AS INT) AS SortOrdinal,
    CAST(FundId AS VARCHAR(36)) AS FundId,
    Description,
    CAST(NAV AS DECIMAL(38,6)) AS NAV,
    CAST(PercentOfGIA AS DECIMAL(38,6)) AS PercentOfGIA,
    CAST(LastValuationDate AS DATE) AS LastValuationDate,
    CAST(PercentReporting AS DECIMAL(38,6)) AS PercentReporting,
    CAST(CategoryReturn AS DECIMAL(38,6)) AS CategoryReturn,
    CAST(IndexId AS VARCHAR(36)) AS IndexId,
    IndexName,
    CAST(IndexReturn AS DECIMAL(38,6)) AS IndexReturn,
    CAST(OverUnderPerformance AS DECIMAL(38,6)) AS OverUnderPerformance,
    CAST(CashFlows AS DECIMAL(38,6)) AS CashFlows,
    CAST(PnL AS DECIMAL(38,6)) AS PnL,
    CAST(Commitment AS DECIMAL(38,6)) AS Commitment,
    CAST(Unfunded AS DECIMAL(38,6)) AS Unfunded,
    CAST(UpdateTimestamp AS TIMESTAMP) AS UpdateTimestamp,
    UpdateByHMCUserId,
    CAST(ETLLoadDateTime AS TIMESTAMP) AS ETLLoadDateTime
FROM Bronze.HMCDataMartInvestmentPerformanceFlash
WHERE PerformanceTypeId IS NOT NULL
  AND StartDate IS NOT NULL
  AND EndDate IS NOT NULL
  AND AsOfDate IS NOT NULL
  AND ETLLoadDateTime IS NOT NULL
', NULL, NULL, 1, 'Dev - Crimson', 'PerformanceFlash', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 234, 'Bronze', 'Database', 'HMCDataMartInvestmentPerformanceFlash', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataMartInvestmentPerformanceFlash', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'SELECT
    CAST(FundId AS VARCHAR(36)) AS FundId,
    Tier,
    CAST(ManagementFee AS DECIMAL(38,2)) AS ManagementFee, 
    FeeTierBasisTypeId,
    ETLLoadDateTime
FROM Bronze.CrimsonXPrivateFeeTiers
WHERE FundId IS NOT NULL
  AND Tier IS NOT NULL
  AND ManagementFee IS NOT NULL
  AND FeeTierBasisTypeId IS NOT NULL;

', NULL, NULL, 1, 'Dev - Crimson', 'PrivateFeeTiers', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 119, 'Bronze', 'Database', 'CrimsonXFeesForPrivateModelTier', 'Lakehouse', NULL, NULL, 'lh_bronze', 'PrivateFeeTiers', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'SELECT      CAST(FundId AS varchar(36)) AS FundId,      CAST(MgmtPct AS decimal(38,6)) AS MgmtPct,      IsHighWaterMark,      FeeHurdleTypeId,      CAST(HurdlePct AS decimal(38,6)) AS HurdlePct,      CAST(IndexId AS varchar(36)) AS IndexId,      CAST(CarryPct AS decimal(38,6)) AS CarryPct,      IsIndexHistorical,      CAST(IndexReturnPct AS decimal(38,6)) AS IndexReturnPct,      CAST(IndexVolPct AS decimal(38,6)) AS IndexVolPct,      CAST(ExpenseRatio AS bigint) AS ExpenseRatio,      FeeCrystalizationTypeId,      IsLossCarry,      IsClawBack,      FeePaymentFrequencyTypeId,      FeePaymentTimingTypeId,      FeeBasisTypeId,      IsRebate,      FeeCarryMethodTypeId,      ContractualTermMatchId,      ETLLoadDateTime  FROM Bronze.CrimsonXPublicFees', NULL, NULL, 1, 'Dev - Crimson', 'PublicFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 117, 'Bronze', 'Database', 'CrimsonXPublicFees', 'Lakehouse', NULL, NULL, 'lh_bronze', 'PublicFees', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, 'SELECT
        CAST(FundId AS VARCHAR(36)) AS FundId,
    InvestmentPeriodQuarters,
    HarvestPeriodQuarters,
    CAST(ExpectedExpensePct AS DECIMAL(38, 6)) AS ExpectedExpensePct,
    CAST(CarryPct AS DECIMAL(38, 6)) AS CarryPct,
    FeeCarryMethodTypeId,
    CAST(PreferredRatePct AS DECIMAL(38, 6)) AS PreferredRatePct,
    HasHardHurdle,
    CAST(GPCatchUpPct AS DECIMAL(38, 6)) AS GPCatchUpPct,
    CAST(ClawbackTaxPct AS DECIMAL(38, 6)) AS ClawbackTaxPct,
    CAST(UncalledCapitalPct AS DECIMAL(38, 6)) AS UncalledCapitalPct,
    ContractualTermMatchId,
    ETLLoadDateTime
FROM Bronze.CrimsonXPrivateFees
WHERE FundId IS NOT NULL

', NULL, NULL, 1, 'Dev - Crimson', 'PrivateFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 118, 'Bronze', 'Database', 'CrimsonXFeesForPrivateModel', 'Lakehouse', NULL, NULL, 'lh_bronze', 'PrivateFees', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'SELECT   
UniversityTransactionId  
,PortfolioTypeId  
,CashFlowTransactionTypeId  
,CashFlowTransactionSubTypeId  
,CAST(TransactionAmountLocal AS DECIMAL(38,2)) AS TransactionAmountLocal 
,CAST(TransactionAmountUSD AS DECIMAL(38,2)) AS TransactionAmountUSD
,CAST(CommitmentEffectLocal AS DECIMAL(38,2)) AS CommitmentEffectLocal
,CAST(MarketValueEffectLocal AS DECIMAL(38,2)) AS MarketValueEffectLocal
,BookStartOfDay  
,ExposureDate  
,TradeDate  
,SettleDate  
,DocumentURL  
,CurrencyId  
FROM Bronze.CrimsonXUniversityTransaction  
WHERE CAST(EndDate AS DATE) = CAST(''9999-12-31'' AS DATE)', NULL, NULL, 1, 'Dev - Crimson', 'UniversityTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 219, 'Bronze', 'Database', 'CrimsonXUniversityTransaction', 'Lakehouse', NULL, NULL, 'lh_bronze', 'TransactionUniversity', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCurrencyRate', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'merge', 'Database', 1, NULL, 270, 'dbo', 'Database', 'CurrencyRate', 'sqlserver', NULL, NULL, NULL, 'CurrencyRate', 'lh_bronze', NULL, NULL, 'CurrencyRate', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ForecastedCashFlow', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 12, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 114, 'Bronze', 'Database', 'CrimsonXForecastedCashFlow', 'Lakehouse', NULL, NULL, 'lh_bronze', 'ForecastedCashFlowSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'WITH fundcomprep AS (
  SELECT  
    abfm.FundId,
	c.CurrencyId,
    to_date(sc.Date, ''M/d/yyyy'') AS CommitmentDate,
    SUM(CAST(sc.DeltaValue AS DECIMAL(18,2))) AS CommitmentAmount,
    sc.ETLLoadDateTime
  FROM Bronze.SolovisCommitments sc
  INNER JOIN Bronze.SolovisActiveBookFundMapping abfm
    ON sc.InvestmentResourceId = abfm.InvestmentResourceId
  INNER JOIN Bronze.SolovisInvestments si ON si.ResourceId = abfm.InvestmentResourceId
  INNER JOIN Bronze.SolovisCurrency scur ON scur.Id = si.LocalCurrencyId
  INNER JOIN Bronze.CrimsonXCurrency c ON c.ISOCode = scur.Code
  GROUP BY abfm.FundId, c.CurrencyId , sc.ETLLoadDateTime --, sc.`Date`
				
)
SELECT 
  FundId, 
  CommitmentDate,
  CurrencyId,
  CommitmentAmount, 
  CASE WHEN CommitmentAmount < 0 THEN 13 ELSE 5 END AS CashflowTransactionTypeId, 
  ETLLoadDateTime
FROM fundcomprep f
', NULL, NULL, 0, 'Dev - Crimson', 'FundCommitment', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 231, 'Bronze', 'Database', 'SolovisCommitments', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Solovis Commitments', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 269, 'dbo', 'Database', 'CashflowTransaction', 'sqlserver', NULL, NULL, NULL, 'CashflowTransaction', 'lh_bronze', NULL, NULL, 'CashflowTransaction', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLiquidityRedemptionFrequencyType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 268, 'dbo', 'Database', 'LiquidityRedemptionFrequencyType', 'sqlserver', NULL, NULL, NULL, 'LiquidityRedemptionFrequencyType', 'lh_bronze', NULL, NULL, 'LiquidityRedemptionFrequencyType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexConstituent', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 267, 'dbo', 'Database', 'IndexConstituent', 'sqlserver', NULL, NULL, NULL, 'IndexConstituent', 'lh_bronze', NULL, NULL, 'IndexConstituent', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTrade', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 14, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 116, 'Bronze', 'Database', 'CrimsonXFundTrade', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTrade', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeForecastedTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 13, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 115, 'Bronze', 'Database', 'CrimsonXFundTradeForecastedTransaction', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeForecastedTransaction', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ForecastedCashFlowType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 112, 'Bronze', 'Database', 'CrimsonXForecastedCashFlowType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'ForecastedCashFlowType', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeApprovalType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 111, 'Bronze', 'Database', 'CrimsonXFundTradeApprovalType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeApprovalType', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 96, 'Bronze', 'Database', 'CrimsonXFundTradeStatus', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeStatusToSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 97, 'Bronze', 'Database', 'CrimsonXFundTradeType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeTypeToSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'aivyeval', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 49, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 1, NULL, 266, 'Bronze', 'Bronze', 'AivyEval', 'Lakehouse', NULL, NULL, 'lh_bronze', 'AivyEvalsToSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 39, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'AivyEval', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 48, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Crimson HMC API', 1, NULL, 265, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, NULL, 'AivyEvalsAPIToBronze', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 38, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'aivychathistory', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 47, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 264, 'Bronze', 'Bronze', 'ChatAiDbChatHistory', 'Lakehouse', NULL, NULL, 'lh_bronze', 'AivyChatHistoryToSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 37, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundValuation', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 46, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 2, NULL, 263, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundValuation', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Universe', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 3, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 63, 'Bronze', 'Database', 'CrimsonXUniverse', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonXSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'SolovisActiveBookFundMapping', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 10, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 2, NULL, 94, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Build ActiveBook & Fund Mappings', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 16, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 2, NULL, 124, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturnSilver Levels', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCUsers', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 9, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Entra', 1, NULL, 92, NULL, 'Entra', NULL, 'Lakehouse', NULL, NULL, NULL, 'Entra Users Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 18, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Region', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 5, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 75, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset-IndexRegionExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'RegionCountry', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 2, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 49, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset-IndexRegionCountryExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'SectorIndustry', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 6, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 50, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset-IndexSectorIndustryExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 21, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'CrimsonXCashflowTransactionDetail', 2, NULL, 209, 'Bronze', 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Update CashflowTransactionDetail USD Amounts with correct FX Rate', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 22, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Crimson HMC API', 3, NULL, 215, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, 'lh_bronze', 'Bottom Up Data to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 26, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundMarketValue', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 20, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 1, NULL, 206, 'Silver', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_curated', 'Solovis Market Values Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Fund', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 18, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 202, 'Bronze', 'Database', 'CrimsonXFund', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehousevwSourceReferenceIndex', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, -1, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 43, 'dbo', 'Database', 'vwSourceReferenceIndex', 'sqlserver', NULL, NULL, 'NULL', 'vwSourceReferenceIndex', 'lh_bronze', NULL, NULL, 'vwSourceReferenceIndex', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Currency', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', 'NULL', NULL, 'overwrite', 'Bronze', 1, NULL, 30, 'Bronze', 'Database', 'HMCDataWarehouseCurrency', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataWarehouseCurrency', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexRegionExposure', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', 'NULL', NULL, 'overwrite', 'Bronze', 1, NULL, 29, 'Bronze', 'Database', 'CrimsonXIndexRegionExposure', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonXIndexRegionExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Frequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', 'NULL', NULL, 'overwrite', 'Bronze', 1, NULL, 28, 'Bronze', 'Database', 'CrimsonXFrequency', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonXFrequency', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'Holdings', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 64, 'Bronze', 'Bronze', 'CrimsonXHoldings', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Holdings to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 65, 'Bronze', 'Bronze', 'CrimsonXCashflowTransactionDetail', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CashflowTransactionDetail to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CashflowTransactionSubtype', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 69, 'Bronze', 'Bronze', 'CrimsonXCashflowTransactionSubtype', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CashflowTransactionSubtype to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CashflowTransactionType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 68, 'Bronze', 'Bronze', 'CrimsonXCashflowTransactionType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CashflowTransactionType to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ReturnType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 60, 'Bronze', 'Bronze', 'CrimsonXReturnType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Return Type to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ReturnSource', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 59, 'Bronze', 'Bronze', 'CrimsonXReturnSource', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Return Source to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundConstituentAccounting', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'merge', 'Bronze', 1, NULL, 10, 'Bronze', 'Database', 'FundConstituentAccounting', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, 'FundId', 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', '02Test', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'merge', 'Bronze', 1, NULL, 2, 'Bronze', 'Bronze', '02Test', 'Lakehouse', NULL, NULL, 'lh_bronze', '01Test', 'lh_curated', NULL, NULL, NULL, NULL, 'Date', 1, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'LiquidityTermSchedule', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 7, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 88, 'Bronze', 'Database', 'LiquidityTerms', 'Lakehouse', NULL, NULL, 'lh_bronze', 'LiquidityTermSch', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FXRate', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 4, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 1, NULL, 76, 'Bronze', 'Database', 'FXRate', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FXRate', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 12, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'FundReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 57, 'Bronze', 'Bronze', 'CrimsonXFundReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Fund Return to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Note', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 8, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 2, NULL, 91, 'Bronze', 'Blob', 'Note', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Notes To Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 24, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentPerformanceGIAReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 87, 'dbo', 'Database', 'PerformanceGIAReturn', 'sqlserver', NULL, NULL, NULL, 'PerformanceGIAReturn', 'lh_bronze', NULL, NULL, 'PerformanceGIAReturn', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentPerformanceFlash', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 86, 'dbo', 'Database', 'PerformanceFlash', 'sqlserver', NULL, NULL, NULL, 'PerformanceFlash', 'lh_bronze', NULL, NULL, 'PerformanceFlash', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentHMCHierarchyAttributes', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 85, 'dbo', 'Database', 'HMCHierarchyAttributes', 'sqlserver', NULL, NULL, NULL, 'HMCHierarchyAttributes', 'lh_bronze', NULL, NULL, 'HMCHierarchyAttributes', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentFundBetaSummaryLog', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 84, 'dbo', 'Database', 'FundBetaSummaryLog', 'sqlserver', NULL, NULL, NULL, 'FundBetaSummaryLog', 'lh_bronze', NULL, NULL, 'FundBetaSummaryLog', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentFundBetaSummaryHeaderLog', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 83, 'dbo', 'Database', 'FundBetaSummaryHeaderLog', 'sqlserver', NULL, NULL, NULL, 'FundBetaSummaryHeaderLog', 'lh_bronze', NULL, NULL, 'FundBetaSummaryHeaderLog', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentBetaAnalyticSummary', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 82, 'dbo', 'Database', 'BetaAnalyticSummary', 'sqlserver', NULL, NULL, NULL, 'BetaAnalyticSummary', 'lh_bronze', NULL, NULL, 'BetaAnalyticSummary', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentBetaAnalytic', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 81, 'dbo', 'Database', 'BetaAnalytic', 'sqlserver', NULL, NULL, NULL, 'BetaAnalytic', 'lh_bronze', NULL, NULL, 'BetaAnalytic', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 133, 'dbo', 'Database', 'ClassificationMap', 'sqlserver', NULL, NULL, NULL, 'ClassificationMap for Solovis Load', 'lh_bronze', NULL, NULL, 'ClassificationMap', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassification', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 132, 'dbo', 'Database', 'Classification', 'sqlserver', NULL, NULL, NULL, 'Classification for Solovis Load', 'lh_bronze', NULL, NULL, 'Classification', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 131, 'dbo', 'Database', 'Entity', 'sqlserver', NULL, NULL, NULL, 'Entity for Solovis Load', 'lh_bronze', NULL, NULL, 'Entity', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 130, 'dbo', 'Database', 'Firm', 'sqlserver', NULL, NULL, NULL, 'Firm for Solovis Load', 'lh_bronze', NULL, NULL, 'Firm', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 129, 'dbo', 'Database', 'Fund', 'sqlserver', NULL, NULL, NULL, 'Fund for Solovis Load', 'lh_bronze', NULL, NULL, 'Fund', NULL, 'FundId', 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 128, 'dbo', 'Database', 'CashflowTransactionDetail', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionDetail for Solovis Load', 'lh_bronze', NULL, NULL, 'CashflowTransactionDetail', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseExternalActiveBook', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 127, 'etl', 'Database', 'vwSolovisLoadHelper_ActiveBookXref', 'sqlserver', NULL, NULL, NULL, 'vwSolovisLoadHelper_ActiveBookXref for Solovis Load', 'lh_bronze', NULL, NULL, 'ExternalActiveBook', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXShareClass', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 126, 'dbo', 'Database', 'ShareClass', 'sqlserver', NULL, NULL, NULL, 'ShareClass for Solovis Load', 'lh_bronze', NULL, NULL, 'ShareClass', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Office365User', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', NULL, 'Office365', 'overwrite', 'Office365', 1, NULL, 44, NULL, 'Database', NULL, 'office365', NULL, NULL, NULL, 'Office365User', 'lh_bronze', NULL, NULL, 'Office365User', NULL, NULL, 0, 8, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundConstituentAccounting', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 4, 'dbo', 'Database', 'FundConstituentAccounting', 'sqlserver', NULL, NULL, '', 'FundConstituentAccounting', 'lh_bronze', NULL, NULL, 'FundConstituentAccounting', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseCurrency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 16, 'dbo', 'Database', 'Currency', 'sqlserver', NULL, NULL, NULL, 'Currency', 'lh_bronze', NULL, NULL, 'Currency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseSolovisCurrency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 46, 'etl', 'Database', 'SolovisCurrency', 'sqlserver', NULL, NULL, NULL, 'SolovisCurrency', 'lh_bronze', NULL, NULL, 'SolovisCurrency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseExternalActiveBook', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 48, 'etl', 'Database', 'vwSolovisLoadHelper_ActiveBookXref', 'sqlserver', NULL, NULL, NULL, 'vwSolovisLoadHelper_ActiveBookXref', 'lh_bronze', NULL, NULL, 'ExternalActiveBook', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseSolovisTransactionMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 61, 'etl', 'Database', 'SolovisTransactionMap', 'sqlserver', NULL, NULL, NULL, 'SolovisTransactionMap', 'lh_bronze', NULL, NULL, 'SolovisTransactionMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'vwUniverseFunds', 'Dev - Crimson', NULL, 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'rawtest', 'overwrite', 'Database', 1, NULL, 53, 'dbo', 'Database', 'vwUniverseFunds', 'sqlserver', NULL, NULL, NULL, 'vwUniverseFunds', 'lh_bronze', NULL, NULL, 'vwUniverseFunds', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXUniverse', 'Dev - Crimson', NULL, 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'rawtest', 'overwrite', 'Database', 1, NULL, 52, 'dbo', 'Database', 'Universe', 'sqlserver', NULL, NULL, NULL, 'Universe', 'lh_bronze', NULL, NULL, 'Universe', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehousevwSourceReferenceFlatten_CrimsonX', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 51, 'dbo', 'Database', 'vwSourceReferenceFlatten_CrimsonX', 'sqlserver', NULL, NULL, NULL, 'vwSourceReferenceFlatten_CrimsonX', 'lh_bronze', NULL, NULL, 'HMCDataWarehousevwSourceReferenceFlatten_CrimsonX', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 11, 'dbo', 'Database', 'Fund', 'sqlserver', NULL, NULL, NULL, 'Fund', 'lh_bronze', NULL, NULL, 'Fund', NULL, 'FundId', 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundReturnSource', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 218, 'dbo', 'Database', 'FundReturnSource', 'sqlserver', NULL, NULL, NULL, 'FundReturnSource', 'lh_bronze', NULL, NULL, 'FundReturnSource', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundReturnType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 217, 'dbo', 'Database', 'FundReturnType', 'sqlserver', NULL, NULL, NULL, 'FundReturnType', 'lh_bronze', NULL, NULL, 'FundReturnType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXAlphaStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 212, 'dbo', 'Database', 'AlphaStrategy', 'sqlserver', NULL, NULL, NULL, 'AlphaStrategy', 'lh_bronze', NULL, NULL, 'AlphaStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXLiquidityCost', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 213, 'dbo', 'Database', 'LiquidityCost', 'sqlserver', NULL, NULL, NULL, 'LiquidityCost', 'lh_bronze', NULL, NULL, 'LiquidityCost', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXWeightedDaysType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 214, 'dbo', 'Database', 'WeightedDaysType', 'sqlserver', NULL, NULL, NULL, 'WeightedDaysType', 'lh_bronze', NULL, NULL, 'WeightedDaysType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundRiskIndexAssociation', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 140, 'dbo', 'Database', 'FundRiskIndexAssociation', 'sqlserver', NULL, NULL, NULL, 'FundRiskIndexAssociation', 'lh_bronze', NULL, NULL, 'FundRiskIndexAssociation', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundRiskStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 144, 'dbo', 'Database', 'FundRiskStatus', 'sqlserver', NULL, NULL, NULL, 'FundRiskStatus', 'lh_bronze', NULL, NULL, 'FundRiskStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXBudgetStrategyClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 210, 'dbo', 'Database', 'BudgetStrategyClassificationMap', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategyClassificationMap', 'lh_bronze', NULL, NULL, 'BudgetStrategyClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXBudgetStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 211, 'dbo', 'Database', 'BudgetStrategy', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategy', 'lh_bronze', NULL, NULL, 'BudgetStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLiquidityCost', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 145, 'dbo', 'Database', 'LiquidityCost', 'sqlserver', NULL, NULL, NULL, 'LiquidityCost', 'lh_bronze', NULL, NULL, 'LiquidityCost', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDBackgroundCheck', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 146, 'dbo', 'Database', 'ODDBackgroundCheck', 'sqlserver', NULL, NULL, NULL, 'ODDBackgroundCheck', 'lh_bronze', NULL, NULL, 'ODDBackgroundCheck', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDBackgroundCheckSubject', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 147, 'dbo', 'Database', 'ODDBackgroundCheckSubject', 'sqlserver', NULL, NULL, NULL, 'ODDBackgroundCheckSubject', 'lh_bronze', NULL, NULL, 'ODDBackgroundCheckSubject', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDCounterPartyType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 148, 'dbo', 'Database', 'ODDCounterPartyType', 'sqlserver', NULL, NULL, NULL, 'ODDCounterPartyType', 'lh_bronze', NULL, NULL, 'ODDCounterPartyType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDCustomFrequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 149, 'dbo', 'Database', 'ODDCustomFrequency', 'sqlserver', NULL, NULL, NULL, 'ODDCustomFrequency', 'lh_bronze', NULL, NULL, 'ODDCustomFrequency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDDocumentRequestType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 150, 'dbo', 'Database', 'ODDDocumentRequestType', 'sqlserver', NULL, NULL, NULL, 'ODDDocumentRequestType', 'lh_bronze', NULL, NULL, 'ODDDocumentRequestType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 151, 'dbo', 'Database', 'ODDEntity', 'sqlserver', NULL, NULL, NULL, 'ODDEntity', 'lh_bronze', NULL, NULL, 'ODDEntity', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 152, 'dbo', 'Database', 'ODDFirm', 'sqlserver', NULL, NULL, NULL, 'ODDFirm', 'lh_bronze', NULL, NULL, 'ODDFirm', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmAdvisor', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 153, 'dbo', 'Database', 'ODDFirmAdvisor', 'sqlserver', NULL, NULL, NULL, 'ODDFirmAdvisor', 'lh_bronze', NULL, NULL, 'ODDFirmAdvisor', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmCrdNumber', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 154, 'dbo', 'Database', 'ODDFirmCrdNumber', 'sqlserver', NULL, NULL, NULL, 'ODDFirmCrdNumber', 'lh_bronze', NULL, NULL, 'ODDFirmCrdNumber', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmStaticDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 155, 'dbo', 'Database', 'ODDFirmStaticDetail', 'sqlserver', NULL, NULL, NULL, 'ODDFirmStaticDetail', 'lh_bronze', NULL, NULL, 'ODDFirmStaticDetail', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmSummary', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 156, 'dbo', 'Database', 'ODDFirmSummary', 'sqlserver', NULL, NULL, NULL, 'ODDFirmSummary', 'lh_bronze', NULL, NULL, 'ODDFirmSummary', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFlag', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 157, 'dbo', 'Database', 'ODDFlag', 'sqlserver', NULL, NULL, NULL, 'ODDFlag', 'lh_bronze', NULL, NULL, 'ODDFlag', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFlagBucket', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 158, 'dbo', 'Database', 'ODDFlagBucket', 'sqlserver', NULL, NULL, NULL, 'ODDFlagBucket', 'lh_bronze', NULL, NULL, 'ODDFlagBucket', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFlagColor', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 159, 'dbo', 'Database', 'ODDFlagColor', 'sqlserver', NULL, NULL, NULL, 'ODDFlagColor', 'lh_bronze', NULL, NULL, 'ODDFlagColor', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 160, 'dbo', 'Database', 'ODDFund', 'sqlserver', NULL, NULL, NULL, 'ODDFund', 'lh_bronze', NULL, NULL, 'ODDFund', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeeting', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 161, 'dbo', 'Database', 'ODDMeeting', 'sqlserver', NULL, NULL, NULL, 'ODDMeeting', 'lh_bronze', NULL, NULL, 'ODDMeeting', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingAdministrator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 162, 'dbo', 'Database', 'ODDMeetingAdministrator', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingAdministrator', 'lh_bronze', NULL, NULL, 'ODDMeetingAdministrator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingAuditor', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 163, 'dbo', 'Database', 'ODDMeetingAuditor', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingAuditor', 'lh_bronze', NULL, NULL, 'ODDMeetingAuditor', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingBackgroundCheckProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 164, 'dbo', 'Database', 'ODDMeetingBackgroundCheckProvider', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingBackgroundCheckProvider', 'lh_bronze', NULL, NULL, 'ODDMeetingBackgroundCheckProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingBank', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 165, 'dbo', 'Database', 'ODDMeetingBank', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingBank', 'lh_bronze', NULL, NULL, 'ODDMeetingBank', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingComplianceConsultant', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 166, 'dbo', 'Database', 'ODDMeetingComplianceConsultant', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingComplianceConsultant', 'lh_bronze', NULL, NULL, 'ODDMeetingComplianceConsultant', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingCounterparty', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 167, 'dbo', 'Database', 'ODDMeetingCounterparty', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingCounterparty', 'lh_bronze', NULL, NULL, 'ODDMeetingCounterparty', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingCustodian', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 168, 'dbo', 'Database', 'ODDMeetingCustodian', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingCustodian', 'lh_bronze', NULL, NULL, 'ODDMeetingCustodian', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingDocumentRequestType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 169, 'dbo', 'Database', 'ODDMeetingDocumentRequestType', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingDocumentRequestType', 'lh_bronze', NULL, NULL, 'ODDMeetingDocumentRequestType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 170, 'dbo', 'Database', 'ODDMeetingEntity', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingEntity', 'lh_bronze', NULL, NULL, 'ODDMeetingEntity', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 171, 'dbo', 'Database', 'ODDMeetingFirm', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingFirm', 'lh_bronze', NULL, NULL, 'ODDMeetingFirm', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingFrequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 172, 'dbo', 'Database', 'ODDMeetingFrequency', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingFrequency', 'lh_bronze', NULL, NULL, 'ODDMeetingFrequency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 173, 'dbo', 'Database', 'ODDMeetingFund', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingFund', 'lh_bronze', NULL, NULL, 'ODDMeetingFund', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingISDA', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 174, 'dbo', 'Database', 'ODDMeetingISDA', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingISDA', 'lh_bronze', NULL, NULL, 'ODDMeetingISDA', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingITProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 175, 'dbo', 'Database', 'ODDMeetingITProvider', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingITProvider', 'lh_bronze', NULL, NULL, 'ODDMeetingITProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingLegalCounsel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 176, 'dbo', 'Database', 'ODDMeetingLegalCounsel', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingLegalCounsel', 'lh_bronze', NULL, NULL, 'ODDMeetingLegalCounsel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingMethod', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 177, 'dbo', 'Database', 'ODDMeetingMethod', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingMethod', 'lh_bronze', NULL, NULL, 'ODDMeetingMethod', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingParticipant', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 178, 'dbo', 'Database', 'ODDMeetingParticipant', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingParticipant', 'lh_bronze', NULL, NULL, 'ODDMeetingParticipant', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingParticipantInternal', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 179, 'dbo', 'Database', 'ODDMeetingParticipantInternal', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingParticipantInternal', 'lh_bronze', NULL, NULL, 'ODDMeetingParticipantInternal', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingPrimaryContact', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 180, 'dbo', 'Database', 'ODDMeetingPrimaryContact', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingPrimaryContact', 'lh_bronze', NULL, NULL, 'ODDMeetingPrimaryContact', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingPrimaryRegulator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 181, 'dbo', 'Database', 'ODDMeetingPrimaryRegulator', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingPrimaryRegulator', 'lh_bronze', NULL, NULL, 'ODDMeetingPrimaryRegulator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingPrimeBroker', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 182, 'dbo', 'Database', 'ODDMeetingPrimeBroker', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingPrimeBroker', 'lh_bronze', NULL, NULL, 'ODDMeetingPrimeBroker', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 183, 'dbo', 'Database', 'ODDMeetingType', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingType', 'lh_bronze', NULL, NULL, 'ODDMeetingType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDNote', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 184, 'dbo', 'Database', 'ODDNote', 'sqlserver', NULL, NULL, NULL, 'ODDNote', 'lh_bronze', NULL, NULL, 'ODDNote', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDPrioritization', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 185, 'dbo', 'Database', 'ODDPrioritization', 'sqlserver', NULL, NULL, NULL, 'ODDPrioritization', 'lh_bronze', NULL, NULL, 'ODDPrioritization', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDRating', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 186, 'dbo', 'Database', 'ODDRating', 'sqlserver', NULL, NULL, NULL, 'ODDRating', 'lh_bronze', NULL, NULL, 'ODDRating', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDRatingCategory', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 187, 'dbo', 'Database', 'ODDRatingCategory', 'sqlserver', NULL, NULL, NULL, 'ODDRatingCategory', 'lh_bronze', NULL, NULL, 'ODDRatingCategory', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXOddTrip', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 188, 'dbo', 'Database', 'OddTrip', 'sqlserver', NULL, NULL, NULL, 'OddTrip', 'lh_bronze', NULL, NULL, 'OddTrip', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXOddTripMeeting', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 189, 'dbo', 'Database', 'OddTripMeeting', 'sqlserver', NULL, NULL, NULL, 'OddTripMeeting', 'lh_bronze', NULL, NULL, 'OddTripMeeting', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXOddTripMeetingAttendee', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 190, 'dbo', 'Database', 'OddTripMeetingAttendee', 'sqlserver', NULL, NULL, NULL, 'OddTripMeetingAttendee', 'lh_bronze', NULL, NULL, 'OddTripMeetingAttendee', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXISDA', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 191, 'dbo', 'Database', 'ISDA', 'sqlserver', NULL, NULL, NULL, 'ISDA', 'lh_bronze', NULL, NULL, 'ISDA', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXITProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 192, 'dbo', 'Database', 'ITProvider', 'sqlserver', NULL, NULL, NULL, 'ITProvider', 'lh_bronze', NULL, NULL, 'ITProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrimaryRegulator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 193, 'dbo', 'Database', 'PrimaryRegulator', 'sqlserver', NULL, NULL, NULL, 'PrimaryRegulator', 'lh_bronze', NULL, NULL, 'PrimaryRegulator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrimeBroker', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 194, 'dbo', 'Database', 'PrimeBroker', 'sqlserver', NULL, NULL, NULL, 'PrimeBroker', 'lh_bronze', NULL, NULL, 'PrimeBroker', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLegalCounsel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 195, 'dbo', 'Database', 'LegalCounsel', 'sqlserver', NULL, NULL, NULL, 'LegalCounsel', 'lh_bronze', NULL, NULL, 'LegalCounsel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCustodian', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 196, 'dbo', 'Database', 'Custodian', 'sqlserver', NULL, NULL, NULL, 'Custodian', 'lh_bronze', NULL, NULL, 'Custodian', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXAdministrator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 197, 'dbo', 'Database', 'Administrator', 'sqlserver', NULL, NULL, NULL, 'Administrator', 'lh_bronze', NULL, NULL, 'Administrator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXComplianceConsultant', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 198, 'dbo', 'Database', 'ComplianceConsultant', 'sqlserver', NULL, NULL, NULL, 'ComplianceConsultant', 'lh_bronze', NULL, NULL, 'ComplianceConsultant', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBank', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 199, 'dbo', 'Database', 'Bank', 'sqlserver', NULL, NULL, NULL, 'Bank', 'lh_bronze', NULL, NULL, 'Bank', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBackgroundCheckProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 200, 'dbo', 'Database', 'BackgroundCheckProvider', 'sqlserver', NULL, NULL, NULL, 'BackgroundCheckProvider', 'lh_bronze', NULL, NULL, 'BackgroundCheckProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundrisk', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 139, 'dbo', 'Database', 'Fundrisk', 'sqlserver', NULL, NULL, NULL, 'Fundrisk', 'lh_bronze', NULL, NULL, 'Fundrisk', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskIndexAssociationRequest', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 141, 'dbo', 'Database', 'FundRiskIndexAssociationRequest', 'sqlserver', NULL, NULL, NULL, 'FundRiskIndexAssociationRequest', 'lh_bronze', NULL, NULL, 'FundRiskIndexAssociationRequest', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskRequest', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 142, 'dbo', 'Database', 'FundRiskRequest', 'sqlserver', NULL, NULL, NULL, 'FundRiskRequest', 'lh_bronze', NULL, NULL, 'FundRiskRequest', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskRequestLog', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 143, 'dbo', 'Database', 'FundRiskRequestLog', 'sqlserver', NULL, NULL, NULL, 'FundRiskRequestLog', 'lh_bronze', NULL, NULL, 'FundRiskRequestLog', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTagType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 138, 'dbo', 'Database', 'TagType', 'sqlserver', NULL, NULL, NULL, 'TagType', 'lh_bronze', NULL, NULL, 'TagType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTagOwner', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 137, 'dbo', 'Database', 'TagOwner', 'sqlserver', NULL, NULL, NULL, 'TagOwner', 'lh_bronze', NULL, NULL, 'TagOwner', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTagMaster', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 136, 'dbo', 'Database', 'TagMaster', 'sqlserver', NULL, NULL, NULL, 'TagMaster', 'lh_bronze', NULL, NULL, 'TagMaster', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTag', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 135, 'dbo', 'Database', 'Tag', 'sqlserver', NULL, NULL, NULL, 'Tag', 'lh_bronze', NULL, NULL, 'Tag', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXUniversityTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 134, 'dbo', 'Database', 'UniversityTransaction', 'sqlserver', NULL, NULL, NULL, 'UniversityTransaction', 'lh_bronze', NULL, NULL, 'UniversityTransaction', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrivateFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 98, 'dbo', 'Database', 'FeesForPrivateModel', 'sqlserver', NULL, NULL, NULL, 'PrivateFees', 'lh_bronze', NULL, NULL, 'PrivateFees', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrivateFeeTiers', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 99, 'dbo', 'Database', 'FeesForPrivateModelTier', 'sqlserver', NULL, NULL, NULL, 'PrivateFeeTiers', 'lh_bronze', NULL, NULL, 'PrivateFeeTiers', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeePaymentFrequencyType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 101, 'dbo', 'Database', 'FeePaymentFrequencyType', 'sqlserver', NULL, NULL, NULL, 'FeePaymentFrequencyType', 'lh_bronze', NULL, NULL, 'FeePaymentFrequencyType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeBasisType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 102, 'dbo', 'Database', 'FeeBasisType', 'sqlserver', NULL, NULL, NULL, 'FeeBasisType', 'lh_bronze', NULL, NULL, 'FeeBasisType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeHurdleType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 104, 'dbo', 'Database', 'FeeHurdleType', 'sqlserver', NULL, NULL, NULL, 'FeeHurdleType', 'lh_bronze', NULL, NULL, 'FeeHurdleType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXShareClass', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 47, 'dbo', 'Database', 'ShareClass', 'sqlserver', NULL, NULL, NULL, 'ShareClass', 'lh_bronze', NULL, NULL, 'ShareClass', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPipelineStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 42, 'dbo', 'Database', 'PipelineStatus', 'sqlserver', NULL, NULL, NULL, 'PipelineStatus', 'lh_bronze', NULL, NULL, 'PipelineStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeTierBasisType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 41, 'dbo', 'Database', 'FeeTierBasisType', 'sqlserver', NULL, NULL, NULL, 'FeeTierBasisType', 'lh_bronze', NULL, NULL, 'FeeTierBasisType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeCarryMethodType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 40, 'dbo', 'Database', 'FeeCarryMethodType', 'sqlserver', NULL, NULL, NULL, 'FeeCarryMethodType', 'lh_bronze', NULL, NULL, 'FeeCarryMethodType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLiquidityTermSchedule', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 39, 'dbo', 'Database', 'LiquidityTermSchedule', 'sqlserver', NULL, NULL, NULL, 'LiquidityTermSchedule', 'lh_bronze', NULL, NULL, 'LiquidityTermSchedule', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeesForPrivateModelTier', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 38, 'dbo', 'Database', 'FeesForPrivateModelTier', 'sqlserver', NULL, NULL, NULL, 'FeesForPrivateModelTier', 'lh_bronze', NULL, NULL, 'FeesForPrivateModelTier', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeesForPrivateModel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 37, 'dbo', 'Database', 'FeesForPrivateModel', 'sqlserver', NULL, NULL, NULL, 'FeesForPrivateModel', 'lh_bronze', NULL, NULL, 'FeesForPrivateModel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBetaCategory', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 36, 'dbo', 'Database', 'BetaCategory', 'sqlserver', NULL, NULL, NULL, 'BetaCategory', 'lh_bronze', NULL, NULL, 'BetaCategory', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskIndexAssociation', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 35, 'dbo', 'Database', 'FundRiskIndexAssociation', 'sqlserver', NULL, NULL, NULL, 'FundRiskIndexAssociation', 'lh_bronze', NULL, NULL, 'FundRiskIndexAssociation', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntityStatistics', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 33, 'dbo', 'Database', 'EntityStatistics', 'sqlserver', NULL, NULL, NULL, 'EntityStatistics', 'lh_bronze', NULL, NULL, 'EntityStatistics', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXAlphaStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 32, 'dbo', 'Database', 'AlphaStrategy', 'sqlserver', NULL, NULL, NULL, 'AlphaStrategy', 'lh_bronze', NULL, NULL, 'AlphaStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRisk', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 31, 'dbo', 'Database', 'FundRisk', 'sqlserver', NULL, NULL, NULL, 'FundRisk', 'lh_bronze', NULL, NULL, 'FundRisk', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXSectorIndustry', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 25, 'dbo', 'Database', 'SectorIndustry', 'sqlserver', NULL, NULL, NULL, 'SectorIndustry', 'lh_bronze', NULL, NULL, 'SectorIndustry', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXSector', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 24, 'dbo', 'Database', 'Sector', 'sqlserver', NULL, NULL, NULL, 'Sector', 'lh_bronze', NULL, NULL, 'Sector', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXSectorIndustryClassification', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 23, 'dbo', 'Database', 'SectorIndustryClassification', 'sqlserver', NULL, NULL, NULL, 'SectorIndustryClassification', 'lh_bronze', NULL, NULL, 'SectorIndustryClassification', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXGeographicStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 22, 'dbo', 'Database', 'GeographicStrategy', 'sqlserver', NULL, NULL, NULL, 'GeographicStrategy', 'lh_bronze', NULL, NULL, 'GeographicStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCountry', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 20, 'dbo', 'Database', 'Country', 'sqlserver', NULL, NULL, NULL, 'Country', 'lh_bronze', NULL, NULL, 'Country', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCountryRegion', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 21, 'dbo', 'Database', 'CountryRegion', 'sqlserver', NULL, NULL, NULL, 'CountryRegion', 'lh_bronze', NULL, NULL, 'CountryRegion', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexRegionExposure', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 19, 'dbo', 'Database', 'IndexRegionExposure', 'sqlserver', NULL, NULL, NULL, 'IndexRegionExposure', 'lh_bronze', NULL, NULL, 'IndexRegionExposure', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndex', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 17, 'dbo', 'Database', 'Index', 'sqlserver', NULL, NULL, NULL, 'Index', 'lh_bronze', NULL, NULL, 'Index', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFrequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 18, 'dbo', 'Database', 'Frequency', 'sqlserver', NULL, NULL, NULL, 'Frequency', 'lh_bronze', NULL, NULL, 'Frequency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 13, 'dbo', 'Database', 'Firm', 'sqlserver', NULL, NULL, NULL, 'Firm', 'lh_bronze', NULL, NULL, 'Firm', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 12, 'dbo', 'Database', 'Entity', 'sqlserver', NULL, NULL, NULL, 'Entity', 'lh_bronze', NULL, NULL, 'Entity', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 9, 'dbo', 'Database', 'FundTradeType', 'sqlserver', NULL, NULL, NULL, 'FundTradeType', 'lh_bronze', NULL, NULL, 'FundTradeType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 8, 'dbo', 'Database', 'FundTradeStatus', 'sqlserver', NULL, NULL, NULL, 'FundTradeStatus', 'lh_bronze', NULL, NULL, 'FundTradeStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeForecastedTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 7, 'dbo', 'Database', 'FundTradeForecastedTransaction', 'sqlserver', NULL, NULL, NULL, 'FundTradeForecastedTransaction', 'lh_bronze', NULL, NULL, 'FundTradeForecastedTransaction', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeApproval', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 6, 'dbo', 'Database', 'FundTradeApproval', 'sqlserver', NULL, NULL, NULL, 'FundTradeApproval', 'lh_bronze', NULL, NULL, 'FundTradeApproval', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTrade', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 5, 'dbo', 'Database', 'FundTrade', 'sqlserver', NULL, NULL, NULL, 'FundTrade', 'lh_bronze', NULL, NULL, 'FundTrade', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 15, 'dbo', 'Database', 'ClassificationMap', 'sqlserver', NULL, NULL, NULL, 'ClassificationMap', 'lh_bronze', NULL, NULL, 'ClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 74, 'dbo', 'Database', 'FundRiskStatus', 'sqlserver', NULL, NULL, NULL, 'FundRiskStatus', 'lh_bronze', NULL, NULL, 'FundRiskStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntityRating', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 72, 'dbo', 'Database', 'EntityRating', 'sqlserver', NULL, NULL, NULL, 'EntityRating', 'lh_bronze', NULL, NULL, 'EntityRating', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundStructure', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 71, 'dbo', 'Database', 'FundStructure', 'sqlserver', NULL, NULL, NULL, 'FundStructure', 'lh_bronze', NULL, NULL, 'FundStructure', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXHoldings', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 58, 'dbo', 'Database', 'Holdings', 'sqlserver', NULL, NULL, NULL, 'Holdings', 'lh_bronze', NULL, NULL, 'Holdings', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXReturnType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 56, 'dbo', 'Database', 'ReturnType', 'sqlserver', NULL, NULL, NULL, 'ReturnType', 'lh_bronze', NULL, NULL, 'ReturnType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionSubtype', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 67, 'dbo', 'Database', 'CashflowTransactionSubtype', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionSubtype', 'lh_bronze', NULL, NULL, 'CashflowTransactionSubtype', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXReturnSource', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 55, 'dbo', 'Database', 'ReturnSource', 'sqlserver', NULL, NULL, NULL, 'ReturnSource', 'lh_bronze', NULL, NULL, 'ReturnSource', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 66, 'dbo', 'Database', 'CashflowTransactionType', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionType', 'lh_bronze', NULL, NULL, 'CashflowTransactionType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, 'ReturnDate <> ''0001-01-01''', 1, 'Dev - Crimson', 'CrimsonXFundReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 54, 'dbo', 'Database', 'FundReturn', 'sqlserver', NULL, NULL, NULL, 'FundReturn', 'lh_bronze', NULL, NULL, 'FundReturn', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTimePeriod', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 122, 'dbo', 'Database', 'TimePeriod', 'sqlserver', NULL, NULL, NULL, 'TimePeriod', 'lh_bronze', NULL, NULL, 'TimePeriod', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundStatistics', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 120, 'dbo', 'Database', 'FundStatistics', 'sqlserver', NULL, NULL, NULL, 'FundStatistics', 'lh_bronze', NULL, NULL, 'FundStatistics', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 70, 'dbo', 'Database', 'CashflowTransactionDetail', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionDetail', 'lh_bronze', NULL, NULL, 'CashflowTransactionDetail', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXForecastedCashFlow', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 108, 'dbo', 'Database', 'ForecastedCashFlow', 'sqlserver', NULL, NULL, NULL, 'ForecastedCashFlow', 'lh_bronze', NULL, NULL, 'ForecastedCashFlow', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXForecastedCashFlowType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 107, 'dbo', 'Database', 'ForecastedCashFlowType', 'sqlserver', NULL, NULL, NULL, 'ForecastedCashFlowType', 'lh_bronze', NULL, NULL, 'ForecastedCashFlowType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeApprovalType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 106, 'dbo', 'Database', 'FundTradeApprovalType', 'sqlserver', NULL, NULL, NULL, 'FundTradeApprovalType', 'lh_bronze', NULL, NULL, 'FundTradeApprovalType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXHMCUser', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 93, 'dbo', 'Database', 'HMCUser', 'sqlserver', NULL, NULL, NULL, 'HMCUser', 'lh_bronze', NULL, NULL, 'HMCUser', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBudgetStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 80, 'dbo', 'Database', 'BudgetStrategy', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategy', 'lh_bronze', NULL, NULL, 'BudgetStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashFlowTransactionType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 79, 'dbo', 'Database', 'CashFlowTransactionType', 'sqlserver', NULL, NULL, NULL, 'CashFlowTransactionType', 'lh_bronze', NULL, NULL, 'CashFlowTransactionType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFirmAttribute', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 78, 'dbo', 'Database', 'FirmAttribute', 'sqlserver', NULL, NULL, NULL, 'FirmAttribute', 'lh_bronze', NULL, NULL, 'FirmAttribute', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXvwClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 223, 'dbo', 'Database', 'vwClassificationMap', 'sqlserver', NULL, NULL, NULL, 'vwClassificationMap to Bronze', 'lh_bronze', NULL, NULL, 'vwClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBudgetStrategyClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 222, 'dbo', 'Database', 'BudgetStrategyClassificationMap', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategyClassificationMap to Bronze', 'lh_bronze', NULL, NULL, 'BudgetStrategyClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundValuation', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 216, 'dbo', 'Database', 'FundValuation', 'sqlserver', NULL, NULL, NULL, 'FundValuation', 'lh_bronze', NULL, NULL, 'FundValuation', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBudgetStrategyClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 204, 'dbo', 'Database', 'BudgetStrategyClassificationMap', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategyClassificationMap', 'lh_bronze', NULL, NULL, 'BudgetStrategyClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXWeightedDaysType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 205, 'dbo', 'Database', 'WeightedDaysType', 'sqlserver', NULL, NULL, NULL, 'WeightedDaysType', 'lh_bronze', NULL, NULL, 'WeightedDaysType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, 'MERGE INTO Silver.CashflowTransactionDetail AS target
USING (
    SELECT 
        FundId,
        CAST(ExposureDate AS DATE) AS CommitmentDate,   -- stored as DATE
        CAST(CommitmentEffectLocal AS DECIMAL(15,2)) AS CommitmentAmount, -- trillions with 2 decimals
        CAST(CashflowTransactionTypeId AS INT) AS CashflowTransactionTypeId,
        FIRST_VALUE(CAST(CommitmentEffectLocal AS DECIMAL(15,2))) 
            OVER (PARTITION BY FundId ORDER BY ExposureDate ASC) AS FirstCommitmentAmount
    FROM Silver.CashflowTransactionDetail
    WHERE CashflowTransactionTypeId IN (5, 13)
) AS source
ON target.FundId = source.FundId
   AND target.ExposureDate = source.CommitmentDate
   AND target.CashflowTransactionTypeId = source.CashflowTransactionTypeId

WHEN MATCHED THEN
    UPDATE SET 
        target.CommitmentAmount = source.CommitmentAmount,
        target.FirstCommitmentAmount = source.FirstCommitmentAmount

WHEN NOT MATCHED THEN
    INSERT (FundId, CommitmentDate, CommitmentAmount, CashflowTransactionTypeId, FirstCommitmentAmount)
    VALUES (source.FundId, source.CommitmentDate, source.CommitmentAmount, source.CashflowTransactionTypeId, source.FirstCommitmentAmount);', NULL, NULL, 1, 'Dev - Crimson', 'CashflowTransactionDetail', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 11, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 1, NULL, 109, NULL, 'Solovis', NULL, 'Lakehouse', NULL, NULL, NULL, 'Solovis Transactions Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, 'SELECT
    CAST(IndexId AS VARCHAR(36)) AS IndexId,
    IndexName,
    DisplayName,
    Description,
    CurrencyId,
    IsRiskIndex,
    BetaCategoryId,
    IsShortIndex,
    IsCustomIndex,
    Ticker,
    Frequency,
    FinancialDataProviderId,
    IsLevelBased,
    ExchangeProviderId,
    IndexReturnTypeId,
    IsTotalReturn,
    IsActive,
    CAST(ETLLoadDateTime AS TIMESTAMP) AS ETLLoadDateTime
FROM Bronze.CrimsonXIndex
WHERE IndexId IS NOT NULL
  AND IndexName IS NOT NULL
  AND CurrencyId IS NOT NULL
  AND IsRiskIndex IS NOT NULL
  AND IsShortIndex IS NOT NULL
  AND IndexReturnTypeId IS NOT NULL
  AND IsTotalReturn IS NOT NULL
  AND ETLLoadDateTime IS NOT NULL;
', NULL, NULL, 1, 'Dev - Crimson', 'Index', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 27, 'Bronze', 'Database', 'CrimsonXIndex', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonIndex', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'IndexReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 95, 'Bronze', 'Database', 'IndexReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'WarehouseIndexReturn', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'IndexReturn_readonly', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 110, 'Bronze', 'Database', 'IndexReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'WarehouseIndexRet_RO', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'IndexReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 77, 'etl', 'Database', 'vwIndexReturnCrimsonXGUID', 'sqlserver', NULL, NULL, NULL, 'WarehouseIndexReturn', 'lh_bronze', NULL, NULL, 'IndexReturnRaw', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexCustomBlendRecipe', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 236, 'etl', 'Database', 'vwIndexBlendRecipeCrimsonXGUID', 'sqlserver', NULL, NULL, NULL, 'IndexCustomBlendRecipe', 'lh_bronze', NULL, NULL, 'IndexCustomBlendRecipe', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'IndexCustomBlendRecipe', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 237, 'Bronze', 'Database', 'CrimsonXIndexCustomBlendRecipe', 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexCustomBlendRecipe', 'lh_silver', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundHorizonReturn', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 27, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 2, NULL, 239, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Calculate fund net/gross returns', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundPerformance', 'Dev - Crimson', 'ETLLoadDateTime', 'Gold', 'ETLLoadDateTime', NULL, NULL, 45, NULL, 1, 'NotebookTask', NULL, NULL, 'overwrite', 'Silver', 1, NULL, 262, 'Silver', 'Database', 'Fund', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundPerformanceToGold', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 32, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Factset', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'merge', 'Bronze', 1, NULL, 3, 'Bronze', 'Facset', 'Factset', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset to Silver', 'lh_curated', NULL, NULL, NULL, NULL, 'SECURITY_ID, DATE', 1, 36, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundBenchmarkTrackRecord', 'Dev - Crimson', 'ETLLoadDateTime', 'Gold', NULL, NULL, NULL, 43, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 261, 'Bronze', 'Database', 'CrimsonXFundStatistics', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundBenchmarkTrackRecordGold', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 32, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundPaidAmount', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 260, 'dbo', 'Database', 'FundPaidAmount', 'sqlserver', NULL, NULL, NULL, 'FundPaidAmount', 'lh_bronze', NULL, NULL, 'FundPaidAmount', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CalculationMethodology', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 259, 'Bronze', 'Bronze', 'CrimsonXCalculationMethodology', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CalculationMethodology', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 35, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCalculationMethodology', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 258, 'dbo', 'Database', 'CalculationMethodology', 'sqlserver', NULL, NULL, NULL, 'CalculationMethodology', 'lh_bronze', NULL, NULL, 'CalculationMethodology', NULL, NULL, 0, 34, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'DrawdownFundAnalytic', 'Dev - Crimson', 'ETLLoadDateTime', 'Gold', 'ETLLoadDateTime', NULL, NULL, 42, NULL, 1, 'NotebookTask', NULL, NULL, 'overwrite', 'Silver', 1, NULL, 257, 'Silver', 'Database', 'Fund', 'Lakehouse', NULL, NULL, 'lh_curated', 'DrawdownFundAnalytic To Gold', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 32, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Classification', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 23, NULL, 1, 'NotebookTask', 'CrimsonX', NULL, 'overwrite', 'Database', 1, NULL, 224, NULL, 'Database', 'Classification', 'sqlserver', NULL, NULL, NULL, 'Classification Table to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CustomRiskBenchmark', 'Dev - Crimson', 'ETLLoadDateTime', 'Gold', 'ETLLoadDateTime', NULL, NULL, 44, NULL, 1, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 226, 'Bronze', 'Database', 'CrimsonXFundStatistics', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CustomRiskBenchmark to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 32, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundProjectedAnalytics', 'Dev - Crimson', 'ETLLoadDateTime', 'Gold', NULL, NULL, NULL, 41, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 256, 'Bronze', 'Database', 'CrimsonXFundStatistics', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundProjectedAnalyticsGold', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 32, NULL
UNION ALL
SELECT NULL, 'SELECT
    EIN,
    AsOfYear,
    COALESCE(FederalTaxIncome, 0) AS FederalTaxIncome,
    COALESCE(FederalUBI, 0) AS FederalUBI,
    COALESCE(UBTITax, 0) AS UBTITax,
    COALESCE(NIITax, 0) AS NIITax
FROM Bronze.TaxData
WHERE EIN IS NOT NULL
  AND AsOfYear IS NOT NULL

', NULL, NULL, 1, 'Dev - Crimson', 'FundTaxIncome', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 255, 'Bronze', 'Database', 'TaxData', 'Lakehouse', NULL, NULL, 'lh_bronze', 'TaxData FunTaxIncome to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, 'SELECT DISTINCT
    FundId,
    EIN
FROM Bronze.TaxData WHERE FundId IS NOT NULL
  AND EIN IS NOT NULL', NULL, NULL, 1, 'Dev - Crimson', 'FundTaxEIN', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 254, 'Bronze', 'Database', 'TaxData', 'Lakehouse', NULL, NULL, 'lh_bronze', 'TaxData EIN to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'SELECT CAST(FirmId AS VARCHAR(36)) AS FirmId, FirmName FROM Bronze.CrimsonXFirm', NULL, NULL, 1, 'Dev - Crimson', 'Firm', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 220, 'Bronze', 'Database', 'CrimsonXFirm', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Firm to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'SELECT     CAST(EntityId AS VARCHAR(36)) AS EntityId,     CAST(FirmId AS VARCHAR(36)) AS FirmId,     EntityName AS EntityName,     EntityInvestmentStatusId AS EntityStatus,     BusinessOwnerHMCUserId AS PrimaryOwner,      BackupBusinessOwnerHMCUserId AS SecondaryOwner,      AssociateHMCUserId AS Associate,     SecondaryBackupBusinessOwnerHMCUserId AS TertiaryOwner, AlphaStrategyID as AlphaStrategyId   FROM Bronze.CrimsonXEntity', NULL, NULL, 1, 'Dev - Crimson', 'Entity', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 221, 'Bronze', 'Database', 'CrimsonXEntity', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Entity to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 36, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 6, NULL, 250, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'UserRiskArea', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 35, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 5, NULL, 249, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'OverallScoreData', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 34, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 4, NULL, 248, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'DeptRiskData', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 33, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 3, NULL, 247, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'UserRiskLevels', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 32, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 2, NULL, 246, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'UserRiskData', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 37, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 245, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'FailureRates', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 31, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 244, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'ManualData', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 30, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 243, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'KnowBe4Data', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 29, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 242, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'PhishingTestSummary', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCHierarchyAttributes', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 233, 'Bronze', 'Database', 'HMCDataMartInvestmentHMCHierarchyAttributes', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataMartInvestmentHMCHierarchyAttributes to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', NULL, 'ETLLoadDateTime', NULL, NULL, 1, NULL, 1, 'NotebookTask', NULL, 'Files/IncomingFeed/CyberSecurityDashboard/KnowBe4', 'overwrite', 'KnowBe4', 1, NULL, 45, NULL, 'API', NULL, 'KnowBe4', NULL, NULL, NULL, 'KnowBe4ApiPhishingTestsCall', 'lh_bronze', NULL, NULL, 'knowbe4_data.parquet', NULL, NULL, 1, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', NULL, NULL, NULL, NULL, NULL, 25, NULL, 1, 'NotebookTask', NULL, 'Files/IncomingFeed/CyberSecurityDashboard/KnowBe4', 'overwrite', 'KnowBe4', 1, NULL, 228, NULL, 'API', NULL, 'KnowBe4', NULL, NULL, NULL, 'KnowBe4ApiUsersCall', 'lh_bronze', NULL, NULL, 'users_output.parquet', NULL, NULL, 0, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundHorizonRiskBenchmark', 'Dev - Crimson', NULL, 'Gold', NULL, NULL, NULL, 38, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 3, NULL, 251, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Calculate fund risk benchmark returns', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPublicFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 34, 'dbo', 'Database', 'FeesForPublicModel', 'sqlserver', NULL, NULL, NULL, 'FeesForPublicModel', 'lh_bronze', NULL, NULL, 'FeesForPublicModel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 28, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Splunk', 1, NULL, 241, NULL, 'API', NULL, 'API', NULL, NULL, 'lh_bronze', 'SplunkDataCall', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 26, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'SpyCloud', 1, NULL, 229, NULL, 'API', NULL, 'API', NULL, NULL, 'lh_bronze', 'SpyCloudDataCall', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 17, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 4, NULL, 125, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturnSilver Frequency', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 24, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 3, NULL, 225, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturn Computed Benchmarks', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 15, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 1, NULL, 123, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturnSilver Gap Fill', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 19, NULL, 0, 'NotebookTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 2, 'hmc-report/api/v1/BottomUp/FundLevelCalc?caseId=3&useBetaSummaryGia=false&asOfDate=7/15/2025&numYears=10&calculationMethodology=1&fundCycleMethodology=0&fundCycleModelId=1', 203, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, 'lh_raw', 'Bottom Up Data to Bronze', 'lh_bronze', NULL, NULL, 'FundLevelCalc.json', NULL, NULL, 0, 23, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 19, NULL, 0, 'NotebookTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 2, 'hmc-report/api/v1/BottomUp/FundLevelCalcMonthly?caseId=3&useBetaSummaryGIA=false&useLTM=false&asOfDate=7/23/2025&reportDate=7/24/2025&calculationMethodology=1&numYears=3&fundCycleMethodology=0&fundCycleModelId=1', 227, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, 'lh_raw', 'Bottom Up Monthly Data to Bronze', 'lh_bronze', NULL, NULL, 'FundLevelCalcMonthly.json', NULL, NULL, 0, 23, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', NULL, NULL, NULL, NULL, 'CrimsonPreAPI', NULL, NULL, 0, 'ApiTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 1, 'hmc-report/api/v1/BottomUp/FundLevelCalcMonthly?caseId=3&useBetaSummaryGIA=false&useLTM=false&asOfDate=7/23/2025&reportDate=7/24/2025&calculationMethodology=1&numYears=3&fundCycleMethodology=0&fundCycleModelId=1', 208, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, NULL, 'FundLevelCalcMonthly to Raw', 'lh_raw', NULL, NULL, 'FundLevelCalcMonthly.json', NULL, NULL, 0, 27, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', NULL, NULL, NULL, NULL, 'CrimsonDevAPI', NULL, NULL, 0, 'ApiTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 1, 'hmc-report/api/v1/BottomUp/FundLevelCalc?caseId=3&useBetaSummaryGia=false&asOfDate=7/15/2025&numYears=10&calculationMethodology=1&fundCycleMethodology=0&fundCycleModelId=1', 207, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, NULL, 'FundLevelCalc to Raw', 'lh_raw', NULL, NULL, 'FundLevelCalc.json', NULL, NULL, 0, 25, NULL
UNION ALL
SELECT NULL, 'SELECT    c.id AS conversationId
,    c.name AS conversationName
,    c.userId AS conversationUserId
,    c.integrationName AS conversationIntegrationName
,    c.createdAt AS conversationCreatedAt
,    c.updatedAt AS conversationUpdatedAt
,    c.tokensRemaining
,    c.tokenCount
,    c._self
,    c._rid
,    c._attachments
,    c._ts
,    m.id AS messageId
,    m.role AS messageRole
,    m.content               AS messageContent
,    m.createdAt             AS messageCreatedAt
,    (IS_DEFINED(m.metadata.messageId)       ? m.metadata.messageId       : null) AS metadata_messageId   
,    (IS_DEFINED(m.metadata.visible)            ? m.metadata.visible            : null) AS metadata_visible
,    (IS_DEFINED(m.metadata.fileName)            ? m.metadata.fileName            : null) AS metadata_fileName
,    (IS_DEFINED(m.metadata.contentType)            ? m.metadata.contentType            : null) AS metadata_contentType
,    (IS_DEFINED(m.metadata.length)            ? m.metadata.length           : null) AS metadata_length
,    (IS_DEFINED(m.metadata.contentDisposition)            ? m.metadata.contentDisposition            : null) AS metadata_contentDisposition
,    (IS_DEFINED(m.metadata.name)            ? m.metadata.name            : null) AS metadata_name
,    (IS_DEFINED(m.metadata.isImage)            ? m.metadata.isImage            : null) AS metadata_isImage
,    (IS_DEFINED(m.metadata.fingerprint)            ? m.metadata.fingerprint            : null) AS metadata_fingerprint
,    (IS_DEFINED(m.metadata.numberOfImages)            ? m.metadata.numberOfImages            : null) AS metadata_numberOfImages
,    (IS_DEFINED(m.metadata.pageCount)            ? m.metadata.pageCount            : null) AS metadata_pageCount
,    (IS_DEFINED(m.metadata.quality)            ? m.metadata.quality            : null) AS metadata_quality
,    (IS_DEFINED(m.metadata.source)             ? m.metadata.source             : null) AS metadata_source
,    (IS_DEFINED(m.metadata.functionArguments)  ? m.metadata.functionArguments  : null) AS metadata_functionArguments
,    (IS_DEFINED(m.metadata.functionName)       ? m.metadata.functionName       : null) AS metadata_functionName
,    (IS_DEFINED(m.metadata.feedbackType)       ? m.metadata.feedbackType       : null) AS metadata_feedbackType
,    (IS_DEFINED(m.metadata.feedbackReason)       ? m.metadata.feedbackReason       : null) AS metadata_feedbackReason
FROM ChatHistory c 
JOIN m IN c.messages', NULL, NULL, 1, 'Dev - Crimson', 'ChatAiDbChatHistory', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'ChatAiDb', 'chatAiDb', 'overwrite', 'chatAiDb', 1, NULL, 230, NULL, 'ChatHistory CosmosDB', 'ChatHistory', 'cosmosdb', NULL, NULL, NULL, 'Get ChatHistory', 'lh_bronze', NULL, NULL, 'ChatHistory', NULL, NULL, 0, 29, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTaxIncome_Consolidated', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 238, 'dbo', 'Database', 'FundTaxIncome_Consolidated', 'sqlserver', NULL, '1', NULL, 'CrimsonXFundTaxIncome_Consolidated', 'lh_bronze', NULL, NULL, 'FundTaxIncome_Consolidated', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, 'SELECT         PerformanceTypeId,
    StartDate,
    EndDate,
    PrivateRefreshDate,
    AsOfDate,
    CAST(WeightedAssetReturn AS DECIMAL(38,6)) AS WeightedAssetReturn,
    CAST(BetaReturn AS DECIMAL(38,6)) AS BetaReturn,
    CAST(BetaReturnFlatIlliquids AS DECIMAL(38,6)) AS BetaReturnFlatIlliquids,
    CAST(PublicReturn AS DECIMAL(38,6)) AS PublicReturn
FROM Bronze.HMCDataMartInvestmentPerformanceGIAReturn
WHERE PerformanceTypeId IS NOT NULL
  AND StartDate IS NOT NULL
  AND EndDate IS NOT NULL
  AND AsOfDate IS NOT NULL

	
', NULL, NULL, 1, 'Dev - Crimson', 'PerformanceGIAReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 235, 'Bronze', 'Database', 'HMCDataMartInvestmentPerformanceGIAReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataMartInvestmentPerformanceGIAReturn', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'SolovisExternalActiveBook', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 232, 'etl', 'Database', 'vwSolovisLoadHelper_ActiveBookXref', 'sqlserver', NULL, NULL, NULL, 'SolovisExternalActiveBook', 'lh_bronze', NULL, NULL, 'SolovisExternalActiveBook', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, 'SELECT FundValuationId        
,FundId        	
,ShareClassId        	
,PortfolioTypeId        	
,NavDate        	
,ValuationDate        	
,ValuationAmt        	
,CurrencyId        	
,ValuationTypeId        	
,FrequencyId        	
,ETLLoadDateTime    	
FROM Bronze.CrimsonXFundValuation	
WHERE EndDate = CAST(''9999-12-31'' AS DATE)	
', NULL, NULL, 0, 'Dev - Crimson', 'FundValuation', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 240, 'Bronze', 'Database', 'CrimsonXFundValuation', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Solovis Valuation to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, '92b328a7-0bb9-47f9-a4b5-7ac4daf3bb13,5b0a2af0-0c1c-44fe-9233-19d31bff303f', 1, 'Dev - Crimson', 'EntraUsers', 'Dev - Crimson', NULL, 'Bronze', NULL, NULL, NULL, NULL, NULL, 0, 'office365', NULL, NULL, 'overwrite', 'Entra', 1, NULL, 89, NULL, 'Entra', 'BasicDataSet_v0.User_v1', 'office365', '  {
    "type": "TabularTranslator",
    "mappings": [
        {
            "source": {
                "name": "accountEnabled",
                "type": "Boolean",
                "physicalType": "boolean"
            },
            "sink": {
                "name": "accountEnabled",
                "physicalType": "boolean"
            }
        },
        {
            "source": {
                "name": "department",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "department",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "givenName",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "givenName",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "mail",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "mail",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "mobilePhone",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "mobilePhone",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "surname",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "surname",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "userPrincipalName",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "userPrincipalName",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "puser",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "puser",
                "physicalType": "string"
            }
        },  {
                "source": {
                    "name": "jobTitle",
                    "type": "String",
                    "physicalType": "string"
                },
                "sink": {
                    "name": "jobTitle",
                    "physicalType": "string"
                }
            }
    ],
    "typeConversion": true,
    "typeConversionSettings": {
        "allowDataTruncation": true,
        "treatBooleanAsNumber": false
    },
    "columnFlattenSettings": {
        "treatArrayAsString": false,
        "treatStructAsString": false,
        "flattenColumnDelimiter": "."
    }
}', NULL, NULL, 'Entra Users', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 13, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ProcessFundChanges', 'Dev - Crimson', NULL, 'Bronze', NULL, NULL, NULL, 40, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 4, NULL, 253, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Cleanup after calculating fund statistics', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundHorizonAlpha', 'Dev - Crimson', NULL, 'Gold', NULL, NULL, NULL, 39, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 3, NULL, 252, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Calculate fund alpha returns', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'EntraUserDevices', 'Dev - Crimson', NULL, 'Bronze', NULL, NULL, NULL, NULL, NULL, 0, 'office365', NULL, NULL, 'overwrite', 'Entra', 1, NULL, 90, NULL, 'Entra', 'BasicDataSet_v0.OwnedDevices_v0', 'office365', NULL, NULL, NULL, 'Entra User Devices', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 13, NULL
)
UPDATE target
SET
    target.SinkWarehouseName = source.SinkWarehouseName,
    target.CustomSQLSourceQuery = source.CustomSQLSourceQuery,
    target.SinkLakehouseId = source.SinkLakehouseId,
    target.SourceWhereClause = source.SourceWhereClause,
    target.IsActiveFlag = source.IsActiveFlag,
    target.SourceWorkspaceName = source.SourceWorkspaceName,
    target.SinkTableName = source.SinkTableName,
    target.SinkWorkspaceName = source.SinkWorkspaceName,
    target.SinkWatermarkColumn = source.SinkWatermarkColumn,
    target.SinkSchemaName = source.SinkSchemaName,
    target.SourceWatermarkColumn = source.SourceWatermarkColumn,
    target.SourceFlatfileConnectionSettings = source.SourceFlatfileConnectionSettings,
    target.SourceConnectionName = source.SourceConnectionName,
    target.NotebookKey = source.NotebookKey,
    target.SinkWorkspaceId = source.SinkWorkspaceId,
    target.ArchiveOriginalFilesFlag = source.ArchiveOriginalFilesFlag,
    target.TaskType = source.TaskType,
    target.SourceDatabaseName = source.SourceDatabaseName,
    target.RawStoragePath = source.RawStoragePath,
    target.SinkLoadMethod = source.SinkLoadMethod,
    target.SourceName = source.SourceName,
    target.TaskRunOrderNbr = source.TaskRunOrderNbr,
    target.RelativeUrl = source.RelativeUrl,
    target.SourceSchemaName = source.SourceSchemaName,
    target.ParentSourceName = source.ParentSourceName,
    target.SourceTableName = source.SourceTableName,
    target.SourceType = source.SourceType,
    target.CustomPipelineCode = source.CustomPipelineCode,
    target.SourceExtractionMethod = source.SourceExtractionMethod,
    target.SourceLakehouseName = source.SourceLakehouseName,
    target.TaskName = source.TaskName,
    target.SinkLakehouseName = source.SinkLakehouseName,
    target.ArchiveStoragePath = source.ArchiveStoragePath,
    target.SourceWarehouseName = source.SourceWarehouseName,
    target.RawStorageFileName = source.RawStorageFileName,
    target.ArchiveStorageFileName = source.ArchiveStorageFileName,
    target.PrimaryKeyColumnList = source.PrimaryKeyColumnList,
    target.IsWatermarkEnabledFlag = source.IsWatermarkEnabledFlag,
    target.JobKey = source.JobKey,
    target.OverrideQuery = source.OverrideQuery
FROM etlControl.etl.Task AS target
JOIN source
    ON target.TaskKey = source.TaskKey;

-- ===== INSERT NEW ROWS =====
WITH source (SinkWarehouseName, CustomSQLSourceQuery, SinkLakehouseId, SourceWhereClause, IsActiveFlag, SourceWorkspaceName, SinkTableName, SinkWorkspaceName, SinkWatermarkColumn, SinkSchemaName, SourceWatermarkColumn, SourceFlatfileConnectionSettings, SourceConnectionName, NotebookKey, SinkWorkspaceId, ArchiveOriginalFilesFlag, TaskType, SourceDatabaseName, RawStoragePath, SinkLoadMethod, SourceName, TaskRunOrderNbr, RelativeUrl, TaskKey, SourceSchemaName, ParentSourceName, SourceTableName, SourceType, CustomPipelineCode, SourceExtractionMethod, SourceLakehouseName, TaskName, SinkLakehouseName, ArchiveStoragePath, SourceWarehouseName, RawStorageFileName, ArchiveStorageFileName, PrimaryKeyColumnList, IsWatermarkEnabledFlag, JobKey, OverrideQuery) AS (
SELECT NULL, 'SELECT
    CAST(PerformanceTypeId AS INT) AS PerformanceTypeId,
    CAST(StartDate AS DATE) AS StartDate,
    CAST(EndDate AS DATE) AS EndDate,
    CAST(AsOfDate AS DATE) AS AsOfDate,
    Level1,
    Level2,
    Level3,
    Level4,
    Level5,
    Level6,
    Level7,
    CAST(SortOrdinal AS INT) AS SortOrdinal,
    CAST(FundId AS VARCHAR(36)) AS FundId,
    Description,
    CAST(NAV AS DECIMAL(38,6)) AS NAV,
    CAST(PercentOfGIA AS DECIMAL(38,6)) AS PercentOfGIA,
    CAST(LastValuationDate AS DATE) AS LastValuationDate,
    CAST(PercentReporting AS DECIMAL(38,6)) AS PercentReporting,
    CAST(CategoryReturn AS DECIMAL(38,6)) AS CategoryReturn,
    CAST(IndexId AS VARCHAR(36)) AS IndexId,
    IndexName,
    CAST(IndexReturn AS DECIMAL(38,6)) AS IndexReturn,
    CAST(OverUnderPerformance AS DECIMAL(38,6)) AS OverUnderPerformance,
    CAST(CashFlows AS DECIMAL(38,6)) AS CashFlows,
    CAST(PnL AS DECIMAL(38,6)) AS PnL,
    CAST(Commitment AS DECIMAL(38,6)) AS Commitment,
    CAST(Unfunded AS DECIMAL(38,6)) AS Unfunded,
    CAST(UpdateTimestamp AS TIMESTAMP) AS UpdateTimestamp,
    UpdateByHMCUserId,
    CAST(ETLLoadDateTime AS TIMESTAMP) AS ETLLoadDateTime
FROM Bronze.HMCDataMartInvestmentPerformanceFlash
WHERE PerformanceTypeId IS NOT NULL
  AND StartDate IS NOT NULL
  AND EndDate IS NOT NULL
  AND AsOfDate IS NOT NULL
  AND ETLLoadDateTime IS NOT NULL
', NULL, NULL, 1, 'Dev - Crimson', 'PerformanceFlash', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 234, 'Bronze', 'Database', 'HMCDataMartInvestmentPerformanceFlash', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataMartInvestmentPerformanceFlash', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'SELECT
    CAST(FundId AS VARCHAR(36)) AS FundId,
    Tier,
    CAST(ManagementFee AS DECIMAL(38,2)) AS ManagementFee, 
    FeeTierBasisTypeId,
    ETLLoadDateTime
FROM Bronze.CrimsonXPrivateFeeTiers
WHERE FundId IS NOT NULL
  AND Tier IS NOT NULL
  AND ManagementFee IS NOT NULL
  AND FeeTierBasisTypeId IS NOT NULL;

', NULL, NULL, 1, 'Dev - Crimson', 'PrivateFeeTiers', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 119, 'Bronze', 'Database', 'CrimsonXFeesForPrivateModelTier', 'Lakehouse', NULL, NULL, 'lh_bronze', 'PrivateFeeTiers', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'SELECT      CAST(FundId AS varchar(36)) AS FundId,      CAST(MgmtPct AS decimal(38,6)) AS MgmtPct,      IsHighWaterMark,      FeeHurdleTypeId,      CAST(HurdlePct AS decimal(38,6)) AS HurdlePct,      CAST(IndexId AS varchar(36)) AS IndexId,      CAST(CarryPct AS decimal(38,6)) AS CarryPct,      IsIndexHistorical,      CAST(IndexReturnPct AS decimal(38,6)) AS IndexReturnPct,      CAST(IndexVolPct AS decimal(38,6)) AS IndexVolPct,      CAST(ExpenseRatio AS bigint) AS ExpenseRatio,      FeeCrystalizationTypeId,      IsLossCarry,      IsClawBack,      FeePaymentFrequencyTypeId,      FeePaymentTimingTypeId,      FeeBasisTypeId,      IsRebate,      FeeCarryMethodTypeId,      ContractualTermMatchId,      ETLLoadDateTime  FROM Bronze.CrimsonXPublicFees', NULL, NULL, 1, 'Dev - Crimson', 'PublicFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 117, 'Bronze', 'Database', 'CrimsonXPublicFees', 'Lakehouse', NULL, NULL, 'lh_bronze', 'PublicFees', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, 'SELECT
        CAST(FundId AS VARCHAR(36)) AS FundId,
    InvestmentPeriodQuarters,
    HarvestPeriodQuarters,
    CAST(ExpectedExpensePct AS DECIMAL(38, 6)) AS ExpectedExpensePct,
    CAST(CarryPct AS DECIMAL(38, 6)) AS CarryPct,
    FeeCarryMethodTypeId,
    CAST(PreferredRatePct AS DECIMAL(38, 6)) AS PreferredRatePct,
    HasHardHurdle,
    CAST(GPCatchUpPct AS DECIMAL(38, 6)) AS GPCatchUpPct,
    CAST(ClawbackTaxPct AS DECIMAL(38, 6)) AS ClawbackTaxPct,
    CAST(UncalledCapitalPct AS DECIMAL(38, 6)) AS UncalledCapitalPct,
    ContractualTermMatchId,
    ETLLoadDateTime
FROM Bronze.CrimsonXPrivateFees
WHERE FundId IS NOT NULL

', NULL, NULL, 1, 'Dev - Crimson', 'PrivateFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 118, 'Bronze', 'Database', 'CrimsonXFeesForPrivateModel', 'Lakehouse', NULL, NULL, 'lh_bronze', 'PrivateFees', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'SELECT   
UniversityTransactionId  
,PortfolioTypeId  
,CashFlowTransactionTypeId  
,CashFlowTransactionSubTypeId  
,CAST(TransactionAmountLocal AS DECIMAL(38,2)) AS TransactionAmountLocal 
,CAST(TransactionAmountUSD AS DECIMAL(38,2)) AS TransactionAmountUSD
,CAST(CommitmentEffectLocal AS DECIMAL(38,2)) AS CommitmentEffectLocal
,CAST(MarketValueEffectLocal AS DECIMAL(38,2)) AS MarketValueEffectLocal
,BookStartOfDay  
,ExposureDate  
,TradeDate  
,SettleDate  
,DocumentURL  
,CurrencyId  
FROM Bronze.CrimsonXUniversityTransaction  
WHERE CAST(EndDate AS DATE) = CAST(''9999-12-31'' AS DATE)', NULL, NULL, 1, 'Dev - Crimson', 'UniversityTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 219, 'Bronze', 'Database', 'CrimsonXUniversityTransaction', 'Lakehouse', NULL, NULL, 'lh_bronze', 'TransactionUniversity', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCurrencyRate', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'merge', 'Database', 1, NULL, 270, 'dbo', 'Database', 'CurrencyRate', 'sqlserver', NULL, NULL, NULL, 'CurrencyRate', 'lh_bronze', NULL, NULL, 'CurrencyRate', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ForecastedCashFlow', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 12, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 114, 'Bronze', 'Database', 'CrimsonXForecastedCashFlow', 'Lakehouse', NULL, NULL, 'lh_bronze', 'ForecastedCashFlowSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'WITH fundcomprep AS (
  SELECT  
    abfm.FundId,
	c.CurrencyId,
    to_date(sc.Date, ''M/d/yyyy'') AS CommitmentDate,
    SUM(CAST(sc.DeltaValue AS DECIMAL(18,2))) AS CommitmentAmount,
    sc.ETLLoadDateTime
  FROM Bronze.SolovisCommitments sc
  INNER JOIN Bronze.SolovisActiveBookFundMapping abfm
    ON sc.InvestmentResourceId = abfm.InvestmentResourceId
  INNER JOIN Bronze.SolovisInvestments si ON si.ResourceId = abfm.InvestmentResourceId
  INNER JOIN Bronze.SolovisCurrency scur ON scur.Id = si.LocalCurrencyId
  INNER JOIN Bronze.CrimsonXCurrency c ON c.ISOCode = scur.Code
  GROUP BY abfm.FundId, c.CurrencyId , sc.ETLLoadDateTime --, sc.`Date`
				
)
SELECT 
  FundId, 
  CommitmentDate,
  CurrencyId,
  CommitmentAmount, 
  CASE WHEN CommitmentAmount < 0 THEN 13 ELSE 5 END AS CashflowTransactionTypeId, 
  ETLLoadDateTime
FROM fundcomprep f
', NULL, NULL, 0, 'Dev - Crimson', 'FundCommitment', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 231, 'Bronze', 'Database', 'SolovisCommitments', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Solovis Commitments', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 269, 'dbo', 'Database', 'CashflowTransaction', 'sqlserver', NULL, NULL, NULL, 'CashflowTransaction', 'lh_bronze', NULL, NULL, 'CashflowTransaction', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLiquidityRedemptionFrequencyType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 268, 'dbo', 'Database', 'LiquidityRedemptionFrequencyType', 'sqlserver', NULL, NULL, NULL, 'LiquidityRedemptionFrequencyType', 'lh_bronze', NULL, NULL, 'LiquidityRedemptionFrequencyType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexConstituent', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 267, 'dbo', 'Database', 'IndexConstituent', 'sqlserver', NULL, NULL, NULL, 'IndexConstituent', 'lh_bronze', NULL, NULL, 'IndexConstituent', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTrade', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 14, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 116, 'Bronze', 'Database', 'CrimsonXFundTrade', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTrade', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeForecastedTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 13, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 115, 'Bronze', 'Database', 'CrimsonXFundTradeForecastedTransaction', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeForecastedTransaction', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ForecastedCashFlowType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 112, 'Bronze', 'Database', 'CrimsonXForecastedCashFlowType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'ForecastedCashFlowType', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeApprovalType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 111, 'Bronze', 'Database', 'CrimsonXFundTradeApprovalType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeApprovalType', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 96, 'Bronze', 'Database', 'CrimsonXFundTradeStatus', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeStatusToSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 97, 'Bronze', 'Database', 'CrimsonXFundTradeType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeTypeToSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'aivyeval', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 49, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 1, NULL, 266, 'Bronze', 'Bronze', 'AivyEval', 'Lakehouse', NULL, NULL, 'lh_bronze', 'AivyEvalsToSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 39, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'AivyEval', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 48, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Crimson HMC API', 1, NULL, 265, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, NULL, 'AivyEvalsAPIToBronze', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 38, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'aivychathistory', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 47, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 264, 'Bronze', 'Bronze', 'ChatAiDbChatHistory', 'Lakehouse', NULL, NULL, 'lh_bronze', 'AivyChatHistoryToSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 37, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundValuation', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 46, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 2, NULL, 263, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundValuation', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Universe', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 3, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 63, 'Bronze', 'Database', 'CrimsonXUniverse', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonXSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'SolovisActiveBookFundMapping', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 10, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 2, NULL, 94, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Build ActiveBook & Fund Mappings', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 16, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 2, NULL, 124, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturnSilver Levels', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCUsers', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 9, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Entra', 1, NULL, 92, NULL, 'Entra', NULL, 'Lakehouse', NULL, NULL, NULL, 'Entra Users Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 18, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Region', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 5, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 75, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset-IndexRegionExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'RegionCountry', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 2, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 49, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset-IndexRegionCountryExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'SectorIndustry', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 6, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 50, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset-IndexSectorIndustryExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 21, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'CrimsonXCashflowTransactionDetail', 2, NULL, 209, 'Bronze', 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Update CashflowTransactionDetail USD Amounts with correct FX Rate', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 22, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Crimson HMC API', 3, NULL, 215, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, 'lh_bronze', 'Bottom Up Data to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 26, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundMarketValue', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 20, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 1, NULL, 206, 'Silver', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_curated', 'Solovis Market Values Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Fund', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 18, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 202, 'Bronze', 'Database', 'CrimsonXFund', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehousevwSourceReferenceIndex', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, -1, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 43, 'dbo', 'Database', 'vwSourceReferenceIndex', 'sqlserver', NULL, NULL, 'NULL', 'vwSourceReferenceIndex', 'lh_bronze', NULL, NULL, 'vwSourceReferenceIndex', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Currency', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', 'NULL', NULL, 'overwrite', 'Bronze', 1, NULL, 30, 'Bronze', 'Database', 'HMCDataWarehouseCurrency', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataWarehouseCurrency', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexRegionExposure', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', 'NULL', NULL, 'overwrite', 'Bronze', 1, NULL, 29, 'Bronze', 'Database', 'CrimsonXIndexRegionExposure', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonXIndexRegionExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Frequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', 'NULL', NULL, 'overwrite', 'Bronze', 1, NULL, 28, 'Bronze', 'Database', 'CrimsonXFrequency', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonXFrequency', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'Holdings', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 64, 'Bronze', 'Bronze', 'CrimsonXHoldings', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Holdings to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 65, 'Bronze', 'Bronze', 'CrimsonXCashflowTransactionDetail', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CashflowTransactionDetail to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CashflowTransactionSubtype', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 69, 'Bronze', 'Bronze', 'CrimsonXCashflowTransactionSubtype', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CashflowTransactionSubtype to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CashflowTransactionType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 68, 'Bronze', 'Bronze', 'CrimsonXCashflowTransactionType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CashflowTransactionType to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ReturnType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 60, 'Bronze', 'Bronze', 'CrimsonXReturnType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Return Type to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ReturnSource', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 59, 'Bronze', 'Bronze', 'CrimsonXReturnSource', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Return Source to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundConstituentAccounting', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'merge', 'Bronze', 1, NULL, 10, 'Bronze', 'Database', 'FundConstituentAccounting', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, 'FundId', 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', '02Test', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'merge', 'Bronze', 1, NULL, 2, 'Bronze', 'Bronze', '02Test', 'Lakehouse', NULL, NULL, 'lh_bronze', '01Test', 'lh_curated', NULL, NULL, NULL, NULL, 'Date', 1, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'LiquidityTermSchedule', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 7, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 88, 'Bronze', 'Database', 'LiquidityTerms', 'Lakehouse', NULL, NULL, 'lh_bronze', 'LiquidityTermSch', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FXRate', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 4, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 1, NULL, 76, 'Bronze', 'Database', 'FXRate', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FXRate', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 12, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'FundReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 57, 'Bronze', 'Bronze', 'CrimsonXFundReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Fund Return to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Note', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 8, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 2, NULL, 91, 'Bronze', 'Blob', 'Note', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Notes To Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 24, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentPerformanceGIAReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 87, 'dbo', 'Database', 'PerformanceGIAReturn', 'sqlserver', NULL, NULL, NULL, 'PerformanceGIAReturn', 'lh_bronze', NULL, NULL, 'PerformanceGIAReturn', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentPerformanceFlash', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 86, 'dbo', 'Database', 'PerformanceFlash', 'sqlserver', NULL, NULL, NULL, 'PerformanceFlash', 'lh_bronze', NULL, NULL, 'PerformanceFlash', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentHMCHierarchyAttributes', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 85, 'dbo', 'Database', 'HMCHierarchyAttributes', 'sqlserver', NULL, NULL, NULL, 'HMCHierarchyAttributes', 'lh_bronze', NULL, NULL, 'HMCHierarchyAttributes', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentFundBetaSummaryLog', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 84, 'dbo', 'Database', 'FundBetaSummaryLog', 'sqlserver', NULL, NULL, NULL, 'FundBetaSummaryLog', 'lh_bronze', NULL, NULL, 'FundBetaSummaryLog', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentFundBetaSummaryHeaderLog', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 83, 'dbo', 'Database', 'FundBetaSummaryHeaderLog', 'sqlserver', NULL, NULL, NULL, 'FundBetaSummaryHeaderLog', 'lh_bronze', NULL, NULL, 'FundBetaSummaryHeaderLog', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentBetaAnalyticSummary', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 82, 'dbo', 'Database', 'BetaAnalyticSummary', 'sqlserver', NULL, NULL, NULL, 'BetaAnalyticSummary', 'lh_bronze', NULL, NULL, 'BetaAnalyticSummary', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentBetaAnalytic', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 81, 'dbo', 'Database', 'BetaAnalytic', 'sqlserver', NULL, NULL, NULL, 'BetaAnalytic', 'lh_bronze', NULL, NULL, 'BetaAnalytic', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 133, 'dbo', 'Database', 'ClassificationMap', 'sqlserver', NULL, NULL, NULL, 'ClassificationMap for Solovis Load', 'lh_bronze', NULL, NULL, 'ClassificationMap', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassification', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 132, 'dbo', 'Database', 'Classification', 'sqlserver', NULL, NULL, NULL, 'Classification for Solovis Load', 'lh_bronze', NULL, NULL, 'Classification', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 131, 'dbo', 'Database', 'Entity', 'sqlserver', NULL, NULL, NULL, 'Entity for Solovis Load', 'lh_bronze', NULL, NULL, 'Entity', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 130, 'dbo', 'Database', 'Firm', 'sqlserver', NULL, NULL, NULL, 'Firm for Solovis Load', 'lh_bronze', NULL, NULL, 'Firm', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 129, 'dbo', 'Database', 'Fund', 'sqlserver', NULL, NULL, NULL, 'Fund for Solovis Load', 'lh_bronze', NULL, NULL, 'Fund', NULL, 'FundId', 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 128, 'dbo', 'Database', 'CashflowTransactionDetail', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionDetail for Solovis Load', 'lh_bronze', NULL, NULL, 'CashflowTransactionDetail', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseExternalActiveBook', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 127, 'etl', 'Database', 'vwSolovisLoadHelper_ActiveBookXref', 'sqlserver', NULL, NULL, NULL, 'vwSolovisLoadHelper_ActiveBookXref for Solovis Load', 'lh_bronze', NULL, NULL, 'ExternalActiveBook', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXShareClass', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 126, 'dbo', 'Database', 'ShareClass', 'sqlserver', NULL, NULL, NULL, 'ShareClass for Solovis Load', 'lh_bronze', NULL, NULL, 'ShareClass', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Office365User', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', NULL, 'Office365', 'overwrite', 'Office365', 1, NULL, 44, NULL, 'Database', NULL, 'office365', NULL, NULL, NULL, 'Office365User', 'lh_bronze', NULL, NULL, 'Office365User', NULL, NULL, 0, 8, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundConstituentAccounting', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 4, 'dbo', 'Database', 'FundConstituentAccounting', 'sqlserver', NULL, NULL, '', 'FundConstituentAccounting', 'lh_bronze', NULL, NULL, 'FundConstituentAccounting', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseCurrency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 16, 'dbo', 'Database', 'Currency', 'sqlserver', NULL, NULL, NULL, 'Currency', 'lh_bronze', NULL, NULL, 'Currency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseSolovisCurrency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 46, 'etl', 'Database', 'SolovisCurrency', 'sqlserver', NULL, NULL, NULL, 'SolovisCurrency', 'lh_bronze', NULL, NULL, 'SolovisCurrency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseExternalActiveBook', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 48, 'etl', 'Database', 'vwSolovisLoadHelper_ActiveBookXref', 'sqlserver', NULL, NULL, NULL, 'vwSolovisLoadHelper_ActiveBookXref', 'lh_bronze', NULL, NULL, 'ExternalActiveBook', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseSolovisTransactionMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 61, 'etl', 'Database', 'SolovisTransactionMap', 'sqlserver', NULL, NULL, NULL, 'SolovisTransactionMap', 'lh_bronze', NULL, NULL, 'SolovisTransactionMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'vwUniverseFunds', 'Dev - Crimson', NULL, 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'rawtest', 'overwrite', 'Database', 1, NULL, 53, 'dbo', 'Database', 'vwUniverseFunds', 'sqlserver', NULL, NULL, NULL, 'vwUniverseFunds', 'lh_bronze', NULL, NULL, 'vwUniverseFunds', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXUniverse', 'Dev - Crimson', NULL, 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'rawtest', 'overwrite', 'Database', 1, NULL, 52, 'dbo', 'Database', 'Universe', 'sqlserver', NULL, NULL, NULL, 'Universe', 'lh_bronze', NULL, NULL, 'Universe', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehousevwSourceReferenceFlatten_CrimsonX', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 51, 'dbo', 'Database', 'vwSourceReferenceFlatten_CrimsonX', 'sqlserver', NULL, NULL, NULL, 'vwSourceReferenceFlatten_CrimsonX', 'lh_bronze', NULL, NULL, 'HMCDataWarehousevwSourceReferenceFlatten_CrimsonX', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 11, 'dbo', 'Database', 'Fund', 'sqlserver', NULL, NULL, NULL, 'Fund', 'lh_bronze', NULL, NULL, 'Fund', NULL, 'FundId', 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundReturnSource', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 218, 'dbo', 'Database', 'FundReturnSource', 'sqlserver', NULL, NULL, NULL, 'FundReturnSource', 'lh_bronze', NULL, NULL, 'FundReturnSource', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundReturnType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 217, 'dbo', 'Database', 'FundReturnType', 'sqlserver', NULL, NULL, NULL, 'FundReturnType', 'lh_bronze', NULL, NULL, 'FundReturnType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXAlphaStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 212, 'dbo', 'Database', 'AlphaStrategy', 'sqlserver', NULL, NULL, NULL, 'AlphaStrategy', 'lh_bronze', NULL, NULL, 'AlphaStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXLiquidityCost', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 213, 'dbo', 'Database', 'LiquidityCost', 'sqlserver', NULL, NULL, NULL, 'LiquidityCost', 'lh_bronze', NULL, NULL, 'LiquidityCost', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXWeightedDaysType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 214, 'dbo', 'Database', 'WeightedDaysType', 'sqlserver', NULL, NULL, NULL, 'WeightedDaysType', 'lh_bronze', NULL, NULL, 'WeightedDaysType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundRiskIndexAssociation', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 140, 'dbo', 'Database', 'FundRiskIndexAssociation', 'sqlserver', NULL, NULL, NULL, 'FundRiskIndexAssociation', 'lh_bronze', NULL, NULL, 'FundRiskIndexAssociation', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundRiskStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 144, 'dbo', 'Database', 'FundRiskStatus', 'sqlserver', NULL, NULL, NULL, 'FundRiskStatus', 'lh_bronze', NULL, NULL, 'FundRiskStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXBudgetStrategyClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 210, 'dbo', 'Database', 'BudgetStrategyClassificationMap', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategyClassificationMap', 'lh_bronze', NULL, NULL, 'BudgetStrategyClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXBudgetStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 211, 'dbo', 'Database', 'BudgetStrategy', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategy', 'lh_bronze', NULL, NULL, 'BudgetStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLiquidityCost', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 145, 'dbo', 'Database', 'LiquidityCost', 'sqlserver', NULL, NULL, NULL, 'LiquidityCost', 'lh_bronze', NULL, NULL, 'LiquidityCost', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDBackgroundCheck', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 146, 'dbo', 'Database', 'ODDBackgroundCheck', 'sqlserver', NULL, NULL, NULL, 'ODDBackgroundCheck', 'lh_bronze', NULL, NULL, 'ODDBackgroundCheck', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDBackgroundCheckSubject', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 147, 'dbo', 'Database', 'ODDBackgroundCheckSubject', 'sqlserver', NULL, NULL, NULL, 'ODDBackgroundCheckSubject', 'lh_bronze', NULL, NULL, 'ODDBackgroundCheckSubject', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDCounterPartyType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 148, 'dbo', 'Database', 'ODDCounterPartyType', 'sqlserver', NULL, NULL, NULL, 'ODDCounterPartyType', 'lh_bronze', NULL, NULL, 'ODDCounterPartyType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDCustomFrequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 149, 'dbo', 'Database', 'ODDCustomFrequency', 'sqlserver', NULL, NULL, NULL, 'ODDCustomFrequency', 'lh_bronze', NULL, NULL, 'ODDCustomFrequency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDDocumentRequestType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 150, 'dbo', 'Database', 'ODDDocumentRequestType', 'sqlserver', NULL, NULL, NULL, 'ODDDocumentRequestType', 'lh_bronze', NULL, NULL, 'ODDDocumentRequestType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 151, 'dbo', 'Database', 'ODDEntity', 'sqlserver', NULL, NULL, NULL, 'ODDEntity', 'lh_bronze', NULL, NULL, 'ODDEntity', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 152, 'dbo', 'Database', 'ODDFirm', 'sqlserver', NULL, NULL, NULL, 'ODDFirm', 'lh_bronze', NULL, NULL, 'ODDFirm', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmAdvisor', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 153, 'dbo', 'Database', 'ODDFirmAdvisor', 'sqlserver', NULL, NULL, NULL, 'ODDFirmAdvisor', 'lh_bronze', NULL, NULL, 'ODDFirmAdvisor', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmCrdNumber', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 154, 'dbo', 'Database', 'ODDFirmCrdNumber', 'sqlserver', NULL, NULL, NULL, 'ODDFirmCrdNumber', 'lh_bronze', NULL, NULL, 'ODDFirmCrdNumber', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmStaticDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 155, 'dbo', 'Database', 'ODDFirmStaticDetail', 'sqlserver', NULL, NULL, NULL, 'ODDFirmStaticDetail', 'lh_bronze', NULL, NULL, 'ODDFirmStaticDetail', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmSummary', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 156, 'dbo', 'Database', 'ODDFirmSummary', 'sqlserver', NULL, NULL, NULL, 'ODDFirmSummary', 'lh_bronze', NULL, NULL, 'ODDFirmSummary', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFlag', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 157, 'dbo', 'Database', 'ODDFlag', 'sqlserver', NULL, NULL, NULL, 'ODDFlag', 'lh_bronze', NULL, NULL, 'ODDFlag', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFlagBucket', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 158, 'dbo', 'Database', 'ODDFlagBucket', 'sqlserver', NULL, NULL, NULL, 'ODDFlagBucket', 'lh_bronze', NULL, NULL, 'ODDFlagBucket', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFlagColor', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 159, 'dbo', 'Database', 'ODDFlagColor', 'sqlserver', NULL, NULL, NULL, 'ODDFlagColor', 'lh_bronze', NULL, NULL, 'ODDFlagColor', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 160, 'dbo', 'Database', 'ODDFund', 'sqlserver', NULL, NULL, NULL, 'ODDFund', 'lh_bronze', NULL, NULL, 'ODDFund', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeeting', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 161, 'dbo', 'Database', 'ODDMeeting', 'sqlserver', NULL, NULL, NULL, 'ODDMeeting', 'lh_bronze', NULL, NULL, 'ODDMeeting', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingAdministrator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 162, 'dbo', 'Database', 'ODDMeetingAdministrator', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingAdministrator', 'lh_bronze', NULL, NULL, 'ODDMeetingAdministrator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingAuditor', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 163, 'dbo', 'Database', 'ODDMeetingAuditor', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingAuditor', 'lh_bronze', NULL, NULL, 'ODDMeetingAuditor', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingBackgroundCheckProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 164, 'dbo', 'Database', 'ODDMeetingBackgroundCheckProvider', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingBackgroundCheckProvider', 'lh_bronze', NULL, NULL, 'ODDMeetingBackgroundCheckProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingBank', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 165, 'dbo', 'Database', 'ODDMeetingBank', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingBank', 'lh_bronze', NULL, NULL, 'ODDMeetingBank', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingComplianceConsultant', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 166, 'dbo', 'Database', 'ODDMeetingComplianceConsultant', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingComplianceConsultant', 'lh_bronze', NULL, NULL, 'ODDMeetingComplianceConsultant', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingCounterparty', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 167, 'dbo', 'Database', 'ODDMeetingCounterparty', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingCounterparty', 'lh_bronze', NULL, NULL, 'ODDMeetingCounterparty', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingCustodian', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 168, 'dbo', 'Database', 'ODDMeetingCustodian', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingCustodian', 'lh_bronze', NULL, NULL, 'ODDMeetingCustodian', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingDocumentRequestType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 169, 'dbo', 'Database', 'ODDMeetingDocumentRequestType', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingDocumentRequestType', 'lh_bronze', NULL, NULL, 'ODDMeetingDocumentRequestType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 170, 'dbo', 'Database', 'ODDMeetingEntity', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingEntity', 'lh_bronze', NULL, NULL, 'ODDMeetingEntity', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 171, 'dbo', 'Database', 'ODDMeetingFirm', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingFirm', 'lh_bronze', NULL, NULL, 'ODDMeetingFirm', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingFrequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 172, 'dbo', 'Database', 'ODDMeetingFrequency', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingFrequency', 'lh_bronze', NULL, NULL, 'ODDMeetingFrequency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 173, 'dbo', 'Database', 'ODDMeetingFund', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingFund', 'lh_bronze', NULL, NULL, 'ODDMeetingFund', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingISDA', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 174, 'dbo', 'Database', 'ODDMeetingISDA', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingISDA', 'lh_bronze', NULL, NULL, 'ODDMeetingISDA', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingITProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 175, 'dbo', 'Database', 'ODDMeetingITProvider', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingITProvider', 'lh_bronze', NULL, NULL, 'ODDMeetingITProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingLegalCounsel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 176, 'dbo', 'Database', 'ODDMeetingLegalCounsel', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingLegalCounsel', 'lh_bronze', NULL, NULL, 'ODDMeetingLegalCounsel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingMethod', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 177, 'dbo', 'Database', 'ODDMeetingMethod', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingMethod', 'lh_bronze', NULL, NULL, 'ODDMeetingMethod', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingParticipant', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 178, 'dbo', 'Database', 'ODDMeetingParticipant', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingParticipant', 'lh_bronze', NULL, NULL, 'ODDMeetingParticipant', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingParticipantInternal', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 179, 'dbo', 'Database', 'ODDMeetingParticipantInternal', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingParticipantInternal', 'lh_bronze', NULL, NULL, 'ODDMeetingParticipantInternal', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingPrimaryContact', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 180, 'dbo', 'Database', 'ODDMeetingPrimaryContact', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingPrimaryContact', 'lh_bronze', NULL, NULL, 'ODDMeetingPrimaryContact', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingPrimaryRegulator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 181, 'dbo', 'Database', 'ODDMeetingPrimaryRegulator', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingPrimaryRegulator', 'lh_bronze', NULL, NULL, 'ODDMeetingPrimaryRegulator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingPrimeBroker', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 182, 'dbo', 'Database', 'ODDMeetingPrimeBroker', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingPrimeBroker', 'lh_bronze', NULL, NULL, 'ODDMeetingPrimeBroker', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 183, 'dbo', 'Database', 'ODDMeetingType', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingType', 'lh_bronze', NULL, NULL, 'ODDMeetingType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDNote', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 184, 'dbo', 'Database', 'ODDNote', 'sqlserver', NULL, NULL, NULL, 'ODDNote', 'lh_bronze', NULL, NULL, 'ODDNote', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDPrioritization', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 185, 'dbo', 'Database', 'ODDPrioritization', 'sqlserver', NULL, NULL, NULL, 'ODDPrioritization', 'lh_bronze', NULL, NULL, 'ODDPrioritization', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDRating', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 186, 'dbo', 'Database', 'ODDRating', 'sqlserver', NULL, NULL, NULL, 'ODDRating', 'lh_bronze', NULL, NULL, 'ODDRating', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDRatingCategory', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 187, 'dbo', 'Database', 'ODDRatingCategory', 'sqlserver', NULL, NULL, NULL, 'ODDRatingCategory', 'lh_bronze', NULL, NULL, 'ODDRatingCategory', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXOddTrip', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 188, 'dbo', 'Database', 'OddTrip', 'sqlserver', NULL, NULL, NULL, 'OddTrip', 'lh_bronze', NULL, NULL, 'OddTrip', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXOddTripMeeting', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 189, 'dbo', 'Database', 'OddTripMeeting', 'sqlserver', NULL, NULL, NULL, 'OddTripMeeting', 'lh_bronze', NULL, NULL, 'OddTripMeeting', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXOddTripMeetingAttendee', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 190, 'dbo', 'Database', 'OddTripMeetingAttendee', 'sqlserver', NULL, NULL, NULL, 'OddTripMeetingAttendee', 'lh_bronze', NULL, NULL, 'OddTripMeetingAttendee', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXISDA', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 191, 'dbo', 'Database', 'ISDA', 'sqlserver', NULL, NULL, NULL, 'ISDA', 'lh_bronze', NULL, NULL, 'ISDA', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXITProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 192, 'dbo', 'Database', 'ITProvider', 'sqlserver', NULL, NULL, NULL, 'ITProvider', 'lh_bronze', NULL, NULL, 'ITProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrimaryRegulator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 193, 'dbo', 'Database', 'PrimaryRegulator', 'sqlserver', NULL, NULL, NULL, 'PrimaryRegulator', 'lh_bronze', NULL, NULL, 'PrimaryRegulator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrimeBroker', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 194, 'dbo', 'Database', 'PrimeBroker', 'sqlserver', NULL, NULL, NULL, 'PrimeBroker', 'lh_bronze', NULL, NULL, 'PrimeBroker', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLegalCounsel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 195, 'dbo', 'Database', 'LegalCounsel', 'sqlserver', NULL, NULL, NULL, 'LegalCounsel', 'lh_bronze', NULL, NULL, 'LegalCounsel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCustodian', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 196, 'dbo', 'Database', 'Custodian', 'sqlserver', NULL, NULL, NULL, 'Custodian', 'lh_bronze', NULL, NULL, 'Custodian', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXAdministrator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 197, 'dbo', 'Database', 'Administrator', 'sqlserver', NULL, NULL, NULL, 'Administrator', 'lh_bronze', NULL, NULL, 'Administrator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXComplianceConsultant', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 198, 'dbo', 'Database', 'ComplianceConsultant', 'sqlserver', NULL, NULL, NULL, 'ComplianceConsultant', 'lh_bronze', NULL, NULL, 'ComplianceConsultant', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBank', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 199, 'dbo', 'Database', 'Bank', 'sqlserver', NULL, NULL, NULL, 'Bank', 'lh_bronze', NULL, NULL, 'Bank', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBackgroundCheckProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 200, 'dbo', 'Database', 'BackgroundCheckProvider', 'sqlserver', NULL, NULL, NULL, 'BackgroundCheckProvider', 'lh_bronze', NULL, NULL, 'BackgroundCheckProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundrisk', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 139, 'dbo', 'Database', 'Fundrisk', 'sqlserver', NULL, NULL, NULL, 'Fundrisk', 'lh_bronze', NULL, NULL, 'Fundrisk', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskIndexAssociationRequest', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 141, 'dbo', 'Database', 'FundRiskIndexAssociationRequest', 'sqlserver', NULL, NULL, NULL, 'FundRiskIndexAssociationRequest', 'lh_bronze', NULL, NULL, 'FundRiskIndexAssociationRequest', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskRequest', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 142, 'dbo', 'Database', 'FundRiskRequest', 'sqlserver', NULL, NULL, NULL, 'FundRiskRequest', 'lh_bronze', NULL, NULL, 'FundRiskRequest', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskRequestLog', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 143, 'dbo', 'Database', 'FundRiskRequestLog', 'sqlserver', NULL, NULL, NULL, 'FundRiskRequestLog', 'lh_bronze', NULL, NULL, 'FundRiskRequestLog', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTagType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 138, 'dbo', 'Database', 'TagType', 'sqlserver', NULL, NULL, NULL, 'TagType', 'lh_bronze', NULL, NULL, 'TagType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTagOwner', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 137, 'dbo', 'Database', 'TagOwner', 'sqlserver', NULL, NULL, NULL, 'TagOwner', 'lh_bronze', NULL, NULL, 'TagOwner', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTagMaster', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 136, 'dbo', 'Database', 'TagMaster', 'sqlserver', NULL, NULL, NULL, 'TagMaster', 'lh_bronze', NULL, NULL, 'TagMaster', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTag', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 135, 'dbo', 'Database', 'Tag', 'sqlserver', NULL, NULL, NULL, 'Tag', 'lh_bronze', NULL, NULL, 'Tag', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXUniversityTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 134, 'dbo', 'Database', 'UniversityTransaction', 'sqlserver', NULL, NULL, NULL, 'UniversityTransaction', 'lh_bronze', NULL, NULL, 'UniversityTransaction', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrivateFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 98, 'dbo', 'Database', 'FeesForPrivateModel', 'sqlserver', NULL, NULL, NULL, 'PrivateFees', 'lh_bronze', NULL, NULL, 'PrivateFees', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrivateFeeTiers', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 99, 'dbo', 'Database', 'FeesForPrivateModelTier', 'sqlserver', NULL, NULL, NULL, 'PrivateFeeTiers', 'lh_bronze', NULL, NULL, 'PrivateFeeTiers', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeePaymentFrequencyType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 101, 'dbo', 'Database', 'FeePaymentFrequencyType', 'sqlserver', NULL, NULL, NULL, 'FeePaymentFrequencyType', 'lh_bronze', NULL, NULL, 'FeePaymentFrequencyType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeBasisType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 102, 'dbo', 'Database', 'FeeBasisType', 'sqlserver', NULL, NULL, NULL, 'FeeBasisType', 'lh_bronze', NULL, NULL, 'FeeBasisType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeHurdleType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 104, 'dbo', 'Database', 'FeeHurdleType', 'sqlserver', NULL, NULL, NULL, 'FeeHurdleType', 'lh_bronze', NULL, NULL, 'FeeHurdleType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXShareClass', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 47, 'dbo', 'Database', 'ShareClass', 'sqlserver', NULL, NULL, NULL, 'ShareClass', 'lh_bronze', NULL, NULL, 'ShareClass', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPipelineStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 42, 'dbo', 'Database', 'PipelineStatus', 'sqlserver', NULL, NULL, NULL, 'PipelineStatus', 'lh_bronze', NULL, NULL, 'PipelineStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeTierBasisType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 41, 'dbo', 'Database', 'FeeTierBasisType', 'sqlserver', NULL, NULL, NULL, 'FeeTierBasisType', 'lh_bronze', NULL, NULL, 'FeeTierBasisType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeCarryMethodType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 40, 'dbo', 'Database', 'FeeCarryMethodType', 'sqlserver', NULL, NULL, NULL, 'FeeCarryMethodType', 'lh_bronze', NULL, NULL, 'FeeCarryMethodType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLiquidityTermSchedule', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 39, 'dbo', 'Database', 'LiquidityTermSchedule', 'sqlserver', NULL, NULL, NULL, 'LiquidityTermSchedule', 'lh_bronze', NULL, NULL, 'LiquidityTermSchedule', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeesForPrivateModelTier', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 38, 'dbo', 'Database', 'FeesForPrivateModelTier', 'sqlserver', NULL, NULL, NULL, 'FeesForPrivateModelTier', 'lh_bronze', NULL, NULL, 'FeesForPrivateModelTier', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeesForPrivateModel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 37, 'dbo', 'Database', 'FeesForPrivateModel', 'sqlserver', NULL, NULL, NULL, 'FeesForPrivateModel', 'lh_bronze', NULL, NULL, 'FeesForPrivateModel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBetaCategory', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 36, 'dbo', 'Database', 'BetaCategory', 'sqlserver', NULL, NULL, NULL, 'BetaCategory', 'lh_bronze', NULL, NULL, 'BetaCategory', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskIndexAssociation', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 35, 'dbo', 'Database', 'FundRiskIndexAssociation', 'sqlserver', NULL, NULL, NULL, 'FundRiskIndexAssociation', 'lh_bronze', NULL, NULL, 'FundRiskIndexAssociation', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntityStatistics', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 33, 'dbo', 'Database', 'EntityStatistics', 'sqlserver', NULL, NULL, NULL, 'EntityStatistics', 'lh_bronze', NULL, NULL, 'EntityStatistics', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXAlphaStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 32, 'dbo', 'Database', 'AlphaStrategy', 'sqlserver', NULL, NULL, NULL, 'AlphaStrategy', 'lh_bronze', NULL, NULL, 'AlphaStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRisk', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 31, 'dbo', 'Database', 'FundRisk', 'sqlserver', NULL, NULL, NULL, 'FundRisk', 'lh_bronze', NULL, NULL, 'FundRisk', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXSectorIndustry', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 25, 'dbo', 'Database', 'SectorIndustry', 'sqlserver', NULL, NULL, NULL, 'SectorIndustry', 'lh_bronze', NULL, NULL, 'SectorIndustry', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXSector', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 24, 'dbo', 'Database', 'Sector', 'sqlserver', NULL, NULL, NULL, 'Sector', 'lh_bronze', NULL, NULL, 'Sector', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXSectorIndustryClassification', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 23, 'dbo', 'Database', 'SectorIndustryClassification', 'sqlserver', NULL, NULL, NULL, 'SectorIndustryClassification', 'lh_bronze', NULL, NULL, 'SectorIndustryClassification', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXGeographicStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 22, 'dbo', 'Database', 'GeographicStrategy', 'sqlserver', NULL, NULL, NULL, 'GeographicStrategy', 'lh_bronze', NULL, NULL, 'GeographicStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCountry', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 20, 'dbo', 'Database', 'Country', 'sqlserver', NULL, NULL, NULL, 'Country', 'lh_bronze', NULL, NULL, 'Country', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCountryRegion', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 21, 'dbo', 'Database', 'CountryRegion', 'sqlserver', NULL, NULL, NULL, 'CountryRegion', 'lh_bronze', NULL, NULL, 'CountryRegion', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexRegionExposure', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 19, 'dbo', 'Database', 'IndexRegionExposure', 'sqlserver', NULL, NULL, NULL, 'IndexRegionExposure', 'lh_bronze', NULL, NULL, 'IndexRegionExposure', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndex', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 17, 'dbo', 'Database', 'Index', 'sqlserver', NULL, NULL, NULL, 'Index', 'lh_bronze', NULL, NULL, 'Index', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFrequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 18, 'dbo', 'Database', 'Frequency', 'sqlserver', NULL, NULL, NULL, 'Frequency', 'lh_bronze', NULL, NULL, 'Frequency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 13, 'dbo', 'Database', 'Firm', 'sqlserver', NULL, NULL, NULL, 'Firm', 'lh_bronze', NULL, NULL, 'Firm', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 12, 'dbo', 'Database', 'Entity', 'sqlserver', NULL, NULL, NULL, 'Entity', 'lh_bronze', NULL, NULL, 'Entity', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 9, 'dbo', 'Database', 'FundTradeType', 'sqlserver', NULL, NULL, NULL, 'FundTradeType', 'lh_bronze', NULL, NULL, 'FundTradeType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 8, 'dbo', 'Database', 'FundTradeStatus', 'sqlserver', NULL, NULL, NULL, 'FundTradeStatus', 'lh_bronze', NULL, NULL, 'FundTradeStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeForecastedTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 7, 'dbo', 'Database', 'FundTradeForecastedTransaction', 'sqlserver', NULL, NULL, NULL, 'FundTradeForecastedTransaction', 'lh_bronze', NULL, NULL, 'FundTradeForecastedTransaction', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeApproval', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 6, 'dbo', 'Database', 'FundTradeApproval', 'sqlserver', NULL, NULL, NULL, 'FundTradeApproval', 'lh_bronze', NULL, NULL, 'FundTradeApproval', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTrade', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 5, 'dbo', 'Database', 'FundTrade', 'sqlserver', NULL, NULL, NULL, 'FundTrade', 'lh_bronze', NULL, NULL, 'FundTrade', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 15, 'dbo', 'Database', 'ClassificationMap', 'sqlserver', NULL, NULL, NULL, 'ClassificationMap', 'lh_bronze', NULL, NULL, 'ClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 74, 'dbo', 'Database', 'FundRiskStatus', 'sqlserver', NULL, NULL, NULL, 'FundRiskStatus', 'lh_bronze', NULL, NULL, 'FundRiskStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntityRating', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 72, 'dbo', 'Database', 'EntityRating', 'sqlserver', NULL, NULL, NULL, 'EntityRating', 'lh_bronze', NULL, NULL, 'EntityRating', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundStructure', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 71, 'dbo', 'Database', 'FundStructure', 'sqlserver', NULL, NULL, NULL, 'FundStructure', 'lh_bronze', NULL, NULL, 'FundStructure', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXHoldings', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 58, 'dbo', 'Database', 'Holdings', 'sqlserver', NULL, NULL, NULL, 'Holdings', 'lh_bronze', NULL, NULL, 'Holdings', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXReturnType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 56, 'dbo', 'Database', 'ReturnType', 'sqlserver', NULL, NULL, NULL, 'ReturnType', 'lh_bronze', NULL, NULL, 'ReturnType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionSubtype', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 67, 'dbo', 'Database', 'CashflowTransactionSubtype', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionSubtype', 'lh_bronze', NULL, NULL, 'CashflowTransactionSubtype', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXReturnSource', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 55, 'dbo', 'Database', 'ReturnSource', 'sqlserver', NULL, NULL, NULL, 'ReturnSource', 'lh_bronze', NULL, NULL, 'ReturnSource', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 66, 'dbo', 'Database', 'CashflowTransactionType', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionType', 'lh_bronze', NULL, NULL, 'CashflowTransactionType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, 'ReturnDate <> ''0001-01-01''', 1, 'Dev - Crimson', 'CrimsonXFundReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 54, 'dbo', 'Database', 'FundReturn', 'sqlserver', NULL, NULL, NULL, 'FundReturn', 'lh_bronze', NULL, NULL, 'FundReturn', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTimePeriod', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 122, 'dbo', 'Database', 'TimePeriod', 'sqlserver', NULL, NULL, NULL, 'TimePeriod', 'lh_bronze', NULL, NULL, 'TimePeriod', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundStatistics', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 120, 'dbo', 'Database', 'FundStatistics', 'sqlserver', NULL, NULL, NULL, 'FundStatistics', 'lh_bronze', NULL, NULL, 'FundStatistics', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 70, 'dbo', 'Database', 'CashflowTransactionDetail', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionDetail', 'lh_bronze', NULL, NULL, 'CashflowTransactionDetail', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXForecastedCashFlow', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 108, 'dbo', 'Database', 'ForecastedCashFlow', 'sqlserver', NULL, NULL, NULL, 'ForecastedCashFlow', 'lh_bronze', NULL, NULL, 'ForecastedCashFlow', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXForecastedCashFlowType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 107, 'dbo', 'Database', 'ForecastedCashFlowType', 'sqlserver', NULL, NULL, NULL, 'ForecastedCashFlowType', 'lh_bronze', NULL, NULL, 'ForecastedCashFlowType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeApprovalType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 106, 'dbo', 'Database', 'FundTradeApprovalType', 'sqlserver', NULL, NULL, NULL, 'FundTradeApprovalType', 'lh_bronze', NULL, NULL, 'FundTradeApprovalType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXHMCUser', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 93, 'dbo', 'Database', 'HMCUser', 'sqlserver', NULL, NULL, NULL, 'HMCUser', 'lh_bronze', NULL, NULL, 'HMCUser', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBudgetStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 80, 'dbo', 'Database', 'BudgetStrategy', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategy', 'lh_bronze', NULL, NULL, 'BudgetStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashFlowTransactionType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 79, 'dbo', 'Database', 'CashFlowTransactionType', 'sqlserver', NULL, NULL, NULL, 'CashFlowTransactionType', 'lh_bronze', NULL, NULL, 'CashFlowTransactionType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFirmAttribute', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 78, 'dbo', 'Database', 'FirmAttribute', 'sqlserver', NULL, NULL, NULL, 'FirmAttribute', 'lh_bronze', NULL, NULL, 'FirmAttribute', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXvwClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 223, 'dbo', 'Database', 'vwClassificationMap', 'sqlserver', NULL, NULL, NULL, 'vwClassificationMap to Bronze', 'lh_bronze', NULL, NULL, 'vwClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBudgetStrategyClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 222, 'dbo', 'Database', 'BudgetStrategyClassificationMap', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategyClassificationMap to Bronze', 'lh_bronze', NULL, NULL, 'BudgetStrategyClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundValuation', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 216, 'dbo', 'Database', 'FundValuation', 'sqlserver', NULL, NULL, NULL, 'FundValuation', 'lh_bronze', NULL, NULL, 'FundValuation', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBudgetStrategyClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 204, 'dbo', 'Database', 'BudgetStrategyClassificationMap', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategyClassificationMap', 'lh_bronze', NULL, NULL, 'BudgetStrategyClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXWeightedDaysType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 205, 'dbo', 'Database', 'WeightedDaysType', 'sqlserver', NULL, NULL, NULL, 'WeightedDaysType', 'lh_bronze', NULL, NULL, 'WeightedDaysType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, 'MERGE INTO Silver.CashflowTransactionDetail AS target
USING (
    SELECT 
        FundId,
        CAST(ExposureDate AS DATE) AS CommitmentDate,   -- stored as DATE
        CAST(CommitmentEffectLocal AS DECIMAL(15,2)) AS CommitmentAmount, -- trillions with 2 decimals
        CAST(CashflowTransactionTypeId AS INT) AS CashflowTransactionTypeId,
        FIRST_VALUE(CAST(CommitmentEffectLocal AS DECIMAL(15,2))) 
            OVER (PARTITION BY FundId ORDER BY ExposureDate ASC) AS FirstCommitmentAmount
    FROM Silver.CashflowTransactionDetail
    WHERE CashflowTransactionTypeId IN (5, 13)
) AS source
ON target.FundId = source.FundId
   AND target.ExposureDate = source.CommitmentDate
   AND target.CashflowTransactionTypeId = source.CashflowTransactionTypeId

WHEN MATCHED THEN
    UPDATE SET 
        target.CommitmentAmount = source.CommitmentAmount,
        target.FirstCommitmentAmount = source.FirstCommitmentAmount

WHEN NOT MATCHED THEN
    INSERT (FundId, CommitmentDate, CommitmentAmount, CashflowTransactionTypeId, FirstCommitmentAmount)
    VALUES (source.FundId, source.CommitmentDate, source.CommitmentAmount, source.CashflowTransactionTypeId, source.FirstCommitmentAmount);', NULL, NULL, 1, 'Dev - Crimson', 'CashflowTransactionDetail', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 11, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 1, NULL, 109, NULL, 'Solovis', NULL, 'Lakehouse', NULL, NULL, NULL, 'Solovis Transactions Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, 'SELECT
    CAST(IndexId AS VARCHAR(36)) AS IndexId,
    IndexName,
    DisplayName,
    Description,
    CurrencyId,
    IsRiskIndex,
    BetaCategoryId,
    IsShortIndex,
    IsCustomIndex,
    Ticker,
    Frequency,
    FinancialDataProviderId,
    IsLevelBased,
    ExchangeProviderId,
    IndexReturnTypeId,
    IsTotalReturn,
    IsActive,
    CAST(ETLLoadDateTime AS TIMESTAMP) AS ETLLoadDateTime
FROM Bronze.CrimsonXIndex
WHERE IndexId IS NOT NULL
  AND IndexName IS NOT NULL
  AND CurrencyId IS NOT NULL
  AND IsRiskIndex IS NOT NULL
  AND IsShortIndex IS NOT NULL
  AND IndexReturnTypeId IS NOT NULL
  AND IsTotalReturn IS NOT NULL
  AND ETLLoadDateTime IS NOT NULL;
', NULL, NULL, 1, 'Dev - Crimson', 'Index', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 27, 'Bronze', 'Database', 'CrimsonXIndex', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonIndex', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'IndexReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 95, 'Bronze', 'Database', 'IndexReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'WarehouseIndexReturn', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'IndexReturn_readonly', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 110, 'Bronze', 'Database', 'IndexReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'WarehouseIndexRet_RO', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'IndexReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 77, 'etl', 'Database', 'vwIndexReturnCrimsonXGUID', 'sqlserver', NULL, NULL, NULL, 'WarehouseIndexReturn', 'lh_bronze', NULL, NULL, 'IndexReturnRaw', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexCustomBlendRecipe', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 236, 'etl', 'Database', 'vwIndexBlendRecipeCrimsonXGUID', 'sqlserver', NULL, NULL, NULL, 'IndexCustomBlendRecipe', 'lh_bronze', NULL, NULL, 'IndexCustomBlendRecipe', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'IndexCustomBlendRecipe', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 237, 'Bronze', 'Database', 'CrimsonXIndexCustomBlendRecipe', 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexCustomBlendRecipe', 'lh_silver', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundHorizonReturn', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 27, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 2, NULL, 239, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Calculate fund net/gross returns', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundPerformance', 'Dev - Crimson', 'ETLLoadDateTime', 'Gold', 'ETLLoadDateTime', NULL, NULL, 45, NULL, 1, 'NotebookTask', NULL, NULL, 'overwrite', 'Silver', 1, NULL, 262, 'Silver', 'Database', 'Fund', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundPerformanceToGold', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 32, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Factset', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'merge', 'Bronze', 1, NULL, 3, 'Bronze', 'Facset', 'Factset', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset to Silver', 'lh_curated', NULL, NULL, NULL, NULL, 'SECURITY_ID, DATE', 1, 36, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundBenchmarkTrackRecord', 'Dev - Crimson', 'ETLLoadDateTime', 'Gold', NULL, NULL, NULL, 43, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 261, 'Bronze', 'Database', 'CrimsonXFundStatistics', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundBenchmarkTrackRecordGold', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 32, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundPaidAmount', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 260, 'dbo', 'Database', 'FundPaidAmount', 'sqlserver', NULL, NULL, NULL, 'FundPaidAmount', 'lh_bronze', NULL, NULL, 'FundPaidAmount', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CalculationMethodology', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 259, 'Bronze', 'Bronze', 'CrimsonXCalculationMethodology', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CalculationMethodology', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 35, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCalculationMethodology', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 258, 'dbo', 'Database', 'CalculationMethodology', 'sqlserver', NULL, NULL, NULL, 'CalculationMethodology', 'lh_bronze', NULL, NULL, 'CalculationMethodology', NULL, NULL, 0, 34, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'DrawdownFundAnalytic', 'Dev - Crimson', 'ETLLoadDateTime', 'Gold', 'ETLLoadDateTime', NULL, NULL, 42, NULL, 1, 'NotebookTask', NULL, NULL, 'overwrite', 'Silver', 1, NULL, 257, 'Silver', 'Database', 'Fund', 'Lakehouse', NULL, NULL, 'lh_curated', 'DrawdownFundAnalytic To Gold', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 32, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Classification', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 23, NULL, 1, 'NotebookTask', 'CrimsonX', NULL, 'overwrite', 'Database', 1, NULL, 224, NULL, 'Database', 'Classification', 'sqlserver', NULL, NULL, NULL, 'Classification Table to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CustomRiskBenchmark', 'Dev - Crimson', 'ETLLoadDateTime', 'Gold', 'ETLLoadDateTime', NULL, NULL, 44, NULL, 1, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 226, 'Bronze', 'Database', 'CrimsonXFundStatistics', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CustomRiskBenchmark to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 32, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundProjectedAnalytics', 'Dev - Crimson', 'ETLLoadDateTime', 'Gold', NULL, NULL, NULL, 41, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 256, 'Bronze', 'Database', 'CrimsonXFundStatistics', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundProjectedAnalyticsGold', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 32, NULL
UNION ALL
SELECT NULL, 'SELECT
    EIN,
    AsOfYear,
    COALESCE(FederalTaxIncome, 0) AS FederalTaxIncome,
    COALESCE(FederalUBI, 0) AS FederalUBI,
    COALESCE(UBTITax, 0) AS UBTITax,
    COALESCE(NIITax, 0) AS NIITax
FROM Bronze.TaxData
WHERE EIN IS NOT NULL
  AND AsOfYear IS NOT NULL

', NULL, NULL, 1, 'Dev - Crimson', 'FundTaxIncome', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 255, 'Bronze', 'Database', 'TaxData', 'Lakehouse', NULL, NULL, 'lh_bronze', 'TaxData FunTaxIncome to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, 'SELECT DISTINCT
    FundId,
    EIN
FROM Bronze.TaxData WHERE FundId IS NOT NULL
  AND EIN IS NOT NULL', NULL, NULL, 1, 'Dev - Crimson', 'FundTaxEIN', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 254, 'Bronze', 'Database', 'TaxData', 'Lakehouse', NULL, NULL, 'lh_bronze', 'TaxData EIN to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'SELECT CAST(FirmId AS VARCHAR(36)) AS FirmId, FirmName FROM Bronze.CrimsonXFirm', NULL, NULL, 1, 'Dev - Crimson', 'Firm', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 220, 'Bronze', 'Database', 'CrimsonXFirm', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Firm to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'SELECT     CAST(EntityId AS VARCHAR(36)) AS EntityId,     CAST(FirmId AS VARCHAR(36)) AS FirmId,     EntityName AS EntityName,     EntityInvestmentStatusId AS EntityStatus,     BusinessOwnerHMCUserId AS PrimaryOwner,      BackupBusinessOwnerHMCUserId AS SecondaryOwner,      AssociateHMCUserId AS Associate,     SecondaryBackupBusinessOwnerHMCUserId AS TertiaryOwner, AlphaStrategyID as AlphaStrategyId   FROM Bronze.CrimsonXEntity', NULL, NULL, 1, 'Dev - Crimson', 'Entity', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 221, 'Bronze', 'Database', 'CrimsonXEntity', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Entity to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 36, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 6, NULL, 250, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'UserRiskArea', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 35, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 5, NULL, 249, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'OverallScoreData', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 34, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 4, NULL, 248, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'DeptRiskData', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 33, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 3, NULL, 247, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'UserRiskLevels', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 32, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 2, NULL, 246, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'UserRiskData', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 37, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 245, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'FailureRates', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 31, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 244, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'ManualData', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 30, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 243, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'KnowBe4Data', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 29, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 242, NULL, 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'PhishingTestSummary', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 31, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCHierarchyAttributes', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 233, 'Bronze', 'Database', 'HMCDataMartInvestmentHMCHierarchyAttributes', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataMartInvestmentHMCHierarchyAttributes to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', NULL, 'ETLLoadDateTime', NULL, NULL, 1, NULL, 1, 'NotebookTask', NULL, 'Files/IncomingFeed/CyberSecurityDashboard/KnowBe4', 'overwrite', 'KnowBe4', 1, NULL, 45, NULL, 'API', NULL, 'KnowBe4', NULL, NULL, NULL, 'KnowBe4ApiPhishingTestsCall', 'lh_bronze', NULL, NULL, 'knowbe4_data.parquet', NULL, NULL, 1, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', NULL, NULL, NULL, NULL, NULL, 25, NULL, 1, 'NotebookTask', NULL, 'Files/IncomingFeed/CyberSecurityDashboard/KnowBe4', 'overwrite', 'KnowBe4', 1, NULL, 228, NULL, 'API', NULL, 'KnowBe4', NULL, NULL, NULL, 'KnowBe4ApiUsersCall', 'lh_bronze', NULL, NULL, 'users_output.parquet', NULL, NULL, 0, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundHorizonRiskBenchmark', 'Dev - Crimson', NULL, 'Gold', NULL, NULL, NULL, 38, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 3, NULL, 251, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Calculate fund risk benchmark returns', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPublicFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 34, 'dbo', 'Database', 'FeesForPublicModel', 'sqlserver', NULL, NULL, NULL, 'FeesForPublicModel', 'lh_bronze', NULL, NULL, 'FeesForPublicModel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 28, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Splunk', 1, NULL, 241, NULL, 'API', NULL, 'API', NULL, NULL, 'lh_bronze', 'SplunkDataCall', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 26, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'SpyCloud', 1, NULL, 229, NULL, 'API', NULL, 'API', NULL, NULL, 'lh_bronze', 'SpyCloudDataCall', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 17, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 4, NULL, 125, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturnSilver Frequency', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 24, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 3, NULL, 225, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturn Computed Benchmarks', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 15, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 1, NULL, 123, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturnSilver Gap Fill', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 19, NULL, 0, 'NotebookTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 2, 'hmc-report/api/v1/BottomUp/FundLevelCalc?caseId=3&useBetaSummaryGia=false&asOfDate=7/15/2025&numYears=10&calculationMethodology=1&fundCycleMethodology=0&fundCycleModelId=1', 203, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, 'lh_raw', 'Bottom Up Data to Bronze', 'lh_bronze', NULL, NULL, 'FundLevelCalc.json', NULL, NULL, 0, 23, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 19, NULL, 0, 'NotebookTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 2, 'hmc-report/api/v1/BottomUp/FundLevelCalcMonthly?caseId=3&useBetaSummaryGIA=false&useLTM=false&asOfDate=7/23/2025&reportDate=7/24/2025&calculationMethodology=1&numYears=3&fundCycleMethodology=0&fundCycleModelId=1', 227, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, 'lh_raw', 'Bottom Up Monthly Data to Bronze', 'lh_bronze', NULL, NULL, 'FundLevelCalcMonthly.json', NULL, NULL, 0, 23, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', NULL, NULL, NULL, NULL, 'CrimsonPreAPI', NULL, NULL, 0, 'ApiTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 1, 'hmc-report/api/v1/BottomUp/FundLevelCalcMonthly?caseId=3&useBetaSummaryGIA=false&useLTM=false&asOfDate=7/23/2025&reportDate=7/24/2025&calculationMethodology=1&numYears=3&fundCycleMethodology=0&fundCycleModelId=1', 208, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, NULL, 'FundLevelCalcMonthly to Raw', 'lh_raw', NULL, NULL, 'FundLevelCalcMonthly.json', NULL, NULL, 0, 27, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', NULL, NULL, NULL, NULL, 'CrimsonDevAPI', NULL, NULL, 0, 'ApiTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 1, 'hmc-report/api/v1/BottomUp/FundLevelCalc?caseId=3&useBetaSummaryGia=false&asOfDate=7/15/2025&numYears=10&calculationMethodology=1&fundCycleMethodology=0&fundCycleModelId=1', 207, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, NULL, 'FundLevelCalc to Raw', 'lh_raw', NULL, NULL, 'FundLevelCalc.json', NULL, NULL, 0, 25, NULL
UNION ALL
SELECT NULL, 'SELECT    c.id AS conversationId
,    c.name AS conversationName
,    c.userId AS conversationUserId
,    c.integrationName AS conversationIntegrationName
,    c.createdAt AS conversationCreatedAt
,    c.updatedAt AS conversationUpdatedAt
,    c.tokensRemaining
,    c.tokenCount
,    c._self
,    c._rid
,    c._attachments
,    c._ts
,    m.id AS messageId
,    m.role AS messageRole
,    m.content               AS messageContent
,    m.createdAt             AS messageCreatedAt
,    (IS_DEFINED(m.metadata.messageId)       ? m.metadata.messageId       : null) AS metadata_messageId   
,    (IS_DEFINED(m.metadata.visible)            ? m.metadata.visible            : null) AS metadata_visible
,    (IS_DEFINED(m.metadata.fileName)            ? m.metadata.fileName            : null) AS metadata_fileName
,    (IS_DEFINED(m.metadata.contentType)            ? m.metadata.contentType            : null) AS metadata_contentType
,    (IS_DEFINED(m.metadata.length)            ? m.metadata.length           : null) AS metadata_length
,    (IS_DEFINED(m.metadata.contentDisposition)            ? m.metadata.contentDisposition            : null) AS metadata_contentDisposition
,    (IS_DEFINED(m.metadata.name)            ? m.metadata.name            : null) AS metadata_name
,    (IS_DEFINED(m.metadata.isImage)            ? m.metadata.isImage            : null) AS metadata_isImage
,    (IS_DEFINED(m.metadata.fingerprint)            ? m.metadata.fingerprint            : null) AS metadata_fingerprint
,    (IS_DEFINED(m.metadata.numberOfImages)            ? m.metadata.numberOfImages            : null) AS metadata_numberOfImages
,    (IS_DEFINED(m.metadata.pageCount)            ? m.metadata.pageCount            : null) AS metadata_pageCount
,    (IS_DEFINED(m.metadata.quality)            ? m.metadata.quality            : null) AS metadata_quality
,    (IS_DEFINED(m.metadata.source)             ? m.metadata.source             : null) AS metadata_source
,    (IS_DEFINED(m.metadata.functionArguments)  ? m.metadata.functionArguments  : null) AS metadata_functionArguments
,    (IS_DEFINED(m.metadata.functionName)       ? m.metadata.functionName       : null) AS metadata_functionName
,    (IS_DEFINED(m.metadata.feedbackType)       ? m.metadata.feedbackType       : null) AS metadata_feedbackType
,    (IS_DEFINED(m.metadata.feedbackReason)       ? m.metadata.feedbackReason       : null) AS metadata_feedbackReason
FROM ChatHistory c 
JOIN m IN c.messages', NULL, NULL, 1, 'Dev - Crimson', 'ChatAiDbChatHistory', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'ChatAiDb', 'chatAiDb', 'overwrite', 'chatAiDb', 1, NULL, 230, NULL, 'ChatHistory CosmosDB', 'ChatHistory', 'cosmosdb', NULL, NULL, NULL, 'Get ChatHistory', 'lh_bronze', NULL, NULL, 'ChatHistory', NULL, NULL, 0, 29, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTaxIncome_Consolidated', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 238, 'dbo', 'Database', 'FundTaxIncome_Consolidated', 'sqlserver', NULL, '1', NULL, 'CrimsonXFundTaxIncome_Consolidated', 'lh_bronze', NULL, NULL, 'FundTaxIncome_Consolidated', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, 'SELECT         PerformanceTypeId,
    StartDate,
    EndDate,
    PrivateRefreshDate,
    AsOfDate,
    CAST(WeightedAssetReturn AS DECIMAL(38,6)) AS WeightedAssetReturn,
    CAST(BetaReturn AS DECIMAL(38,6)) AS BetaReturn,
    CAST(BetaReturnFlatIlliquids AS DECIMAL(38,6)) AS BetaReturnFlatIlliquids,
    CAST(PublicReturn AS DECIMAL(38,6)) AS PublicReturn
FROM Bronze.HMCDataMartInvestmentPerformanceGIAReturn
WHERE PerformanceTypeId IS NOT NULL
  AND StartDate IS NOT NULL
  AND EndDate IS NOT NULL
  AND AsOfDate IS NOT NULL

	
', NULL, NULL, 1, 'Dev - Crimson', 'PerformanceGIAReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 235, 'Bronze', 'Database', 'HMCDataMartInvestmentPerformanceGIAReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataMartInvestmentPerformanceGIAReturn', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'SolovisExternalActiveBook', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 232, 'etl', 'Database', 'vwSolovisLoadHelper_ActiveBookXref', 'sqlserver', NULL, NULL, NULL, 'SolovisExternalActiveBook', 'lh_bronze', NULL, NULL, 'SolovisExternalActiveBook', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, 'SELECT FundValuationId        
,FundId        	
,ShareClassId        	
,PortfolioTypeId        	
,NavDate        	
,ValuationDate        	
,ValuationAmt        	
,CurrencyId        	
,ValuationTypeId        	
,FrequencyId        	
,ETLLoadDateTime    	
FROM Bronze.CrimsonXFundValuation	
WHERE EndDate = CAST(''9999-12-31'' AS DATE)	
', NULL, NULL, 0, 'Dev - Crimson', 'FundValuation', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 240, 'Bronze', 'Database', 'CrimsonXFundValuation', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Solovis Valuation to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, '92b328a7-0bb9-47f9-a4b5-7ac4daf3bb13,5b0a2af0-0c1c-44fe-9233-19d31bff303f', 1, 'Dev - Crimson', 'EntraUsers', 'Dev - Crimson', NULL, 'Bronze', NULL, NULL, NULL, NULL, NULL, 0, 'office365', NULL, NULL, 'overwrite', 'Entra', 1, NULL, 89, NULL, 'Entra', 'BasicDataSet_v0.User_v1', 'office365', '  {
    "type": "TabularTranslator",
    "mappings": [
        {
            "source": {
                "name": "accountEnabled",
                "type": "Boolean",
                "physicalType": "boolean"
            },
            "sink": {
                "name": "accountEnabled",
                "physicalType": "boolean"
            }
        },
        {
            "source": {
                "name": "department",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "department",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "givenName",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "givenName",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "mail",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "mail",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "mobilePhone",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "mobilePhone",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "surname",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "surname",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "userPrincipalName",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "userPrincipalName",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "puser",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "puser",
                "physicalType": "string"
            }
        },  {
                "source": {
                    "name": "jobTitle",
                    "type": "String",
                    "physicalType": "string"
                },
                "sink": {
                    "name": "jobTitle",
                    "physicalType": "string"
                }
            }
    ],
    "typeConversion": true,
    "typeConversionSettings": {
        "allowDataTruncation": true,
        "treatBooleanAsNumber": false
    },
    "columnFlattenSettings": {
        "treatArrayAsString": false,
        "treatStructAsString": false,
        "flattenColumnDelimiter": "."
    }
}', NULL, NULL, 'Entra Users', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 13, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ProcessFundChanges', 'Dev - Crimson', NULL, 'Bronze', NULL, NULL, NULL, 40, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 4, NULL, 253, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Cleanup after calculating fund statistics', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundHorizonAlpha', 'Dev - Crimson', NULL, 'Gold', NULL, NULL, NULL, 39, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 3, NULL, 252, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Calculate fund alpha returns', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'EntraUserDevices', 'Dev - Crimson', NULL, 'Bronze', NULL, NULL, NULL, NULL, NULL, 0, 'office365', NULL, NULL, 'overwrite', 'Entra', 1, NULL, 90, NULL, 'Entra', 'BasicDataSet_v0.OwnedDevices_v0', 'office365', NULL, NULL, NULL, 'Entra User Devices', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 13, NULL
)
INSERT INTO etlControl.etl.Task (SinkWarehouseName, CustomSQLSourceQuery, SinkLakehouseId, SourceWhereClause, IsActiveFlag, SourceWorkspaceName, SinkTableName, SinkWorkspaceName, SinkWatermarkColumn, SinkSchemaName, SourceWatermarkColumn, SourceFlatfileConnectionSettings, SourceConnectionName, NotebookKey, SinkWorkspaceId, ArchiveOriginalFilesFlag, TaskType, SourceDatabaseName, RawStoragePath, SinkLoadMethod, SourceName, TaskRunOrderNbr, RelativeUrl, TaskKey, SourceSchemaName, ParentSourceName, SourceTableName, SourceType, CustomPipelineCode, SourceExtractionMethod, SourceLakehouseName, TaskName, SinkLakehouseName, ArchiveStoragePath, SourceWarehouseName, RawStorageFileName, ArchiveStorageFileName, PrimaryKeyColumnList, IsWatermarkEnabledFlag, JobKey, OverrideQuery)
SELECT source.SinkWarehouseName, source.CustomSQLSourceQuery, source.SinkLakehouseId, source.SourceWhereClause, source.IsActiveFlag, source.SourceWorkspaceName, source.SinkTableName, source.SinkWorkspaceName, source.SinkWatermarkColumn, source.SinkSchemaName, source.SourceWatermarkColumn, source.SourceFlatfileConnectionSettings, source.SourceConnectionName, source.NotebookKey, source.SinkWorkspaceId, source.ArchiveOriginalFilesFlag, source.TaskType, source.SourceDatabaseName, source.RawStoragePath, source.SinkLoadMethod, source.SourceName, source.TaskRunOrderNbr, source.RelativeUrl, source.TaskKey, source.SourceSchemaName, source.ParentSourceName, source.SourceTableName, source.SourceType, source.CustomPipelineCode, source.SourceExtractionMethod, source.SourceLakehouseName, source.TaskName, source.SinkLakehouseName, source.ArchiveStoragePath, source.SourceWarehouseName, source.RawStorageFileName, source.ArchiveStorageFileName, source.PrimaryKeyColumnList, source.IsWatermarkEnabledFlag, source.JobKey, source.OverrideQuery
FROM source
WHERE NOT EXISTS (
    SELECT 1
    FROM etlControl.etl.Task AS target
    WHERE target.TaskKey = source.TaskKey
);


-- ***** Script to update the table: etlControl.etl.Watermark *****
-- ===== UPDATE EXISTING ROWS =====
WITH source (TaskKey, HighWatermarkValue, FileTaskKey) AS (
SELECT NULL, NULL, 3
UNION ALL
SELECT NULL, NULL, 2
UNION ALL
SELECT NULL, NULL, 1
UNION ALL
SELECT 45, NULL, NULL
UNION ALL
SELECT 1, NULL, NULL
UNION ALL
SELECT 2, NULL, NULL
UNION ALL
SELECT 3, NULL, NULL
)
UPDATE target
SET
    target.HighWatermarkValue = source.HighWatermarkValue,
    target.FileTaskKey = source.FileTaskKey
FROM etlControl.etl.Watermark AS target
JOIN source
    ON target.TaskKey = source.TaskKey;

-- ===== INSERT NEW ROWS =====
WITH source (TaskKey, HighWatermarkValue, FileTaskKey) AS (
SELECT NULL, NULL, 3
UNION ALL
SELECT NULL, NULL, 2
UNION ALL
SELECT NULL, NULL, 1
UNION ALL
SELECT 45, NULL, NULL
UNION ALL
SELECT 1, NULL, NULL
UNION ALL
SELECT 2, NULL, NULL
UNION ALL
SELECT 3, NULL, NULL
)
INSERT INTO etlControl.etl.Watermark (TaskKey, HighWatermarkValue, FileTaskKey)
SELECT source.TaskKey, source.HighWatermarkValue, source.FileTaskKey
FROM source
WHERE NOT EXISTS (
    SELECT 1
    FROM etlControl.etl.Watermark AS target
    WHERE target.TaskKey = source.TaskKey
);
