
/*
select * from  etl.Job order by JobKey
select * from etl.Task 
select * from etl.FileTask
*/

SELECT j.JobKey, t.TaskKey, j.JobName, t.TaskRunOrderNbr, t.TaskName, t.TaskType, t.TaskTableName, t.NotebookKey,  nb.NotebookName
FROM etl.Job j
JOIN (
    SELECT JobKey, TaskKey, TaskName, TaskType, TaskRunOrderNbr, 'Task' as 'TaskTableName', NotebookKey FROM etl.Task
    UNION ALL
    SELECT JobKey, FileTaskKey as TaskKey, TaskName, TaskType, TaskRunOrderNbr, 'FileTask' as 'TaskTableName', NotebookKey FROM etl.FileTask
) AS t ON j.JobKey = t.JobKey
LEFT JOIN etl.Notebook nb on nb.NotebookKey = t.NotebookKey
--where TaskKey = 263
where NotebookName = 'SolovisTransactionIBORSilver'
order by JobName, TaskRunOrderNbr, TaskName

select * from etl.Notebook where NotebookName = 'SolovisTransactionIBORSilver'
select * from etl.FileTask
select *
from etl.TaskAudit
where TaskKey = 109
order by StartTime


