-- ***** Script to update the table: etlControl.etl.Job *****
-- ===== UPDATE EXISTING ROWS =====
WITH source (JobName, JobKey, JobDescription, IsActiveFlag) AS (
SELECT 'ChatHistoryRawBronze', 29, 'Get Chat History from CosmosDB', 1
UNION ALL
SELECT 'IndexReturn Bronze', 7, 'process Index Return Data', 1
UNION ALL
SELECT 'CyberSecurityDataBronze', 9, 'Ingests various Phishing Test Datasets', 1
UNION ALL
SELECT 'Flatten Classification', 28, 'This job handles flatten classification', 1
UNION ALL
SELECT 'FundLevelCalcRaw', 25, 'This job handles loading from source API to raw', 1
UNION ALL
SELECT 'FundLevelCalcMonthlyRaw', 27, 'This job handles loading API data from FundLevelCalcMonthly API to raw', 1
UNION ALL
SELECT 'BottomUpToSilver', 26, 'This job handles loading API data from FundLevelCalc and FundLevelCalcMonthly to Silver tables', 1
UNION ALL
SELECT 'NotesOrchestration', 24, 'Notes Tables from Raw to Silver', 1
UNION ALL
SELECT 'BottomUpBronze', 23, 'This job handles processing for BottomUp API data to Bronze', 1
UNION ALL
SELECT 'HMCDataMartInvestmentBronze', 22, 'Ingest data from HMCDataMartInvestment to Bronze', 1
UNION ALL
SELECT 'IndexReturnSilver', 21, 'IndexReturn to Silver', 1
UNION ALL
SELECT 'SolovisSilver', 20, 'Transforms solovis bronze data into silver', 1
UNION ALL
SELECT 'FundTradeSilver', 19, 'Transform FundTrade data', 1
UNION ALL
SELECT 'EntraSilver', 18, 'Entra Silver Transformations', 1
UNION ALL
SELECT 'AbnormalBronze', 17, 'Ingest Abnormal csv file to bronze', 1
UNION ALL
SELECT 'MimecastBronze', 16, 'Ingest Mimecast csv file to bronze', 1
UNION ALL
SELECT 'SpyCloudBronze', 15, 'Ingest SpyCloud csv file to bronze', 1
UNION ALL
SELECT 'ManualExceptionBronze', 14, 'Ingest Manual Exception csv file to bronze', 1
UNION ALL
SELECT 'EntraBronze', 13, 'Copying Entra/Active Directory data to Raw/bronze', 1
UNION ALL
SELECT 'CrimsonXBronze', 5, 'Copying tables from sql server to parquet files', 1
UNION ALL
SELECT 'FXRate', 12, 'This job handles processing for Reuters FXRates to Bronze', 1
UNION ALL
SELECT 'CrimsonXSilver', 11, 'Move transformed crimsonx data to Silver', 1
UNION ALL
SELECT 'SilverTransformations', 10, 'Runs transformations for Silver tables', 1
UNION ALL
SELECT 'Office365UserBronze', 8, 'Copy Office 365 User Data to Bronze', 1
UNION ALL
SELECT 'Solovis Bronze', 6, 'Solovis flat files load from Blob>Raw>Bronze', 1
UNION ALL
SELECT 'Test', 1, 'Test Pipeline', 1
UNION ALL
SELECT 'Factset', 4, 'This job handles ETL operations for Factset source data processing to raw (parquet)', 1
UNION ALL
SELECT 'TestCSVLoad2', 3, 'Test Pipeline', 1
UNION ALL
SELECT 'BronzeToSilver', 2, 'Job for transforming data from bronze to silver', 1
)
UPDATE target
SET
    target.JobName = source.JobName,
    target.JobDescription = source.JobDescription,
    target.IsActiveFlag = source.IsActiveFlag
FROM etlControl.etl.Job AS target
JOIN source
    ON target.JobKey = source.JobKey;

-- ===== INSERT NEW ROWS =====
WITH source (JobName, JobKey, JobDescription, IsActiveFlag) AS (
SELECT 'ChatHistoryRawBronze', 29, 'Get Chat History from CosmosDB', 1
UNION ALL
SELECT 'IndexReturn Bronze', 7, 'process Index Return Data', 1
UNION ALL
SELECT 'CyberSecurityDataBronze', 9, 'Ingests various Phishing Test Datasets', 1
UNION ALL
SELECT 'Flatten Classification', 28, 'This job handles flatten classification', 1
UNION ALL
SELECT 'FundLevelCalcRaw', 25, 'This job handles loading from source API to raw', 1
UNION ALL
SELECT 'FundLevelCalcMonthlyRaw', 27, 'This job handles loading API data from FundLevelCalcMonthly API to raw', 1
UNION ALL
SELECT 'BottomUpToSilver', 26, 'This job handles loading API data from FundLevelCalc and FundLevelCalcMonthly to Silver tables', 1
UNION ALL
SELECT 'NotesOrchestration', 24, 'Notes Tables from Raw to Silver', 1
UNION ALL
SELECT 'BottomUpBronze', 23, 'This job handles processing for BottomUp API data to Bronze', 1
UNION ALL
SELECT 'HMCDataMartInvestmentBronze', 22, 'Ingest data from HMCDataMartInvestment to Bronze', 1
UNION ALL
SELECT 'IndexReturnSilver', 21, 'IndexReturn to Silver', 1
UNION ALL
SELECT 'SolovisSilver', 20, 'Transforms solovis bronze data into silver', 1
UNION ALL
SELECT 'FundTradeSilver', 19, 'Transform FundTrade data', 1
UNION ALL
SELECT 'EntraSilver', 18, 'Entra Silver Transformations', 1
UNION ALL
SELECT 'AbnormalBronze', 17, 'Ingest Abnormal csv file to bronze', 1
UNION ALL
SELECT 'MimecastBronze', 16, 'Ingest Mimecast csv file to bronze', 1
UNION ALL
SELECT 'SpyCloudBronze', 15, 'Ingest SpyCloud csv file to bronze', 1
UNION ALL
SELECT 'ManualExceptionBronze', 14, 'Ingest Manual Exception csv file to bronze', 1
UNION ALL
SELECT 'EntraBronze', 13, 'Copying Entra/Active Directory data to Raw/bronze', 1
UNION ALL
SELECT 'CrimsonXBronze', 5, 'Copying tables from sql server to parquet files', 1
UNION ALL
SELECT 'FXRate', 12, 'This job handles processing for Reuters FXRates to Bronze', 1
UNION ALL
SELECT 'CrimsonXSilver', 11, 'Move transformed crimsonx data to Silver', 1
UNION ALL
SELECT 'SilverTransformations', 10, 'Runs transformations for Silver tables', 1
UNION ALL
SELECT 'Office365UserBronze', 8, 'Copy Office 365 User Data to Bronze', 1
UNION ALL
SELECT 'Solovis Bronze', 6, 'Solovis flat files load from Blob>Raw>Bronze', 1
UNION ALL
SELECT 'Test', 1, 'Test Pipeline', 1
UNION ALL
SELECT 'Factset', 4, 'This job handles ETL operations for Factset source data processing to raw (parquet)', 1
UNION ALL
SELECT 'TestCSVLoad2', 3, 'Test Pipeline', 1
UNION ALL
SELECT 'BronzeToSilver', 2, 'Job for transforming data from bronze to silver', 1
)
INSERT INTO etlControl.etl.Job (JobName, JobKey, JobDescription, IsActiveFlag)
SELECT source.JobName, source.JobKey, source.JobDescription, source.IsActiveFlag
FROM source
WHERE NOT EXISTS (
    SELECT 1
    FROM etlControl.etl.Job AS target
    WHERE target.JobKey = source.JobKey
);


-- ***** Script to update the table: etlControl.etl.Notebook *****
-- ===== UPDATE EXISTING ROWS =====
WITH source (NotebookName, NotebookKey, NotebookDescription) AS (
SELECT 'IndexReturnStep3ComputedBenchmarksSilver_06', 24, 'IndexReturn Computed Benchmarks'
UNION ALL
SELECT 'KnowBe4Users', 25, 'Write the users data from KnowBe4 to a parquet file'
UNION ALL
SELECT 'SpyCloudData', 26, 'Wrtie the SpyCloud data to  Bronze.CyberDashboardSpyCloud table'
UNION ALL
SELECT 'IndexReturnStep1GapFillSilver_7', 15, 'IndexReturn Gap Filler'
UNION ALL
SELECT 'IndexReturnStep2ComputeLevelsSilver_11', 16, 'IndexReturn Compute Levels'
UNION ALL
SELECT 'IndexReturnStep4FrequencyPromotionSilver_06', 17, 'IndexReturn Frequency Promotiion'
UNION ALL
SELECT 'Flatten_Classifications', 23, 'Flatten the classification structure to Silver'
UNION ALL
SELECT 'APIBottomUpSilver', 22, 'Silver transformations for Bottom up tables'
UNION ALL
SELECT 'UpdateCashflowTransactionDetailsUSDAmountsBronze', 21, 'Updates the USD with the correct FX rate for Bronze.CrimsonXCashflowTransactionDetail'
UNION ALL
SELECT 'SolovisMarketValueSilver', 20, 'Loads solovis market values into holdingshistory and FundMarketValues'
UNION ALL
SELECT 'APIBottomUpBronze', 19, 'Create bronze tables for Bottom Up'
UNION ALL
SELECT 'FundSilver', 18, 'Load FundSilver from bronze to silver'
UNION ALL
SELECT 'EntraHMCUserSilver', 9, 'Silver Entra Users'
UNION ALL
SELECT 'FundTradeSilver', 14, 'Load FundTradeSilver from bronze to silver'
UNION ALL
SELECT 'ForecastedTransactionSilver', 13, 'Load ForecastedTransactionSilver from bronze to silver'
UNION ALL
SELECT 'ForecastedCashflowSilver', 12, 'Load ForecastedCashflowSilver from bronze to silver'
UNION ALL
SELECT 'SolovisTransactionsCashflowTransactionDetailSilver', 11, 'Load solovis transactions into cashflowtransactiondetail'
UNION ALL
SELECT 'NotesSilver', 8, 'Silver Transformations to create Note, NoteLink,NoteAttachments'
UNION ALL
SELECT 'Bronze Build ActiveBook and Fund Mappings', 10, 'Builds the ActiveBook and Fund mappings from solovis to Crimson'
UNION ALL
SELECT 'LiquidityTermSchedule', 7, 'Transform Liquidity terms to LiquidityTermSchedule'
UNION ALL
SELECT 'Factset_IndexRegionCountryExposure_Silver', 2, 'Runs transformation for IndexCountryExposure table in Silver'
UNION ALL
SELECT 'FXRateSilver', 4, 'Custom load process of FxRate to Silver'
UNION ALL
SELECT 'Factset_IndexSectorIndustryExposure_Silver', 6, 'Runs transformation for IndeSectorIndustryExposure table in Silver'
UNION ALL
SELECT 'Factset_IndexRegionExposure_Silver', 5, 'Runs transformation for IndexRegionExposure table in Silver'
UNION ALL
SELECT 'TransformUniverseSilver', 3, 'Tranform Universe data to Silver'
UNION ALL
SELECT 'KnowBe4PhishingData', 1, 'Ingests various Phishing Test Datasets'
)
UPDATE target
SET
    target.NotebookName = source.NotebookName,
    target.NotebookDescription = source.NotebookDescription
FROM etlControl.etl.Notebook AS target
JOIN source
    ON target.NotebookKey = source.NotebookKey;

-- ===== INSERT NEW ROWS =====
WITH source (NotebookName, NotebookKey, NotebookDescription) AS (
SELECT 'IndexReturnStep3ComputedBenchmarksSilver_06', 24, 'IndexReturn Computed Benchmarks'
UNION ALL
SELECT 'KnowBe4Users', 25, 'Write the users data from KnowBe4 to a parquet file'
UNION ALL
SELECT 'SpyCloudData', 26, 'Wrtie the SpyCloud data to  Bronze.CyberDashboardSpyCloud table'
UNION ALL
SELECT 'IndexReturnStep1GapFillSilver_7', 15, 'IndexReturn Gap Filler'
UNION ALL
SELECT 'IndexReturnStep2ComputeLevelsSilver_11', 16, 'IndexReturn Compute Levels'
UNION ALL
SELECT 'IndexReturnStep4FrequencyPromotionSilver_06', 17, 'IndexReturn Frequency Promotiion'
UNION ALL
SELECT 'Flatten_Classifications', 23, 'Flatten the classification structure to Silver'
UNION ALL
SELECT 'APIBottomUpSilver', 22, 'Silver transformations for Bottom up tables'
UNION ALL
SELECT 'UpdateCashflowTransactionDetailsUSDAmountsBronze', 21, 'Updates the USD with the correct FX rate for Bronze.CrimsonXCashflowTransactionDetail'
UNION ALL
SELECT 'SolovisMarketValueSilver', 20, 'Loads solovis market values into holdingshistory and FundMarketValues'
UNION ALL
SELECT 'APIBottomUpBronze', 19, 'Create bronze tables for Bottom Up'
UNION ALL
SELECT 'FundSilver', 18, 'Load FundSilver from bronze to silver'
UNION ALL
SELECT 'EntraHMCUserSilver', 9, 'Silver Entra Users'
UNION ALL
SELECT 'FundTradeSilver', 14, 'Load FundTradeSilver from bronze to silver'
UNION ALL
SELECT 'ForecastedTransactionSilver', 13, 'Load ForecastedTransactionSilver from bronze to silver'
UNION ALL
SELECT 'ForecastedCashflowSilver', 12, 'Load ForecastedCashflowSilver from bronze to silver'
UNION ALL
SELECT 'SolovisTransactionsCashflowTransactionDetailSilver', 11, 'Load solovis transactions into cashflowtransactiondetail'
UNION ALL
SELECT 'NotesSilver', 8, 'Silver Transformations to create Note, NoteLink,NoteAttachments'
UNION ALL
SELECT 'Bronze Build ActiveBook and Fund Mappings', 10, 'Builds the ActiveBook and Fund mappings from solovis to Crimson'
UNION ALL
SELECT 'LiquidityTermSchedule', 7, 'Transform Liquidity terms to LiquidityTermSchedule'
UNION ALL
SELECT 'Factset_IndexRegionCountryExposure_Silver', 2, 'Runs transformation for IndexCountryExposure table in Silver'
UNION ALL
SELECT 'FXRateSilver', 4, 'Custom load process of FxRate to Silver'
UNION ALL
SELECT 'Factset_IndexSectorIndustryExposure_Silver', 6, 'Runs transformation for IndeSectorIndustryExposure table in Silver'
UNION ALL
SELECT 'Factset_IndexRegionExposure_Silver', 5, 'Runs transformation for IndexRegionExposure table in Silver'
UNION ALL
SELECT 'TransformUniverseSilver', 3, 'Tranform Universe data to Silver'
UNION ALL
SELECT 'KnowBe4PhishingData', 1, 'Ingests various Phishing Test Datasets'
)
INSERT INTO etlControl.etl.Notebook (NotebookName, NotebookKey, NotebookDescription)
SELECT source.NotebookName, source.NotebookKey, source.NotebookDescription
FROM source
WHERE NOT EXISTS (
    SELECT 1
    FROM etlControl.etl.Notebook AS target
    WHERE target.NotebookKey = source.NotebookKey
);


-- ***** Script to update the table: etlControl.etl.FileTask *****
-- ===== UPDATE EXISTING ROWS =====
WITH source (SkipRows, SinkWarehouseName, IsActiveFlag, SinkTableName, RawLakehouseName, SinkWorkspaceName, SourceDataSet, SinkWatermarkColumn, LastModifiedFrom, SinkSchemaName, SinkObjectType, NotebookKey, Delimiter, SinkDataset, TaskType, RawStoragePath, SinkLoadMethod, SourceName, TaskRunOrderNbr, SourceWildcardFileName, ETLWarehouseName, FileFilter, ParentSourceName, SourceType, TaskName, FileType, SinkLakehouseName, FileTaskKey, RawStorageFileName, PrimaryKeyColumnList, IsWatermarkEnabledFlag, SourceWildcardFolderPath, JobKey) AS (
SELECT 0, NULL, 1, 'CyberDashboardSpyCloud', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, NULL, NULL, 'FileTask', NULL, 'merge', 'SpyCloud', 2, '*.parquet', 'etlControl', NULL, 'SpyCloudAPI', 'SpyCloud', 'SpyCloudData', 'parquet', 'lh_bronze', 5026, 'SpyCloud', NULL, 0, 'Files/IncomingFeed/CyberSecurityDashboard/SpyCloud/spycloud.parquet', 9
UNION ALL
SELECT 0, NULL, 1, 'KnowBe4Users', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ' ', NULL, 'FileTask', 'KnowBe4', 'merge', 'KnowBe4', 2, '*.parquet', 'etlControl', NULL, 'KnowBe4API', 'KnowBe4', 'KnowBe4Users', 'parquet', 'lh_bronze', 5025, 'knowbe4_users.parquet', NULL, 0, 'IncomingFeed/CyberSecurityDashboard/KnowBe4/knowbe4_users.parquet', 9
UNION ALL
SELECT 0, NULL, 1, 'KnowBe4PhishingTest', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, -1, '', '', 'FileTask', 'KnowBe4', 'merge', 'KnowBe4', 2, '*.parquet', 'etlControl', NULL, 'KnowBe4API', 'KnowBe4', 'KnowBe4PhishingTests', 'parquet', 'lh_bronze', 5018, 'knowbe4_data.parquet', 'pst_id,recipient_id', 0, 'IncomingFeed/CyberSecurityDashboard/KnowBe4/knowbe4_data.parquet', 9
UNION ALL
SELECT 0, 'Bronze', 1, '02Test', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, 1, ',', '', 'FileTask', 'rawtest', 'overwrite', 'Test', 1, 'S&P500HistoricalData.csv', 'etlControl', NULL, 'Test', 'file', 'Test', 'delimited', 'lh_bronze', 5002, 'S&P500HistoricalData', 'Date', 0, 'IncomingFeed/test', 1
UNION ALL
SELECT 0, 'Bronze', 1, '01Test', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, 1, ',', '', 'FileTask', 'rawtest', 'overwrite', 'Test', 1, 'INDEX_US_DOW JONES GLOBAL_DJIA.csv', 'etlControl', NULL, 'Test', 'file', 'Test', 'delimited', 'lh_bronze', 5001, 'INDEX_US_DOW JONES GLOBAL_DJIA', 'Date', 0, 'IncomingFeed/test', 1
UNION ALL
SELECT 0, 'Bronze', 1, 'Factset', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, 1, '|', '', 'FileTask', 'Factset', 'overwrite', 'FactSet', 1, '*.txt', 'etlControl', NULL, 'FactSet', 'file', 'Factset Files', 'delimited', 'lh_bronze', 5004, 'Factset', '', 0, 'proworkspace/FactSet', 1
UNION ALL
SELECT NULL, NULL, 1, 'Note', 'lh_raw', 'Dev - Crimson', '', NULL, NULL, 'Bronze', NULL, NULL, NULL, NULL, 'FileTask', 'Notes', 'merge', 'Blob', 1, '{date.today():%Y%m}', 'etlControl', NULL, 'Blob', 'file', 'Notes to Bronze', 'json', 'lh_bronze', 5022, 'Notes', 'noteId', 0, 'proworkspace/Notes/MetaData', 24
UNION ALL
SELECT 2, NULL, 1, 'FXRate', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, NULL, ',', NULL, 'FileTask', 'ReutersFX', 'append', 'ReutersFX', 1, '*.csv', 'etlControl', 'to_date(`"Date & Time"`, ''dd/MM/yyyy HH:mm'') = ''{yesterday}''', 'ReutersFX', 'ReutersFX', 'ReutersFXBronze', 'delimited', 'lh_bronze', 5003, 'FXRate', NULL, 0, 'proworkspace/ReutersFX', 12
UNION ALL
SELECT 0, NULL, 1, 'SolovisInvestmentIgnoreList', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'SolovisInvestmentIgnoreList.csv', 'etlControl', NULL, 'Solovis', 'file', 'SolovisInvestmentIgnoreList', 'delimited', 'lh_bronze', 5017, 'SolovisInvestmentIgnoreList', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisEntityIgnoreList', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'SolovisEntityIgnoreList.csv', 'etlControl', NULL, 'Solovis', 'file', 'SolovisEntityIgnoreList', 'delimited', 'lh_bronze', 5016, 'SolovisEntityIgnoreList', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisMarketValues', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_market_values.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_market_values', 'delimited', 'lh_bronze', 5011, 'solovis_market_values', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisTransactions', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_transactions.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_transactions', 'delimited', 'lh_bronze', 5014, 'solovis_transactions', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisTransactionsMaterial', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_transactions_material.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_transactions_material', 'delimited', 'lh_bronze', 5015, 'solovis_transactions_material', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisTagsets', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_tagsets.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_tagsets', 'delimited', 'lh_bronze', 5013, 'solovis_tagsets', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisMarketValuesMaterial', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_market_values_material.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_market_values_material', 'delimited', 'lh_bronze', 5012, 'solovis_market_values_material', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisLiquidityTerms', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_liquidity_terms.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_liquidity_terms', 'delimited', 'lh_bronze', 5010, 'solovis_liquidity_terms', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisLiquiditySidePockets', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_liquidity_side_pockets.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_liquidity_side_pockets', 'delimited', 'lh_bronze', 5009, 'solovis_liquidity_side_pockets', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisLiquidityReceipts', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_liquidity_receipts.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_liquidity_receipts', 'delimited', 'lh_bronze', 5008, 'solovis_liquidity_receipts', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisEntities', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_entities.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_entities', 'delimited', 'lh_bronze', 5006, 'solovis_entities', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisInvestments', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_investments.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_investments', 'delimited', 'lh_bronze', 5007, 'solovis_investments', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisCommitments', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_commitments.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_commitments', 'delimited', 'lh_bronze', 5005, 'solovis_commitments', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 13, NULL, 1, 'BloombergIndexReturn', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'IndexReturn', 'overwrite', 'IndexReturn', 1, '*.txt', 'etlControl', NULL, 'IndexReturn', 'file', 'BloombergIndexReturn', 'delimited', 'lh_bronze', 5019, 'BloombergIndexReturn', NULL, 0, 'proworkspace/IndexReturn/BloombergIndexReturn', 7
UNION ALL
SELECT 0, NULL, 1, 'Mimecast', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'Mimecast', 'overwrite', 'Mimecast', 1, 'Mimecast*', 'etlControl', NULL, 'Mimecast', 'file', 'Mimecast', 'delimited', 'lh_bronze', 5023, 'Mimecast', NULL, 0, 'proworkspace/Mimecast', 16
UNION ALL
SELECT 0, NULL, 1, 'Abnormal', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'Abnormal', 'overwrite', 'Abnormal', 1, 'Abnormal_results.csv', 'etlControl', NULL, 'Abnormal', 'file', 'Abnormal', 'delimited', 'lh_bronze', 5024, 'Abnormal', NULL, 0, 'proworkspace/Abnormal', 17
UNION ALL
SELECT 0, NULL, 1, 'SpyCloud', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'SpyCloud', 'overwrite', 'SpyCloud', 1, 'SpyCloudData.csv', 'etlControl', NULL, 'SpyCloud', 'file', 'SpyCloud', 'delimited', 'lh_bronze', 5021, 'SpyCloud', NULL, 0, 'proworkspace/SpyCloud', 15
UNION ALL
SELECT 0, NULL, 1, 'ManualExceptions', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'ManualExceptions', 'overwrite', 'ManualExceptions', 1, 'ManualExceptionsData.csv', 'etlControl', NULL, 'ManualExceptions', 'file', 'ManualExceptions', 'delimited', 'lh_bronze', 5020, 'ManualExceptions', NULL, 0, 'proworkspace/ManualExceptions', 14
)
UPDATE target
SET
    target.SkipRows = source.SkipRows,
    target.SinkWarehouseName = source.SinkWarehouseName,
    target.IsActiveFlag = source.IsActiveFlag,
    target.SinkTableName = source.SinkTableName,
    target.RawLakehouseName = source.RawLakehouseName,
    target.SinkWorkspaceName = source.SinkWorkspaceName,
    target.SourceDataSet = source.SourceDataSet,
    target.SinkWatermarkColumn = source.SinkWatermarkColumn,
    target.LastModifiedFrom = source.LastModifiedFrom,
    target.SinkSchemaName = source.SinkSchemaName,
    target.SinkObjectType = source.SinkObjectType,
    target.NotebookKey = source.NotebookKey,
    target.Delimiter = source.Delimiter,
    target.SinkDataset = source.SinkDataset,
    target.TaskType = source.TaskType,
    target.RawStoragePath = source.RawStoragePath,
    target.SinkLoadMethod = source.SinkLoadMethod,
    target.SourceName = source.SourceName,
    target.TaskRunOrderNbr = source.TaskRunOrderNbr,
    target.SourceWildcardFileName = source.SourceWildcardFileName,
    target.ETLWarehouseName = source.ETLWarehouseName,
    target.FileFilter = source.FileFilter,
    target.ParentSourceName = source.ParentSourceName,
    target.SourceType = source.SourceType,
    target.TaskName = source.TaskName,
    target.FileType = source.FileType,
    target.SinkLakehouseName = source.SinkLakehouseName,
    target.RawStorageFileName = source.RawStorageFileName,
    target.PrimaryKeyColumnList = source.PrimaryKeyColumnList,
    target.IsWatermarkEnabledFlag = source.IsWatermarkEnabledFlag,
    target.SourceWildcardFolderPath = source.SourceWildcardFolderPath,
    target.JobKey = source.JobKey
FROM etlControl.etl.FileTask AS target
JOIN source
    ON target.FileTaskKey = source.FileTaskKey;

-- ===== INSERT NEW ROWS =====
WITH source (SkipRows, SinkWarehouseName, IsActiveFlag, SinkTableName, RawLakehouseName, SinkWorkspaceName, SourceDataSet, SinkWatermarkColumn, LastModifiedFrom, SinkSchemaName, SinkObjectType, NotebookKey, Delimiter, SinkDataset, TaskType, RawStoragePath, SinkLoadMethod, SourceName, TaskRunOrderNbr, SourceWildcardFileName, ETLWarehouseName, FileFilter, ParentSourceName, SourceType, TaskName, FileType, SinkLakehouseName, FileTaskKey, RawStorageFileName, PrimaryKeyColumnList, IsWatermarkEnabledFlag, SourceWildcardFolderPath, JobKey) AS (
SELECT 0, NULL, 1, 'CyberDashboardSpyCloud', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, NULL, NULL, 'FileTask', NULL, 'merge', 'SpyCloud', 2, '*.parquet', 'etlControl', NULL, 'SpyCloudAPI', 'SpyCloud', 'SpyCloudData', 'parquet', 'lh_bronze', 5026, 'SpyCloud', NULL, 0, 'Files/IncomingFeed/CyberSecurityDashboard/SpyCloud/spycloud.parquet', 9
UNION ALL
SELECT 0, NULL, 1, 'KnowBe4Users', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ' ', NULL, 'FileTask', 'KnowBe4', 'merge', 'KnowBe4', 2, '*.parquet', 'etlControl', NULL, 'KnowBe4API', 'KnowBe4', 'KnowBe4Users', 'parquet', 'lh_bronze', 5025, 'knowbe4_users.parquet', NULL, 0, 'IncomingFeed/CyberSecurityDashboard/KnowBe4/knowbe4_users.parquet', 9
UNION ALL
SELECT 0, NULL, 1, 'KnowBe4PhishingTest', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, -1, '', '', 'FileTask', 'KnowBe4', 'merge', 'KnowBe4', 2, '*.parquet', 'etlControl', NULL, 'KnowBe4API', 'KnowBe4', 'KnowBe4PhishingTests', 'parquet', 'lh_bronze', 5018, 'knowbe4_data.parquet', 'pst_id,recipient_id', 0, 'IncomingFeed/CyberSecurityDashboard/KnowBe4/knowbe4_data.parquet', 9
UNION ALL
SELECT 0, 'Bronze', 1, '02Test', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, 1, ',', '', 'FileTask', 'rawtest', 'overwrite', 'Test', 1, 'S&P500HistoricalData.csv', 'etlControl', NULL, 'Test', 'file', 'Test', 'delimited', 'lh_bronze', 5002, 'S&P500HistoricalData', 'Date', 0, 'IncomingFeed/test', 1
UNION ALL
SELECT 0, 'Bronze', 1, '01Test', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, 1, ',', '', 'FileTask', 'rawtest', 'overwrite', 'Test', 1, 'INDEX_US_DOW JONES GLOBAL_DJIA.csv', 'etlControl', NULL, 'Test', 'file', 'Test', 'delimited', 'lh_bronze', 5001, 'INDEX_US_DOW JONES GLOBAL_DJIA', 'Date', 0, 'IncomingFeed/test', 1
UNION ALL
SELECT 0, 'Bronze', 1, 'Factset', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', '', 'Bronze', NULL, 1, '|', '', 'FileTask', 'Factset', 'overwrite', 'FactSet', 1, '*.txt', 'etlControl', NULL, 'FactSet', 'file', 'Factset Files', 'delimited', 'lh_bronze', 5004, 'Factset', '', 0, 'proworkspace/FactSet', 1
UNION ALL
SELECT NULL, NULL, 1, 'Note', 'lh_raw', 'Dev - Crimson', '', NULL, NULL, 'Bronze', NULL, NULL, NULL, NULL, 'FileTask', 'Notes', 'merge', 'Blob', 1, '{date.today():%Y%m}', 'etlControl', NULL, 'Blob', 'file', 'Notes to Bronze', 'json', 'lh_bronze', 5022, 'Notes', 'noteId', 0, 'proworkspace/Notes/MetaData', 24
UNION ALL
SELECT 2, NULL, 1, 'FXRate', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, NULL, ',', NULL, 'FileTask', 'ReutersFX', 'append', 'ReutersFX', 1, '*.csv', 'etlControl', 'to_date(`"Date & Time"`, ''dd/MM/yyyy HH:mm'') = ''{yesterday}''', 'ReutersFX', 'ReutersFX', 'ReutersFXBronze', 'delimited', 'lh_bronze', 5003, 'FXRate', NULL, 0, 'proworkspace/ReutersFX', 12
UNION ALL
SELECT 0, NULL, 1, 'SolovisInvestmentIgnoreList', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'SolovisInvestmentIgnoreList.csv', 'etlControl', NULL, 'Solovis', 'file', 'SolovisInvestmentIgnoreList', 'delimited', 'lh_bronze', 5017, 'SolovisInvestmentIgnoreList', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisEntityIgnoreList', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'SolovisEntityIgnoreList.csv', 'etlControl', NULL, 'Solovis', 'file', 'SolovisEntityIgnoreList', 'delimited', 'lh_bronze', 5016, 'SolovisEntityIgnoreList', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisMarketValues', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_market_values.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_market_values', 'delimited', 'lh_bronze', 5011, 'solovis_market_values', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisTransactions', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_transactions.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_transactions', 'delimited', 'lh_bronze', 5014, 'solovis_transactions', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisTransactionsMaterial', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_transactions_material.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_transactions_material', 'delimited', 'lh_bronze', 5015, 'solovis_transactions_material', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisTagsets', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_tagsets.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_tagsets', 'delimited', 'lh_bronze', 5013, 'solovis_tagsets', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisMarketValuesMaterial', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_market_values_material.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_market_values_material', 'delimited', 'lh_bronze', 5012, 'solovis_market_values_material', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisLiquidityTerms', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_liquidity_terms.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_liquidity_terms', 'delimited', 'lh_bronze', 5010, 'solovis_liquidity_terms', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisLiquiditySidePockets', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_liquidity_side_pockets.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_liquidity_side_pockets', 'delimited', 'lh_bronze', 5009, 'solovis_liquidity_side_pockets', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisLiquidityReceipts', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_liquidity_receipts.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_liquidity_receipts', 'delimited', 'lh_bronze', 5008, 'solovis_liquidity_receipts', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisEntities', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_entities.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_entities', 'delimited', 'lh_bronze', 5006, 'solovis_entities', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisInvestments', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_investments.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_investments', 'delimited', 'lh_bronze', 5007, 'solovis_investments', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 0, NULL, 1, 'SolovisCommitments', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'Solovis', 'overwrite', 'Solovis', 1, 'solovis_commitments.csv', 'etlControl', NULL, 'Solovis', 'file', 'solovis_commitments', 'delimited', 'lh_bronze', 5005, 'solovis_commitments', NULL, 0, 'proworkspace/Solovis', 6
UNION ALL
SELECT 13, NULL, 1, 'BloombergIndexReturn', 'lh_raw', 'Dev - Crimson', '', 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, '|', NULL, 'FileTask', 'IndexReturn', 'overwrite', 'IndexReturn', 1, '*.txt', 'etlControl', NULL, 'IndexReturn', 'file', 'BloombergIndexReturn', 'delimited', 'lh_bronze', 5019, 'BloombergIndexReturn', NULL, 0, 'proworkspace/IndexReturn/BloombergIndexReturn', 7
UNION ALL
SELECT 0, NULL, 1, 'Mimecast', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'Mimecast', 'overwrite', 'Mimecast', 1, 'Mimecast*', 'etlControl', NULL, 'Mimecast', 'file', 'Mimecast', 'delimited', 'lh_bronze', 5023, 'Mimecast', NULL, 0, 'proworkspace/Mimecast', 16
UNION ALL
SELECT 0, NULL, 1, 'Abnormal', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'Abnormal', 'overwrite', 'Abnormal', 1, 'Abnormal_results.csv', 'etlControl', NULL, 'Abnormal', 'file', 'Abnormal', 'delimited', 'lh_bronze', 5024, 'Abnormal', NULL, 0, 'proworkspace/Abnormal', 17
UNION ALL
SELECT 0, NULL, 1, 'SpyCloud', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'SpyCloud', 'overwrite', 'SpyCloud', 1, 'SpyCloudData.csv', 'etlControl', NULL, 'SpyCloud', 'file', 'SpyCloud', 'delimited', 'lh_bronze', 5021, 'SpyCloud', NULL, 0, 'proworkspace/SpyCloud', 15
UNION ALL
SELECT 0, NULL, 1, 'ManualExceptions', 'lh_raw', 'Dev - Crimson', NULL, 'ETLLoadDateTime', NULL, 'Bronze', NULL, -1, ',', NULL, 'FileTask', 'ManualExceptions', 'overwrite', 'ManualExceptions', 1, 'ManualExceptionsData.csv', 'etlControl', NULL, 'ManualExceptions', 'file', 'ManualExceptions', 'delimited', 'lh_bronze', 5020, 'ManualExceptions', NULL, 0, 'proworkspace/ManualExceptions', 14
)
INSERT INTO etlControl.etl.FileTask (SkipRows, SinkWarehouseName, IsActiveFlag, SinkTableName, RawLakehouseName, SinkWorkspaceName, SourceDataSet, SinkWatermarkColumn, LastModifiedFrom, SinkSchemaName, SinkObjectType, NotebookKey, Delimiter, SinkDataset, TaskType, RawStoragePath, SinkLoadMethod, SourceName, TaskRunOrderNbr, SourceWildcardFileName, ETLWarehouseName, FileFilter, ParentSourceName, SourceType, TaskName, FileType, SinkLakehouseName, FileTaskKey, RawStorageFileName, PrimaryKeyColumnList, IsWatermarkEnabledFlag, SourceWildcardFolderPath, JobKey)
SELECT source.SkipRows, source.SinkWarehouseName, source.IsActiveFlag, source.SinkTableName, source.RawLakehouseName, source.SinkWorkspaceName, source.SourceDataSet, source.SinkWatermarkColumn, source.LastModifiedFrom, source.SinkSchemaName, source.SinkObjectType, source.NotebookKey, source.Delimiter, source.SinkDataset, source.TaskType, source.RawStoragePath, source.SinkLoadMethod, source.SourceName, source.TaskRunOrderNbr, source.SourceWildcardFileName, source.ETLWarehouseName, source.FileFilter, source.ParentSourceName, source.SourceType, source.TaskName, source.FileType, source.SinkLakehouseName, source.FileTaskKey, source.RawStorageFileName, source.PrimaryKeyColumnList, source.IsWatermarkEnabledFlag, source.SourceWildcardFolderPath, source.JobKey
FROM source
WHERE NOT EXISTS (
    SELECT 1
    FROM etlControl.etl.FileTask AS target
    WHERE target.FileTaskKey = source.FileTaskKey
);


-- ***** Script to update the table: etlControl.etl.Task *****
-- ===== UPDATE EXISTING ROWS =====
WITH source (SinkWarehouseName, CustomSQLSourceQuery, SinkLakehouseId, SourceWhereClause, IsActiveFlag, SourceWorkspaceName, SinkTableName, SinkWorkspaceName, SinkWatermarkColumn, SinkSchemaName, SourceWatermarkColumn, SourceFlatfileConnectionSettings, SourceConnectionName, NotebookKey, SinkWorkspaceId, ArchiveOriginalFilesFlag, TaskType, SourceDatabaseName, RawStoragePath, SinkLoadMethod, SourceName, TaskRunOrderNbr, RelativeUrl, TaskKey, SourceSchemaName, ParentSourceName, SourceTableName, SourceType, CustomPipelineCode, SourceExtractionMethod, SourceLakehouseName, TaskName, SinkLakehouseName, ArchiveStoragePath, SourceWarehouseName, RawStorageFileName, ArchiveStorageFileName, PrimaryKeyColumnList, IsWatermarkEnabledFlag, JobKey, OverrideQuery) AS (
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'SolovisExternalActiveBook', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 232, 'etl', 'Database', 'vwSolovisLoadHelper_ActiveBookXref', 'sqlserver', NULL, NULL, NULL, 'SolovisExternalActiveBook', 'lh_bronze', NULL, NULL, 'SolovisExternalActiveBook', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'IndexReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 95, 'Bronze', 'Database', 'IndexReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'WarehouseIndexReturn', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Index', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 27, 'Bronze', 'Database', 'CrimsonXIndex', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonIndex', 'lh_silver', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'IndexReturn_readonly', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 110, 'Bronze', 'Database', 'IndexReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'WarehouseIndexRet_RO', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'IndexReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 77, 'etl', 'Database', 'vwIndexReturnCrimsonXGUID', 'sqlserver', NULL, NULL, NULL, 'WarehouseIndexReturn', 'lh_bronze', NULL, NULL, 'IndexReturnRaw', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexCustomBlendRecipe', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 236, 'etl', 'Database', 'vwIndexBlendRecipeCrimsonXGUID', 'sqlserver', NULL, NULL, NULL, 'IndexCustomBlendRecipe', 'lh_bronze', NULL, NULL, 'IndexCustomBlendRecipe', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'IndexCustomBlendRecipe', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 237, 'Bronze', 'Database', 'CrimsonXIndexCustomBlendRecipe', 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexCustomBlendRecipe', 'lh_silver', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'SolovisActiveBookFundMapping', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 10, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 2, NULL, 94, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Build ActiveBook & Fund Mappings', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 16, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 2, NULL, 124, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturnSilver Levels', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CashflowTransactionDetail', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 11, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 1, NULL, 109, NULL, 'Solovis', NULL, 'Lakehouse', NULL, NULL, NULL, 'Solovis Transactions Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCUsers', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 9, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Entra', 1, NULL, 92, NULL, 'Entra', NULL, 'Lakehouse', NULL, NULL, NULL, 'Entra Users Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 18, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Universe', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 3, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 63, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonXSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Region', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 5, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 75, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset-IndexRegionExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'RegionCountry', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 2, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 49, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset-IndexRegionCountryExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'SectorIndustry', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 6, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 50, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset-IndexSectorIndustryExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 21, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'CrimsonXCashflowTransactionDetail', 2, NULL, 209, 'Bronze', 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Update CashflowTransactionDetail USD Amounts with correct FX Rate', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 22, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Crimson HMC API', 3, NULL, 215, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, 'lh_bronze', 'Bottom Up Data to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 26, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundMarketValue', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 20, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 1, NULL, 206, 'Silver', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_curated', 'Solovis Market Values Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Fund', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 18, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 202, 'Bronze', 'Database', 'CrimsonXFund', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehousevwSourceReferenceIndex', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, -1, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 43, 'dbo', 'Database', 'vwSourceReferenceIndex', 'sqlserver', NULL, NULL, 'NULL', 'vwSourceReferenceIndex', 'lh_bronze', NULL, NULL, 'vwSourceReferenceIndex', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Currency', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', 'NULL', NULL, 'overwrite', 'Bronze', 1, NULL, 30, 'Bronze', 'Database', 'HMCDataWarehouseCurrency', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataWarehouseCurrency', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexRegionExposure', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', 'NULL', NULL, 'overwrite', 'Bronze', 1, NULL, 29, 'Bronze', 'Database', 'CrimsonXIndexRegionExposure', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonXIndexRegionExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Frequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', 'NULL', NULL, 'overwrite', 'Bronze', 1, NULL, 28, 'Bronze', 'Database', 'CrimsonXFrequency', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonXFrequency', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'Holdings', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 64, 'Bronze', 'Bronze', 'CrimsonXHoldings', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Holdings to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 65, 'Bronze', 'Bronze', 'CrimsonXCashflowTransactionDetail', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CashflowTransactionDetail to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CashflowTransactionSubtype', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 69, 'Bronze', 'Bronze', 'CrimsonXCashflowTransactionSubtype', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CashflowTransactionSubtype to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CashflowTransactionType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 68, 'Bronze', 'Bronze', 'CrimsonXCashflowTransactionType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CashflowTransactionType to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ReturnType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 60, 'Bronze', 'Bronze', 'CrimsonXReturnType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Return Type to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ReturnSource', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 59, 'Bronze', 'Bronze', 'CrimsonXReturnSource', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Return Source to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundConstituentAccounting', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'merge', 'Bronze', 1, NULL, 10, 'Bronze', 'Database', 'FundConstituentAccounting', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, 'FundId', 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Factset', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'merge', 'Bronze', 1, NULL, 3, 'Bronze', 'Facset', 'Factset', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset to Silver', 'lh_curated', NULL, NULL, NULL, NULL, 'SECURITY_ID, DATE', 1, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', '02Test', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'merge', 'Bronze', 1, NULL, 2, 'Bronze', 'Bronze', '02Test', 'Lakehouse', NULL, NULL, 'lh_bronze', '01Test', 'lh_curated', NULL, NULL, NULL, NULL, 'Date', 1, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTrade', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 14, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 116, 'Bronze', 'Database', 'CrimsonXFundTrade', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTrade', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeForecastedTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 13, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 115, 'Bronze', 'Database', 'CrimsonXFundTradeForecastedTransaction', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeForecastedTransaction', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ForecastedCashFlow', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 12, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 114, 'Bronze', 'Database', 'CrimsonXForecastedCashFlow', 'Lakehouse', NULL, NULL, 'lh_bronze', 'ForecastedCashFlowSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'LiquidityTermSchedule', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 7, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 88, 'Bronze', 'Database', 'LiquidityTerms', 'Lakehouse', NULL, NULL, 'lh_bronze', 'LiquidityTermSch', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FXRate', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 4, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 1, NULL, 76, 'Bronze', 'Database', 'FXRate', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FXRate', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 12, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Classification', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 23, NULL, 1, 'NotebookTask', 'CrimsonX', NULL, 'overwrite', 'Database', 1, NULL, 224, NULL, 'Database', 'Classification', 'sqlserver', NULL, NULL, NULL, 'Classification Table to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 28, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'FundReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 57, 'Bronze', 'Bronze', 'CrimsonXFundReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Fund Return to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Note', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 8, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 2, NULL, 91, 'Bronze', 'Blob', 'Note', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Notes To Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 24, NULL
UNION ALL
SELECT NULL, 'SELECT FirmId, FirmName FROM delta.`{bronze_lh_basepath}/Tables/Bronze/CrimsonXFirm`', NULL, NULL, 1, 'Dev - Crimson', 'Firm', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 220, 'Bronze', 'Database', 'CrimsonXFirm', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Firm to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'SELECT
    EntityId AS EntityId,
    FirmId AS FirmId,
    EntityName AS EntityName,
    EntityInvestmentStatusId AS EntityStatus,
    BusinessOwnerHMCUserId AS PrimaryOwner, 
    BackupBusinessOwnerHMCUserId AS SecondaryOwner, 
    AssociateHMCUserId AS Associate,
    SecondaryBackupBusinessOwnerHMCUserId AS TertiaryOwner
FROM delta.`{bronze_lh_basepath}/Tables/Bronze/CrimsonXEntity`', NULL, NULL, 1, 'Dev - Crimson', 'Entity', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 221, 'Bronze', 'Database', 'CrimsonXEntity', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Entity to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, '92b328a7-0bb9-47f9-a4b5-7ac4daf3bb13,5b0a2af0-0c1c-44fe-9233-19d31bff303f', 1, 'Dev - Crimson', 'EntraUsers', 'Dev - Crimson', NULL, 'Bronze', NULL, NULL, NULL, NULL, NULL, 0, 'office365', NULL, NULL, 'overwrite', 'Entra', 1, NULL, 89, NULL, 'Entra', 'BasicDataSet_v0.User_v1', 'office365', '{
    "type": "TabularTranslator",
    "mappings": [
        {
            "source": {
                "name": "accountEnabled",
                "type": "Boolean",
                "physicalType": "boolean"
            },
            "sink": {
                "name": "accountEnabled",
                "physicalType": "boolean"
            }
        },
        {
            "source": {
                "name": "department",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "department",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "givenName",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "givenName",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "mail",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "mail",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "mobilePhone",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "mobilePhone",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "surname",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "surname",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "userPrincipalName",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "userPrincipalName",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "puser",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "puser",
                "physicalType": "string"
            }
        }
    ],
    "typeConversion": true,
    "typeConversionSettings": {
        "allowDataTruncation": true,
        "treatBooleanAsNumber": false
    },
    "columnFlattenSettings": {
        "treatArrayAsString": false,
        "treatStructAsString": false,
        "flattenColumnDelimiter": "."
    }
}', NULL, NULL, 'Entra Users', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 13, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'PrivateFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 118, 'Bronze', 'Database', 'CrimsonXFeesForPrivateModel', 'Lakehouse', NULL, NULL, 'lh_bronze', 'PrivateFees', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'PrivateFeeTiers', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 119, 'Bronze', 'Database', 'CrimsonXFeesForPrivateModelTier', 'Lakehouse', NULL, NULL, 'lh_bronze', 'PrivateFeeTiers', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ForecastedCashFlowType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 112, 'Bronze', 'Database', 'CrimsonXForecastedCashFlowType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'ForecastedCashFlowType', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeApprovalType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 111, 'Bronze', 'Database', 'CrimsonXFundTradeApprovalType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeApprovalType', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 96, 'Bronze', 'Database', 'CrimsonXFundTradeStatus', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeStatusToSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 97, 'Bronze', 'Database', 'CrimsonXFundTradeType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeTypeToSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'EntraUserDevices', 'Dev - Crimson', NULL, 'Bronze', NULL, NULL, NULL, NULL, NULL, 0, 'office365', NULL, NULL, 'overwrite', 'Entra', 1, NULL, 90, NULL, 'Entra', 'BasicDataSet_v0.OwnedDevices_v0', 'office365', NULL, NULL, NULL, 'Entra User Devices', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 13, NULL
UNION ALL
SELECT NULL, NULL, NULL, 'CAST(EndDate AS DATE) = CAST(''9999-12-31'' AS DATE)', 1, 'Dev - Crimson', 'TransactionUniversity', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 219, 'Bronze', 'Database', 'CrimsonXUniversityTransaction', 'Lakehouse', NULL, NULL, 'lh_bronze', 'TransactionUniversity', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentPerformanceGIAReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 87, 'dbo', 'Database', 'PerformanceGIAReturn', 'sqlserver', NULL, NULL, NULL, 'PerformanceGIAReturn', 'lh_bronze', NULL, NULL, 'PerformanceGIAReturn', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentPerformanceFlash', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 86, 'dbo', 'Database', 'PerformanceFlash', 'sqlserver', NULL, NULL, NULL, 'PerformanceFlash', 'lh_bronze', NULL, NULL, 'PerformanceFlash', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentHMCHierarchyAttributes', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 85, 'dbo', 'Database', 'HMCHierarchyAttributes', 'sqlserver', NULL, NULL, NULL, 'HMCHierarchyAttributes', 'lh_bronze', NULL, NULL, 'HMCHierarchyAttributes', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentFundBetaSummaryLog', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 84, 'dbo', 'Database', 'FundBetaSummaryLog', 'sqlserver', NULL, NULL, NULL, 'FundBetaSummaryLog', 'lh_bronze', NULL, NULL, 'FundBetaSummaryLog', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentFundBetaSummaryHeaderLog', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 83, 'dbo', 'Database', 'FundBetaSummaryHeaderLog', 'sqlserver', NULL, NULL, NULL, 'FundBetaSummaryHeaderLog', 'lh_bronze', NULL, NULL, 'FundBetaSummaryHeaderLog', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentBetaAnalyticSummary', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 82, 'dbo', 'Database', 'BetaAnalyticSummary', 'sqlserver', NULL, NULL, NULL, 'BetaAnalyticSummary', 'lh_bronze', NULL, NULL, 'BetaAnalyticSummary', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentBetaAnalytic', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 81, 'dbo', 'Database', 'BetaAnalytic', 'sqlserver', NULL, NULL, NULL, 'BetaAnalytic', 'lh_bronze', NULL, NULL, 'BetaAnalytic', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 133, 'dbo', 'Database', 'ClassificationMap', 'sqlserver', NULL, NULL, NULL, 'ClassificationMap for Solovis Load', 'lh_bronze', NULL, NULL, 'ClassificationMap', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassification', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 132, 'dbo', 'Database', 'Classification', 'sqlserver', NULL, NULL, NULL, 'Classification for Solovis Load', 'lh_bronze', NULL, NULL, 'Classification', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 131, 'dbo', 'Database', 'Entity', 'sqlserver', NULL, NULL, NULL, 'Entity for Solovis Load', 'lh_bronze', NULL, NULL, 'Entity', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 130, 'dbo', 'Database', 'Firm', 'sqlserver', NULL, NULL, NULL, 'Firm for Solovis Load', 'lh_bronze', NULL, NULL, 'Firm', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 129, 'dbo', 'Database', 'Fund', 'sqlserver', NULL, NULL, NULL, 'Fund for Solovis Load', 'lh_bronze', NULL, NULL, 'Fund', NULL, 'FundId', 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 128, 'dbo', 'Database', 'CashflowTransactionDetail', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionDetail for Solovis Load', 'lh_bronze', NULL, NULL, 'CashflowTransactionDetail', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseExternalActiveBook', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 127, 'etl', 'Database', 'vwSolovisLoadHelper_ActiveBookXref', 'sqlserver', NULL, NULL, NULL, 'vwSolovisLoadHelper_ActiveBookXref for Solovis Load', 'lh_bronze', NULL, NULL, 'ExternalActiveBook', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXShareClass', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 126, 'dbo', 'Database', 'ShareClass', 'sqlserver', NULL, NULL, NULL, 'ShareClass for Solovis Load', 'lh_bronze', NULL, NULL, 'ShareClass', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Office365User', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', NULL, 'Office365', 'overwrite', 'Office365', 1, NULL, 44, NULL, 'Database', NULL, 'office365', NULL, NULL, NULL, 'Office365User', 'lh_bronze', NULL, NULL, 'Office365User', NULL, NULL, 0, 8, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundConstituentAccounting', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 4, 'dbo', 'Database', 'FundConstituentAccounting', 'sqlserver', NULL, NULL, '', 'FundConstituentAccounting', 'lh_bronze', NULL, NULL, 'FundConstituentAccounting', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseCurrency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 16, 'dbo', 'Database', 'Currency', 'sqlserver', NULL, NULL, NULL, 'Currency', 'lh_bronze', NULL, NULL, 'Currency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseSolovisCurrency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 46, 'etl', 'Database', 'SolovisCurrency', 'sqlserver', NULL, NULL, NULL, 'SolovisCurrency', 'lh_bronze', NULL, NULL, 'SolovisCurrency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseExternalActiveBook', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 48, 'etl', 'Database', 'vwSolovisLoadHelper_ActiveBookXref', 'sqlserver', NULL, NULL, NULL, 'vwSolovisLoadHelper_ActiveBookXref', 'lh_bronze', NULL, NULL, 'ExternalActiveBook', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseSolovisTransactionMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 61, 'etl', 'Database', 'SolovisTransactionMap', 'sqlserver', NULL, NULL, NULL, 'SolovisTransactionMap', 'lh_bronze', NULL, NULL, 'SolovisTransactionMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'vwUniverseFunds', 'Dev - Crimson', NULL, 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'rawtest', 'overwrite', 'Database', 1, NULL, 53, 'dbo', 'Database', 'vwUniverseFunds', 'sqlserver', NULL, NULL, NULL, 'vwUniverseFunds', 'lh_bronze', NULL, NULL, 'vwUniverseFunds', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXUniverse', 'Dev - Crimson', NULL, 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'rawtest', 'overwrite', 'Database', 1, NULL, 52, 'dbo', 'Database', 'Universe', 'sqlserver', NULL, NULL, NULL, 'Universe', 'lh_bronze', NULL, NULL, 'Universe', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehousevwSourceReferenceFlatten_CrimsonX', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 51, 'dbo', 'Database', 'vwSourceReferenceFlatten_CrimsonX', 'sqlserver', NULL, NULL, NULL, 'vwSourceReferenceFlatten_CrimsonX', 'lh_bronze', NULL, NULL, 'HMCDataWarehousevwSourceReferenceFlatten_CrimsonX', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 11, 'dbo', 'Database', 'Fund', 'sqlserver', NULL, NULL, NULL, 'Fund', 'lh_bronze', NULL, NULL, 'Fund', NULL, 'FundId', 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundReturnSource', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 218, 'dbo', 'Database', 'FundReturnSource', 'sqlserver', NULL, NULL, NULL, 'FundReturnSource', 'lh_bronze', NULL, NULL, 'FundReturnSource', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundReturnType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 217, 'dbo', 'Database', 'FundReturnType', 'sqlserver', NULL, NULL, NULL, 'FundReturnType', 'lh_bronze', NULL, NULL, 'FundReturnType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXAlphaStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 212, 'dbo', 'Database', 'AlphaStrategy', 'sqlserver', NULL, NULL, NULL, 'AlphaStrategy', 'lh_bronze', NULL, NULL, 'AlphaStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXLiquidityCost', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 213, 'dbo', 'Database', 'LiquidityCost', 'sqlserver', NULL, NULL, NULL, 'LiquidityCost', 'lh_bronze', NULL, NULL, 'LiquidityCost', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXWeightedDaysType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 214, 'dbo', 'Database', 'WeightedDaysType', 'sqlserver', NULL, NULL, NULL, 'WeightedDaysType', 'lh_bronze', NULL, NULL, 'WeightedDaysType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundRiskIndexAssociation', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 140, 'dbo', 'Database', 'FundRiskIndexAssociation', 'sqlserver', NULL, NULL, NULL, 'FundRiskIndexAssociation', 'lh_bronze', NULL, NULL, 'FundRiskIndexAssociation', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundRiskStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 144, 'dbo', 'Database', 'FundRiskStatus', 'sqlserver', NULL, NULL, NULL, 'FundRiskStatus', 'lh_bronze', NULL, NULL, 'FundRiskStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXBudgetStrategyClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 210, 'dbo', 'Database', 'BudgetStrategyClassificationMap', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategyClassificationMap', 'lh_bronze', NULL, NULL, 'BudgetStrategyClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXBudgetStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 211, 'dbo', 'Database', 'BudgetStrategy', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategy', 'lh_bronze', NULL, NULL, 'BudgetStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLiquidityCost', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 145, 'dbo', 'Database', 'LiquidityCost', 'sqlserver', NULL, NULL, NULL, 'LiquidityCost', 'lh_bronze', NULL, NULL, 'LiquidityCost', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDBackgroundCheck', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 146, 'dbo', 'Database', 'ODDBackgroundCheck', 'sqlserver', NULL, NULL, NULL, 'ODDBackgroundCheck', 'lh_bronze', NULL, NULL, 'ODDBackgroundCheck', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDBackgroundCheckSubject', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 147, 'dbo', 'Database', 'ODDBackgroundCheckSubject', 'sqlserver', NULL, NULL, NULL, 'ODDBackgroundCheckSubject', 'lh_bronze', NULL, NULL, 'ODDBackgroundCheckSubject', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDCounterPartyType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 148, 'dbo', 'Database', 'ODDCounterPartyType', 'sqlserver', NULL, NULL, NULL, 'ODDCounterPartyType', 'lh_bronze', NULL, NULL, 'ODDCounterPartyType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDCustomFrequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 149, 'dbo', 'Database', 'ODDCustomFrequency', 'sqlserver', NULL, NULL, NULL, 'ODDCustomFrequency', 'lh_bronze', NULL, NULL, 'ODDCustomFrequency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDDocumentRequestType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 150, 'dbo', 'Database', 'ODDDocumentRequestType', 'sqlserver', NULL, NULL, NULL, 'ODDDocumentRequestType', 'lh_bronze', NULL, NULL, 'ODDDocumentRequestType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 151, 'dbo', 'Database', 'ODDEntity', 'sqlserver', NULL, NULL, NULL, 'ODDEntity', 'lh_bronze', NULL, NULL, 'ODDEntity', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 152, 'dbo', 'Database', 'ODDFirm', 'sqlserver', NULL, NULL, NULL, 'ODDFirm', 'lh_bronze', NULL, NULL, 'ODDFirm', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmAdvisor', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 153, 'dbo', 'Database', 'ODDFirmAdvisor', 'sqlserver', NULL, NULL, NULL, 'ODDFirmAdvisor', 'lh_bronze', NULL, NULL, 'ODDFirmAdvisor', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmCrdNumber', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 154, 'dbo', 'Database', 'ODDFirmCrdNumber', 'sqlserver', NULL, NULL, NULL, 'ODDFirmCrdNumber', 'lh_bronze', NULL, NULL, 'ODDFirmCrdNumber', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmStaticDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 155, 'dbo', 'Database', 'ODDFirmStaticDetail', 'sqlserver', NULL, NULL, NULL, 'ODDFirmStaticDetail', 'lh_bronze', NULL, NULL, 'ODDFirmStaticDetail', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmSummary', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 156, 'dbo', 'Database', 'ODDFirmSummary', 'sqlserver', NULL, NULL, NULL, 'ODDFirmSummary', 'lh_bronze', NULL, NULL, 'ODDFirmSummary', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFlag', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 157, 'dbo', 'Database', 'ODDFlag', 'sqlserver', NULL, NULL, NULL, 'ODDFlag', 'lh_bronze', NULL, NULL, 'ODDFlag', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFlagBucket', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 158, 'dbo', 'Database', 'ODDFlagBucket', 'sqlserver', NULL, NULL, NULL, 'ODDFlagBucket', 'lh_bronze', NULL, NULL, 'ODDFlagBucket', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFlagColor', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 159, 'dbo', 'Database', 'ODDFlagColor', 'sqlserver', NULL, NULL, NULL, 'ODDFlagColor', 'lh_bronze', NULL, NULL, 'ODDFlagColor', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 160, 'dbo', 'Database', 'ODDFund', 'sqlserver', NULL, NULL, NULL, 'ODDFund', 'lh_bronze', NULL, NULL, 'ODDFund', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeeting', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 161, 'dbo', 'Database', 'ODDMeeting', 'sqlserver', NULL, NULL, NULL, 'ODDMeeting', 'lh_bronze', NULL, NULL, 'ODDMeeting', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingAdministrator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 162, 'dbo', 'Database', 'ODDMeetingAdministrator', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingAdministrator', 'lh_bronze', NULL, NULL, 'ODDMeetingAdministrator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingAuditor', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 163, 'dbo', 'Database', 'ODDMeetingAuditor', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingAuditor', 'lh_bronze', NULL, NULL, 'ODDMeetingAuditor', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingBackgroundCheckProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 164, 'dbo', 'Database', 'ODDMeetingBackgroundCheckProvider', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingBackgroundCheckProvider', 'lh_bronze', NULL, NULL, 'ODDMeetingBackgroundCheckProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingBank', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 165, 'dbo', 'Database', 'ODDMeetingBank', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingBank', 'lh_bronze', NULL, NULL, 'ODDMeetingBank', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingComplianceConsultant', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 166, 'dbo', 'Database', 'ODDMeetingComplianceConsultant', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingComplianceConsultant', 'lh_bronze', NULL, NULL, 'ODDMeetingComplianceConsultant', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingCounterparty', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 167, 'dbo', 'Database', 'ODDMeetingCounterparty', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingCounterparty', 'lh_bronze', NULL, NULL, 'ODDMeetingCounterparty', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingCustodian', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 168, 'dbo', 'Database', 'ODDMeetingCustodian', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingCustodian', 'lh_bronze', NULL, NULL, 'ODDMeetingCustodian', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingDocumentRequestType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 169, 'dbo', 'Database', 'ODDMeetingDocumentRequestType', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingDocumentRequestType', 'lh_bronze', NULL, NULL, 'ODDMeetingDocumentRequestType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 170, 'dbo', 'Database', 'ODDMeetingEntity', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingEntity', 'lh_bronze', NULL, NULL, 'ODDMeetingEntity', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 171, 'dbo', 'Database', 'ODDMeetingFirm', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingFirm', 'lh_bronze', NULL, NULL, 'ODDMeetingFirm', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingFrequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 172, 'dbo', 'Database', 'ODDMeetingFrequency', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingFrequency', 'lh_bronze', NULL, NULL, 'ODDMeetingFrequency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 173, 'dbo', 'Database', 'ODDMeetingFund', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingFund', 'lh_bronze', NULL, NULL, 'ODDMeetingFund', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingISDA', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 174, 'dbo', 'Database', 'ODDMeetingISDA', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingISDA', 'lh_bronze', NULL, NULL, 'ODDMeetingISDA', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingITProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 175, 'dbo', 'Database', 'ODDMeetingITProvider', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingITProvider', 'lh_bronze', NULL, NULL, 'ODDMeetingITProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingLegalCounsel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 176, 'dbo', 'Database', 'ODDMeetingLegalCounsel', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingLegalCounsel', 'lh_bronze', NULL, NULL, 'ODDMeetingLegalCounsel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingMethod', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 177, 'dbo', 'Database', 'ODDMeetingMethod', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingMethod', 'lh_bronze', NULL, NULL, 'ODDMeetingMethod', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingParticipant', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 178, 'dbo', 'Database', 'ODDMeetingParticipant', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingParticipant', 'lh_bronze', NULL, NULL, 'ODDMeetingParticipant', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingParticipantInternal', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 179, 'dbo', 'Database', 'ODDMeetingParticipantInternal', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingParticipantInternal', 'lh_bronze', NULL, NULL, 'ODDMeetingParticipantInternal', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingPrimaryContact', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 180, 'dbo', 'Database', 'ODDMeetingPrimaryContact', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingPrimaryContact', 'lh_bronze', NULL, NULL, 'ODDMeetingPrimaryContact', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingPrimaryRegulator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 181, 'dbo', 'Database', 'ODDMeetingPrimaryRegulator', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingPrimaryRegulator', 'lh_bronze', NULL, NULL, 'ODDMeetingPrimaryRegulator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingPrimeBroker', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 182, 'dbo', 'Database', 'ODDMeetingPrimeBroker', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingPrimeBroker', 'lh_bronze', NULL, NULL, 'ODDMeetingPrimeBroker', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 183, 'dbo', 'Database', 'ODDMeetingType', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingType', 'lh_bronze', NULL, NULL, 'ODDMeetingType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDNote', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 184, 'dbo', 'Database', 'ODDNote', 'sqlserver', NULL, NULL, NULL, 'ODDNote', 'lh_bronze', NULL, NULL, 'ODDNote', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDPrioritization', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 185, 'dbo', 'Database', 'ODDPrioritization', 'sqlserver', NULL, NULL, NULL, 'ODDPrioritization', 'lh_bronze', NULL, NULL, 'ODDPrioritization', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDRating', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 186, 'dbo', 'Database', 'ODDRating', 'sqlserver', NULL, NULL, NULL, 'ODDRating', 'lh_bronze', NULL, NULL, 'ODDRating', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDRatingCategory', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 187, 'dbo', 'Database', 'ODDRatingCategory', 'sqlserver', NULL, NULL, NULL, 'ODDRatingCategory', 'lh_bronze', NULL, NULL, 'ODDRatingCategory', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXOddTrip', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 188, 'dbo', 'Database', 'OddTrip', 'sqlserver', NULL, NULL, NULL, 'OddTrip', 'lh_bronze', NULL, NULL, 'OddTrip', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXOddTripMeeting', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 189, 'dbo', 'Database', 'OddTripMeeting', 'sqlserver', NULL, NULL, NULL, 'OddTripMeeting', 'lh_bronze', NULL, NULL, 'OddTripMeeting', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXOddTripMeetingAttendee', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 190, 'dbo', 'Database', 'OddTripMeetingAttendee', 'sqlserver', NULL, NULL, NULL, 'OddTripMeetingAttendee', 'lh_bronze', NULL, NULL, 'OddTripMeetingAttendee', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXISDA', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 191, 'dbo', 'Database', 'ISDA', 'sqlserver', NULL, NULL, NULL, 'ISDA', 'lh_bronze', NULL, NULL, 'ISDA', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXITProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 192, 'dbo', 'Database', 'ITProvider', 'sqlserver', NULL, NULL, NULL, 'ITProvider', 'lh_bronze', NULL, NULL, 'ITProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrimaryRegulator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 193, 'dbo', 'Database', 'PrimaryRegulator', 'sqlserver', NULL, NULL, NULL, 'PrimaryRegulator', 'lh_bronze', NULL, NULL, 'PrimaryRegulator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrimeBroker', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 194, 'dbo', 'Database', 'PrimeBroker', 'sqlserver', NULL, NULL, NULL, 'PrimeBroker', 'lh_bronze', NULL, NULL, 'PrimeBroker', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLegalCounsel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 195, 'dbo', 'Database', 'LegalCounsel', 'sqlserver', NULL, NULL, NULL, 'LegalCounsel', 'lh_bronze', NULL, NULL, 'LegalCounsel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCustodian', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 196, 'dbo', 'Database', 'Custodian', 'sqlserver', NULL, NULL, NULL, 'Custodian', 'lh_bronze', NULL, NULL, 'Custodian', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXAdministrator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 197, 'dbo', 'Database', 'Administrator', 'sqlserver', NULL, NULL, NULL, 'Administrator', 'lh_bronze', NULL, NULL, 'Administrator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXComplianceConsultant', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 198, 'dbo', 'Database', 'ComplianceConsultant', 'sqlserver', NULL, NULL, NULL, 'ComplianceConsultant', 'lh_bronze', NULL, NULL, 'ComplianceConsultant', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBank', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 199, 'dbo', 'Database', 'Bank', 'sqlserver', NULL, NULL, NULL, 'Bank', 'lh_bronze', NULL, NULL, 'Bank', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBackgroundCheckProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 200, 'dbo', 'Database', 'BackgroundCheckProvider', 'sqlserver', NULL, NULL, NULL, 'BackgroundCheckProvider', 'lh_bronze', NULL, NULL, 'BackgroundCheckProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundrisk', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 139, 'dbo', 'Database', 'Fundrisk', 'sqlserver', NULL, NULL, NULL, 'Fundrisk', 'lh_bronze', NULL, NULL, 'Fundrisk', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskIndexAssociationRequest', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 141, 'dbo', 'Database', 'FundRiskIndexAssociationRequest', 'sqlserver', NULL, NULL, NULL, 'FundRiskIndexAssociationRequest', 'lh_bronze', NULL, NULL, 'FundRiskIndexAssociationRequest', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskRequest', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 142, 'dbo', 'Database', 'FundRiskRequest', 'sqlserver', NULL, NULL, NULL, 'FundRiskRequest', 'lh_bronze', NULL, NULL, 'FundRiskRequest', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskRequestLog', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 143, 'dbo', 'Database', 'FundRiskRequestLog', 'sqlserver', NULL, NULL, NULL, 'FundRiskRequestLog', 'lh_bronze', NULL, NULL, 'FundRiskRequestLog', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTagType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 138, 'dbo', 'Database', 'TagType', 'sqlserver', NULL, NULL, NULL, 'TagType', 'lh_bronze', NULL, NULL, 'TagType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTagOwner', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 137, 'dbo', 'Database', 'TagOwner', 'sqlserver', NULL, NULL, NULL, 'TagOwner', 'lh_bronze', NULL, NULL, 'TagOwner', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTagMaster', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 136, 'dbo', 'Database', 'TagMaster', 'sqlserver', NULL, NULL, NULL, 'TagMaster', 'lh_bronze', NULL, NULL, 'TagMaster', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTag', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 135, 'dbo', 'Database', 'Tag', 'sqlserver', NULL, NULL, NULL, 'Tag', 'lh_bronze', NULL, NULL, 'Tag', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXUniversityTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 134, 'dbo', 'Database', 'UniversityTransaction', 'sqlserver', NULL, NULL, NULL, 'UniversityTransaction', 'lh_bronze', NULL, NULL, 'UniversityTransaction', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrivateFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 98, 'dbo', 'Database', 'FeesForPrivateModel', 'sqlserver', NULL, NULL, NULL, 'PrivateFees', 'lh_bronze', NULL, NULL, 'PrivateFees', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrivateFeeTiers', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 99, 'dbo', 'Database', 'FeesForPrivateModelTier', 'sqlserver', NULL, NULL, NULL, 'PrivateFeeTiers', 'lh_bronze', NULL, NULL, 'PrivateFeeTiers', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeePaymentFrequencyType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 101, 'dbo', 'Database', 'FeePaymentFrequencyType', 'sqlserver', NULL, NULL, NULL, 'FeePaymentFrequencyType', 'lh_bronze', NULL, NULL, 'FeePaymentFrequencyType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeBasisType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 102, 'dbo', 'Database', 'FeeBasisType', 'sqlserver', NULL, NULL, NULL, 'FeeBasisType', 'lh_bronze', NULL, NULL, 'FeeBasisType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeHurdleType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 104, 'dbo', 'Database', 'FeeHurdleType', 'sqlserver', NULL, NULL, NULL, 'FeeHurdleType', 'lh_bronze', NULL, NULL, 'FeeHurdleType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXShareClass', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 47, 'dbo', 'Database', 'ShareClass', 'sqlserver', NULL, NULL, NULL, 'ShareClass', 'lh_bronze', NULL, NULL, 'ShareClass', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPipelineStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 42, 'dbo', 'Database', 'PipelineStatus', 'sqlserver', NULL, NULL, NULL, 'PipelineStatus', 'lh_bronze', NULL, NULL, 'PipelineStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeTierBasisType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 41, 'dbo', 'Database', 'FeeTierBasisType', 'sqlserver', NULL, NULL, NULL, 'FeeTierBasisType', 'lh_bronze', NULL, NULL, 'FeeTierBasisType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeCarryMethodType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 40, 'dbo', 'Database', 'FeeCarryMethodType', 'sqlserver', NULL, NULL, NULL, 'FeeCarryMethodType', 'lh_bronze', NULL, NULL, 'FeeCarryMethodType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLiquidityTermSchedule', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 39, 'dbo', 'Database', 'LiquidityTermSchedule', 'sqlserver', NULL, NULL, NULL, 'LiquidityTermSchedule', 'lh_bronze', NULL, NULL, 'LiquidityTermSchedule', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeesForPrivateModelTier', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 38, 'dbo', 'Database', 'FeesForPrivateModelTier', 'sqlserver', NULL, NULL, NULL, 'FeesForPrivateModelTier', 'lh_bronze', NULL, NULL, 'FeesForPrivateModelTier', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeesForPrivateModel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 37, 'dbo', 'Database', 'FeesForPrivateModel', 'sqlserver', NULL, NULL, NULL, 'FeesForPrivateModel', 'lh_bronze', NULL, NULL, 'FeesForPrivateModel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBetaCategory', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 36, 'dbo', 'Database', 'BetaCategory', 'sqlserver', NULL, NULL, NULL, 'BetaCategory', 'lh_bronze', NULL, NULL, 'BetaCategory', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskIndexAssociation', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 35, 'dbo', 'Database', 'FundRiskIndexAssociation', 'sqlserver', NULL, NULL, NULL, 'FundRiskIndexAssociation', 'lh_bronze', NULL, NULL, 'FundRiskIndexAssociation', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeesForPublicModel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 34, 'dbo', 'Database', 'FeesForPublicModel', 'sqlserver', NULL, NULL, NULL, 'FeesForPublicModel', 'lh_bronze', NULL, NULL, 'FeesForPublicModel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntityStatistics', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 33, 'dbo', 'Database', 'EntityStatistics', 'sqlserver', NULL, NULL, NULL, 'EntityStatistics', 'lh_bronze', NULL, NULL, 'EntityStatistics', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXAlphaStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 32, 'dbo', 'Database', 'AlphaStrategy', 'sqlserver', NULL, NULL, NULL, 'AlphaStrategy', 'lh_bronze', NULL, NULL, 'AlphaStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRisk', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 31, 'dbo', 'Database', 'FundRisk', 'sqlserver', NULL, NULL, NULL, 'FundRisk', 'lh_bronze', NULL, NULL, 'FundRisk', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXSectorIndustry', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 25, 'dbo', 'Database', 'SectorIndustry', 'sqlserver', NULL, NULL, NULL, 'SectorIndustry', 'lh_bronze', NULL, NULL, 'SectorIndustry', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXSector', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 24, 'dbo', 'Database', 'Sector', 'sqlserver', NULL, NULL, NULL, 'Sector', 'lh_bronze', NULL, NULL, 'Sector', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXSectorIndustryClassification', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 23, 'dbo', 'Database', 'SectorIndustryClassification', 'sqlserver', NULL, NULL, NULL, 'SectorIndustryClassification', 'lh_bronze', NULL, NULL, 'SectorIndustryClassification', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXGeographicStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 22, 'dbo', 'Database', 'GeographicStrategy', 'sqlserver', NULL, NULL, NULL, 'GeographicStrategy', 'lh_bronze', NULL, NULL, 'GeographicStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCountry', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 20, 'dbo', 'Database', 'Country', 'sqlserver', NULL, NULL, NULL, 'Country', 'lh_bronze', NULL, NULL, 'Country', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCountryRegion', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 21, 'dbo', 'Database', 'CountryRegion', 'sqlserver', NULL, NULL, NULL, 'CountryRegion', 'lh_bronze', NULL, NULL, 'CountryRegion', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexRegionExposure', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 19, 'dbo', 'Database', 'IndexRegionExposure', 'sqlserver', NULL, NULL, NULL, 'IndexRegionExposure', 'lh_bronze', NULL, NULL, 'IndexRegionExposure', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndex', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 17, 'dbo', 'Database', 'Index', 'sqlserver', NULL, NULL, NULL, 'Index', 'lh_bronze', NULL, NULL, 'Index', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFrequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 18, 'dbo', 'Database', 'Frequency', 'sqlserver', NULL, NULL, NULL, 'Frequency', 'lh_bronze', NULL, NULL, 'Frequency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassification', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 14, 'dbo', 'Database', 'Classification', 'sqlserver', NULL, NULL, NULL, 'Classification', 'lh_bronze', NULL, NULL, 'Classification', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 13, 'dbo', 'Database', 'Firm', 'sqlserver', NULL, NULL, NULL, 'Firm', 'lh_bronze', NULL, NULL, 'Firm', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 12, 'dbo', 'Database', 'Entity', 'sqlserver', NULL, NULL, NULL, 'Entity', 'lh_bronze', NULL, NULL, 'Entity', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 9, 'dbo', 'Database', 'FundTradeType', 'sqlserver', NULL, NULL, NULL, 'FundTradeType', 'lh_bronze', NULL, NULL, 'FundTradeType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 8, 'dbo', 'Database', 'FundTradeStatus', 'sqlserver', NULL, NULL, NULL, 'FundTradeStatus', 'lh_bronze', NULL, NULL, 'FundTradeStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeForecastedTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 7, 'dbo', 'Database', 'FundTradeForecastedTransaction', 'sqlserver', NULL, NULL, NULL, 'FundTradeForecastedTransaction', 'lh_bronze', NULL, NULL, 'FundTradeForecastedTransaction', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeApproval', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 6, 'dbo', 'Database', 'FundTradeApproval', 'sqlserver', NULL, NULL, NULL, 'FundTradeApproval', 'lh_bronze', NULL, NULL, 'FundTradeApproval', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTrade', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 5, 'dbo', 'Database', 'FundTrade', 'sqlserver', NULL, NULL, NULL, 'FundTrade', 'lh_bronze', NULL, NULL, 'FundTrade', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 15, 'dbo', 'Database', 'ClassificationMap', 'sqlserver', NULL, NULL, NULL, 'ClassificationMap', 'lh_bronze', NULL, NULL, 'ClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 74, 'dbo', 'Database', 'FundRiskStatus', 'sqlserver', NULL, NULL, NULL, 'FundRiskStatus', 'lh_bronze', NULL, NULL, 'FundRiskStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntityRating', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 72, 'dbo', 'Database', 'EntityRating', 'sqlserver', NULL, NULL, NULL, 'EntityRating', 'lh_bronze', NULL, NULL, 'EntityRating', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundStructure', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 71, 'dbo', 'Database', 'FundStructure', 'sqlserver', NULL, NULL, NULL, 'FundStructure', 'lh_bronze', NULL, NULL, 'FundStructure', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXHoldings', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 58, 'dbo', 'Database', 'Holdings', 'sqlserver', NULL, NULL, NULL, 'Holdings', 'lh_bronze', NULL, NULL, 'Holdings', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXReturnType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 56, 'dbo', 'Database', 'ReturnType', 'sqlserver', NULL, NULL, NULL, 'ReturnType', 'lh_bronze', NULL, NULL, 'ReturnType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionSubtype', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 67, 'dbo', 'Database', 'CashflowTransactionSubtype', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionSubtype', 'lh_bronze', NULL, NULL, 'CashflowTransactionSubtype', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXReturnSource', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 55, 'dbo', 'Database', 'ReturnSource', 'sqlserver', NULL, NULL, NULL, 'ReturnSource', 'lh_bronze', NULL, NULL, 'ReturnSource', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 66, 'dbo', 'Database', 'CashflowTransactionType', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionType', 'lh_bronze', NULL, NULL, 'CashflowTransactionType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, 'ReturnDate <> ''0001-01-01''', 1, 'Dev - Crimson', 'CrimsonXFundReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 54, 'dbo', 'Database', 'FundReturn', 'sqlserver', NULL, NULL, NULL, 'FundReturn', 'lh_bronze', NULL, NULL, 'FundReturn', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTimePeriod', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 122, 'dbo', 'Database', 'TimePeriod', 'sqlserver', NULL, NULL, NULL, 'TimePeriod', 'lh_bronze', NULL, NULL, 'TimePeriod', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundStatistics', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 120, 'dbo', 'Database', 'FundStatistics', 'sqlserver', NULL, NULL, NULL, 'FundStatistics', 'lh_bronze', NULL, NULL, 'FundStatistics', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 70, 'dbo', 'Database', 'CashflowTransactionDetail', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionDetail', 'lh_bronze', NULL, NULL, 'CashflowTransactionDetail', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXForecastedCashFlow', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 108, 'dbo', 'Database', 'ForecastedCashFlow', 'sqlserver', NULL, NULL, NULL, 'ForecastedCashFlow', 'lh_bronze', NULL, NULL, 'ForecastedCashFlow', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXForecastedCashFlowType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 107, 'dbo', 'Database', 'ForecastedCashFlowType', 'sqlserver', NULL, NULL, NULL, 'ForecastedCashFlowType', 'lh_bronze', NULL, NULL, 'ForecastedCashFlowType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeApprovalType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 106, 'dbo', 'Database', 'FundTradeApprovalType', 'sqlserver', NULL, NULL, NULL, 'FundTradeApprovalType', 'lh_bronze', NULL, NULL, 'FundTradeApprovalType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXHMCUser', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 93, 'dbo', 'Database', 'HMCUser', 'sqlserver', NULL, NULL, NULL, 'HMCUser', 'lh_bronze', NULL, NULL, 'HMCUser', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBudgetStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 80, 'dbo', 'Database', 'BudgetStrategy', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategy', 'lh_bronze', NULL, NULL, 'BudgetStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashFlowTransactionType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 79, 'dbo', 'Database', 'CashFlowTransactionType', 'sqlserver', NULL, NULL, NULL, 'CashFlowTransactionType', 'lh_bronze', NULL, NULL, 'CashFlowTransactionType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFirmAttribute', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 78, 'dbo', 'Database', 'FirmAttribute', 'sqlserver', NULL, NULL, NULL, 'FirmAttribute', 'lh_bronze', NULL, NULL, 'FirmAttribute', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXvwClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 223, 'dbo', 'Database', 'vwClassificationMap', 'sqlserver', NULL, NULL, NULL, 'vwClassificationMap to Bronze', 'lh_bronze', NULL, NULL, 'vwClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBudgetStrategyClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 222, 'dbo', 'Database', 'BudgetStrategyClassificationMap', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategyClassificationMap to Bronze', 'lh_bronze', NULL, NULL, 'BudgetStrategyClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundValuation', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 216, 'dbo', 'Database', 'FundValuation', 'sqlserver', NULL, NULL, NULL, 'FundValuation', 'lh_bronze', NULL, NULL, 'FundValuation', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBudgetStrategyClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 204, 'dbo', 'Database', 'BudgetStrategyClassificationMap', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategyClassificationMap', 'lh_bronze', NULL, NULL, 'BudgetStrategyClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXWeightedDaysType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 205, 'dbo', 'Database', 'WeightedDaysType', 'sqlserver', NULL, NULL, NULL, 'WeightedDaysType', 'lh_bronze', NULL, NULL, 'WeightedDaysType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCHierarchyAttributes', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 233, 'Bronze', 'Database', 'HMCDataMartInvestmentHMCHierarchyAttributes', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataMartInvestmentHMCHierarchyAttributes to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'PerformanceFlash', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 234, 'Bronze', 'Database', 'HMCDataMartInvestmentPerformanceFlash', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataMartInvestmentPerformanceFlash', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'PerformanceGIAReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 235, 'Bronze', 'Database', 'HMCDataMartInvestmentPerformanceGIAReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataMartInvestmentPerformanceGIAReturn', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, '
SELECT
    sc.InvestmentResourceId,
    sc.Date,
    coalesce(CAST(sc.WholeValue AS DECIMAL(35,2)), 0) -
    coalesce(LAG(CAST(sc.WholeValue AS DECIMAL(35,2))) OVER (
        PARTITION BY sc.InvestmentResourceId
        ORDER BY CAST(sc.Date AS DATE)
    ), 0) AS Amount,
    coalesce(LAG(CAST(sc.WholeValue AS DECIMAL(35,2))) OVER (
        PARTITION BY sc.InvestmentResourceId
        ORDER BY CAST(sc.Date AS DATE)
    ), 0) AS PreviousAmount,
    abfm.FundId,
    abfm.ShareClassId,
    sc.WholeValue,
    sc.DeltaValue
FROM delta.`{bronze_lh_basepath}/Tables/Bronze/SolovisCommitments` sc
JOIN delta.`{bronze_lh_basepath}/Tables/Bronze/SolovisActiveBookFundMapping` abfm
    ON sc.InvestmentResourceId = abfm.InvestmentResourceId
ORDER BY CAST(sc.Date AS DATE)', NULL, NULL, 1, 'Dev - Crimson', 'FundCommitment', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 231, 'Bronze', 'Database', 'SolovisCommitments', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Solovis Commitments', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, 'SELECT
    c.id                    AS conversationId,
    c.name                  AS conversationName,
    c.userId,
    c.integrationName,
    c.createdAt             AS conversationCreatedAt,
    c.updatedAt             AS conversationUpdatedAt,
    c.tokensRemaining,
    c.tokenCount,
    c._self,
    c._rid,
    c._attachments,
    c._ts,
    m.id                    AS messageId,
    m.role                  AS messageRole,
    m.content               AS messageContent,
    m.createdAt             AS messageCreatedAt,
    (IS_DEFINED(m.metadata) ? m.metadata : {})                         AS messageMetadata,
    (IS_DEFINED(m.metadata.visible)            ? m.metadata.visible            : null) AS metadata_visible,
    (IS_DEFINED(m.metadata.source)             ? m.metadata.source             : null) AS metadata_source,
    (IS_DEFINED(m.metadata.functionArguments)  ? m.metadata.functionArguments  : null) AS metadata_functionArguments,
    (IS_DEFINED(m.metadata.functionName)       ? m.metadata.functionName       : null) AS metadata_functionName
FROM ChatHistory c
JOIN m IN c.messages', NULL, NULL, 1, 'Dev - Crimson', 'ChatAiDbChatHistory', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'ChatAiDb', 'chatAiDb', 'overwrite', 'chatAiDb', 1, NULL, 230, NULL, 'ChatHistory CosmosDB', 'ChatHistory', 'cosmosdb', NULL, NULL, NULL, 'Get ChatHistory', 'lh_bronze', NULL, NULL, 'ChatHistory', NULL, NULL, 0, 29, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', NULL, 'ETLLoadDateTime', NULL, NULL, 26, NULL, 1, 'NotebookTask', NULL, 'Files/IncomingFeed/CyberSecurityDashboard/SpyCloud', 'overwrite', 'SpyCloud', 1, NULL, 229, NULL, 'API', NULL, 'SpyCloud', NULL, NULL, NULL, 'SpyCloudDataCall', NULL, NULL, NULL, 'Spycloud_data.parquet', NULL, NULL, 1, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 17, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 4, NULL, 125, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturnSilver Frequency', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 24, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 3, NULL, 225, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturn Computed Benchmarks', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 15, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 1, NULL, 123, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturnSilver Gap Fill', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', NULL, 'ETLLoadDateTime', NULL, NULL, 1, NULL, 1, 'NotebookTask', NULL, 'Files/IncomingFeed/CyberSecurityDashboard/KnowBe4', 'overwrite', 'KnowBe4', 1, NULL, 45, NULL, 'API', NULL, 'KnowBe4', NULL, NULL, NULL, 'KnowBe4ApiPhishingTestsCall', NULL, NULL, NULL, 'knowbe4_data.parquet', NULL, NULL, 1, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', NULL, NULL, NULL, NULL, NULL, 25, NULL, 1, 'NotebookTask', NULL, 'Files/IncomingFeed/CyberSecurityDashboard/KnowBe4', 'overwrite', 'KnowBe4', 1, NULL, 228, NULL, 'API', NULL, 'KnowBe4', NULL, NULL, NULL, 'KnowBe4ApiUsersCall', NULL, NULL, NULL, 'users_output.parquet', NULL, NULL, 0, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'PublicFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 117, 'Bronze', 'Database', 'CrimsonXFeesForPublicModel', 'Lakehouse', NULL, NULL, 'lh_bronze', 'PublicFees', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 19, NULL, 0, 'NotebookTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 2, 'hmc-report/api/v1/BottomUp/FundLevelCalc?caseId=3&useBetaSummaryGia=false&asOfDate=7/15/2025&numYears=10&calculationMethodology=1&fundCycleMethodology=0&fundCycleModelId=1', 203, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, 'lh_raw', 'Bottom Up Data to Bronze', 'lh_bronze', NULL, NULL, 'FundLevelCalc.json', NULL, NULL, 0, 23, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 19, NULL, 0, 'NotebookTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 2, 'hmc-report/api/v1/BottomUp/FundLevelCalcMonthly?caseId=3&useBetaSummaryGIA=false&useLTM=false&asOfDate=7/23/2025&reportDate=7/24/2025&calculationMethodology=1&numYears=3&fundCycleMethodology=0&fundCycleModelId=1', 227, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, 'lh_raw', 'Bottom Up Monthly Data to Bronze', 'lh_bronze', NULL, NULL, 'FundLevelCalcMonthly.json', NULL, NULL, 0, 23, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', NULL, NULL, NULL, NULL, 'CrimsonPreAPI', NULL, NULL, 0, 'ApiTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 1, 'hmc-report/api/v1/BottomUp/FundLevelCalcMonthly?caseId=3&useBetaSummaryGIA=false&useLTM=false&asOfDate=7/23/2025&reportDate=7/24/2025&calculationMethodology=1&numYears=3&fundCycleMethodology=0&fundCycleModelId=1', 208, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, NULL, 'FundLevelCalcMonthly to Raw', 'lh_raw', NULL, NULL, 'FundLevelCalcMonthly.json', NULL, NULL, 0, 27, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', NULL, NULL, NULL, NULL, 'CrimsonDevAPI', NULL, NULL, 0, 'ApiTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 1, 'hmc-report/api/v1/BottomUp/FundLevelCalc?caseId=3&useBetaSummaryGia=false&asOfDate=7/15/2025&numYears=10&calculationMethodology=1&fundCycleMethodology=0&fundCycleModelId=1', 207, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, NULL, 'FundLevelCalc to Raw', 'lh_raw', NULL, NULL, 'FundLevelCalc.json', NULL, NULL, 0, 25, NULL
UNION ALL
SELECT NULL, 'SELECT fs.CustomRiskBenchmark, tp.Description, fs.FundId, tp.TimePeriodId, fs.FundStatisticReferenceTypeId FROM delta.`{bronze_lh_basepath}/Tables/Bronze/CrimsonXFundStatistics` fs JOIN delta.`{bronze_lh_basepath}/Tables/Bronze/CrimsonXTimePeriod` tp ON fs.TimePeriodId = tp.TimePeriodId WHERE fs.CustomRiskBenchmark IS NOT NULL AND fs.FundStatisticReferenceTypeId = 1', NULL, NULL, 1, 'Dev - Crimson', 'CustomRiskBenchmark', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 226, 'Bronze', 'Database', 'CrimsonXFundStatistics', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CustomRiskBenchmark to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
)
UPDATE target
SET
    target.SinkWarehouseName = source.SinkWarehouseName,
    target.CustomSQLSourceQuery = source.CustomSQLSourceQuery,
    target.SinkLakehouseId = source.SinkLakehouseId,
    target.SourceWhereClause = source.SourceWhereClause,
    target.IsActiveFlag = source.IsActiveFlag,
    target.SourceWorkspaceName = source.SourceWorkspaceName,
    target.SinkTableName = source.SinkTableName,
    target.SinkWorkspaceName = source.SinkWorkspaceName,
    target.SinkWatermarkColumn = source.SinkWatermarkColumn,
    target.SinkSchemaName = source.SinkSchemaName,
    target.SourceWatermarkColumn = source.SourceWatermarkColumn,
    target.SourceFlatfileConnectionSettings = source.SourceFlatfileConnectionSettings,
    target.SourceConnectionName = source.SourceConnectionName,
    target.NotebookKey = source.NotebookKey,
    target.SinkWorkspaceId = source.SinkWorkspaceId,
    target.ArchiveOriginalFilesFlag = source.ArchiveOriginalFilesFlag,
    target.TaskType = source.TaskType,
    target.SourceDatabaseName = source.SourceDatabaseName,
    target.RawStoragePath = source.RawStoragePath,
    target.SinkLoadMethod = source.SinkLoadMethod,
    target.SourceName = source.SourceName,
    target.TaskRunOrderNbr = source.TaskRunOrderNbr,
    target.RelativeUrl = source.RelativeUrl,
    target.SourceSchemaName = source.SourceSchemaName,
    target.ParentSourceName = source.ParentSourceName,
    target.SourceTableName = source.SourceTableName,
    target.SourceType = source.SourceType,
    target.CustomPipelineCode = source.CustomPipelineCode,
    target.SourceExtractionMethod = source.SourceExtractionMethod,
    target.SourceLakehouseName = source.SourceLakehouseName,
    target.TaskName = source.TaskName,
    target.SinkLakehouseName = source.SinkLakehouseName,
    target.ArchiveStoragePath = source.ArchiveStoragePath,
    target.SourceWarehouseName = source.SourceWarehouseName,
    target.RawStorageFileName = source.RawStorageFileName,
    target.ArchiveStorageFileName = source.ArchiveStorageFileName,
    target.PrimaryKeyColumnList = source.PrimaryKeyColumnList,
    target.IsWatermarkEnabledFlag = source.IsWatermarkEnabledFlag,
    target.JobKey = source.JobKey,
    target.OverrideQuery = source.OverrideQuery
FROM etlControl.etl.Task AS target
JOIN source
    ON target.TaskKey = source.TaskKey;

-- ===== INSERT NEW ROWS =====
WITH source (SinkWarehouseName, CustomSQLSourceQuery, SinkLakehouseId, SourceWhereClause, IsActiveFlag, SourceWorkspaceName, SinkTableName, SinkWorkspaceName, SinkWatermarkColumn, SinkSchemaName, SourceWatermarkColumn, SourceFlatfileConnectionSettings, SourceConnectionName, NotebookKey, SinkWorkspaceId, ArchiveOriginalFilesFlag, TaskType, SourceDatabaseName, RawStoragePath, SinkLoadMethod, SourceName, TaskRunOrderNbr, RelativeUrl, TaskKey, SourceSchemaName, ParentSourceName, SourceTableName, SourceType, CustomPipelineCode, SourceExtractionMethod, SourceLakehouseName, TaskName, SinkLakehouseName, ArchiveStoragePath, SourceWarehouseName, RawStorageFileName, ArchiveStorageFileName, PrimaryKeyColumnList, IsWatermarkEnabledFlag, JobKey, OverrideQuery) AS (
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'SolovisExternalActiveBook', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 232, 'etl', 'Database', 'vwSolovisLoadHelper_ActiveBookXref', 'sqlserver', NULL, NULL, NULL, 'SolovisExternalActiveBook', 'lh_bronze', NULL, NULL, 'SolovisExternalActiveBook', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'IndexReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 95, 'Bronze', 'Database', 'IndexReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'WarehouseIndexReturn', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Index', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 27, 'Bronze', 'Database', 'CrimsonXIndex', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonIndex', 'lh_silver', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'IndexReturn_readonly', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 110, 'Bronze', 'Database', 'IndexReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'WarehouseIndexRet_RO', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'IndexReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 77, 'etl', 'Database', 'vwIndexReturnCrimsonXGUID', 'sqlserver', NULL, NULL, NULL, 'WarehouseIndexReturn', 'lh_bronze', NULL, NULL, 'IndexReturnRaw', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexCustomBlendRecipe', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 236, 'etl', 'Database', 'vwIndexBlendRecipeCrimsonXGUID', 'sqlserver', NULL, NULL, NULL, 'IndexCustomBlendRecipe', 'lh_bronze', NULL, NULL, 'IndexCustomBlendRecipe', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'IndexCustomBlendRecipe', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 237, 'Bronze', 'Database', 'CrimsonXIndexCustomBlendRecipe', 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexCustomBlendRecipe', 'lh_silver', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'SolovisActiveBookFundMapping', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 10, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 2, NULL, 94, 'Bronze', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Build ActiveBook & Fund Mappings', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 16, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 2, NULL, 124, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturnSilver Levels', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CashflowTransactionDetail', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 11, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 1, NULL, 109, NULL, 'Solovis', NULL, 'Lakehouse', NULL, NULL, NULL, 'Solovis Transactions Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCUsers', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 9, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Entra', 1, NULL, 92, NULL, 'Entra', NULL, 'Lakehouse', NULL, NULL, NULL, 'Entra Users Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 18, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Universe', 'Dev - Crimson', NULL, 'Silver', NULL, NULL, NULL, 3, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 63, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonXSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Region', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 5, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 75, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset-IndexRegionExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'RegionCountry', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 2, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 49, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset-IndexRegionCountryExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'SectorIndustry', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 6, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 50, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset-IndexSectorIndustryExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 21, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'CrimsonXCashflowTransactionDetail', 2, NULL, 209, 'Bronze', 'Bronze', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'Update CashflowTransactionDetail USD Amounts with correct FX Rate', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 22, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Crimson HMC API', 3, NULL, 215, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, 'lh_bronze', 'Bottom Up Data to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 26, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundMarketValue', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 20, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Solovis', 1, NULL, 206, 'Silver', 'Solovis', NULL, 'Lakehouse', NULL, NULL, 'lh_curated', 'Solovis Market Values Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Fund', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 18, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 202, 'Bronze', 'Database', 'CrimsonXFund', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehousevwSourceReferenceIndex', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, -1, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 43, 'dbo', 'Database', 'vwSourceReferenceIndex', 'sqlserver', NULL, NULL, 'NULL', 'vwSourceReferenceIndex', 'lh_bronze', NULL, NULL, 'vwSourceReferenceIndex', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Currency', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', 'NULL', NULL, 'overwrite', 'Bronze', 1, NULL, 30, 'Bronze', 'Database', 'HMCDataWarehouseCurrency', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataWarehouseCurrency', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexRegionExposure', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', 'NULL', NULL, 'overwrite', 'Bronze', 1, NULL, 29, 'Bronze', 'Database', 'CrimsonXIndexRegionExposure', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonXIndexRegionExposure', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Frequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', 'NULL', NULL, 'overwrite', 'Bronze', 1, NULL, 28, 'Bronze', 'Database', 'CrimsonXFrequency', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CrimsonXFrequency', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'Holdings', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 64, 'Bronze', 'Bronze', 'CrimsonXHoldings', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Holdings to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 65, 'Bronze', 'Bronze', 'CrimsonXCashflowTransactionDetail', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CashflowTransactionDetail to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CashflowTransactionSubtype', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 69, 'Bronze', 'Bronze', 'CrimsonXCashflowTransactionSubtype', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CashflowTransactionSubtype to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CashflowTransactionType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 68, 'Bronze', 'Bronze', 'CrimsonXCashflowTransactionType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CashflowTransactionType to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ReturnType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 60, 'Bronze', 'Bronze', 'CrimsonXReturnType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Return Type to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ReturnSource', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 59, 'Bronze', 'Bronze', 'CrimsonXReturnSource', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Return Source to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundConstituentAccounting', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'merge', 'Bronze', 1, NULL, 10, 'Bronze', 'Database', 'FundConstituentAccounting', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Bronze to Silver', 'lh_curated', NULL, NULL, NULL, NULL, 'FundId', 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Factset', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'merge', 'Bronze', 1, NULL, 3, 'Bronze', 'Facset', 'Factset', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Factset to Silver', 'lh_curated', NULL, NULL, NULL, NULL, 'SECURITY_ID, DATE', 1, 10, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', '02Test', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'merge', 'Bronze', 1, NULL, 2, 'Bronze', 'Bronze', '02Test', 'Lakehouse', NULL, NULL, 'lh_bronze', '01Test', 'lh_curated', NULL, NULL, NULL, NULL, 'Date', 1, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTrade', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 14, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 116, 'Bronze', 'Database', 'CrimsonXFundTrade', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTrade', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeForecastedTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 13, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 115, 'Bronze', 'Database', 'CrimsonXFundTradeForecastedTransaction', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeForecastedTransaction', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ForecastedCashFlow', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 12, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 114, 'Bronze', 'Database', 'CrimsonXForecastedCashFlow', 'Lakehouse', NULL, NULL, 'lh_bronze', 'ForecastedCashFlowSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'LiquidityTermSchedule', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 7, NULL, 0, 'NotebookTask', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 88, 'Bronze', 'Database', 'LiquidityTerms', 'Lakehouse', NULL, NULL, 'lh_bronze', 'LiquidityTermSch', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FXRate', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 4, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 1, NULL, 76, 'Bronze', 'Database', 'FXRate', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FXRate', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 12, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Classification', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 23, NULL, 1, 'NotebookTask', 'CrimsonX', NULL, 'overwrite', 'Database', 1, NULL, 224, NULL, 'Database', 'Classification', 'sqlserver', NULL, NULL, NULL, 'Classification Table to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 28, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'FundReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, -1, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 57, 'Bronze', 'Bronze', 'CrimsonXFundReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Fund Return to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Note', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 8, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 2, NULL, 91, 'Bronze', 'Blob', 'Note', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Notes To Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 24, NULL
UNION ALL
SELECT NULL, 'SELECT FirmId, FirmName FROM delta.`{bronze_lh_basepath}/Tables/Bronze/CrimsonXFirm`', NULL, NULL, 1, 'Dev - Crimson', 'Firm', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 220, 'Bronze', 'Database', 'CrimsonXFirm', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Firm to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, 'SELECT
    EntityId AS EntityId,
    FirmId AS FirmId,
    EntityName AS EntityName,
    EntityInvestmentStatusId AS EntityStatus,
    BusinessOwnerHMCUserId AS PrimaryOwner, 
    BackupBusinessOwnerHMCUserId AS SecondaryOwner, 
    AssociateHMCUserId AS Associate,
    SecondaryBackupBusinessOwnerHMCUserId AS TertiaryOwner
FROM delta.`{bronze_lh_basepath}/Tables/Bronze/CrimsonXEntity`', NULL, NULL, 1, 'Dev - Crimson', 'Entity', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 221, 'Bronze', 'Database', 'CrimsonXEntity', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Entity to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, '92b328a7-0bb9-47f9-a4b5-7ac4daf3bb13,5b0a2af0-0c1c-44fe-9233-19d31bff303f', 1, 'Dev - Crimson', 'EntraUsers', 'Dev - Crimson', NULL, 'Bronze', NULL, NULL, NULL, NULL, NULL, 0, 'office365', NULL, NULL, 'overwrite', 'Entra', 1, NULL, 89, NULL, 'Entra', 'BasicDataSet_v0.User_v1', 'office365', '{
    "type": "TabularTranslator",
    "mappings": [
        {
            "source": {
                "name": "accountEnabled",
                "type": "Boolean",
                "physicalType": "boolean"
            },
            "sink": {
                "name": "accountEnabled",
                "physicalType": "boolean"
            }
        },
        {
            "source": {
                "name": "department",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "department",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "givenName",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "givenName",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "mail",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "mail",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "mobilePhone",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "mobilePhone",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "surname",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "surname",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "userPrincipalName",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "userPrincipalName",
                "physicalType": "string"
            }
        },
        {
            "source": {
                "name": "puser",
                "type": "String",
                "physicalType": "string"
            },
            "sink": {
                "name": "puser",
                "physicalType": "string"
            }
        }
    ],
    "typeConversion": true,
    "typeConversionSettings": {
        "allowDataTruncation": true,
        "treatBooleanAsNumber": false
    },
    "columnFlattenSettings": {
        "treatArrayAsString": false,
        "treatStructAsString": false,
        "flattenColumnDelimiter": "."
    }
}', NULL, NULL, 'Entra Users', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 13, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'PrivateFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 118, 'Bronze', 'Database', 'CrimsonXFeesForPrivateModel', 'Lakehouse', NULL, NULL, 'lh_bronze', 'PrivateFees', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'PrivateFeeTiers', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 119, 'Bronze', 'Database', 'CrimsonXFeesForPrivateModelTier', 'Lakehouse', NULL, NULL, 'lh_bronze', 'PrivateFeeTiers', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'ForecastedCashFlowType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 112, 'Bronze', 'Database', 'CrimsonXForecastedCashFlowType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'ForecastedCashFlowType', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeApprovalType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 111, 'Bronze', 'Database', 'CrimsonXFundTradeApprovalType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeApprovalType', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 96, 'Bronze', 'Database', 'CrimsonXFundTradeStatus', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeStatusToSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'FundTradeType', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 97, 'Bronze', 'Database', 'CrimsonXFundTradeType', 'Lakehouse', NULL, NULL, 'lh_bronze', 'FundTradeTypeToSilver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 19, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'EntraUserDevices', 'Dev - Crimson', NULL, 'Bronze', NULL, NULL, NULL, NULL, NULL, 0, 'office365', NULL, NULL, 'overwrite', 'Entra', 1, NULL, 90, NULL, 'Entra', 'BasicDataSet_v0.OwnedDevices_v0', 'office365', NULL, NULL, NULL, 'Entra User Devices', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 13, NULL
UNION ALL
SELECT NULL, NULL, NULL, 'CAST(EndDate AS DATE) = CAST(''9999-12-31'' AS DATE)', 1, 'Dev - Crimson', 'TransactionUniversity', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 219, 'Bronze', 'Database', 'CrimsonXUniversityTransaction', 'Lakehouse', NULL, NULL, 'lh_bronze', 'TransactionUniversity', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentPerformanceGIAReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 87, 'dbo', 'Database', 'PerformanceGIAReturn', 'sqlserver', NULL, NULL, NULL, 'PerformanceGIAReturn', 'lh_bronze', NULL, NULL, 'PerformanceGIAReturn', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentPerformanceFlash', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 86, 'dbo', 'Database', 'PerformanceFlash', 'sqlserver', NULL, NULL, NULL, 'PerformanceFlash', 'lh_bronze', NULL, NULL, 'PerformanceFlash', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentHMCHierarchyAttributes', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 85, 'dbo', 'Database', 'HMCHierarchyAttributes', 'sqlserver', NULL, NULL, NULL, 'HMCHierarchyAttributes', 'lh_bronze', NULL, NULL, 'HMCHierarchyAttributes', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentFundBetaSummaryLog', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 84, 'dbo', 'Database', 'FundBetaSummaryLog', 'sqlserver', NULL, NULL, NULL, 'FundBetaSummaryLog', 'lh_bronze', NULL, NULL, 'FundBetaSummaryLog', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentFundBetaSummaryHeaderLog', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 83, 'dbo', 'Database', 'FundBetaSummaryHeaderLog', 'sqlserver', NULL, NULL, NULL, 'FundBetaSummaryHeaderLog', 'lh_bronze', NULL, NULL, 'FundBetaSummaryHeaderLog', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentBetaAnalyticSummary', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 82, 'dbo', 'Database', 'BetaAnalyticSummary', 'sqlserver', NULL, NULL, NULL, 'BetaAnalyticSummary', 'lh_bronze', NULL, NULL, 'BetaAnalyticSummary', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataMartInvestmentBetaAnalytic', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataMartInvestment', 'HMCDataMartInvestment', 'overwrite', 'Database', 1, NULL, 81, 'dbo', 'Database', 'BetaAnalytic', 'sqlserver', NULL, NULL, NULL, 'BetaAnalytic', 'lh_bronze', NULL, NULL, 'BetaAnalytic', NULL, NULL, 0, 22, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 133, 'dbo', 'Database', 'ClassificationMap', 'sqlserver', NULL, NULL, NULL, 'ClassificationMap for Solovis Load', 'lh_bronze', NULL, NULL, 'ClassificationMap', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassification', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 132, 'dbo', 'Database', 'Classification', 'sqlserver', NULL, NULL, NULL, 'Classification for Solovis Load', 'lh_bronze', NULL, NULL, 'Classification', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 131, 'dbo', 'Database', 'Entity', 'sqlserver', NULL, NULL, NULL, 'Entity for Solovis Load', 'lh_bronze', NULL, NULL, 'Entity', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 130, 'dbo', 'Database', 'Firm', 'sqlserver', NULL, NULL, NULL, 'Firm for Solovis Load', 'lh_bronze', NULL, NULL, 'Firm', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 129, 'dbo', 'Database', 'Fund', 'sqlserver', NULL, NULL, NULL, 'Fund for Solovis Load', 'lh_bronze', NULL, NULL, 'Fund', NULL, 'FundId', 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 128, 'dbo', 'Database', 'CashflowTransactionDetail', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionDetail for Solovis Load', 'lh_bronze', NULL, NULL, 'CashflowTransactionDetail', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseExternalActiveBook', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 127, 'etl', 'Database', 'vwSolovisLoadHelper_ActiveBookXref', 'sqlserver', NULL, NULL, NULL, 'vwSolovisLoadHelper_ActiveBookXref for Solovis Load', 'lh_bronze', NULL, NULL, 'ExternalActiveBook', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXShareClass', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 126, 'dbo', 'Database', 'ShareClass', 'sqlserver', NULL, NULL, NULL, 'ShareClass for Solovis Load', 'lh_bronze', NULL, NULL, 'ShareClass', NULL, NULL, 0, 6, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'Office365User', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', NULL, 'Office365', 'overwrite', 'Office365', 1, NULL, 44, NULL, 'Database', NULL, 'office365', NULL, NULL, NULL, 'Office365User', 'lh_bronze', NULL, NULL, 'Office365User', NULL, NULL, 0, 8, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundConstituentAccounting', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 4, 'dbo', 'Database', 'FundConstituentAccounting', 'sqlserver', NULL, NULL, '', 'FundConstituentAccounting', 'lh_bronze', NULL, NULL, 'FundConstituentAccounting', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseCurrency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 16, 'dbo', 'Database', 'Currency', 'sqlserver', NULL, NULL, NULL, 'Currency', 'lh_bronze', NULL, NULL, 'Currency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseSolovisCurrency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 46, 'etl', 'Database', 'SolovisCurrency', 'sqlserver', NULL, NULL, NULL, 'SolovisCurrency', 'lh_bronze', NULL, NULL, 'SolovisCurrency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseExternalActiveBook', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 48, 'etl', 'Database', 'vwSolovisLoadHelper_ActiveBookXref', 'sqlserver', NULL, NULL, NULL, 'vwSolovisLoadHelper_ActiveBookXref', 'lh_bronze', NULL, NULL, 'ExternalActiveBook', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehouseSolovisTransactionMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 61, 'etl', 'Database', 'SolovisTransactionMap', 'sqlserver', NULL, NULL, NULL, 'SolovisTransactionMap', 'lh_bronze', NULL, NULL, 'SolovisTransactionMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'vwUniverseFunds', 'Dev - Crimson', NULL, 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'rawtest', 'overwrite', 'Database', 1, NULL, 53, 'dbo', 'Database', 'vwUniverseFunds', 'sqlserver', NULL, NULL, NULL, 'vwUniverseFunds', 'lh_bronze', NULL, NULL, 'vwUniverseFunds', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXUniverse', 'Dev - Crimson', NULL, 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'rawtest', 'overwrite', 'Database', 1, NULL, 52, 'dbo', 'Database', 'Universe', 'sqlserver', NULL, NULL, NULL, 'Universe', 'lh_bronze', NULL, NULL, 'Universe', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCDataWarehousevwSourceReferenceFlatten_CrimsonX', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'HMCDataWarehouse', 'HMCDataWarehouse', 'overwrite', 'Database', 1, NULL, 51, 'dbo', 'Database', 'vwSourceReferenceFlatten_CrimsonX', 'sqlserver', NULL, NULL, NULL, 'vwSourceReferenceFlatten_CrimsonX', 'lh_bronze', NULL, NULL, 'HMCDataWarehousevwSourceReferenceFlatten_CrimsonX', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 11, 'dbo', 'Database', 'Fund', 'sqlserver', NULL, NULL, NULL, 'Fund', 'lh_bronze', NULL, NULL, 'Fund', NULL, 'FundId', 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundReturnSource', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 218, 'dbo', 'Database', 'FundReturnSource', 'sqlserver', NULL, NULL, NULL, 'FundReturnSource', 'lh_bronze', NULL, NULL, 'FundReturnSource', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundReturnType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 217, 'dbo', 'Database', 'FundReturnType', 'sqlserver', NULL, NULL, NULL, 'FundReturnType', 'lh_bronze', NULL, NULL, 'FundReturnType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXAlphaStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 212, 'dbo', 'Database', 'AlphaStrategy', 'sqlserver', NULL, NULL, NULL, 'AlphaStrategy', 'lh_bronze', NULL, NULL, 'AlphaStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXLiquidityCost', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 213, 'dbo', 'Database', 'LiquidityCost', 'sqlserver', NULL, NULL, NULL, 'LiquidityCost', 'lh_bronze', NULL, NULL, 'LiquidityCost', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXWeightedDaysType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 214, 'dbo', 'Database', 'WeightedDaysType', 'sqlserver', NULL, NULL, NULL, 'WeightedDaysType', 'lh_bronze', NULL, NULL, 'WeightedDaysType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundRiskIndexAssociation', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 140, 'dbo', 'Database', 'FundRiskIndexAssociation', 'sqlserver', NULL, NULL, NULL, 'FundRiskIndexAssociation', 'lh_bronze', NULL, NULL, 'FundRiskIndexAssociation', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXFundRiskStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 144, 'dbo', 'Database', 'FundRiskStatus', 'sqlserver', NULL, NULL, NULL, 'FundRiskStatus', 'lh_bronze', NULL, NULL, 'FundRiskStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXBudgetStrategyClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 210, 'dbo', 'Database', 'BudgetStrategyClassificationMap', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategyClassificationMap', 'lh_bronze', NULL, NULL, 'BudgetStrategyClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 0, 'Dev - Crimson', 'CrimsonXBudgetStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 211, 'dbo', 'Database', 'BudgetStrategy', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategy', 'lh_bronze', NULL, NULL, 'BudgetStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLiquidityCost', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 145, 'dbo', 'Database', 'LiquidityCost', 'sqlserver', NULL, NULL, NULL, 'LiquidityCost', 'lh_bronze', NULL, NULL, 'LiquidityCost', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDBackgroundCheck', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 146, 'dbo', 'Database', 'ODDBackgroundCheck', 'sqlserver', NULL, NULL, NULL, 'ODDBackgroundCheck', 'lh_bronze', NULL, NULL, 'ODDBackgroundCheck', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDBackgroundCheckSubject', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 147, 'dbo', 'Database', 'ODDBackgroundCheckSubject', 'sqlserver', NULL, NULL, NULL, 'ODDBackgroundCheckSubject', 'lh_bronze', NULL, NULL, 'ODDBackgroundCheckSubject', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDCounterPartyType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 148, 'dbo', 'Database', 'ODDCounterPartyType', 'sqlserver', NULL, NULL, NULL, 'ODDCounterPartyType', 'lh_bronze', NULL, NULL, 'ODDCounterPartyType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDCustomFrequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 149, 'dbo', 'Database', 'ODDCustomFrequency', 'sqlserver', NULL, NULL, NULL, 'ODDCustomFrequency', 'lh_bronze', NULL, NULL, 'ODDCustomFrequency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDDocumentRequestType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 150, 'dbo', 'Database', 'ODDDocumentRequestType', 'sqlserver', NULL, NULL, NULL, 'ODDDocumentRequestType', 'lh_bronze', NULL, NULL, 'ODDDocumentRequestType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 151, 'dbo', 'Database', 'ODDEntity', 'sqlserver', NULL, NULL, NULL, 'ODDEntity', 'lh_bronze', NULL, NULL, 'ODDEntity', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 152, 'dbo', 'Database', 'ODDFirm', 'sqlserver', NULL, NULL, NULL, 'ODDFirm', 'lh_bronze', NULL, NULL, 'ODDFirm', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmAdvisor', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 153, 'dbo', 'Database', 'ODDFirmAdvisor', 'sqlserver', NULL, NULL, NULL, 'ODDFirmAdvisor', 'lh_bronze', NULL, NULL, 'ODDFirmAdvisor', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmCrdNumber', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 154, 'dbo', 'Database', 'ODDFirmCrdNumber', 'sqlserver', NULL, NULL, NULL, 'ODDFirmCrdNumber', 'lh_bronze', NULL, NULL, 'ODDFirmCrdNumber', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmStaticDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 155, 'dbo', 'Database', 'ODDFirmStaticDetail', 'sqlserver', NULL, NULL, NULL, 'ODDFirmStaticDetail', 'lh_bronze', NULL, NULL, 'ODDFirmStaticDetail', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFirmSummary', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 156, 'dbo', 'Database', 'ODDFirmSummary', 'sqlserver', NULL, NULL, NULL, 'ODDFirmSummary', 'lh_bronze', NULL, NULL, 'ODDFirmSummary', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFlag', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 157, 'dbo', 'Database', 'ODDFlag', 'sqlserver', NULL, NULL, NULL, 'ODDFlag', 'lh_bronze', NULL, NULL, 'ODDFlag', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFlagBucket', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 158, 'dbo', 'Database', 'ODDFlagBucket', 'sqlserver', NULL, NULL, NULL, 'ODDFlagBucket', 'lh_bronze', NULL, NULL, 'ODDFlagBucket', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFlagColor', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 159, 'dbo', 'Database', 'ODDFlagColor', 'sqlserver', NULL, NULL, NULL, 'ODDFlagColor', 'lh_bronze', NULL, NULL, 'ODDFlagColor', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 160, 'dbo', 'Database', 'ODDFund', 'sqlserver', NULL, NULL, NULL, 'ODDFund', 'lh_bronze', NULL, NULL, 'ODDFund', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeeting', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 161, 'dbo', 'Database', 'ODDMeeting', 'sqlserver', NULL, NULL, NULL, 'ODDMeeting', 'lh_bronze', NULL, NULL, 'ODDMeeting', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingAdministrator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 162, 'dbo', 'Database', 'ODDMeetingAdministrator', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingAdministrator', 'lh_bronze', NULL, NULL, 'ODDMeetingAdministrator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingAuditor', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 163, 'dbo', 'Database', 'ODDMeetingAuditor', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingAuditor', 'lh_bronze', NULL, NULL, 'ODDMeetingAuditor', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingBackgroundCheckProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 164, 'dbo', 'Database', 'ODDMeetingBackgroundCheckProvider', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingBackgroundCheckProvider', 'lh_bronze', NULL, NULL, 'ODDMeetingBackgroundCheckProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingBank', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 165, 'dbo', 'Database', 'ODDMeetingBank', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingBank', 'lh_bronze', NULL, NULL, 'ODDMeetingBank', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingComplianceConsultant', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 166, 'dbo', 'Database', 'ODDMeetingComplianceConsultant', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingComplianceConsultant', 'lh_bronze', NULL, NULL, 'ODDMeetingComplianceConsultant', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingCounterparty', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 167, 'dbo', 'Database', 'ODDMeetingCounterparty', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingCounterparty', 'lh_bronze', NULL, NULL, 'ODDMeetingCounterparty', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingCustodian', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 168, 'dbo', 'Database', 'ODDMeetingCustodian', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingCustodian', 'lh_bronze', NULL, NULL, 'ODDMeetingCustodian', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingDocumentRequestType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 169, 'dbo', 'Database', 'ODDMeetingDocumentRequestType', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingDocumentRequestType', 'lh_bronze', NULL, NULL, 'ODDMeetingDocumentRequestType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 170, 'dbo', 'Database', 'ODDMeetingEntity', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingEntity', 'lh_bronze', NULL, NULL, 'ODDMeetingEntity', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 171, 'dbo', 'Database', 'ODDMeetingFirm', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingFirm', 'lh_bronze', NULL, NULL, 'ODDMeetingFirm', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingFrequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 172, 'dbo', 'Database', 'ODDMeetingFrequency', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingFrequency', 'lh_bronze', NULL, NULL, 'ODDMeetingFrequency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingFund', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 173, 'dbo', 'Database', 'ODDMeetingFund', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingFund', 'lh_bronze', NULL, NULL, 'ODDMeetingFund', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingISDA', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 174, 'dbo', 'Database', 'ODDMeetingISDA', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingISDA', 'lh_bronze', NULL, NULL, 'ODDMeetingISDA', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingITProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 175, 'dbo', 'Database', 'ODDMeetingITProvider', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingITProvider', 'lh_bronze', NULL, NULL, 'ODDMeetingITProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingLegalCounsel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 176, 'dbo', 'Database', 'ODDMeetingLegalCounsel', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingLegalCounsel', 'lh_bronze', NULL, NULL, 'ODDMeetingLegalCounsel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingMethod', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 177, 'dbo', 'Database', 'ODDMeetingMethod', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingMethod', 'lh_bronze', NULL, NULL, 'ODDMeetingMethod', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingParticipant', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 178, 'dbo', 'Database', 'ODDMeetingParticipant', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingParticipant', 'lh_bronze', NULL, NULL, 'ODDMeetingParticipant', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingParticipantInternal', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 179, 'dbo', 'Database', 'ODDMeetingParticipantInternal', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingParticipantInternal', 'lh_bronze', NULL, NULL, 'ODDMeetingParticipantInternal', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingPrimaryContact', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 180, 'dbo', 'Database', 'ODDMeetingPrimaryContact', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingPrimaryContact', 'lh_bronze', NULL, NULL, 'ODDMeetingPrimaryContact', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingPrimaryRegulator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 181, 'dbo', 'Database', 'ODDMeetingPrimaryRegulator', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingPrimaryRegulator', 'lh_bronze', NULL, NULL, 'ODDMeetingPrimaryRegulator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingPrimeBroker', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 182, 'dbo', 'Database', 'ODDMeetingPrimeBroker', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingPrimeBroker', 'lh_bronze', NULL, NULL, 'ODDMeetingPrimeBroker', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDMeetingType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 183, 'dbo', 'Database', 'ODDMeetingType', 'sqlserver', NULL, NULL, NULL, 'ODDMeetingType', 'lh_bronze', NULL, NULL, 'ODDMeetingType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDNote', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 184, 'dbo', 'Database', 'ODDNote', 'sqlserver', NULL, NULL, NULL, 'ODDNote', 'lh_bronze', NULL, NULL, 'ODDNote', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDPrioritization', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 185, 'dbo', 'Database', 'ODDPrioritization', 'sqlserver', NULL, NULL, NULL, 'ODDPrioritization', 'lh_bronze', NULL, NULL, 'ODDPrioritization', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDRating', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 186, 'dbo', 'Database', 'ODDRating', 'sqlserver', NULL, NULL, NULL, 'ODDRating', 'lh_bronze', NULL, NULL, 'ODDRating', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXODDRatingCategory', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 187, 'dbo', 'Database', 'ODDRatingCategory', 'sqlserver', NULL, NULL, NULL, 'ODDRatingCategory', 'lh_bronze', NULL, NULL, 'ODDRatingCategory', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXOddTrip', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 188, 'dbo', 'Database', 'OddTrip', 'sqlserver', NULL, NULL, NULL, 'OddTrip', 'lh_bronze', NULL, NULL, 'OddTrip', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXOddTripMeeting', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 189, 'dbo', 'Database', 'OddTripMeeting', 'sqlserver', NULL, NULL, NULL, 'OddTripMeeting', 'lh_bronze', NULL, NULL, 'OddTripMeeting', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXOddTripMeetingAttendee', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 190, 'dbo', 'Database', 'OddTripMeetingAttendee', 'sqlserver', NULL, NULL, NULL, 'OddTripMeetingAttendee', 'lh_bronze', NULL, NULL, 'OddTripMeetingAttendee', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXISDA', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 191, 'dbo', 'Database', 'ISDA', 'sqlserver', NULL, NULL, NULL, 'ISDA', 'lh_bronze', NULL, NULL, 'ISDA', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXITProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 192, 'dbo', 'Database', 'ITProvider', 'sqlserver', NULL, NULL, NULL, 'ITProvider', 'lh_bronze', NULL, NULL, 'ITProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrimaryRegulator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 193, 'dbo', 'Database', 'PrimaryRegulator', 'sqlserver', NULL, NULL, NULL, 'PrimaryRegulator', 'lh_bronze', NULL, NULL, 'PrimaryRegulator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrimeBroker', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 194, 'dbo', 'Database', 'PrimeBroker', 'sqlserver', NULL, NULL, NULL, 'PrimeBroker', 'lh_bronze', NULL, NULL, 'PrimeBroker', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLegalCounsel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 195, 'dbo', 'Database', 'LegalCounsel', 'sqlserver', NULL, NULL, NULL, 'LegalCounsel', 'lh_bronze', NULL, NULL, 'LegalCounsel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCustodian', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 196, 'dbo', 'Database', 'Custodian', 'sqlserver', NULL, NULL, NULL, 'Custodian', 'lh_bronze', NULL, NULL, 'Custodian', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXAdministrator', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 197, 'dbo', 'Database', 'Administrator', 'sqlserver', NULL, NULL, NULL, 'Administrator', 'lh_bronze', NULL, NULL, 'Administrator', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXComplianceConsultant', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 198, 'dbo', 'Database', 'ComplianceConsultant', 'sqlserver', NULL, NULL, NULL, 'ComplianceConsultant', 'lh_bronze', NULL, NULL, 'ComplianceConsultant', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBank', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 199, 'dbo', 'Database', 'Bank', 'sqlserver', NULL, NULL, NULL, 'Bank', 'lh_bronze', NULL, NULL, 'Bank', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBackgroundCheckProvider', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 200, 'dbo', 'Database', 'BackgroundCheckProvider', 'sqlserver', NULL, NULL, NULL, 'BackgroundCheckProvider', 'lh_bronze', NULL, NULL, 'BackgroundCheckProvider', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundrisk', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 139, 'dbo', 'Database', 'Fundrisk', 'sqlserver', NULL, NULL, NULL, 'Fundrisk', 'lh_bronze', NULL, NULL, 'Fundrisk', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskIndexAssociationRequest', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 141, 'dbo', 'Database', 'FundRiskIndexAssociationRequest', 'sqlserver', NULL, NULL, NULL, 'FundRiskIndexAssociationRequest', 'lh_bronze', NULL, NULL, 'FundRiskIndexAssociationRequest', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskRequest', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 142, 'dbo', 'Database', 'FundRiskRequest', 'sqlserver', NULL, NULL, NULL, 'FundRiskRequest', 'lh_bronze', NULL, NULL, 'FundRiskRequest', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskRequestLog', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 143, 'dbo', 'Database', 'FundRiskRequestLog', 'sqlserver', NULL, NULL, NULL, 'FundRiskRequestLog', 'lh_bronze', NULL, NULL, 'FundRiskRequestLog', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTagType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 138, 'dbo', 'Database', 'TagType', 'sqlserver', NULL, NULL, NULL, 'TagType', 'lh_bronze', NULL, NULL, 'TagType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTagOwner', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 137, 'dbo', 'Database', 'TagOwner', 'sqlserver', NULL, NULL, NULL, 'TagOwner', 'lh_bronze', NULL, NULL, 'TagOwner', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTagMaster', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 136, 'dbo', 'Database', 'TagMaster', 'sqlserver', NULL, NULL, NULL, 'TagMaster', 'lh_bronze', NULL, NULL, 'TagMaster', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTag', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 135, 'dbo', 'Database', 'Tag', 'sqlserver', NULL, NULL, NULL, 'Tag', 'lh_bronze', NULL, NULL, 'Tag', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXUniversityTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 134, 'dbo', 'Database', 'UniversityTransaction', 'sqlserver', NULL, NULL, NULL, 'UniversityTransaction', 'lh_bronze', NULL, NULL, 'UniversityTransaction', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrivateFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 98, 'dbo', 'Database', 'FeesForPrivateModel', 'sqlserver', NULL, NULL, NULL, 'PrivateFees', 'lh_bronze', NULL, NULL, 'PrivateFees', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPrivateFeeTiers', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 99, 'dbo', 'Database', 'FeesForPrivateModelTier', 'sqlserver', NULL, NULL, NULL, 'PrivateFeeTiers', 'lh_bronze', NULL, NULL, 'PrivateFeeTiers', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeePaymentFrequencyType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 101, 'dbo', 'Database', 'FeePaymentFrequencyType', 'sqlserver', NULL, NULL, NULL, 'FeePaymentFrequencyType', 'lh_bronze', NULL, NULL, 'FeePaymentFrequencyType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeBasisType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 102, 'dbo', 'Database', 'FeeBasisType', 'sqlserver', NULL, NULL, NULL, 'FeeBasisType', 'lh_bronze', NULL, NULL, 'FeeBasisType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeHurdleType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 104, 'dbo', 'Database', 'FeeHurdleType', 'sqlserver', NULL, NULL, NULL, 'FeeHurdleType', 'lh_bronze', NULL, NULL, 'FeeHurdleType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXShareClass', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 47, 'dbo', 'Database', 'ShareClass', 'sqlserver', NULL, NULL, NULL, 'ShareClass', 'lh_bronze', NULL, NULL, 'ShareClass', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXPipelineStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 42, 'dbo', 'Database', 'PipelineStatus', 'sqlserver', NULL, NULL, NULL, 'PipelineStatus', 'lh_bronze', NULL, NULL, 'PipelineStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeTierBasisType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 41, 'dbo', 'Database', 'FeeTierBasisType', 'sqlserver', NULL, NULL, NULL, 'FeeTierBasisType', 'lh_bronze', NULL, NULL, 'FeeTierBasisType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeeCarryMethodType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 40, 'dbo', 'Database', 'FeeCarryMethodType', 'sqlserver', NULL, NULL, NULL, 'FeeCarryMethodType', 'lh_bronze', NULL, NULL, 'FeeCarryMethodType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXLiquidityTermSchedule', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 39, 'dbo', 'Database', 'LiquidityTermSchedule', 'sqlserver', NULL, NULL, NULL, 'LiquidityTermSchedule', 'lh_bronze', NULL, NULL, 'LiquidityTermSchedule', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeesForPrivateModelTier', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 38, 'dbo', 'Database', 'FeesForPrivateModelTier', 'sqlserver', NULL, NULL, NULL, 'FeesForPrivateModelTier', 'lh_bronze', NULL, NULL, 'FeesForPrivateModelTier', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeesForPrivateModel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 37, 'dbo', 'Database', 'FeesForPrivateModel', 'sqlserver', NULL, NULL, NULL, 'FeesForPrivateModel', 'lh_bronze', NULL, NULL, 'FeesForPrivateModel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBetaCategory', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 36, 'dbo', 'Database', 'BetaCategory', 'sqlserver', NULL, NULL, NULL, 'BetaCategory', 'lh_bronze', NULL, NULL, 'BetaCategory', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskIndexAssociation', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 35, 'dbo', 'Database', 'FundRiskIndexAssociation', 'sqlserver', NULL, NULL, NULL, 'FundRiskIndexAssociation', 'lh_bronze', NULL, NULL, 'FundRiskIndexAssociation', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFeesForPublicModel', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 34, 'dbo', 'Database', 'FeesForPublicModel', 'sqlserver', NULL, NULL, NULL, 'FeesForPublicModel', 'lh_bronze', NULL, NULL, 'FeesForPublicModel', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntityStatistics', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 33, 'dbo', 'Database', 'EntityStatistics', 'sqlserver', NULL, NULL, NULL, 'EntityStatistics', 'lh_bronze', NULL, NULL, 'EntityStatistics', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXAlphaStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 32, 'dbo', 'Database', 'AlphaStrategy', 'sqlserver', NULL, NULL, NULL, 'AlphaStrategy', 'lh_bronze', NULL, NULL, 'AlphaStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRisk', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 31, 'dbo', 'Database', 'FundRisk', 'sqlserver', NULL, NULL, NULL, 'FundRisk', 'lh_bronze', NULL, NULL, 'FundRisk', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXSectorIndustry', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 25, 'dbo', 'Database', 'SectorIndustry', 'sqlserver', NULL, NULL, NULL, 'SectorIndustry', 'lh_bronze', NULL, NULL, 'SectorIndustry', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXSector', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 24, 'dbo', 'Database', 'Sector', 'sqlserver', NULL, NULL, NULL, 'Sector', 'lh_bronze', NULL, NULL, 'Sector', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXSectorIndustryClassification', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 23, 'dbo', 'Database', 'SectorIndustryClassification', 'sqlserver', NULL, NULL, NULL, 'SectorIndustryClassification', 'lh_bronze', NULL, NULL, 'SectorIndustryClassification', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXGeographicStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 22, 'dbo', 'Database', 'GeographicStrategy', 'sqlserver', NULL, NULL, NULL, 'GeographicStrategy', 'lh_bronze', NULL, NULL, 'GeographicStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCountry', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 20, 'dbo', 'Database', 'Country', 'sqlserver', NULL, NULL, NULL, 'Country', 'lh_bronze', NULL, NULL, 'Country', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCountryRegion', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 21, 'dbo', 'Database', 'CountryRegion', 'sqlserver', NULL, NULL, NULL, 'CountryRegion', 'lh_bronze', NULL, NULL, 'CountryRegion', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndexRegionExposure', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 19, 'dbo', 'Database', 'IndexRegionExposure', 'sqlserver', NULL, NULL, NULL, 'IndexRegionExposure', 'lh_bronze', NULL, NULL, 'IndexRegionExposure', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXIndex', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 17, 'dbo', 'Database', 'Index', 'sqlserver', NULL, NULL, NULL, 'Index', 'lh_bronze', NULL, NULL, 'Index', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFrequency', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 18, 'dbo', 'Database', 'Frequency', 'sqlserver', NULL, NULL, NULL, 'Frequency', 'lh_bronze', NULL, NULL, 'Frequency', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassification', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 14, 'dbo', 'Database', 'Classification', 'sqlserver', NULL, NULL, NULL, 'Classification', 'lh_bronze', NULL, NULL, 'Classification', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFirm', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 13, 'dbo', 'Database', 'Firm', 'sqlserver', NULL, NULL, NULL, 'Firm', 'lh_bronze', NULL, NULL, 'Firm', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntity', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 12, 'dbo', 'Database', 'Entity', 'sqlserver', NULL, NULL, NULL, 'Entity', 'lh_bronze', NULL, NULL, 'Entity', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 9, 'dbo', 'Database', 'FundTradeType', 'sqlserver', NULL, NULL, NULL, 'FundTradeType', 'lh_bronze', NULL, NULL, 'FundTradeType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 8, 'dbo', 'Database', 'FundTradeStatus', 'sqlserver', NULL, NULL, NULL, 'FundTradeStatus', 'lh_bronze', NULL, NULL, 'FundTradeStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeForecastedTransaction', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 7, 'dbo', 'Database', 'FundTradeForecastedTransaction', 'sqlserver', NULL, NULL, NULL, 'FundTradeForecastedTransaction', 'lh_bronze', NULL, NULL, 'FundTradeForecastedTransaction', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeApproval', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 6, 'dbo', 'Database', 'FundTradeApproval', 'sqlserver', NULL, NULL, NULL, 'FundTradeApproval', 'lh_bronze', NULL, NULL, 'FundTradeApproval', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTrade', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 5, 'dbo', 'Database', 'FundTrade', 'sqlserver', NULL, NULL, NULL, 'FundTrade', 'lh_bronze', NULL, NULL, 'FundTrade', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 15, 'dbo', 'Database', 'ClassificationMap', 'sqlserver', NULL, NULL, NULL, 'ClassificationMap', 'lh_bronze', NULL, NULL, 'ClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundRiskStatus', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 74, 'dbo', 'Database', 'FundRiskStatus', 'sqlserver', NULL, NULL, NULL, 'FundRiskStatus', 'lh_bronze', NULL, NULL, 'FundRiskStatus', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXEntityRating', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 72, 'dbo', 'Database', 'EntityRating', 'sqlserver', NULL, NULL, NULL, 'EntityRating', 'lh_bronze', NULL, NULL, 'EntityRating', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundStructure', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 71, 'dbo', 'Database', 'FundStructure', 'sqlserver', NULL, NULL, NULL, 'FundStructure', 'lh_bronze', NULL, NULL, 'FundStructure', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXHoldings', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 58, 'dbo', 'Database', 'Holdings', 'sqlserver', NULL, NULL, NULL, 'Holdings', 'lh_bronze', NULL, NULL, 'Holdings', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXReturnType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 56, 'dbo', 'Database', 'ReturnType', 'sqlserver', NULL, NULL, NULL, 'ReturnType', 'lh_bronze', NULL, NULL, 'ReturnType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionSubtype', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 67, 'dbo', 'Database', 'CashflowTransactionSubtype', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionSubtype', 'lh_bronze', NULL, NULL, 'CashflowTransactionSubtype', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXReturnSource', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 55, 'dbo', 'Database', 'ReturnSource', 'sqlserver', NULL, NULL, NULL, 'ReturnSource', 'lh_bronze', NULL, NULL, 'ReturnSource', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 66, 'dbo', 'Database', 'CashflowTransactionType', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionType', 'lh_bronze', NULL, NULL, 'CashflowTransactionType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, 'ReturnDate <> ''0001-01-01''', 1, 'Dev - Crimson', 'CrimsonXFundReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 54, 'dbo', 'Database', 'FundReturn', 'sqlserver', NULL, NULL, NULL, 'FundReturn', 'lh_bronze', NULL, NULL, 'FundReturn', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXTimePeriod', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 122, 'dbo', 'Database', 'TimePeriod', 'sqlserver', NULL, NULL, NULL, 'TimePeriod', 'lh_bronze', NULL, NULL, 'TimePeriod', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundStatistics', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 120, 'dbo', 'Database', 'FundStatistics', 'sqlserver', NULL, NULL, NULL, 'FundStatistics', 'lh_bronze', NULL, NULL, 'FundStatistics', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashflowTransactionDetail', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 70, 'dbo', 'Database', 'CashflowTransactionDetail', 'sqlserver', NULL, NULL, NULL, 'CashflowTransactionDetail', 'lh_bronze', NULL, NULL, 'CashflowTransactionDetail', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXForecastedCashFlow', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 108, 'dbo', 'Database', 'ForecastedCashFlow', 'sqlserver', NULL, NULL, NULL, 'ForecastedCashFlow', 'lh_bronze', NULL, NULL, 'ForecastedCashFlow', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXForecastedCashFlowType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 107, 'dbo', 'Database', 'ForecastedCashFlowType', 'sqlserver', NULL, NULL, NULL, 'ForecastedCashFlowType', 'lh_bronze', NULL, NULL, 'ForecastedCashFlowType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundTradeApprovalType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 106, 'dbo', 'Database', 'FundTradeApprovalType', 'sqlserver', NULL, NULL, NULL, 'FundTradeApprovalType', 'lh_bronze', NULL, NULL, 'FundTradeApprovalType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXHMCUser', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 93, 'dbo', 'Database', 'HMCUser', 'sqlserver', NULL, NULL, NULL, 'HMCUser', 'lh_bronze', NULL, NULL, 'HMCUser', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBudgetStrategy', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 80, 'dbo', 'Database', 'BudgetStrategy', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategy', 'lh_bronze', NULL, NULL, 'BudgetStrategy', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXCashFlowTransactionType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 79, 'dbo', 'Database', 'CashFlowTransactionType', 'sqlserver', NULL, NULL, NULL, 'CashFlowTransactionType', 'lh_bronze', NULL, NULL, 'CashFlowTransactionType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFirmAttribute', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 78, 'dbo', 'Database', 'FirmAttribute', 'sqlserver', NULL, NULL, NULL, 'FirmAttribute', 'lh_bronze', NULL, NULL, 'FirmAttribute', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXvwClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 223, 'dbo', 'Database', 'vwClassificationMap', 'sqlserver', NULL, NULL, NULL, 'vwClassificationMap to Bronze', 'lh_bronze', NULL, NULL, 'vwClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBudgetStrategyClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 222, 'dbo', 'Database', 'BudgetStrategyClassificationMap', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategyClassificationMap to Bronze', 'lh_bronze', NULL, NULL, 'BudgetStrategyClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXFundValuation', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 216, 'dbo', 'Database', 'FundValuation', 'sqlserver', NULL, NULL, NULL, 'FundValuation', 'lh_bronze', NULL, NULL, 'FundValuation', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXBudgetStrategyClassificationMap', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 204, 'dbo', 'Database', 'BudgetStrategyClassificationMap', 'sqlserver', NULL, NULL, NULL, 'BudgetStrategyClassificationMap', 'lh_bronze', NULL, NULL, 'BudgetStrategyClassificationMap', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'CrimsonXWeightedDaysType', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'CrimsonX', 'CrimsonX', 'overwrite', 'Database', 1, NULL, 205, 'dbo', 'Database', 'WeightedDaysType', 'sqlserver', NULL, NULL, NULL, 'WeightedDaysType', 'lh_bronze', NULL, NULL, 'WeightedDaysType', NULL, NULL, 0, 5, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'HMCHierarchyAttributes', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 233, 'Bronze', 'Database', 'HMCDataMartInvestmentHMCHierarchyAttributes', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataMartInvestmentHMCHierarchyAttributes to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'PerformanceFlash', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 234, 'Bronze', 'Database', 'HMCDataMartInvestmentPerformanceFlash', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataMartInvestmentPerformanceFlash', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'PerformanceGIAReturn', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 235, 'Bronze', 'Database', 'HMCDataMartInvestmentPerformanceGIAReturn', 'Lakehouse', NULL, NULL, 'lh_bronze', 'HMCDataMartInvestmentPerformanceGIAReturn', 'lh_bronze', NULL, NULL, NULL, NULL, NULL, 0, 2, NULL
UNION ALL
SELECT NULL, '
SELECT
    sc.InvestmentResourceId,
    sc.Date,
    coalesce(CAST(sc.WholeValue AS DECIMAL(35,2)), 0) -
    coalesce(LAG(CAST(sc.WholeValue AS DECIMAL(35,2))) OVER (
        PARTITION BY sc.InvestmentResourceId
        ORDER BY CAST(sc.Date AS DATE)
    ), 0) AS Amount,
    coalesce(LAG(CAST(sc.WholeValue AS DECIMAL(35,2))) OVER (
        PARTITION BY sc.InvestmentResourceId
        ORDER BY CAST(sc.Date AS DATE)
    ), 0) AS PreviousAmount,
    abfm.FundId,
    abfm.ShareClassId,
    sc.WholeValue,
    sc.DeltaValue
FROM delta.`{bronze_lh_basepath}/Tables/Bronze/SolovisCommitments` sc
JOIN delta.`{bronze_lh_basepath}/Tables/Bronze/SolovisActiveBookFundMapping` abfm
    ON sc.InvestmentResourceId = abfm.InvestmentResourceId
ORDER BY CAST(sc.Date AS DATE)', NULL, NULL, 1, 'Dev - Crimson', 'FundCommitment', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 231, 'Bronze', 'Database', 'SolovisCommitments', 'Lakehouse', NULL, NULL, 'lh_bronze', 'Solovis Commitments', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 20, NULL
UNION ALL
SELECT NULL, 'SELECT
    c.id                    AS conversationId,
    c.name                  AS conversationName,
    c.userId,
    c.integrationName,
    c.createdAt             AS conversationCreatedAt,
    c.updatedAt             AS conversationUpdatedAt,
    c.tokensRemaining,
    c.tokenCount,
    c._self,
    c._rid,
    c._attachments,
    c._ts,
    m.id                    AS messageId,
    m.role                  AS messageRole,
    m.content               AS messageContent,
    m.createdAt             AS messageCreatedAt,
    (IS_DEFINED(m.metadata) ? m.metadata : {})                         AS messageMetadata,
    (IS_DEFINED(m.metadata.visible)            ? m.metadata.visible            : null) AS metadata_visible,
    (IS_DEFINED(m.metadata.source)             ? m.metadata.source             : null) AS metadata_source,
    (IS_DEFINED(m.metadata.functionArguments)  ? m.metadata.functionArguments  : null) AS metadata_functionArguments,
    (IS_DEFINED(m.metadata.functionName)       ? m.metadata.functionName       : null) AS metadata_functionName
FROM ChatHistory c
JOIN m IN c.messages', NULL, NULL, 1, 'Dev - Crimson', 'ChatAiDbChatHistory', 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, NULL, NULL, 1, 'DatabaseTask', 'ChatAiDb', 'chatAiDb', 'overwrite', 'chatAiDb', 1, NULL, 230, NULL, 'ChatHistory CosmosDB', 'ChatHistory', 'cosmosdb', NULL, NULL, NULL, 'Get ChatHistory', 'lh_bronze', NULL, NULL, 'ChatHistory', NULL, NULL, 0, 29, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', NULL, 'ETLLoadDateTime', NULL, NULL, 26, NULL, 1, 'NotebookTask', NULL, 'Files/IncomingFeed/CyberSecurityDashboard/SpyCloud', 'overwrite', 'SpyCloud', 1, NULL, 229, NULL, 'API', NULL, 'SpyCloud', NULL, NULL, NULL, 'SpyCloudDataCall', NULL, NULL, NULL, 'Spycloud_data.parquet', NULL, NULL, 1, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 17, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 4, NULL, 125, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturnSilver Frequency', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 24, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 3, NULL, 225, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturn Computed Benchmarks', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', NULL, NULL, NULL, 15, NULL, 0, 'NotebookTask', NULL, NULL, 'append', 'Bronze', 1, NULL, 123, 'Bronze', 'Database', NULL, 'Lakehouse', NULL, NULL, 'lh_bronze', 'IndexReturnSilver Gap Fill', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 21, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', NULL, 'ETLLoadDateTime', NULL, NULL, 1, NULL, 1, 'NotebookTask', NULL, 'Files/IncomingFeed/CyberSecurityDashboard/KnowBe4', 'overwrite', 'KnowBe4', 1, NULL, 45, NULL, 'API', NULL, 'KnowBe4', NULL, NULL, NULL, 'KnowBe4ApiPhishingTestsCall', NULL, NULL, NULL, 'knowbe4_data.parquet', NULL, NULL, 1, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', NULL, NULL, NULL, NULL, NULL, 25, NULL, 1, 'NotebookTask', NULL, 'Files/IncomingFeed/CyberSecurityDashboard/KnowBe4', 'overwrite', 'KnowBe4', 1, NULL, 228, NULL, 'API', NULL, 'KnowBe4', NULL, NULL, NULL, 'KnowBe4ApiUsersCall', NULL, NULL, NULL, 'users_output.parquet', NULL, NULL, 0, 9, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', 'PublicFees', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 117, 'Bronze', 'Database', 'CrimsonXFeesForPublicModel', 'Lakehouse', NULL, NULL, 'lh_bronze', 'PublicFees', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 1, 2, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 19, NULL, 0, 'NotebookTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 2, 'hmc-report/api/v1/BottomUp/FundLevelCalc?caseId=3&useBetaSummaryGia=false&asOfDate=7/15/2025&numYears=10&calculationMethodology=1&fundCycleMethodology=0&fundCycleModelId=1', 203, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, 'lh_raw', 'Bottom Up Data to Bronze', 'lh_bronze', NULL, NULL, 'FundLevelCalc.json', NULL, NULL, 0, 23, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', 'ETLLoadDateTime', 'Bronze', NULL, NULL, NULL, 19, NULL, 0, 'NotebookTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 2, 'hmc-report/api/v1/BottomUp/FundLevelCalcMonthly?caseId=3&useBetaSummaryGIA=false&useLTM=false&asOfDate=7/23/2025&reportDate=7/24/2025&calculationMethodology=1&numYears=3&fundCycleMethodology=0&fundCycleModelId=1', 227, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, 'lh_raw', 'Bottom Up Monthly Data to Bronze', 'lh_bronze', NULL, NULL, 'FundLevelCalcMonthly.json', NULL, NULL, 0, 23, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', NULL, NULL, NULL, NULL, 'CrimsonPreAPI', NULL, NULL, 0, 'ApiTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 1, 'hmc-report/api/v1/BottomUp/FundLevelCalcMonthly?caseId=3&useBetaSummaryGIA=false&useLTM=false&asOfDate=7/23/2025&reportDate=7/24/2025&calculationMethodology=1&numYears=3&fundCycleMethodology=0&fundCycleModelId=1', 208, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, NULL, 'FundLevelCalcMonthly to Raw', 'lh_raw', NULL, NULL, 'FundLevelCalcMonthly.json', NULL, NULL, 0, 27, NULL
UNION ALL
SELECT NULL, NULL, NULL, NULL, 1, 'Dev - Crimson', NULL, 'Dev - Crimson', NULL, NULL, NULL, NULL, 'CrimsonDevAPI', NULL, NULL, 0, 'ApiTask', NULL, 'HMCReport', 'overwrite', 'Crimson HMC API', 1, 'hmc-report/api/v1/BottomUp/FundLevelCalc?caseId=3&useBetaSummaryGia=false&asOfDate=7/15/2025&numYears=10&calculationMethodology=1&fundCycleMethodology=0&fundCycleModelId=1', 207, NULL, 'Crimson HMC API', NULL, 'API', NULL, NULL, NULL, 'FundLevelCalc to Raw', 'lh_raw', NULL, NULL, 'FundLevelCalc.json', NULL, NULL, 0, 25, NULL
UNION ALL
SELECT NULL, 'SELECT fs.CustomRiskBenchmark, tp.Description, fs.FundId, tp.TimePeriodId, fs.FundStatisticReferenceTypeId FROM delta.`{bronze_lh_basepath}/Tables/Bronze/CrimsonXFundStatistics` fs JOIN delta.`{bronze_lh_basepath}/Tables/Bronze/CrimsonXTimePeriod` tp ON fs.TimePeriodId = tp.TimePeriodId WHERE fs.CustomRiskBenchmark IS NOT NULL AND fs.FundStatisticReferenceTypeId = 1', NULL, NULL, 1, 'Dev - Crimson', 'CustomRiskBenchmark', 'Dev - Crimson', 'ETLLoadDateTime', 'Silver', 'ETLLoadDateTime', NULL, NULL, NULL, NULL, 1, 'BronzeToSilver', NULL, NULL, 'overwrite', 'Bronze', 1, NULL, 226, 'Bronze', 'Database', 'CrimsonXFundStatistics', 'Lakehouse', NULL, NULL, 'lh_bronze', 'CustomRiskBenchmark to Silver', 'lh_curated', NULL, NULL, NULL, NULL, NULL, 0, 11, NULL
)
INSERT INTO etlControl.etl.Task (SinkWarehouseName, CustomSQLSourceQuery, SinkLakehouseId, SourceWhereClause, IsActiveFlag, SourceWorkspaceName, SinkTableName, SinkWorkspaceName, SinkWatermarkColumn, SinkSchemaName, SourceWatermarkColumn, SourceFlatfileConnectionSettings, SourceConnectionName, NotebookKey, SinkWorkspaceId, ArchiveOriginalFilesFlag, TaskType, SourceDatabaseName, RawStoragePath, SinkLoadMethod, SourceName, TaskRunOrderNbr, RelativeUrl, TaskKey, SourceSchemaName, ParentSourceName, SourceTableName, SourceType, CustomPipelineCode, SourceExtractionMethod, SourceLakehouseName, TaskName, SinkLakehouseName, ArchiveStoragePath, SourceWarehouseName, RawStorageFileName, ArchiveStorageFileName, PrimaryKeyColumnList, IsWatermarkEnabledFlag, JobKey, OverrideQuery)
SELECT source.SinkWarehouseName, source.CustomSQLSourceQuery, source.SinkLakehouseId, source.SourceWhereClause, source.IsActiveFlag, source.SourceWorkspaceName, source.SinkTableName, source.SinkWorkspaceName, source.SinkWatermarkColumn, source.SinkSchemaName, source.SourceWatermarkColumn, source.SourceFlatfileConnectionSettings, source.SourceConnectionName, source.NotebookKey, source.SinkWorkspaceId, source.ArchiveOriginalFilesFlag, source.TaskType, source.SourceDatabaseName, source.RawStoragePath, source.SinkLoadMethod, source.SourceName, source.TaskRunOrderNbr, source.RelativeUrl, source.TaskKey, source.SourceSchemaName, source.ParentSourceName, source.SourceTableName, source.SourceType, source.CustomPipelineCode, source.SourceExtractionMethod, source.SourceLakehouseName, source.TaskName, source.SinkLakehouseName, source.ArchiveStoragePath, source.SourceWarehouseName, source.RawStorageFileName, source.ArchiveStorageFileName, source.PrimaryKeyColumnList, source.IsWatermarkEnabledFlag, source.JobKey, source.OverrideQuery
FROM source
WHERE NOT EXISTS (
    SELECT 1
    FROM etlControl.etl.Task AS target
    WHERE target.TaskKey = source.TaskKey
);


-- ***** Script to update the table: etlControl.etl.Watermark *****
-- ===== UPDATE EXISTING ROWS =====
WITH source (TaskKey, HighWatermarkValue, FileTaskKey) AS (
SELECT 45, NULL, NULL
UNION ALL
SELECT 1, NULL, NULL
UNION ALL
SELECT 2, NULL, NULL
UNION ALL
SELECT 3, NULL, NULL
UNION ALL
SELECT NULL, NULL, 3
UNION ALL
SELECT NULL, NULL, 2
UNION ALL
SELECT NULL, NULL, 1
)
UPDATE target
SET
    target.HighWatermarkValue = source.HighWatermarkValue,
    target.FileTaskKey = source.FileTaskKey
FROM etlControl.etl.Watermark AS target
JOIN source
    ON target.TaskKey = source.TaskKey;

-- ===== INSERT NEW ROWS =====
WITH source (TaskKey, HighWatermarkValue, FileTaskKey) AS (
SELECT 45, NULL, NULL
UNION ALL
SELECT 1, NULL, NULL
UNION ALL
SELECT 2, NULL, NULL
UNION ALL
SELECT 3, NULL, NULL
UNION ALL
SELECT NULL, NULL, 3
UNION ALL
SELECT NULL, NULL, 2
UNION ALL
SELECT NULL, NULL, 1
)
INSERT INTO etlControl.etl.Watermark (TaskKey, HighWatermarkValue, FileTaskKey)
SELECT source.TaskKey, source.HighWatermarkValue, source.FileTaskKey
FROM source
WHERE NOT EXISTS (
    SELECT 1
    FROM etlControl.etl.Watermark AS target
    WHERE target.TaskKey = source.TaskKey
);