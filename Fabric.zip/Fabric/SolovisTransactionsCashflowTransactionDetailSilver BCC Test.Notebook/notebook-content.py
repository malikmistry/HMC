# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     },
# META     "environment": {}
# META   }
# META }

# CELL ********************

# import all the libraries
from pyspark.sql.functions import col
from datetime import datetime, date, timedelta
from pyspark.sql import functions as F
from pyspark.sql.types import DecimalType, IntegerType, DateType, BooleanType, LongType, TimestampType, ShortType, StringType
from pyspark.sql import Window
from delta.tables import DeltaTable

# Set configurations
spark.conf.set('spark.sql.caseSensitive', True)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Build paths
bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisTransactions").createOrReplaceTempView("st")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisActiveBookFundMapping").createOrReplaceTempView("abfm")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/HMCDataWarehouseSolovisCurrency").createOrReplaceTempView("scur")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/CrimsonXCurrency").createOrReplaceTempView("c")


# Gather all the daily transactions active book and funds
dfTransactions =  spark.sql("""SELECT 
	abfm.InvestmentResourceId
	, abfm.InvestmentId
	, abfm.FundId
	, abfm.ShareClassId
	, c.CurrencyId
	, st.AmountIn
	, st.AmountOut
	, st.ImpactsCommitment
	, st.IsAdjustment
	, st.IsInternalFlow
	, st.IsStartOfDay
	, st.IsStock
	, st.RecallableAmount
	, st.ExposureDate
	, st.TradeDate
	, st.SettleDate 
	, st.TransactionTypeTagId
	, st.TransactionEntryId
	, st.OwnerId
	, st.PrimaryTxTypeTagId
	, st.ExecutingBroker
	, abfm.ActiveBookType
FROM st
		JOIN abfm ON st.InvestmentResourceId = abfm.InvestmentResourceId
		JOIN scur ON scur.Id = st.CurrencyId
		JOIN c ON c.ISOCode = scur.Code""")
		
display(dfTransactions.count())


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(dfTransactions)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Perform data type conversions and defaults for nulls
# Get the max CashflowTransactionDetailId
max_id_df = spark.sql("SELECT MAX(CashflowTransactionDetailId) AS max_id FROM lh_curated.Silver.CashflowTransactionDetail")
max_id = max_id_df.collect()[0]["max_id"]
max_id = max_id if max_id is not None else 0  # Default to 0 if table is empty
window_spec = Window.orderBy(F.lit(1))

dfTransactions = dfTransactions \
    .withColumn("AmountIn", F.coalesce(col("AmountIn").cast(DecimalType(38, 2)), F.lit(0))) \
    .withColumn("AmountOut", F.coalesce(col("AmountOut").cast(DecimalType(38, 2)), F.lit(0))) \
    .withColumn("InvestmentResourceId", col("InvestmentResourceId").cast(IntegerType())) \
    .withColumn("InvestmentId", col("InvestmentId").cast(IntegerType())) \
    .withColumn("CurrencyId", col("CurrencyId").cast(IntegerType())) \
    .withColumn("RecallableAmount", F.coalesce(col("RecallableAmount").cast(DecimalType(38,2)), F.lit(0))) \
    .withColumn("ExposureDate", F.to_date(col("ExposureDate"), "M/d/yyyy")) \
    .withColumn("TradeDate", F.to_date(col("TradeDate"), "M/d/yyyy")) \
    .withColumn("SettleDate", F.to_date(col("SettleDate"), "M/d/yyyy")) \
    .withColumn("TransactionTypeTagId", col("TransactionTypeTagId").cast(IntegerType())) \
    .withColumn("ImpactsCommitment", col("ImpactsCommitment").cast(BooleanType())) \
    .withColumn("IsAdjustment", col("IsAdjustment").cast(BooleanType())) \
    .withColumn("IsInternalFlow", col("IsInternalFlow").cast(BooleanType())) \
    .withColumn("IsStartOfDay", F.when(col("IsStartOfDay") == "True", 1).otherwise(0).cast(ShortType())) \
    .withColumn("IsStock", col("IsStock").cast(BooleanType())) \
    .withColumn("PortfolioTypeId", F.when((col("OwnerId") == 1), 0)
                                   .when((col("OwnerId") == 2), 2)
                                   .otherwise(4)) \
    .withColumn(
        "CashflowTransactionDetailId",
        (F.row_number().over(window_spec) + max_id).cast(LongType())) \
    .withColumn("TransactionAmountInUSD", F.lit(0)) \
    .withColumn("TransactionAmountOutUSD", F.lit(0)) \
    .withColumn("UpdateTimeStamp", F.lit(datetime.now())) \
    .withColumn("UpdateByHMCUserId", F.lit("SYSTEMACCOUNT"))

#    .withColumn("AmountOut", col("AmountOut") * -1) \

# Rename columns
dfTransactions = dfTransactions \
    .withColumnRenamed("IsStartOfDay", "BookStartOfDay") \
    .withColumnRenamed("AmountIn", "TransactionAmountInLocal") \
    .withColumnRenamed("AmountOut", "TransactionAmountOutLocal") \
    .withColumnRenamed("TransactionEntryId", "TransactionIdSource") \
    .withColumnRenamed("PrimaryTxTypeTagId","TransactionTypeIdSource") \
    .withColumnRenamed("ExecutingBroker","TransactionTag")

# Filter by t-1 to only include everything prior to today because we know it was validated
# dfTransactions = dfTransactions \
#     .filter(col("ExposureDate") < date.today())

display(dfTransactions.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Add in supporting data for calculations
# Get Fund Structure
dfFundStructure = spark.sql("""SELECT f.FundId
	                                    , fs.Description FundStructure
                                FROM lh_bronze.Bronze.CrimsonXFund f
		                        JOIN lh_bronze.Bronze.CrimsonXFundStructure fs ON f.FundStructureId = fs.FundStructureId""")

dfTransactions = dfTransactions \
    .join(dfFundStructure, "FundId", "inner")

# Apply Transaction Mappings
dfTransactionMappings = spark.table("lh_bronze.Bronze.HMCDataWarehouseSolovisTransactionMap")
dfCashflows = dfTransactions.join(dfTransactionMappings, dfTransactions["TransactionTypeTagId"] == dfTransactionMappings["SolovisTransactionComponentId"], "left")

# Get the FX Rate
# dfFXRate = spark.table("lh_curated.Silver.FXRate") \
#    .withColumnRenamed("CurrencyId","FXCurrencyId")
dfFXRate = spark.sql("""
     SELECT DISTINCT CurrencyId FXCurrencyId, FXDate, FXRate FROM lh_curated.Silver.FXRate
 """)

dfCashflows = dfCashflows.join(dfFXRate, (dfCashflows["CurrencyId"] == dfFXRate["FXCurrencyId"]) & (dfCashflows["ExposureDate"] == dfFXRate["FXDate"]), "inner")

dfCashflows = dfCashflows \
    .withColumn("ImpactsCommitmentInt", F.when(col("ImpactsCommitment"), F.lit(1)).otherwise(F.lit(0)))
dfCashflows = dfCashflows \
    .withColumn("ImpactsCommitmentInt", col("ImpactsCommitmentInt") * col("UseCommitmentImpact"))

display(dfCashflows.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(dfCashflows)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Perform calculations
dfCashflows = dfCashflows \
    .withColumn("TransactionAmountLocal", col("TransactionAmountInLocal") - col("TransactionAmountOutLocal")) \
    .withColumn("FundedAmountLocal", 
        F.when((F.coalesce(col("ImpactsFunded"), F.lit(0)) == 1) 
            & (col("UseCommitmentImpact") == 1) 
            & (col("ImpactsCommitment")), col("TransactionAmountInLocal") - col("TransactionAmountOutLocal"))
            .when((col("ImpactsCommitment")) 
                & (col("TransactionTypeIdSource").isin(10050,10051,10052)), col("TransactionAmountInLocal") - col("TransactionAmountOutLocal"))
                .otherwise(0)) \
    .withColumn("ReturnedAmountLocal", (F.when((col("ActiveBookType") == 'Fund') & (col("ImpactsReturned") == 1), col("TransactionAmountOutLocal") - col("TransactionAmountInLocal"))
                                                .otherwise(F.when((col("TransactionTypeIdSource").isin(1,2)) | (col("ImpactsReturned") == 1), col("TransactionAmountOutLocal") - col("TransactionAmountInLocal"))
                                                            .otherwise(0)))) \
    .withColumn("RecallableAmountLocal", 
            F.when((col("TransactionAmountOutLocal") != 0) \
                & (col("RecallableAmount") != 0), F.abs("RecallableAmount"))
            .when((col("ActiveBookType") == "Cash"), 0) \
            .when((col("TransactionAmountOutLocal") == 0) \
                & (col("TransactionAmountInLocal") != 0) \
                & (col("RecallableAmount") != 0), col("RecallableAmount")).otherwise(0)) \
    .withColumn("MarketValueEffectLocal", F.when((F.col("ImpactsValuation") == 1), col("TransactionAmountInLocal") - col("TransactionAmountOutLocal")).otherwise(0)) \
    .withColumn("UnfundedAdjustmentLocal", F.when((col("ActiveBookType") == "Cash"), 0).when((col("CashFlowTransactionTypeId") == 18), col("RecallableAmount")).otherwise(0)) \
    .withColumn("CommitmentEffectLocal", \
                F.when((col("CashFlowTransactionTypeId") == 18), 0)
                .when(((col("FundStructure").isin("Drawdown","Hybrid")) 
                            & (col("ImpactsCommitment") | (col("UseCommitmentImpact") == F.lit(1)))), 
                        F.when((~col("CashFlowTransactionTypeId").isin(5,13,18)),((((((col("TransactionAmountInLocal") - col("TransactionAmountOutLocal"))*-1) * col("ImpactsCommitmentInt")) - col("RecallableAmountLocal")))))
                        .when((col("CashFlowTransactionTypeId").isin(5,13)), ((((((col("TransactionAmountInLocal") - col("TransactionAmountOutLocal"))*-1) * col("ImpactsCommitmentInt")) - col("RecallableAmountLocal")))))
                        .otherwise(0)) .otherwise(0))
dfCashflows = dfCashflows \
    .withColumn("ReturnedAmountLocal", F.when((col("ActiveBookType") != 'Fund'), F.when((col("ReturnedAmountLocal") < 0), 0).otherwise(col("ReturnedAmountLocal"))).otherwise(col("ReturnedAmountLocal"))) \

dfCashflows = dfCashflows \
    .withColumnRenamed("CashFlowTransactionSubTypeId", "CashflowTransactionSubtypeId") \
    .withColumnRenamed("CashFlowTransactionTypeId", "CashflowTransactionTypeId") \
    .withColumn("TransactionAmountInUSD", col("TransactionAmountInLocal") * col("FXRate")) \
    .withColumn("TransactionAmountOutUSD", col("TransactionAmountOutLocal") * col("FXRate")) \
    .withColumn("TransactionAmountUSD", col("TransactionAmountLocal") * col("FXRate")) \
    .withColumn("FundedAmountUSD", col("FundedAmountLocal") * col("FXRate")) \
    .withColumn("ReturnedAmountUSD", col("ReturnedAmountLocal") * col("FXRate")) \
    .withColumn("RecallableAmountUSD", col("RecallableAmountLocal") * col("FXRate")) \
    .withColumn("UnfundedAdjustmentUSD" ,col("UnfundedAdjustmentLocal") * col("FXRate")) \
    .withColumn("MarketValueEffectUSD" ,col("MarketValueEffectLocal") * col("FXRate"))


display(dfCashflows.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(dfCashflows)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Align the source schema with the destination schema
# destination_schema = spark.read.table("lh_curated.Silver.CashflowTransactionDetail").schema()
destination_schema = spark.table("lh_curated.Silver.CashflowTransactionDetail").schema
default_values = {
    "DecimalType(35,2)": F.lit(0).cast(DecimalType(35, 2)),
    "DecimalType(33,15)": F.lit(0).cast(DecimalType(33, 15)),
    "StringType()": F.lit("").cast(StringType()),
    "IntegerType()": F.lit(0).cast(IntegerType()),
    "LongType()": F.lit(0).cast(LongType()),
    "DateType()": F.lit(None).cast(DateType()),
    "TimestampType()": F.lit(None).cast(TimestampType()),
    "ShortType()": F.lit(0).cast(ShortType()),
}
dfCashflows = dfCashflows \
    .select("CashflowTransactionDetailId"
        , "FundId"
        , "ShareClassId"
        , "PortfolioTypeId"
        , "CashflowTransactionTypeId"
        , "CashflowTransactionSubtypeId"
        , "TransactionAmountLocal"
        , "TransactionAmountUSD"
        , "TransactionAmountInLocal"
        , "TransactionAmountInUSD"
        , "TransactionAmountOutLocal"
        , "TransactionAmountOutUSD"
        , "CommitmentEffectLocal"
        , "MarketValueEffectLocal"
        , "BookStartOfDay"
        , "ExposureDate"
        , "TradeDate"
        , "SettleDate"
        , "CurrencyId"
        , "FXRate"
        , "ReturnedAmountLocal"
        , "ReturnedAmountUSD"
        , "UnfundedAdjustmentLocal"
        , "UnfundedAdjustmentUSD"
        , "FundedAmountLocal"
        , "FundedAmountUSD"
        , "RecallableAmountLocal"
        , "RecallableAmountUSD"
        , "UpdateTimeStamp"
        , "UpdateByHMCUserId"
        , "TransactionIdSource"
        , "TransactionTypeIdSource"
        , "TransactionTag")

dfCashflows = dfCashflows
for field in destination_schema:
    if field.name not in dfCashflows.columns:
        dfCashflows = dfCashflows.withColumn(field.name, default_values[str(field.dataType)])
    else:
        dfCashflows = dfCashflows.withColumn(field.name, F.col(field.name).cast(field.dataType))

dfCashflows = dfCashflows.select([field.name for field in destination_schema])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(dfCashflows)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Write data out to lh_curated.Review.CashflowTransactionDetail
dfCashflowDetail = spark.table("lh_curated.Review.CashflowTransactionDetail")
#dfCashflowDetail = spark.table("lh_bronze.Bronze.CrimsonXCashflowTransactionDetail")

joinKeys = ["TransactionIdSource","TransactionTypeIdSource"]

dfExisting = dfCashflows.alias("new") \
    .join(dfCashflowDetail.alias("existing"), on=joinKeys, how="inner") \
    .select("new.*").distinct()

dfNew = dfCashflows.alias("new") \
    .join(dfCashflowDetail.alias("existing"), on=joinKeys, how="left_anti") \
    .select("new.*")

dfNew = dfNew \
    .filter((col("TransactionAmountInLocal") != 0) 
        | (col("TransactionAmountOutLocal") != 0)
        | (col("RecallableAmountLocal") != 0))

dfCashflows = dfExisting.unionByName(dfNew)

dtReviewCashflowDetail = DeltaTable.forPath(spark, "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465/Tables/Review/CashflowTransactionDetail")
dtReviewCashflowDetail.alias("target").merge(
    dfCashflows.alias("source"),
    """target.TransactionIdSource = source.TransactionIdSource
            AND target.TransactionTypeIdSource = source.TransactionTypeIdSource""") \
    .whenMatchedUpdateAll() \
    .whenNotMatchedInsertAll() \
    .execute()

spark.sql("REFRESH TABLE lh_curated.Review.CashflowTransactionDetail")
spark.sql("SELECT COUNT(*) FROM lh_curated.Review.CashflowTransactionDetail").show()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(dfNew)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Handle the clean up transactions and write out the result set to stage table
dfCleanUps = spark.sql("""SELECT TransactionEntryId TransactionIdSource
	   , TransactionTypeTagId TransactionTypeIdSource
FROM Bronze.SolovisTransactions
WHERE InvestmentResourceId = 215880""")

dfCashflowDetail = spark.table("lh_curated.Review.CashflowTransactionDetail")
#dfCashflowDetail = spark.table("lh_bronze.Bronze.CrimsonXCashflowTransactionDetail")
dfCashflowDetail = dfCashflowDetail \
    .join(dfCleanUps, ["TransactionIdSource", "TransactionTypeIdSource"], how="left_anti")

dfCashflowDetail = dfCashflowDetail \
    .select("CashflowTransactionDetailId"
        , "CashflowTransactionId"
        , "FundId"
        , "ShareClassId"
        , "PortfolioTypeId"
        , "CashflowTransactionTypeId"
        , "CashflowTransactionSubtypeId"
        , "StartDate"
        , "EndDate"
        , "TransactionAmountInLocal"
        , "TransactionAmountInUSD"
        , "TransactionAmountOutLocal"
        , "TransactionAmountOutUSD"
        , "CommitmentEffectLocal"
        , "MarketValueEffectLocal"
        , "BookStartOfDay"
        , "ExposureDate"
        , "TradeDate"
        , "SettleDate"
        , "CurrencyId"
        , "FXRate"
        , "ReturnedAmountLocal"
        , "ReturnedAmountUSD"
        , "UnfundedAdjustmentLocal"
        , "UnfundedAdjustmentUSD"
        , "FundedAmountLocal"
        , "FundedAmountUSD"
        , "RecallableAmountLocal"
        , "RecallableAmountUSD"
        , "FundedXCommitAmtLocal"
        , 'FundedXCommitAmtUSD'
        , "ReturnedXCommitAmtUSD"
        , "ReturnedXCommitAmtLocal"
        , "UpdateTimeStamp"
        , "UpdateByHMCUserId"
        , "TransactionTypeIdSource"
        , "TransactionIdSource"
        , "CommitmentEffectUSD"
        , "MarketValueEffectUSD"
        , "TransactionTag"
        , "ETLLoadDateTime").distinct()
        
# dfCashflowDetail = dfCashflowDetail \
#    .withColumnRenamed("CurrencyRate", "FXRate")

dfCashflowDetail.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("lh_curated.Review.CashflowTransactionDetail")

dfCashflows.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("lh_bronze.Bronze.SolovisDailyLoadTransactions")
spark.sql("REFRESH TABLE lh_bronze.Bronze.SolovisDailyLoadTransactions")
spark.sql("SELECT COUNT(*) FROM lh_bronze.Bronze.SolovisDailyLoadTransactions").show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Backup CashflowTransactionDetail and then write review data to silver
dfReviewCashflowDetail = spark.table("lh_curated.Review.CashflowTransactionDetail")
dCashflowDetailBackup = spark.table("lh_curated.Silver.CashflowTransactionDetail")

# Save this off to the side in case something goes wrong
dCashflowDetailBackup.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("lh_bronze.Bronze.CrimsonXCashflowTransactionDetailBackUp")

dfReviewCashflowDetail.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("lh_curated.Silver.CashflowTransactionDetail")

spark.sql("REFRESH TABLE lh_curated.Silver.CashflowTransactionDetail")
spark.sql("SELECT COUNT(*) FROM lh_curated.Silver.CashflowTransactionDetail").show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# from pyspark.sql import functions as F
# from pyspark.sql.types import DecimalType, IntegerType, DateType, BooleanType, LongType, TimestampType, ShortType, StringType
# from pyspark.sql import Window
# # Align the source schema with the destination schema
# # destination_schema = spark.read.table("lh_curated.Silver.CashflowTransactionDetail").schema()
# destination_schema = spark.table("lh_curated.Silver.CashflowTransactionDetail").schema
# default_values = {
#     "DecimalType(35,2)": F.lit(0).cast(DecimalType(35, 2)),
#     "DecimalType(33,15)": F.lit(0).cast(DecimalType(33, 15)),
# #    "DecimalType(18,6)": F.lit(0).cast(DecimalType(18, 6)),
#     "StringType()": F.lit("").cast(StringType()),
#     "IntegerType()": F.lit(0).cast(IntegerType()),
#     "LongType()": F.lit(0).cast(LongType()),
#     "DateType()": F.lit(None).cast(DateType()),
#     "TimestampType()": F.lit(None).cast(TimestampType()),
#     "ShortType()": F.lit(0).cast(ShortType()),
# }
# dfCXCashflowDetail = spark.table("lh_bronze.Bronze.CrimsonXCashflowTransactionDetail")

# dfCXCashflowDetail = dfCXCashflowDetail \
#     .withColumnRenamed("CurrencyRate", "FXRate")

# dfCXCashflowDetail = dfCXCashflowDetail
# for field in destination_schema:
#     if field.name not in dfCXCashflowDetail.columns:
#         dfCXCashflowDetail = dfCXCashflowDetail.withColumn(field.name, default_values[str(field.dataType)])
#     else:
#         dfCXCashflowDetail = dfCXCashflowDetail.withColumn(field.name, F.col(field.name).cast(field.dataType))

# dfCXCashflowDetail = dfCXCashflowDetail.select([field.name for field in destination_schema])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
