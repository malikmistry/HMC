# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "920a12cc-7104-4013-a2a3-d7baa57e9e3f",
# META       "default_lakehouse_name": "lh_raw",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "920a12cc-7104-4013-a2a3-d7baa57e9e3f"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import json
from delta.tables import DeltaTable
from datetime import datetime, timezone, date, timedelta
from pyspark.sql.functions import lit
from pyspark.sql.utils import AnalysisException
from pyspark.sql import SparkSession
from collections import defaultdict
import fnmatch
import re
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
# TaskList = "{\"JobAuditKey\":1463,\"TaskKey\":5003,\"TaskType\":\"FileTask\",\"SourceName\":\"ReutersFX\",\"SourceType\":\"ReutersFX\",\"FileType\":\"delimited\",\"SourceWildcardFolderPath\":\"proworkspace/ReutersFX/Archive\",\"SourceWildcardFileName\":\"wmr0809.csv\",\"SourceDataSet\":null,\"PrimaryKeyColumnList\":\"\",\"Delimiter\":\",\",\"RawLakehouseName\":\"lh_raw\",\"RawStoragePath\":\"ReutersFX\",\"RawStorageFileName\":\"FXRate\",\"ETLWarehouseName\":\"etlControl\",\"FileFilter\":\"to_date(`\\\"Date & Time\\\"`, 'dd/MM/yyyy HH:mm') = '{yesterday}'\",\"BronzeWorkspaceName\":\"Dev - Crimson\",\"BronzeLakehouseName\":\"lh_bronze\",\"BronzeSchemaName\":\"Bronze\",\"BronzeObjectName\":null,\"BronzeObject\":null,\"BronzeLoadMethod\":\"append\",\"WatermarkColumn\":\"ETLLoadDateTime\",\"SinkTableName\":\"FXRate\",\"SinkSchemaName\":\"Bronze\",\"SourceTableName\":\"FXRate\",\"SinkWatermarkColumn\":\"ETLLoadDateTime\",\"SinkLoadMethod\":\"append\",\"IsWatermarkEnabledFlag\":false,\"SourceFullExtractOverrideFlag\":null,\"SkipRows\":2,\"SinkWorkspaceName\":\"Dev - Crimson\",\"SheetIndexArray\":null}"
# RawLHId = "920a12cc-7104-4013-a2a3-d7baa57e9e3f"
# WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
# BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
RawLHId = ""
TaskList = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Convert JSON String to list
tasklist = [json.loads(TaskList)]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print_test()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import csv
from io import StringIO

def process_task(task, raw_lh_basepath):
    try:
        print(f"Processing TaskKey: {task['TaskKey']}. Sink: {task['SinkTableName']}")
        skiprows = task['SkipRows']
        delimiter = task['Delimiter']
        quotechar = '"'  # DEV_NOTE: to do - make this dynamic from etl table
        source_folder = f"{raw_lh_basepath}/Files/{task['SourceWildcardFolderPath']}"
        file_pattern = task['SourceWildcardFileName']
        dest_path = f"{raw_lh_basepath}/Files/{task['RawStoragePath']}/{task['RawStorageFileName']}"
        file_filter = task['FileFilter']
        context = {"yesterday": (date.today()).strftime("%Y-%m-%d")}

        all_files = mssparkutils.fs.ls(source_folder)
        matching_files = [f.path for f in all_files if fnmatch.fnmatch(f.name, file_pattern)]
        print(matching_files)

        if not matching_files:
            print("No matching files found.")
            return

        dfs = []
        for file_path in matching_files:
            print(f"\nReading file: {file_path}")
            lines = spark.read.text(file_path).rdd.map(lambda r: r[0]).collect()

            try:
                header_line = lines[skiprows]
                reader = csv.reader([header_line], delimiter=delimiter, quotechar=quotechar)
                header = next(reader)
            except IndexError:
                print(f"Skipping file {file_path}: Unable to read header line at index {skiprows}.")
                continue

            data_lines = lines[skiprows + 1:]


            reader = csv.reader(data_lines, delimiter=delimiter, quotechar=quotechar)
            valid_rows = [row for row in reader if len(row) == len(header)]

            if not valid_rows:
                raise RuntimeError(f"Skipping file {file_path}: No valid rows match header length {len(header)}.")

            rdd_data = spark.sparkContext.parallelize(valid_rows)
            df = spark.createDataFrame(rdd_data, schema=header)

            if file_filter:
                try:
                    file_filter_df = resolve_template(file_filter, context)
                    df = df.filter(file_filter_df)
                    print(f'date resolved file_filter: {file_filter_df}')
                except:
                    print(f'no date in filter: {file_filter}')
                    df = df.filter(file_filter)

            dfs.append(df)

        if not dfs:
            print("No valid DataFrames to process.")
            return

        final_df = dfs[0]
        for df in dfs[1:]:
            final_df = final_df.unionByName(df)

        final_df.write.mode("overwrite").parquet(dest_path)
        print(f"Written {len(dfs)} file(s) to Parquet at: {dest_path}")

    except Exception as e:
        raise RuntimeError(f"Task {task['TaskKey']} failed: {str(e)}") from e


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([RawLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        raw_lh_basepath = get_basepath(WorkspaceId, RawLHId)
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)

        # Process the task
        result = process_task(task_item,raw_lh_basepath)

    except Exception as e:
        print(f"Error processing task: {e}")
        raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
