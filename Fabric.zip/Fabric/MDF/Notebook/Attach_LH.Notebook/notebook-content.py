# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# PARAMETERS CELL ********************

WorkspaceName = 'Dev - Crimson'
NotebookName = ''
LakehouseSinkName = 'lh_bronze'
BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLHId = ''
RawLHId = '920a12cc-7104-4013-a2a3-d7baa57e9e3f'
WorkspaceId = ''
TenantId = ""
KeyVaultName = ""
ClientId = ""
SecretName = ""
SecretValue = ""
TaskList = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#we will attach the sinklakehouse to the notebook
if LakehouseSinkName == 'lh_bronze':
    LakehouseId = BronzeLHId
elif LakehouseSinkName == 'lh_curated':
    LakehouseId = CuratedLHId
# elif LakehouseSinkName == 'lh_raw':
#     LakehouseId = RawLHId

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#import sempy.fabric as fabric
import notebookutils
import json
import notebookutils
import json
from pyspark.sql import SparkSession
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
import msal, requests

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Convert JSON String to list
tasklist = json.loads(TaskList)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************



# # replace with actual values or pass via notebook parameters
# workspace_name = WorkspaceName         
# lakehouse_id = LakehouseId              
# lakehouse_name = LakehouseSinkName     

# notebooks_to_update = [
#     NotebookName,                       
#     "test_attach"
# ]

# # resolve workspace ID
# workspace_id = fabric.resolve_workspace_id(workspace_name)

# # list notebooks in the workspace
# items = fabric.list_items(workspace=workspace_name).where(lambda x: x["Type"] == "Notebook")

# # looop through notebooks and update binding
# for index, item in items.iterrows():
#     notebook_name = item["Display Name"]

#     if notebook_name in notebooks_to_update:
#         try:
#             # get notebook JSON definition
#             definition = notebookutils.notebook.getDefinition(notebook_name, workspace_id)
#             notebook_json = json.loads(definition)

#             #remove any existing Lakehouse bindings
#             bindings = notebook_json.get("bindings", [])
#             bindings = [b for b in bindings if b.get("type") != "Lakehouse"]

#             # add the new Lakehouse binding and set as default
#             lakehouse_binding = {
#                 "binding": {
#                     "name": lakehouse_name,
#                     "id": lakehouse_id,
#                     "workspaceId": workspace_id
#                 },
#                 "type": "Lakehouse",
#                 "isDefault": True
#             }
#             bindings.append(lakehouse_binding)
#             notebook_json["bindings"] = bindings

#             # update the notebook definition
#             updated_definition = json.dumps(notebook_json)
#             notebookutils.notebook.updateDefinition(
#                 name=notebook_name,
#                 content=updated_definition,
#                 workspaceId=workspace_id
#             )

#             print(f"Lakehouse attached and set as default for notebook: {notebook_name}")
#             print("Current lakehouse bindings:")
#             for b in bindings:
#                 if b["type"] == "Lakehouse":
#                     print(f" - {b['binding']['name']} (ID: {b['binding']['id']}, Default: {b.get('isDefault', False)})")


#         except Exception as e:
#             print(f"Failed to update {notebook_name}: {e}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

# import sempy.fabric as fabric
# import notebookutils

# # Get current notebook context (name and workspace)
# notebook_name = "test_attach"
# workspace_name = "Dev - Crimson"
# workspace_id = fabric.resolve_workspace_id(workspace_name)

# # Get notebook definition
# definition = notebookutils.notebook.getDefinition(notebook_name, workspace_id)

# import json
# notebook_json = json.loads(definition)

# # Check Lakehouse bindings
# bindings = notebook_json.get("bindings", [])
# lakehouses = [b for b in bindings if b.get("type") == "Lakehouse"]

# # Output the results
# if not lakehouses:
#     print("No Lakehouse is attached to this notebook.")
# else:
#     print("Attached Lakehouses:")
#     for lh in lakehouses:
#         print(f"- Name: {lh['binding']['name']}")
#         print(f"  ID: {lh['binding']['id']}")
#         print(f"  Default: {lh.get('isDefault', False)}\n")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

try:
    # ------------------------------------------------------------
    # 1. Initialize Spark session
    # ------------------------------------------------------------
    spark = SparkSession.builder.getOrCreate()

    # ------------------------------------------------------------
    # 2. Retrieve credentials securely from Azure Key Vault
    # ------------------------------------------------------------
    key_vault_url = f"https://{KeyVaultName}.vault.azure.net/"
    credential = DefaultAzureCredential()
    SecretValue = notebookutils.credentials.getSecret(key_vault_url,SecretName)
    print(SecretValue)
except Exception as e:
    raise RuntimeError(f"Task {tasklist['TaskKey']} failed: {str(e)}") from e

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

app = msal.ConfidentialClientApplication(
    ClientId,
    authority=f"https://login.microsoftonline.com/{TenantId}",
    client_credential=SecretValue
)

token = app.acquire_token_for_client(scopes=["https://api.fabric.microsoft.com/.default"])
access_token = token["access_token"]

headers = {"Authorization": f"Bearer {access_token}"}

url = f"https://api.fabric.microsoft.com/v1/workspaces/{WorkspaceId}/items"
resp = requests.get(url, headers=headers)

items = resp.json().get("value", [])

notebookList = [
    {"Id": item["id"], "Display Name": item["displayName"]}
    for item in items
    if item["type"].lower() == "notebook"
]

notebooks = {nb["Display Name"]: nb["Id"] for nb in notebookList}

if NotebookName not in notebooks:    
    raise ValueError(f"Notebook '{NotebookName}' not found in workspace '{WorkspaceName}'")

notebook_id = notebooks[NotebookName]
print(f"Notebook ID: {notebook_id}")
mssparkutils.notebook.exit(notebook_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# import pandas as pd
# import time

# max_retries = 3
# wait_seconds = 10

# # Get workspace ID
# workspace_id = WorkspaceId

# # Retry loop for listing items (handles Fabric timeout issues)
# for attempt in range(1, max_retries + 1):
#     try:
#         # List all items in workspace
#         items = fabric.list_items(workspace=WorkspaceName)
#         break
#     except Exception as e:
#         print(f"Attempt {attempt} failed: {e}")
#         if attempt < max_retries:
#             wait = wait_seconds * attempt
#             print(f"Retrying in {wait} seconds...")
#             time.sleep(wait)
#         else:
#             raise RuntimeError("All retries to fetch workspace items failed") from e

# # Filter valid notebook entries with non-null names and IDs
# notebooks = items[
#     (items["Type"].str.lower().str.contains("notebook")) &
#     (pd.notnull(items["Display Name"])) &
#     (pd.notnull(items["Id"]))
# ]

# # Print available valid notebooks
# print("Available notebooks with valid metadata:")
# print(notebooks[["Display Name", "Id"]])

# # Match notebook by exact name
# notebook_match = notebooks[notebooks["Display Name"] == NotebookName]

# if notebook_match.empty:
#     raise ValueError(f"Notebook '{NotebookName}' not found in workspace '{WorkspaceName}'")

# # Extract and return notebook ID
# notebook_id = notebook_match.iloc[0]["Id"]
# print(f"Notebook ID: {notebook_id}")

# # Return the notebook ID to pipeline caller
# mssparkutils.notebook.exit(notebook_id)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
