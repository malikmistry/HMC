# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************


# CELL ********************

# ---------------------------------------------------------------------------
# | Scenario                     | Action                                   |
# |------------------------------|------------------------------------------|
# | First-time write             |  Full load (overwrite + mergeSchema)     |
# | New columns detected         |  Schema evolution (append + mergeSchema) |
# | Column data type change      |  MUST BE MANUALLY CASTED BEFORE WRITE    |
# | Rows exist but changed       |  MERGE updates changed rows              |
# | New rows added               |  MERGE inserts missing rows              |
# | All columns are primary keys |  Only updates HWM if data changed        |
# ---------------------------------------------------------------------------

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import json
from delta.tables import DeltaTable
from datetime import datetime, timezone
from pyspark.sql.functions import lit
from pyspark.sql.utils import AnalysisException
from pyspark.sql import SparkSession
from collections import defaultdict
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
TaskKey = 5003
TaskList = "{\"JobAuditKey\":1463,\"TaskKey\":5003,\"TaskType\":\"FileTask\",\"SourceName\":\"ReutersFX\",\"SourceType\":\"ReutersFX\",\"FileType\":\"delimited\",\"SourceWildcardFolderPath\":\"proworkspace/ReutersFX\",\"SourceWildcardFileName\":\"*.csv\",\"SourceDataSet\":null,\"PrimaryKeyColumnList\":\"\",\"Delimiter\":\",\",\"RawLakehouseName\":\"lh_raw\",\"RawStoragePath\":\"ReutersFX\",\"RawStorageFileName\":\"FXRate\",\"ETLWarehouseName\":\"etlControl\",\"FileFilter\":\"to_date(`\\\"Date & Time\\\"`, 'dd/MM/yyyy HH:mm') = '{yesterday}'\",\"BronzeWorkspaceName\":\"Dev - Crimson\",\"BronzeLakehouseName\":\"lh_bronze\",\"BronzeSchemaName\":\"Bronze\",\"BronzeObjectName\":null,\"BronzeObject\":null,\"BronzeLoadMethod\":\"append\",\"WatermarkColumn\":\"ETLLoadDateTime\",\"SinkTableName\":\"FXRate\",\"SinkSchemaName\":\"Bronze\",\"SourceTableName\":\"FXRate\",\"SinkWatermarkColumn\":\"ETLLoadDateTime\",\"SinkLoadMethod\":\"append\",\"IsWatermarkEnabledFlag\":false,\"SourceFullExtractOverrideFlag\":null,\"SkipRows\":2,\"SinkWorkspaceName\":\"Dev - Crimson\",\"SheetIndexArray\":null}"
BronzeLhId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
RawLhId = "920a12cc-7104-4013-a2a3-d7baa57e9e3f"
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

TaskList = ''
WatermarkList = ''
# GUIDList = ''
BronzeLhId = ''
WorkspaceId = ''
RawLhId= ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Convert JSON String to list
tasklist = [json.loads(TaskList)]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Set watermark
etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
print(etlloadtime) 

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import re

def sanitize_column_names_with_mapping(df):
    rename_map = {}
    for col in df.columns:
        sanitized = col.replace("%", "Percentage")
        sanitized = re.sub(r"[^a-zA-Z0-9_]", "_", sanitized)
        sanitized = re.sub(r"_+", "_", sanitized).strip("_")
        
        if sanitized != col:
            df = df.withColumnRenamed(col, sanitized)
            rename_map[sanitized] = col  # store reverse mapping for restoring, not used in this code but for future development

    if rename_map:
        print(f"[i] Column rename mapping: {rename_map}")
    return df


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def restore_original_column_names(df, rename_map):
    for sanitized, original in rename_map.items():
        df = df.withColumnRenamed(sanitized, original)
    return df


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col, coalesce

def unify_hwm_column(df, hwm_column):
    # Identify all columns with HWM name or variants like etlloaddatetime_1
    hwm_candidates = [c for c in df.columns if c == hwm_column or c.startswith(f"{hwm_column}_")]

    if len(hwm_candidates) > 1:
        print(f"Multiple HWM columns detected: {hwm_candidates}. Unifying into one '{hwm_column}'.")

        # Create unified column using coalesce (first non-null wins)
        df = df.withColumn(hwm_column, coalesce(*[col(c) for c in hwm_candidates]))

        # Drop all other variants except the unified one
        cols_to_drop = [c for c in hwm_candidates if c != hwm_column]
        df = df.drop(*cols_to_drop)

    return df


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************



return_value = []

def process_task(task, etlloadtime):
    try:
        print(f"Processing TaskKey: {task['TaskKey']}. Sink: {task['SinkTableName']}")

        # Define Parameters
        base_path = f"{raw_lh_basepath}/Files/{task['RawStoragePath']}"
        source_path = f"{raw_lh_basepath}/Files/{task['RawStoragePath']}/{task['RawStorageFileName']}"
        target_table = task['SinkTableName']
        target_schema = task['SinkSchemaName']
        target_path = f"{bronze_lh_basepath}/Tables/{target_schema}/{target_table}"
        hwm_column_raw = task['SinkWatermarkColumn']
        hwm_column = (
            "ETLLoadDateTime"
            if not hwm_column_raw or str(hwm_column_raw).strip().upper() == "NULL"
            else hwm_column_raw
        )
        primary_column = task['PrimaryKeyColumnList']
        method = task['SinkLoadMethod']
        # hwm_value = next((item["HighWatermarkValue"] for item in watermarklist if item["TaskKey"] == task["TaskKey"]), None)

        # Try reading using RawStorageFileName
        # for suffix in [f"/{task['RawStorageFileName']}/", f"/{task['RawStorageFileName']}.parquet"]: --mdf modification convertdb notebook removed, folder is not being utilized, use .parquet files
        for suffix in [f"/{task['RawStorageFileName']}.parquet"]:
            source_path = base_path + suffix
            print(f'Trying to read from: {source_path}')
            try:
                df_source = spark.read.format("parquet").load(source_path)
                break  # Success, no need to try further
            except AnalysisException:
                df_source = None  # Continue to try next

        # If RawStorageFileName failed, try SourceTableName
        if df_source is None:
            for suffix in [f"/{task['SourceTableName']}/", f"/{task['SourceTableName']}.parquet"]:
                source_path = base_path + suffix
                print(f'Trying to read from: {source_path}')
                try:
                    df_source = spark.read.format("parquet").load(source_path)
                    break  # Success
                except AnalysisException:
                    df_source = None

        # If still not loaded, raise error
        if df_source is None:
            raise FileNotFoundError(
                f"Parquet file not found at any of the expected paths using RawStorageFileName or SourceTableName under: {base_path}"
            )

        df_source = sanitize_column_names_with_mapping(df_source)
        RowsRead = df_source.count()

        #determine primary keys: if primary_column is None, use all columns as primary keys
        if not primary_column or str(primary_column).strip().upper() == "NULL":
            primary_keys = df_source.columns  # all columns
            print('No primary column')
        else:
            primary_keys = [col.strip() for col in (primary_column.split(",") if isinstance(primary_column, str) else primary_column)]
       # Sanitize primary columns to match cleansed columns of df_source
        sanitized_primary_keys = []
        for col in primary_keys:
            sanitized = col.replace("%", "Percentage")
            sanitized = re.sub(r"[^a-zA-Z0-9_]", "_", sanitized)
            sanitized = re.sub(r"_+", "_", sanitized).strip("_")
            sanitized_primary_keys.append(sanitized)


        # Deduplicate based on the primary keys
        df_source = df_source.dropDuplicates(sanitized_primary_keys)
        print(f"[debug] Columns after reading and dedup: {df_source.columns}")
        print()

        #create temporary view
        df_source.createOrReplaceTempView("df_source_view")
        spark.catalog.cacheTable("df_source_view")


        #skip processing if source table is empty
        if df_source.rdd.isEmpty():
            print(f"\n Source table is empty. Skipping TaskKey: {task['TaskKey']}.")
            RowsRead = 0
            RowsInserted = 0
            RowsUpdated = 0
            RowsDeleted = 0
            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsInserted,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }
            

        # Check if target table exists
        table_exists = True
        try:
            df_target = spark.read.format("delta").load(target_path)
        except AnalysisException:
            table_exists = False


        if not table_exists:
            print(f"\nTarget table does not exist. Creating it at: {target_path}")
            if hwm_column not in df_source.columns:
                try:
                    df_source = df_source.withColumn(hwm_column, lit(etlloadtime))
                except Exception as e:
                    print(f"[ERROR] Failed to add watermark column '{hwm_column}': {e}")
                    raise
            df_source.write.format("delta").mode("overwrite").save(target_path)

            spark.sql(f"""
                CREATE TABLE IF NOT EXISTS {target_schema}.{target_table}
                USING DELTA
                LOCATION '{target_path}'
            """)
            RowsRead = df_source.count()
            RowsUpdated = 0
            RowsDeleted = 0
            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsRead,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }

        elif method == 'overwrite':
            print(f"\nOverwriting existing table at: {target_path}")
            if hwm_column not in df_source.columns:
                try:
                    df_source = df_source.withColumn(hwm_column, lit(etlloadtime))
                except Exception as e:
                    print(f"[ERROR] Failed to add watermark column '{hwm_column}': {e}")
                    raise
            df_source.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(target_path)

            RowsRead = df_source.count()
            RowsUpdated = 0
            RowsDeleted = 0
            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsRead,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }

        elif method == 'append':
            print(f"\nAppending to existing table at: {target_path}")
            if hwm_column not in df_source.columns:
                try:
                    df_source = df_source.withColumn(hwm_column, lit(etlloadtime))
                except Exception as e:
                    print(f"[ERROR] Failed to add watermark column '{hwm_column}': {e}")
                    raise
            df_source.write.format("delta").mode("append").save(target_path)
            display(df_source.limit(10))
            RowsRead = df_source.count()
            RowsUpdated = 0
            RowsDeleted = 0
            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsRead,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }
        
        else:
            print(f"Method is not overwrite or append, '{method}' — performing merge")
        # Get schema information
        df_source_view_df = spark.table("df_source_view")
        schema_target = {field.name: field.dataType for field in df_target.schema if field.name != hwm_column}
        schema_source = {field.name: field.dataType for field in df_source_view_df.schema if field.name != hwm_column}

        # Schema doesn't match
        if schema_target != schema_source:
            print(f"Schema change detected on {task['SourceTableName']}")
            # Only add the watermark column if it doesn't already exist
            if hwm_column not in df_source_view_df.columns:
                df_source = df_source_view_df.withColumn(hwm_column, lit(etlloadtime))
            else:
                print(f"Watermark column '{hwm_column}' already exists in source. Skipping addition.")
                df_source = df_source_view_df
            df_source.write.format("delta").mode("append").option("mergeSchema", "true").save(target_path)

            RowsInserted = df_source.count()
            RowsUpdated = 0
            RowsDeleted = 0
            print(f"\n [✓] COMPLETE MergeSchema: TaskKey {task['SinkTableName']}")
            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsInserted,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }


        # Perform Merge
        print(f"Performing merge on {task['SinkTableName']}")
        columns = df_source.columns
        change_condition = " OR ".join([f"target.{col} IS DISTINCT FROM source.{col}" for col in columns if col not in sanitized_primary_keys and col != hwm_column])

        # Check if all columns are primary keys by comparing with the primary_column list
        if len(sanitized_primary_keys) == len(columns):
            # All columns are primary keys, meaning only inserts should happen unless data changes.
            print(f"All columns are primary keys. Ensuring valid update conditions.")

            merge_query = f"""
            MERGE INTO {target_schema}.{target_table} AS target
            USING (
                SELECT * FROM (
                    SELECT *, ROW_NUMBER() OVER (PARTITION BY {', '.join(sanitized_primary_keys)} ORDER BY rand()) AS rn
                    FROM df_source_view
                ) AS subquery
                WHERE rn = 1
            ) AS source
            ON ({' AND '.join([f"target.{col} = source.{col}" for col in sanitized_primary_keys])})
            """

            if change_condition:  # Only include the update condition if there are non-PK columns to compare, this part of the code is for fail-safe. If all columns are PK here, this will not be added
                merge_query += f"""
                WHEN MATCHED
                AND ({change_condition})
                THEN
                    UPDATE SET target.{hwm_column} = '{etlloadtime}'
                """

            merge_query += f"""
            WHEN NOT MATCHED THEN
                INSERT ({', '.join(columns)}, {hwm_column})
                VALUES ({', '.join([f'source.{col}' for col in columns])}, '{etlloadtime}'); 
            """

            print(merge_query)


        else:
            # Regular merge logic (non-primary-key columns can be updated)
            merge_query = f"""
            MERGE INTO {target_schema}.{target_table} AS target
            USING (
                SELECT * FROM (
                    SELECT *, ROW_NUMBER() OVER (PARTITION BY {', '.join(sanitized_primary_keys)} ORDER BY rand()) AS rn
                    FROM df_source_view
                ) AS subquery
                WHERE rn = 1
            ) AS source
            ON ({' AND '.join([f"target.{col} = source.{col}" for col in sanitized_primary_keys])})
            WHEN MATCHED
            AND ({change_condition})
            THEN
                UPDATE SET {', '.join([f"target.{col} = source.{col}" for col in columns if col != hwm_column])},
                        target.{hwm_column} = '{etlloadtime}'
            WHEN NOT MATCHED THEN
                INSERT ({', '.join(columns)}, {hwm_column})
                VALUES ({', '.join([f'source.{col}' for col in columns])}, '{etlloadtime}'); 
            """

        spark.sql(merge_query)


        delta_table = DeltaTable.forPath(spark, target_path)
        # Load as DataFrame, not DeltaTable
        df_target = spark.read.format("delta").load(target_path)

        # Apply reverse column renaming to DataFrame
        # df_restored = restore_original_column_names(df_target, rename_map)

        # Get the latest commit history
        history_df_audit = delta_table.history(1)  # Get last operation only

        # Extract operation metrics
        operation_metrics = history_df_audit.select("operationMetrics").collect()[0][0]
        RowsInserted = int(operation_metrics.get("numOutputRows", 0))  # Rows written
        RowsUpdated = int(operation_metrics.get("numUpdatedRows", 0))  # Updated rows
        RowsDeleted = int(operation_metrics.get("numDeletedRows", 0))  # Deleted rows

        
        # Overwrite the cleaned DataFrame
        # df_restored.write.format("delta").mode("overwrite").save(target_path)

        print(f"\n [✓] COMPLETE Merge: TaskKey {task['SinkTableName']}")
        return {
            "RowsRead": RowsRead,
            "RowsInserted": RowsInserted,
            "RowsUpdated": RowsUpdated,
            "RowsDeleted": RowsDeleted
        }

    except Exception as e:
        raise RuntimeError(f"Task {task['TaskKey']} failed: {str(e)}") from e



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_guid_value(key):
    value = next((item['ConfigValue'] for item in guidlist if item['ConfigKey'] == key), None)
    if value is None:
        print(f"Missing GUID for key: {key}")
    return value


for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([BronzeLhId, RawLhId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLhId)
        raw_lh_basepath = get_basepath(WorkspaceId, RawLhId)

        # Process the task
        result = process_task(task_item, etlloadtime)

    except Exception as e:
        print(f"Error processing task: {e}")
        raise


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from datetime import datetime
import re
from notebookutils import mssparkutils  # Import Fabric-specific file system utilities

# Archive path (already created earlier in the code)
archive_path = f"{raw_lh_basepath}/Files/Archive"
print(archive_path)

def move_to_archive(file_path):
    file_path = file_path.rstrip('/')  # Remove trailing slash
    print(f"Processed file path: {file_path}")
    
    # Get current date (year, month, day)
    current_date = datetime.now()
    year = current_date.year
    month = current_date.strftime('%m')  # Zero-padded month
    day = current_date.strftime('%d')   # Zero-padded day

    # Extract folder name like "01Test" from the input file path
    match = re.search(r'/Files/([^/]+)(?:/|$)', file_path)

    print(f"Regex match result: {match}")
    
    if not match:
        print(" Unable to extract source folder (e.g., 01Test) from path.")
        return
    
    table_folder = match.group(1)
    print(f"Extracted folder: {table_folder}")

    # Construct full archive destination path
    archive_dir = f"{archive_path}/{year}/{month}/{day}"
    file_name = file_path.split('/')[-1]  # Extract the file name from the path
    destination_path = f"{archive_dir}"

    print(f"Moving to: {destination_path}")

    try:
        # Ensure the destination directory exists in Fabric
        # In Fabric, use mssparkutils.fs.mkdirs for directory creation (works with ADLS/OneLake)
        mssparkutils.fs.mkdirs(archive_dir)

        # Use mssparkutils.fs.mv() to move the file in Fabric
        mssparkutils.fs.mv(file_path, destination_path)

        # Delete the original after confirming copy
        mssparkutils.fs.rm(file_path, recurse=False)
        print(f"File moved successfully to: {destination_path}")
    except Exception as e:
        print(f"Error occurred while moving file: {e}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

result = {
    "RowsCopied": result["RowsRead"],
    "RowsInserted": result["RowsInserted"],
    "RowsUpdated": result["RowsUpdated"],
    "RowsDeleted": result["RowsDeleted"]
}
notebookutils.notebook.exit(str(result))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
