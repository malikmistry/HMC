# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "920a12cc-7104-4013-a2a3-d7baa57e9e3f",
# META       "default_lakehouse_name": "lh_raw",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "920a12cc-7104-4013-a2a3-d7baa57e9e3f"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import json
from pyspark.sql.functions import col, hex, lower
from delta.tables import DeltaTable
from datetime import datetime, timezone
from pyspark.sql.functions import lit
from pyspark.sql.utils import AnalysisException
from pyspark.sql import SparkSession
from collections import defaultdict

spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "LEGACY")
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.json.maxStringLimit", 100000000) 

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

TaskList = ''
WorkspaceName = ''
RawLHId = ''
BronzeLHId = ''
WorkspaceId = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Convert JSON String to list
tasklist = [json.loads(TaskList)]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
import uuid

def convert_binary_column(b):
    try:
        if hasattr(b, 'toByteArray'):
            b = bytes(b.toByteArray())
        if isinstance(b, (bytes, bytearray)):
            if len(b) == 16:
                return str(uuid.UUID(bytes_le=b)).lower()
            else:
                return b.hex().lower()
    except:
        return None
    return None

binary_to_guid_udf = udf(convert_binary_column, StringType())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col, hex, trim, upper, col
from notebookutils import mssparkutils


def process_task(task):
    try:
        folder_base = f"{raw_lh_basepath}/Files/{task['RawStoragePath']}/{task['RawStorageFileName']}"
        file_path = folder_base + ".parquet"

        # Check if .parquet file exists
        if mssparkutils.fs.exists(file_path):
            source_file = file_path
            print(f"Reading from file: {source_file}")
        # Else check if folder exists
        elif mssparkutils.fs.exists(folder_base):
            source_file = folder_base
            print(f"Reading from folder: {source_file}")
        else:
            raise RuntimeError(f"Neither file nor folder found for task {task['TaskKey']}:\n  - {file_path}\n  - {folder_base}")

        # Set target path (write as a folder)
        target_path = folder_base

        df = spark.read.parquet(source_file)
        df.show(5)

        binary_columns = [f.name for f in df.schema.fields if f.dataType.simpleString() == "binary"]
        print("Binary columns detected:", binary_columns)

        for col_name, dtype in df.dtypes:
            if col_name.lower().endswith("id"):
                if dtype == "binary":
                    df = df.withColumn(col_name, binary_to_guid_udf(col(col_name)))
                elif dtype in ("string", "varchar"):
                    df = df.withColumn(col_name, lower(col(col_name)))
                else:
                    # Leave int or other types untouched
                    pass


        df.show(5, truncate=False)
        df.write.mode("overwrite").parquet(target_path)

        print(f"Converted Parquet saved to {target_path}")
    except Exception as e:
        raise RuntimeError(f"Task {task['TaskKey']} failed: {str(e)}") from e


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print_test()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([WorkspaceId, RawLHId, BronzeLHId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception

        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        raw_lh_basepath = get_basepath(WorkspaceId, RawLHId)
        # Process the task
        result = process_task(task_item)

    except Exception as e:
        print(f"Error processing task: {e}")
        raise
    

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
