# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

import json
from delta.tables import DeltaTable
from datetime import datetime, timezone
from pyspark.sql.functions import lit
from pyspark.sql.utils import AnalysisException
from pyspark.sql import SparkSession
from collections import defaultdict
import fnmatch
import re
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from datetime import date
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
# TaskList = "{\"JobAuditKey\":457,\"TaskKey\":5022,\"TaskType\":\"FileTask\",\"SourceName\":\"Blob\",\"SourceType\":\"file\",\"FileType\":\"json\",\"SourceWildcardFolderPath\":\"proworkspace/Notes/MetaData\",\"SourceWildcardFileName\":\"{date.today():%Y%m}\",\"SourceDataSet\":\"\",\"PrimaryKeyColumnList\":\"noteId\",\"Delimiter\":null,\"RawLakehouseName\":\"lh_raw\",\"RawStoragePath\":\"Notes\",\"RawStorageFileName\":\"Notes\",\"ETLWarehouseName\":\"etlControl\",\"BronzeWorkspaceName\":\"Dev - Crimson\",\"BronzeLakehouseName\":\"lh_bronze\",\"BronzeSchemaName\":\"Bronze\",\"BronzeObjectName\":null,\"BronzeObject\":null,\"BronzeLoadMethod\":\"merge\",\"WatermarkColumn\":null,\"SinkTableName\":\"Note\",\"SinkSchemaName\":\"Bronze\",\"SourceTableName\":\"Notes\",\"SinkWatermarkColumn\":null,\"SinkLoadMethod\":\"merge\",\"IsWatermarkEnabledFlag\":false,\"SourceFullExtractOverrideFlag\":null,\"SkipRows\":null,\"SinkWorkspaceName\":\"Dev - Crimson\"}"
# RawLHId = "920a12cc-7104-4013-a2a3-d7baa57e9e3f"
# WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
# BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
RawLHId = ""
TaskList = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Convert JSON String to list
tasklist = [json.loads(TaskList)]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def resolve_template(template_str: str, context: dict) -> str:
    try:
        return eval(f"f'{template_str}'", {}, context)
    except Exception as e:
        raise ValueError(f"Error resolving template '{template_str}': {e}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from notebookutils import mssparkutils

def list_json_files_recursively(base_path):
    files = []

    def list_dir(path):
        entries = mssparkutils.fs.ls(path)
        for entry in entries:
            if entry.isDir:
                list_dir(entry.path)
            elif entry.path.endswith(".json"):
                files.append(entry.path)

    list_dir(base_path)
    return files

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def process_task(task, raw_lh_basepath):
    try:
        context = {
            "date": date
        }
        source_folder = f"{raw_lh_basepath}/Files/{task['SourceWildcardFolderPath']}"
        source_name = task['SourceWildcardFileName']
        dest_path = f"{raw_lh_basepath}/Files/{task['RawStoragePath']}/{task['RawStorageFileName']}"
        resolved_filename = resolve_template(task["SourceWildcardFileName"], context)

        path1 = f"{source_folder}/{source_name}"
        # path1 = f"{source_folder}/"
        path2 = f"{source_folder}/{resolved_filename}"
        # path2 = list_json_files_recursively(source_folder)

        if mssparkutils.fs.exists(path1):
            df_raw = spark.read.option("multiline", True).json(path1)
            # df_raw = spark.read.json(path1)
            print(path1)
        elif mssparkutils.fs.exists(path2):
            print(path2)
            df_raw = spark.read.option("multiline", True).json(path2)
        else:
            raise FileNotFoundError(f"Neither {path1} nor {path2} exist.")


        # df_raw.show(10)

        # Write to Delta
        df_raw.write.format("parquet").mode("overwrite").save(dest_path)

    except Exception as e:
        raise RuntimeError(f"Task {task['TaskKey']} failed: {str(e)}") from e


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([RawLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        raw_lh_basepath = get_basepath(WorkspaceId, RawLHId)
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)

        # Process the task
        result = process_task(task_item,raw_lh_basepath)

    except Exception as e:
        print(f"Error processing task: {e}")
        raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
