# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": ""
# META     }
# META   }
# META }

# CELL ********************

# Import necessary libraries
from concurrent.futures import ThreadPoolExecutor, as_completed
from notebookutils import mssparkutils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import sempy.fabric as fabric
import notebookutils

# Get current notebook context (name and workspace)
notebook_name = "99_ExecuteNotebookbyName"
workspace_name = "Dev - Crimson"
workspace_id = fabric.resolve_workspace_id(workspace_name)

# Get notebook definition
definition = notebookutils.notebook.getDefinition(notebook_name, workspace_id)

import json
notebook_json = json.loads(definition)

# Check Lakehouse bindings
bindings = notebook_json.get("bindings", [])
lakehouses = [b for b in bindings if b.get("type") == "Lakehouse"]

# Output the results
if not lakehouses:
    print("No Lakehouse is attached to this notebook.")
else:
    print("Attached Lakehouses:")
    for lh in lakehouses:
        print(f"- Name: {lh['binding']['name']}")
        print(f"  ID: {lh['binding']['id']}")
        print(f"  Default: {lh.get('isDefault', False)}\n")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

NotebookName = ''
WorkspaceId = ''
BronzeLHId = ''
CuratedLHId = ''
TaskList = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

params = {
    "WorkspaceId": WorkspaceId,
    "BronzeLHId": BronzeLHId,
    "CuratedLHId": CuratedLHId,
    "TaskList": TaskList
}
print(params)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************



def run_notebook_by_path(notebook_path: str, params: dict, timeout: int = 600) -> str:
    try:
        result = mssparkutils.notebook.run(notebook_path, timeout, params)
        if result:
            return f"SUCCESS: {notebook_path} → {result}"
        else:
            return f"SUCCESS: {notebook_path} → No return value" #not expect a return value everytime, if no return value, last cell may show up as suceeded but there may be failure
    except Exception as e:
        raise RuntimeError(f"Task {params.get('TaskKey', 'unknown')} failed: {str(e)}") from e



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

result = run_notebook_by_path(NotebookName, params)
print(result)
if "FAILED" in result:
   print("Stopping further execution due to failure.")
  

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
NotebookName = "FXRate_Silver"
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "{\"JobAuditKey\":370,\"TaskKey\":76,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"FXRate\",\"SinkLakehouseName\":\"lh_silver\",\"SinkTableName\":\"FXRate\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"4\",\"NotebookName\":\"FXRate_Silver\"}"
LakehouseName = "lh_silver"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
