# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# ---------------------------------------------------------------------------
# | Scenario                     | Action                                   |
# |------------------------------|------------------------------------------|
# | First-time write/Overwrite   |  Full load (overwrite + overwriteSchema) |
# | New columns detected         |  Schema evolution (append + mergeSchema) |
# | Column data type change      |  MUST BE MANUALLY CASTED BEFORE WRITE    |
# | Rows exist but changed       |  MERGE updates changed rows              |
# | New rows added               |  MERGE inserts missing rows              |
# | All columns are primary keys |  Only updates HWM if data changed        |
# ---------------------------------------------------------------------------

#Note: Overwrite if CustomSQLSourceQuery exists is TRUNCATE + APPEND (to preserve schema)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import json
from delta.tables import DeltaTable
from datetime import datetime, timezone, date, timedelta
from pyspark.sql.functions import lit
from pyspark.sql.utils import AnalysisException
from pyspark.sql import SparkSession
from collections import defaultdict
from notebookutils import fs
import re
from pyspark.sql.functions import col, coalesce
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

TaskList = ''
BronzeLhId = ''
CuratedLhId = ''
WorkspaceId = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Convert JSON String to list
tasklist = json.loads(TaskList)
# Set watermark
etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### **HIDDEN CELL BELOW, DON'T DELETE** _Functions for the main process_

# CELL ********************

# Clean column headers to save to Delta Table
def sanitize_column_names_with_mapping(df):
    rename_map = {}
    for col in df.columns:
        sanitized = col.replace("%", "Percentage")
        sanitized = re.sub(r"[^a-zA-Z0-9_]", "_", sanitized)
        sanitized = re.sub(r"_+", "_", sanitized).strip("_")
        
        if sanitized != col:
            df = df.withColumnRenamed(col, sanitized)
            rename_map[sanitized] = col  # store reverse mapping for restoring, not used in this code but for future development

    if rename_map:
        print(f"[i] Column rename mapping: {rename_map}")
    return df

def restore_original_column_names(df, rename_map):
    for sanitized, original in rename_map.items():
        df = df.withColumnRenamed(sanitized, original)
    return df

#Functions to make sure only one HWM column exists before merge
def unify_hwm_column(df, hwm_column):
    # Identify all columns with HWM name or variants like etlloaddatetime_1
    hwm_candidates = [c for c in df.columns if c == hwm_column or c.startswith(f"{hwm_column}_")]

    if len(hwm_candidates) > 1:
        print(f"Multiple HWM columns detected: {hwm_candidates}. Unifying into one '{hwm_column}'.")

        # Create unified column using coalesce (first non-null wins)
        df = df.withColumn(hwm_column, coalesce(*[col(c) for c in hwm_candidates]))

        # Drop all other variants except the unified one
        cols_to_drop = [c for c in hwm_candidates if c != hwm_column]
        df = df.drop(*cols_to_drop)

    return df

def replace_with_delta(sql, bronze_lh_basepath, silver_lh_basepath):
    # Replace Bronze.<table> only if it appears
    sql = re.sub(
        r"\bBronze\.([A-Za-z0-9_]+)", 
        lambda m: f"delta.`{bronze_lh_basepath}/Tables/Bronze/{m.group(1)}`", 
        sql
    )
    
    # Replace Silver.<table> only if it appears
    sql = re.sub(
        r"\bSilver\.([A-Za-z0-9_]+)", 
        lambda m: f"delta.`{silver_lh_basepath}/Tables/Silver/{m.group(1)}`", 
        sql
    )
    
    return sql


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

return_value = []

def process_task(task):
    try:
        # Define Parameters
        source_path = f"{bronze_lh_basepath}/Tables/Bronze/{task['SourceTableName']}"
        print(f"Reading: {source_path}")
        target_table = task['SinkTableName']
        target_path = f"{silver_lh_basepath}/Tables/Silver/{target_table}"
        hwm_column = task['SinkWatermarkColumn']
        primary_column = task['PrimaryKeyColumnList']
        method = task['SinkLoadMethod']

        # Custom transformations - small transformation tasks from etl table
        source_where_clause = task['SourceWhereClause']
        sourcesqlcode = task['CustomSQLSourceQuery']
            

        # If custom source sql query exists, take source data from the query result, otherwise, take it from source path
        if (
            sourcesqlcode is None
            or str(sourcesqlcode).strip() == ""
            or str(sourcesqlcode).strip().upper() == "NULL"
        ):
            #default to reading from Delta source path
            source_path = f"{bronze_lh_basepath}/Tables/Bronze/{task['SourceTableName']}"
            print(f"Using source path: {source_path}")
            df_temp = spark.read.format("delta").load(source_path)
        else:
            #use SQL logic as custom source
            ddl_path = f"{silver_lh_basepath}/Files/DDLScripts"
            execute_ddl(target_table, ddl_path) #DEV_NOTE: This will not fail for now if DDL Script does not exist
            sourcesqlcode_resolved = replace_with_delta(sourcesqlcode,bronze_lh_basepath,silver_lh_basepath)
            print(f"Using SQL as source: {sourcesqlcode_resolved}")
            df_temp = spark.sql(sourcesqlcode_resolved)

        # Determine primary keys
        if not primary_column or str(primary_column).strip().upper() == "NULL":
            primary_keys = [col for col in df_temp.columns if col != hwm_column]
            df_source = df_temp.dropDuplicates(primary_keys)
        else:
            primary_keys = [col.strip() for col in primary_column.split(",")]
            df_source = df_temp.dropDuplicates(primary_keys)

        #Read Parquet source and clean
        df_source = sanitize_column_names_with_mapping(df_source)
        if "ETLLoadDateTime" in df_source.columns:
            df_source = df_source.drop("ETLLoadDateTime")

        # Create tempview for spark.sql use
        df_source.createOrReplaceTempView("df_source_view")

        # ---------- LOGIC FOR PROCESSING DATA ---------- #

        # Skip processing if source table is empty
        if df_source.rdd.isEmpty():
            print(f"\n Source table {source_path} is empty. Skipping TaskKey: {task['TaskKey']}.")
            RowsRead = 0
            RowsInserted = 0
            RowsUpdated = 0
            RowsDeleted = 0
            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsInserted,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }

        # Check if a filter clause is provided
        if source_where_clause:
            df_source = df_source.filter(source_where_clause)
        else:
            print("No source where clause applied")

            
        # Check if target table exists
        table_exists = True
        try:
            df_target = spark.read.format("delta").load(target_path)
        except AnalysisException:
            table_exists = False

        RowsRead = df_source.count()  # Count total rows in source

        if not table_exists:
            print(f"\nTarget table does not exist. Creating it at: {target_path}")
            if hwm_column not in df_source.columns:
                try:
                    df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast("timestamp"))
                except Exception as e:
                    print(f"[ERROR] Failed to add watermark column '{hwm_column}': {e}")
                    raise
            df_source.write.format("delta").mode("overwrite").save(target_path)
            RowsRead = df_source.count()
            RowsInserted = df_source.count()
            RowsUpdated = 0
            RowsDeleted = 0
            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsInserted,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }
        #Overwrite
        #Dev Note (9/18/2025)
        #Complete: Replace overwrite with truncate+append
        elif method == 'overwrite' and not (
            sourcesqlcode is None 
            or str(sourcesqlcode).strip() == "" 
            or str(sourcesqlcode).strip().upper() == "NULL"
        ):
            print(f"\nTruncating and reloading table at: {target_path}")

            if hwm_column not in df_source.columns:
                try:
                    df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast("timestamp"))
                except Exception as e:
                    print(f"[ERROR] Failed to add watermark column '{hwm_column}': {e}")
                    raise

            # --- Truncate the target table using Spark SQL (preserves schema) ---
            truncateQuery = f"""
                TRUNCATE TABLE {task['SinkSchemaName']}.{task['SinkTableName']}
            """
            print(f"Executing truncate query")
            spark.sql(truncateQuery)

            # --- Append the new data ---
            df_source.write.format("delta").mode("append").save(target_path)

            RowsRead = df_source.count()
            RowsInserted = RowsRead
            RowsUpdated = 0
            RowsDeleted = 0

            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsInserted,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }
        elif method == 'overwrite' and (
            sourcesqlcode is None 
            or str(sourcesqlcode).strip() == "" 
            or str(sourcesqlcode).strip().upper() == "NULL"
            ):
        
            print(f"\nOverwriting existing table at: {target_path}")
            if hwm_column not in df_source.columns:
                try:
                    df_source = df_source.withColumn(hwm_column, lit(etlloadtime))
                except Exception as e:
                    print(f"[ERROR] Failed to add watermark column '{hwm_column}': {e}")
                    raise
            df_source.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(target_path)
            RowsRead = df_source.count()
            RowsInserted = df_source.count()
            RowsUpdated = 0
            RowsDeleted = 0
            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsInserted,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }
        # Append
        elif method == 'append':
            print(f"\nAppending to existing table at: {target_path}")
            if hwm_column not in df_source.columns:
                try:
                    df_source = df_source.withColumn(hwm_column, lit(etlloadtime).cast("timestamp"))
                except Exception as e:
                    print(f"[ERROR] Failed to add watermark column '{hwm_column}': {e}")
                    raise
            df_source.write.format("delta").mode("append").save(target_path)
            RowsRead = df_source.count()
            RowsInserted = df_source.count()
            RowsUpdated = 0
            RowsDeleted = 0
            return {
                "RowsRead": RowsRead,
                "RowsInserted": RowsInserted,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }
        
        else:
            print(f"Method is not overwrite or append, '{method}' — performing merge")
        #Merge
        # Get schema information
        df_source_view_df = spark.table("df_source_view")
        schema_target = {field.name: field.dataType for field in df_target.schema if field.name != hwm_column}
        schema_source = {field.name: field.dataType for field in df_source_view_df.schema if field.name != hwm_column}

        if schema_target != schema_source:
            print(f"Schema change detected on {task['SourceTableName']}")

            # Only add the watermark column if it doesn't already exist
            if hwm_column not in df_source_view_df.columns:
                df_source = df_source_view_df.withColumn(hwm_column, lit(etlloadtime).cast("timestamp"))
            else:
                print(f"Watermark column '{hwm_column}' already exists in source. Skipping addition.")
                df_source = df_source_view_df

            df_source.write.format("delta").mode("append").option("mergeSchema", "true").save(target_path)

            RowsInserted = df_source.count()
            RowsUpdated = 0
            RowsDeleted = 0
            print(f"\nCOMPLETE MergeSchema: TaskKey {task['SinkTableName']}")
            return {
              #  "SourcePath": source_path,
                "RowsRead": RowsRead,
                "RowsInserted": RowsInserted,
                "RowsUpdated": RowsUpdated,
                "RowsDeleted": RowsDeleted
            }


        # Perform Merge
        print(f"Performing merge on {task['SinkTableName']}")
        # Identify non-primary-key columns (excluding HWM)
        columns = df_source_view_df.columns
        change_condition = " OR ".join([f"target.{col} IS DISTINCT FROM source.{col}" for col in columns if col not in primary_keys and col != hwm_column])
        print(hwm_column)
        columns_excl_hwm = [col for col in columns if col != hwm_column]
        # Check if all columns are primary keys by comparing with the primary_column list
        if len(primary_keys) == len(columns_excl_hwm):
            # All columns are primary keys, meaning only inserts should happen unless data changes.
            print(f"All columns are primary keys. Ensuring valid update conditions.")

            merge_query = f"""
            MERGE INTO delta.`{target_path}` AS target
            USING (
                SELECT * FROM (
                    SELECT *, ROW_NUMBER() OVER (PARTITION BY {', '.join(primary_keys)} ORDER BY rand()) AS rn
                    FROM df_source_view
                ) AS subquery
                WHERE rn = 1
            ) AS source
            ON ({' AND '.join([f"target.{col} = source.{col}" for col in primary_keys])})
            """

            if change_condition:  # Only include the update condition if there are non-PK columns to compare, this part of the code is for fail-safe. If all columns are PK here, this will not be added
                merge_query += f"""
                WHEN MATCHED
                AND ({change_condition})
                THEN
                    UPDATE SET target.{hwm_column} = TIMESTAMP('{etlloadtime}')
                """

            insert_columns = columns.copy()
            insert_values = [f"source.{col}" for col in columns]

            # Add HWM column only if not already present
            if hwm_column not in columns:
                insert_columns.append(hwm_column)
                insert_values.append(f"TIMESTAMP('{etlloadtime}')")

            merge_query += f"""
                WHEN NOT MATCHED THEN
                    INSERT ({', '.join(insert_columns)})
                    VALUES ({', '.join(insert_values)});
                """
            print(merge_query)


        else:
            # Regular merge logic (non-primary-key columns can be updated)
            merge_query = f"""
            MERGE INTO delta.`{target_path}` AS target
            USING (
                SELECT * FROM (
                    SELECT *, ROW_NUMBER() OVER (PARTITION BY {', '.join(primary_keys)} ORDER BY rand()) AS rn
                    FROM df_source_view
                ) AS subquery
                WHERE rn = 1
            ) AS source
            ON ({' AND '.join([f"target.{col} = source.{col}" for col in primary_keys])})
            WHEN MATCHED
            AND ({change_condition})
            THEN
                UPDATE SET {', '.join([f"target.{col} = source.{col}" for col in columns if col != hwm_column])},
                        target.{hwm_column} = TIMESTAMP('{etlloadtime}')
            WHEN NOT MATCHED THEN
                INSERT ({', '.join(columns)}, {hwm_column})
                VALUES ({', '.join([f'source.{col}' for col in columns])}, TIMESTAMP('{etlloadtime}')); 
            """

        try:
            print("Executing merge query...")
            spark.sql(merge_query)
        except Exception as merge_err:
            print(f"[ERROR] Merge failed for table {task['SinkTableName']}: {merge_err}")
            # Re-raise to ensure notebook fails
            raise RuntimeError(f"Merge failed for {task['SinkTableName']} with error: {merge_err}") from merge_err


        delta_table = DeltaTable.forPath(spark, target_path)
        # Load as DataFrame, not DeltaTable
        df_target = spark.read.format("delta").load(target_path)

        # Get the latest commit history
        history_df_audit = delta_table.history(1)  # Get last operation only

        # Extract operation metrics
        operation_metrics = history_df_audit.select("operationMetrics").collect()[0][0]
        RowsInserted = int(operation_metrics.get("numOutputRows", 0))  # Rows written
        RowsUpdated = int(operation_metrics.get("numUpdatedRows", 0))  # Updated rows
        RowsDeleted = int(operation_metrics.get("numDeletedRows", 0))  # Deleted rows

        print(f"\nCOMPLETE Merge: TaskKey {task['SinkTableName']}")
        return {
        #    "SourcePath": source_path,
            "RowsRead": RowsRead,
            "RowsInserted": RowsInserted,
            "RowsUpdated": RowsUpdated,
            "RowsDeleted": RowsDeleted
        }

    except Exception as e:
        raise RuntimeError(f"Task {task['TaskKey']} failed: {str(e)}") from e



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([BronzeLhId, CuratedLhId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLhId)
        silver_lh_basepath = get_basepath(WorkspaceId, CuratedLhId)

        # Process the task
        result = process_task(task_item)


    except Exception as e:
        print(f"Error processing task: {e}")
        raise Exception


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# from datetime import datetime
# import re
# from notebookutils import mssparkutils  # Import Fabric-specific file system utilities

# # Archive path (already created earlier in the code)
# archive_path = f"{raw_lh_basepath}/Files/Archive"
# print(archive_path)

# def move_to_archive(file_path):
#     file_path = file_path.rstrip('/')  # Remove trailing slash
#     print(f"Processed file path: {file_path}")
    
#     # Get current date (year, month, day)
#     current_date = datetime.now()
#     year = current_date.year
#     month = current_date.strftime('%m')  # Zero-padded month
#     day = current_date.strftime('%d')   # Zero-padded day

#     # Extract folder name like "01Test" from the input file path
#     match = re.search(r'/Files/([^/]+)(?:/|$)', file_path)

#     print(f"Regex match result: {match}")
    
#     if not match:
#         print(" Unable to extract source folder (e.g., 01Test) from path.")
#         return
    
#     table_folder = match.group(1)
#     print(f"Extracted folder: {table_folder}")

#     # Construct full archive destination path
#     archive_dir = f"{archive_path}/{year}/{month}/{day}"
#     file_name = file_path.split('/')[-1]  # Extract the file name from the path
#     destination_path = f"{archive_dir}"

#     print(f"Moving to: {destination_path}")

#     try:
#         # Ensure the destination directory exists in Fabric (ADLS/OneLake)
#         # In Fabric, use mssparkutils.fs.mkdirs for directory creation (works with ADLS/OneLake)
#         mssparkutils.fs.mkdirs(archive_dir)

#         # Use mssparkutils.fs.mv() to move the file in Fabric
#         mssparkutils.fs.mv(file_path, destination_path)

#         print(f"File moved successfully to: {destination_path}")
#     except Exception as e:
#         print(f"Error occurred while moving file: {e}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

audit_result = {
    "RowsCopied": result['RowsRead'],
    "RowsInserted": result['RowsInserted'],
    "RowsUpdated": result['RowsUpdated'],
    "RowsDeleted": result['RowsDeleted']
}
notebookutils.notebook.exit(str(audit_result))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
