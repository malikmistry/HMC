# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# 0) Imports & config

import os, time, json, requests
from typing import Iterable, Dict, Any, List
from requests.auth import HTTPBasicAuth
from notebookutils import mssparkutils
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# ────────────────────────────────────────────────────────────────────────────────
# JIRA config
# ────────────────────────────────────────────────────────────────────────────────
JIRA_SITE   = "https://crimsonjira.atlassian.net"
JIRA_EMAIL  = "crimsonjira@hmc.harvard.edu"

# NEW: project keys to include (IT and CX)
PROJECT_KEYS = ["IT", "CX"]

DAYS_LOOKBACK = int(os.environ.get("JIRA_DAYS_LOOKBACK", "365"))
INCLUDE_SUBTASKS = True

KV_URL = "https://KV-DC1Dev-ADF.vault.azure.net/"
JIRA_KV_URI = os.environ.get("JIRA_KV_URI", None)
JIRA_API_TOKEN = mssparkutils.credentials.getSecret(KV_URL, "JIRA-API-KEY")

# ────────────────────────────────────────────────────────────────────────────────
# 2) Auth (site URL first; ex URL fallback)
# ────────────────────────────────────────────────────────────────────────────────
def get_cloud_id(site_url: str) -> str:
    r = requests.get(f"{site_url}/_edge/tenant_info", timeout=10)
    r.raise_for_status()
    return r.json()["cloudId"]

def make_session(email: str, token: str) -> requests.Session:
    s = requests.Session()
    s.auth = HTTPBasicAuth(email, token)
    s.headers.update({"Accept": "application/json"})
    return s

def check_myself(session: requests.Session, base_url: str) -> int:
    r = session.get(f"{base_url}/rest/api/3/myself", timeout=20)
    return r.status_code

session = make_session(JIRA_EMAIL, JIRA_API_TOKEN)
JIRA_BASE_URL = JIRA_SITE

status_site = check_myself(session, JIRA_BASE_URL)
if status_site == 200:
    print(f"Authenticated via site URL: {JIRA_BASE_URL}")
else:
    cloud_id = get_cloud_id(JIRA_SITE)
    ex_base = f"https://api.atlassian.com/ex/jira/{cloud_id}"
    status_ex = check_myself(session, ex_base)
    if status_ex == 200:
        JIRA_BASE_URL = ex_base
        print(f"Authenticated via ex URL: {JIRA_BASE_URL} (cloudId={cloud_id})")
    else:
        raise RuntimeError(f"Auth failed. /myself => site:{status_site}, ex:{status_ex}.")

# ────────────────────────────────────────────────────────────────────────────────
# 3) Helpers
# ────────────────────────────────────────────────────────────────────────────────
def adf_to_text(doc: Any) -> str:
    if doc is None: return ""
    if isinstance(doc, str): return doc
    if isinstance(doc, dict):
        t = doc.get("type")
        if t == "text": return doc.get("text","")
        if t in ("paragraph","heading","blockquote"): return "".join(adf_to_text(c) for c in doc.get("content",[])) + "\n"
        if t in ("bulletList","orderedList"): return "".join(adf_to_text(c) for c in doc.get("content",[]))
        if t == "listItem": return "- " + "".join(adf_to_text(c) for c in doc.get("content",[])) + "\n"
        return "".join(adf_to_text(c) for c in doc.get("content",[]))
    if isinstance(doc, list): return "".join(adf_to_text(c) for c in doc)
    return ""

def jira_search(jql: str, fields: Iterable[str] = None, page_size: int = 100):
    endpoint = f"{JIRA_BASE_URL}/rest/api/3/search/jql"
    next_token = None

    while True:
        body = {"jql": jql, "maxResults": int(page_size)}
        if fields:
            body["fields"] = list(fields)  # array, not CSV
        if next_token:
            body["nextPageToken"] = next_token

        r = session.post(endpoint, json=body, timeout=60)
        if r.status_code == 429:
            time.sleep(int(r.headers.get("Retry-After", "5"))); continue
        if r.status_code == 410:
            raise RuntimeError("Jira returned 410 Gone for legacy search. This function must hit /rest/api/3/search/jql.")
        r.raise_for_status()

        data = r.json()
        for issue in data.get("issues", []):
            yield issue

        # Enhanced pagination
        next_token = data.get("nextPageToken")
        if data.get("isLast", False) or not next_token:
            break


def value(obj, *path, default=None):
    cur = obj
    for p in path:
        if cur is None: return default
        if isinstance(cur, dict): cur = cur.get(p)
        else: return default
    return cur if cur is not None else default

def to_str(x) -> str:
    if x is None: return None
    if isinstance(x, (int, float, bool)): return str(x)
    if isinstance(x, (dict, list)): return json.dumps(x, ensure_ascii=False)
    return str(x)

# ────────────────────────────────────────────────────────────────────────────────
# NEW: field discovery for Start date / Epic Link (auto; env var override)
# ────────────────────────────────────────────────────────────────────────────────
_field_cache = None
def get_all_fields() -> List[Dict[str, Any]]:
    global _field_cache
    if _field_cache is not None:
        return _field_cache
    try:
        r = session.get(f"{JIRA_BASE_URL}/rest/api/3/field", timeout=60)
        r.raise_for_status()
        _field_cache = r.json()
    except Exception as e:
        print(f"Warning: unable to fetch /field. Proceeding without auto-discovery. {e}")
        _field_cache = []
    return _field_cache

def find_field_id_by_names(candidate_names: List[str]) -> str:
    cand = [c.lower() for c in candidate_names if c]
    for fld in get_all_fields():
        nm = (fld.get("name") or "").lower()
        if nm in cand:
            return fld.get("id")
    return None

STARTDATE_FIELD_ID = os.environ.get("JIRA_STARTDATE_FIELD") or find_field_id_by_names(["Start date", "Start Date", "StartDate"])
EPICLINK_FIELD_ID  = os.environ.get("JIRA_EPICLINK_FIELD")  or find_field_id_by_names(["Epic Link", "Epic link", "Epic"])

print(f"Detected StartDate field id: {STARTDATE_FIELD_ID}")
print(f"Detected Epic Link field id: {EPICLINK_FIELD_ID}")

# ────────────────────────────────────────────────────────────────────────────────
# 4) Columns, schema (explicit strings), coercion helpers
# ────────────────────────────────────────────────────────────────────────────────
COLUMNS = [
    "Parent",
    "Summary",
    "IssueKey",
    "IssueId",
    "IssueType",
    "Status",
    "ProjectKey",
    "ProjectName",
    "ProjectType",
    "ProjectLead",
    "ProjectLeadId",
    "ProjectDescription",
    "ProjectUrl",
    "Priority",
    "Resolution",
    "Assignee",
    "AssigneeId",
    "Reporter",
    "ReporterId",
    "Creator",
    "CreatorId",
    "Created",
    "Updated",
    "LastViewed",
    "Resolved",
    "DueDate",
    "StartDate", 
    "Labels",       
    "Votes",
    "Description"
]

HELPER = ["_parent_key_direct", "_epic_key"]

SCHEMA = StructType([StructField(c, StringType(), True) for c in (COLUMNS + HELPER)])

# Cache per-project details
_project_cache: Dict[str, Dict[str, Any]] = {}
def get_project_details(project_key: str) -> Dict[str, Any]:
    if not project_key: return {}
    if project_key in _project_cache: return _project_cache[project_key]
    try:
        r = session.get(f"{JIRA_BASE_URL}/rest/api/3/project/{project_key}", timeout=30)
        r.raise_for_status()
        _project_cache[project_key] = r.json()
        return _project_cache[project_key]
    except Exception:
        _project_cache[project_key] = {}
        return {}

def to_row(issue: Dict[str, Any], epic_key_hint: str = None) -> Dict[str, Any]:
    f = issue.get("fields", {}) or {}
    proj = f.get("project") or {}
    project_key = proj.get("key")
    pdet = get_project_details(project_key) if project_key else {}
    plead = (pdet.get("lead") or {})
    labels_val = f.get("labels") or []            # array of strings
    labels_str = ",".join([str(x) for x in labels_val]) if isinstance(labels_val, list) else (labels_val or None)

    parent_direct = value(f, "parent", "key")

    # NEW: attempt to read Start date and Epic Link
    start_date_val = f.get(STARTDATE_FIELD_ID) if STARTDATE_FIELD_ID else None
    epic_by_field  = f.get(EPICLINK_FIELD_ID)  if EPICLINK_FIELD_ID  else None

    # Prefer: hint (from parent story) → explicit Epic Link field → direct parent (for subtasks)
    epic_key = epic_key_hint or epic_by_field or parent_direct

    return {
        "Parent": to_str(epic_key),
        "Summary": to_str(f.get("summary")),
        "IssueKey": to_str(issue.get("key")),
        "IssueId": to_str(issue.get("id")),
        "IssueType": to_str(value(f, "issuetype", "name")),
        "Status": to_str(value(f, "status", "name")),
        "ProjectKey": to_str(project_key),
        "ProjectName": to_str(proj.get("name")),
        "ProjectType": to_str(proj.get("projectTypeKey")),
        "ProjectLead": to_str(plead.get("displayName")),
        "ProjectLeadId": to_str(plead.get("accountId")),
        "ProjectDescription": to_str(adf_to_text(pdet.get("description")) if pdet else ""),
        "ProjectUrl": to_str(f"{JIRA_SITE}/browse/{project_key}" if project_key else ""),
        "Priority": to_str(value(f, "priority", "name")),
        "Resolution": to_str(value(f, "resolution", "name")),
        "Assignee": to_str(value(f, "assignee", "displayName")),
        "AssigneeId": to_str(value(f, "assignee", "accountId")),
        "Reporter": to_str(value(f, "reporter", "displayName")),
        "ReporterId": to_str(value(f, "reporter", "accountId")),
        "Creator": to_str(value(f, "creator", "displayName")),
        "CreatorId": to_str(value(f, "creator", "accountId")),
        "Created": to_str(f.get("created")),
        "Updated": to_str(f.get("updated")),
        "LastViewed": to_str(f.get("lastViewed")),
        "Resolved": to_str(f.get("resolutiondate")),
        "DueDate": to_str(f.get("duedate")),
        "StartDate": to_str(start_date_val),
        "Labels": labels_str,
        "Votes": to_str(value(f, "votes", "votes")),
        "Description": to_str(adf_to_text(f.get("description"))),
        "_parent_key_direct": to_str(parent_direct),
        "_epic_key": to_str(epic_key)
    }

# ────────────────────────────────────────────────────────────────────────────────
# 5) Pull issues for IT & CX, with optional subtasks (date logic preserved)
# ────────────────────────────────────────────────────────────────────────────────

# Keep your “recent Done” logic intact
status_filter = f"(statusCategory != Done OR resolutiondate >= -{DAYS_LOOKBACK}d)"
project_list = ",".join(PROJECT_KEYS)

# Include base fields; add discovered custom fields if available
issue_fields = [
    "summary","issuetype","status","project","priority","resolution",
    "assignee","reporter","creator","created","updated",
    "lastViewed","resolutiondate","duedate","description","parent","labels"
]
if STARTDATE_FIELD_ID: issue_fields.append(STARTDATE_FIELD_ID)
if EPICLINK_FIELD_ID:  issue_fields.append(EPICLINK_FIELD_ID)

# Top-level issues (exclude subtasks)
jql_top = f"project in ({project_list}) AND issuetype not in subTaskIssueTypes() AND {status_filter} ORDER BY updated DESC"
top_rows = [to_row(i) for i in jira_search(jql_top, fields=issue_fields, page_size=100)]

if top_rows:
    top_df = spark.createDataFrame(top_rows, schema=SCHEMA)
else:
    top_df = spark.createDataFrame([], schema=SCHEMA)

# Subtasks, if requested
def chunk(items: List[str], n=900):
    for i in range(0, len(items), n):
        yield items[i:i+n]

if INCLUDE_SUBTASKS:
    # Map story/task → epic (if we have it)
    story_to_epic = {r["IssueKey"]: r["_epic_key"] for r in top_rows}
    subtasks_all = []
    jql_sub = f"project in ({project_list}) AND issuetype in subTaskIssueTypes() AND {status_filter} ORDER BY updated DESC"
    for issue in jira_search(jql_sub, fields=issue_fields, page_size=100):
        parent_story_key = value(issue, "fields", "parent", "key")
        epic_hint = story_to_epic.get(parent_story_key)
        subtasks_all.append(to_row(issue, epic_key_hint=epic_hint))

    if subtasks_all:
        sub_df = spark.createDataFrame(subtasks_all, schema=SCHEMA)
    else:
        sub_df = spark.createDataFrame([], schema=SCHEMA)
else:
    sub_df = spark.createDataFrame([], schema=SCHEMA)

# ────────────────────────────────────────────────────────────────────────────────
# 6) Union and persist
# ────────────────────────────────────────────────────────────────────────────────
curated_df = top_df.unionByName(sub_df, allowMissingColumns=True)
curated_df = curated_df.select(*COLUMNS)  # includes StartDate

target_rel = "Bronze/JIRAData"
target_path = tbl_path(bronze_lh_id, target_rel)

(curated_df
    .write
    .mode("overwrite")
    .format("delta")
    .save(target_path)
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
