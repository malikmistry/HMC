# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# 0) Imports & config
import requests, json, base64
from urllib.parse import urlparse, parse_qs, unquote
import pandas as pd
from pyspark.sql import functions as F
from notebookutils import mssparkutils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

KV_URL = "https://KV-DC1Dev-ADF.vault.azure.net/"
TEAMS_CHANNEL_URL = "https://teams.microsoft.com/l/channel/19%3A8b6e096deafe42f2968a267b1286c208%40thread.tacv2/Tests%20and%20Policies?groupId=90003a4b-4267-49b1-99fe-1dd33f69538a&tenantId=385f9270-6e2d-44ab-8297-02cf20fd17ce"
CLASSIC_PLAN_TITLE = "Activities"   # match the tab name you created
GRAPH = "https://graph.microsoft.com/v1.0"

client_id     = mssparkutils.credentials.getSecret(KV_URL, "GraphClientId")
client_secret = mssparkutils.credentials.getSecret(KV_URL, "GraphClientSecret")

def parse_url(url):
    u = urlparse(url); q = parse_qs(u.query)
    group_id  = (q.get("groupId") or [None])[0]
    tenant_id = (q.get("tenantId") or [None])[0]
    channel_id = unquote(u.path.split("/l/channel/")[1].split("/")[0])
    return tenant_id, group_id, channel_id

def get_token(tenant_id):
    r = requests.post(f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token",
                      data={"client_id": client_id, "client_secret": client_secret,
                            "grant_type": "client_credentials",
                            "scope": "https://graph.microsoft.com/.default"},
                      timeout=30); r.raise_for_status()
    return r.json()["access_token"]

def gget(url, H, params=None):
    r = requests.get(url, headers=H, params=params, timeout=30)
    if r.status_code >= 400: print("ERROR", r.status_code, r.url, "\n", r.text[:600])
    r.raise_for_status(); return r.json()

tenant_id, group_id, channel_id = parse_url(TEAMS_CHANNEL_URL)
H = {"Authorization": f"Bearer {get_token(tenant_id)}"}

plans = gget(f"{GRAPH}/groups/{group_id}/planner/plans", H)["value"]
plan = next((p for p in plans if p["title"] == CLASSIC_PLAN_TITLE), None)
assert plan, f"Plan titled '{CLASSIC_PLAN_TITLE}' not found."
plan_id = plan["id"]

buckets = gget(f"{GRAPH}/planner/plans/{plan_id}/buckets", H)["value"]
tasks   = gget(f"{GRAPH}/planner/plans/{plan_id}/tasks",   H)["value"]
bucket_name = {b["id"]: b["name"] for b in buckets}

buckets_df = pd.DataFrame(buckets)[["id", "name", "planId", "orderHint"]].rename(
    columns={"id": "bucketId", "name": "bucket"}
)
bucket_map = dict(zip(buckets_df["bucketId"], buckets_df["bucket"]))

def progress_label(p):
    if p is None:
        return None
    try:
        p = int(p)
    except Exception:
        return None
    if p >= 100:
        return "Completed"
    if p == 0:
        return "Not started"
    return "In Progress"

rows = []
for t in tasks:
    assignments = t.get("assignments") or {}
    rows.append({
        "taskId": t.get("id"),
        "title": t.get("title"),
        "bucketId": t.get("bucketId"),
        "bucket": bucket_map.get(t.get("bucketId")),
        "percentComplete": t.get("percentComplete"),
        "PROGRESS": progress_label(t.get("percentComplete")),
        "priority": t.get("priority"),
        "startDateTime": t.get("startDateTime"),
        "dueDateTime": t.get("dueDateTime"),
        "createdDateTime": t.get("createdDateTime"),
        "hasDescription": t.get("hasDescription"),
        "checklistItemCount": t.get("checklistItemCount"),
        "referenceCount": t.get("referenceCount"),
        "labels": sorted([k for k, v in (t.get("appliedCategories") or {}).items() if v]),
        "assignee_ids": list(assignments.keys()),
        "assignees_count": len(assignments),
    })

tasks_df = pd.DataFrame(rows)

for col in ["startDateTime", "dueDateTime", "createdDateTime"]:
    tasks_df[col] = pd.to_datetime(tasks_df[col], errors="coerce")

tasks_df = tasks_df.sort_values(
    by=["bucket", "dueDateTime", "priority", "title"],
    ascending=[True, True, True, True],
    kind="stable"
).reset_index(drop=True)

def gget_all(url, H):
    items = []
    while url:
        page = gget(url, H)
        items.extend(page.get("value", []))
        url = page.get("@odata.nextLink")
    return items

members = gget_all(f"{GRAPH}/groups/{group_id}/members", H)
member_map = {m["id"]: m.get("displayName") for m in members if m.get("displayName")}

def ids_to_names(ids):
    if not ids:
        return []
    return [member_map.get(i, i) for i in ids]

tasks_df["assignees"] = (
    tasks_df["assignee_ids"]
    .apply(ids_to_names)
    .apply(lambda xs: ", ".join(xs) if xs else None)
)

expanded_rows = []
for t in tasks:
    assignments = t.get("assignments") or {}
    if not assignments:
        expanded_rows.append({
            "taskId": t.get("id"),
            "title": t.get("title"),
            "bucketId": t.get("bucketId"),
            "bucket": bucket_map.get(t.get("bucketId")),
            "percentComplete": t.get("percentComplete"),
            "PROGRESS": progress_label(t.get("percentComplete")),
            "priority": t.get("priority"),
            "startDateTime": t.get("startDateTime"),
            "dueDateTime": t.get("dueDateTime"),
            "createdDateTime": t.get("createdDateTime"),
            "assignee_id": None,
            "assignee_name": None,
        })
    else:
        for uid in assignments.keys():
            expanded_rows.append({
                "taskId": t.get("id"),
                "title": t.get("title"),
                "bucketId": t.get("bucketId"),
                "bucket": bucket_map.get(t.get("bucketId")),
                "percentComplete": t.get("percentComplete"),
                "PROGRESS": progress_label(t.get("percentComplete")),
                "priority": t.get("priority"),
                "startDateTime": t.get("startDateTime"),
                "dueDateTime": t.get("dueDateTime"),
                "createdDateTime": t.get("createdDateTime"),
                "assignee_id": uid,
                "assignee_name": member_map.get(uid),
            })

tasks_expanded_df = pd.DataFrame(expanded_rows)

for col in ["startDateTime", "dueDateTime", "createdDateTime"]:
    tasks_expanded_df[col] = pd.to_datetime(tasks_expanded_df[col], errors="coerce")

def progress_label(p):
    try:
        p = int(p)
    except Exception:
        return None
    if p >= 100: return "Completed"
    if p == 0:   return "Not started"
    return "In Progress"

def priority_label(n):
    if n is None: return None
    try:
        n = int(n)
    except Exception:
        return None
    if n <= 1:  return "Urgent"
    if n <= 4:  return "Important"
    if n <= 7:  return "Medium"
    return "Low"

def gget_all(url, H):
    items = []
    while url:
        page = gget(url, H)
        items.extend(page.get("value", []))
        url = page.get("@odata.nextLink")
    return items

members = gget_all(f"{GRAPH}/groups/{group_id}/members", H)
id_to_name = {m["id"]: m.get("displayName") for m in members if m.get("displayName")}

def ids_to_names(ids):
    if not ids: return []
    return [id_to_name.get(i, i) for i in ids]

def to_date_only(ts):
    d = pd.to_datetime(ts, errors="coerce")
    return d.dt.date if isinstance(d, pd.Series) else (d.date() if pd.notna(d) else None)

table_rows = []
for t in tasks:
    assignments = t.get("assignments") or {}
    assignee_ids = list(assignments.keys())
    table_rows.append({
        "Task Name": t.get("title"),
        "Assignment": ", ".join(ids_to_names(assignee_ids)) or None,
        "Start date": to_date_only(t.get("startDateTime")),
        "Due date":   to_date_only(t.get("dueDateTime")),
        "Bucket":     bucket_map.get(t.get("bucketId")),
        "Progress":   progress_label(t.get("percentComplete")),
        "Priority":   priority_label(t.get("priority")),
    })

table_df = pd.DataFrame(table_rows)

spark_table_df = spark.createDataFrame(table_df)

in_scope_buckets = [
    "IT Resource Guide Review",
    "Information Security Policy Review",
    "AD User Group Review",
    "HMC Annual Security Training",
]
UP = [b.upper() for b in in_scope_buckets]

def norm(c):
    c = F.coalesce(c, F.lit(""))
    c = F.regexp_replace(c, u"\u00A0", " ")
    c = F.regexp_replace(c, r"\s+", " ")
    c = F.trim(c)
    return F.upper(c)

base_df = (
    spark.createDataFrame(table_df)
    .selectExpr(
        "`Task Name` as TaskName",
        "`Assignment` as Assignment",
        "`Start date` as StartDate",
        "`Due date` as DueDate",
        "Bucket as Bucket",
        "Progress as Progress",
        "Priority as Priority"
    )
)

normed = (
    base_df
    .withColumn("BucketCanon",   norm(F.col("Bucket")))
    .withColumn("ProgressCanon", norm(F.col("Progress")))
)

final_df = (
    normed
    .withColumn(
        "InUserPage",
        (F.col("BucketCanon").isin(UP) & (F.col("ProgressCanon") == F.lit("COMPLETED"))).cast("boolean")
    )
    .drop("BucketCanon", "ProgressCanon")
)


target_rel = "Bronze/PlannerData"
target_path = tbl_path(bronze_lh_id, target_rel)

(final_df.write
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .format("delta")
    .save(target_path)
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
