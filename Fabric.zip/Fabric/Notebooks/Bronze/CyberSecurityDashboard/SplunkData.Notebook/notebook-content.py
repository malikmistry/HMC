# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# Allowed users
entra_users = (
    read_delta(bronze_lh_id, "Bronze/EntraUsers")
      .select(F.lower(F.col("mail")).alias("email_lc"))
      .where(F.col("mail").isNotNull())
      .distinct()
)

# Mimecast pivot
mime = (
    read_delta(bronze_lh_id, "Bronze/Mimecast")
      .withColumn("load_date", F.to_date("ETLLoadDateTime"))
      .groupBy("recipients", "load_date")
      .pivot("category", ["Total Emails","Spam Emails","Phishing Emails","Malware Emails","Virus Emails","Suspicious Emails"])
      .agg(F.sum("count"))
      .fillna(0)
      .select(
          F.col("recipients"),
          F.col("load_date"),
          F.col("Total Emails").alias("ExternalMailsReceived"),
          F.col("Spam Emails").alias("Spam"),
          F.col("Phishing Emails").alias("Phishing"),
          (F.col("Malware Emails") + F.col("Virus Emails")).alias("Malware"),
          F.col("Suspicious Emails").alias("Suspicious")
      )
)

# Abnormal aggregate
abn = (
    read_delta(bronze_lh_id, "Bronze/Abnormal")
      .withColumn("load_date", F.to_date("ETLLoadDateTime"))
      .groupBy(F.col("recipient").alias("recipients"), "load_date")
      .agg(
          F.sum(F.coalesce(F.col("spam"), F.lit(0))).alias("Abnormalspam"),
          F.sum(F.coalesce(F.col("phishing_credential"), F.lit(0))).alias("Abnormalphishing_credential"),
          F.sum(F.coalesce(F.col("other"), F.lit(0))).alias("Abnormalrecon"),
          F.sum(F.coalesce(F.col("scam"), F.lit(0))).alias("Abnormalscam"),
          F.sum(F.coalesce(F.col("social_engineering"), F.lit(0))).alias("Abnormalsocial_eng_bec"),
      )
         .withColumn("Abnormalmalware", F.lit(0).cast("bigint"))
)

# Join Mimecast + Abnormal
out_daily = (
    mime.alias("m")
      .join(abn.alias("a"), on=["recipients","load_date"], how="full")
      .select(
          F.coalesce(F.col("m.recipients"), F.col("a.recipients")).alias("Email"),
          F.col("load_date").cast("timestamp").alias("UploadDateTime"),
          F.coalesce(F.col("m.ExternalMailsReceived"), F.lit(0)).alias("ExternalMailsReceived"),
          F.coalesce(F.col("a.Abnormalmalware"), F.lit(0)).alias("Abnormalmalware"),
          F.coalesce(F.col("a.Abnormalphishing_credential"), F.lit(0)).alias("Abnormalphishing_credential"),
          F.coalesce(F.col("a.Abnormalrecon"), F.lit(0)).alias("Abnormalrecon"),
          F.coalesce(F.col("a.Abnormalscam"), F.lit(0)).alias("Abnormalscam"),
          F.coalesce(F.col("a.Abnormalsocial_eng_bec"), F.lit(0)).alias("Abnormalsocial_eng_bec"),
          F.coalesce(F.col("a.Abnormalspam"), F.lit(0)).alias("Abnormalspam"),
          F.coalesce(F.col("m.Malware"), F.lit(0)).alias("Malware"),
          F.coalesce(F.col("m.Phishing"), F.lit(0)).alias("Phishing"),
          F.coalesce(F.col("m.Spam"), F.lit(0)).alias("Spam"),
          F.coalesce(F.col("m.Suspicious"), F.lit(0)).alias("Suspicious"),
      )
      .withColumn("Email_lc", F.lower(F.col("Email")))
)

# Keep only allowed users (left_semi avoids duplicate columns)
out_filtered = out_daily.join(
    entra_users,
    on=out_daily.Email_lc == entra_users.email_lc,
    how="left_semi"
)

# Aggregate to one row per user
out_user = (
    out_filtered
      .groupBy("Email_lc")
      .agg(
          F.max("UploadDateTime").alias("UploadDateTime"),
          F.sum("ExternalMailsReceived").cast("bigint").alias("ExternalMailsReceived"),
          F.sum("Abnormalmalware").cast("bigint").alias("Abnormalmalware"),
          F.sum("Abnormalphishing_credential").cast("bigint").alias("Abnormalphishing_credential"),
          F.sum("Abnormalrecon").cast("bigint").alias("Abnormalrecon"),
          F.sum("Abnormalscam").cast("bigint").alias("Abnormalscam"),
          F.sum("Abnormalsocial_eng_bec").cast("bigint").alias("Abnormalsocial_eng_bec"),
          F.sum("Abnormalspam").cast("bigint").alias("Abnormalspam"),
          F.sum("Malware").cast("bigint").alias("Malware"),
          F.sum("Phishing").cast("bigint").alias("Phishing"),
          F.sum("Spam").cast("bigint").alias("Spam"),
          F.sum("Suspicious").cast("bigint").alias("Suspicious"),
      )
      .withColumn(
          "TotalHeldEmails",
          (F.col("Spam") + F.col("Phishing") + F.col("Malware") + F.col("Suspicious")).cast("bigint")
      )
      .select(
          F.col("Email_lc").alias("HMCUserIdentifier"),
          "UploadDateTime",
          F.col("Email_lc").alias("Email"),
          "ExternalMailsReceived",
          "Abnormalmalware",
          "Abnormalphishing_credential",
          "Abnormalrecon",
          "Abnormalscam",
          "Abnormalsocial_eng_bec",
          "Abnormalspam",
          "Malware",
          "Phishing",
          "Spam",
          "Suspicious",
          "TotalHeldEmails"
      )
)

target_rel = "Bronze/CyberDashboardSplunk"
target_path = tbl_path(bronze_lh_id, target_rel)

(out_user
    .write
    .mode("overwrite")
    .format("delta")
    .save(target_path)
)

#CREATE TABLE [Bronze].[CyberDashboardSplunk](
#	[HMCUserIdentifier] [varchar](8000) NULL,
#	[UploadDateTime] [datetime2](6) NULL,
#	[Email] [varchar](8000) NULL,
#	[ExternalMailsReceived] [bigint] NULL,
#	[Abnormalmalware] [bigint] NULL,
#	[Abnormalphishing_credential] [bigint] NULL,
#	[Abnormalrecon] [bigint] NULL,
#	[Abnormalscam] [bigint] NULL,
#	[Abnormalsocial_eng_bec] [bigint] NULL,
#	[Abnormalspam] [bigint] NULL,
#	[Malware] [bigint] NULL,
#	[Phishing] [bigint] NULL,
#	[Spam] [bigint] NULL,
#	[Suspicious] [bigint] NULL,
#	[TotalHeldEmails] [bigint] NULL
#)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
