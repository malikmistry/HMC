# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "920a12cc-7104-4013-a2a3-d7baa57e9e3f",
# META       "default_lakehouse_name": "lh_raw",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "920a12cc-7104-4013-a2a3-d7baa57e9e3f"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Imports
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, concat_ws, lit, to_timestamp
from pyspark.sql.types import StringType, TimestampType
import pandas as pd
import requests, time

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Spark setup
spark = SparkSession.builder.getOrCreate()

# Auth / Config
base_url = "https://us.api.knowbe4.com/v1/phishing/security_tests"
bearer_token = mssparkutils.credentials.getSecret(
    'https://KV-DC1Dev-ADF.vault.azure.net/', 'knowbe4-token'
)
headers = {"Authorization": f"Bearer {bearer_token}", "Accept": "application/json"}
params = {"page": 1, "per_page": 500}
REQUESTS_PER_MINUTE = 45
SECONDS_PER_REQUEST = 60 / REQUESTS_PER_MINUTE
api_call_count, TEST_MODE = 0, False

# Output config (simplified)
base_output = "Files/IncomingFeed/CyberSecurityDashboard/KnowBe4"
tests_path = f"{base_output}/tests.parquet"
recipients_path = f"{base_output}/knowbe4_data.parquet"

# ------------------------------------
# 1. Fetch Security Test Metadata
# ------------------------------------
all_tests = []
while True:
    response = requests.get(base_url, headers=headers, params=params)
    api_call_count += 1
    response.raise_for_status()
    page_data = response.json()
    if not page_data: break
    all_tests.extend(page_data)
    if len(page_data) < params["per_page"]: break
    params["page"] += 1

test_df = spark.createDataFrame(pd.DataFrame(all_tests)) \
    .withColumnRenamed("landing-page", "landing_page") \
    .withColumn("groups", concat_ws(",", col("groups.name"))) \
    .withColumn("categories", concat_ws(",", col("categories.name"))) \
    .withColumn("template_name", col("template.name")) \
    .withColumn("landing_page_name", col("landing_page.name")) \
    .drop("template", "landing_page") \
    .withColumn("started_at_ts", to_timestamp(col("started_at")))

test_df.coalesce(1).write.mode("overwrite").parquet(tests_path)
print(f"✅ Security test metadata written to: {tests_path}")

# ------------------------------------
# 2. Select Latest Test ID
# ------------------------------------
OVERRIDE_PST_ID = None
pst_id = (
    OVERRIDE_PST_ID
    if OVERRIDE_PST_ID
    else test_df.orderBy(col("started_at_ts").desc()).limit(1).collect()[0]["pst_id"]
)

# ------------------------------------
# 3. Fetch Recipients for Selected Test
# ------------------------------------
recipient_ids_to_fetch = []
recipients_url = f"{base_url}/{pst_id}/recipients"
params = {"page": 1, "per_page": 1 if TEST_MODE else 500}

while True:
    response = requests.get(recipients_url, headers=headers, params=params)
    api_call_count += 1
    if response.status_code == 429:
        time.sleep(int(response.headers.get("Retry-After", 60)))
        continue
    response.raise_for_status()
    recipients = response.json()
    if not recipients: break
    for r in recipients:
        recipient_ids_to_fetch.append((pst_id, r["recipient_id"]))
    if TEST_MODE or len(recipients) < 500: break
    params["page"] += 1
    time.sleep(SECONDS_PER_REQUEST)

# ------------------------------------
# 4. Fetch Recipient Details
# ------------------------------------
detailed_recipient_data = []
for pst_id, recipient_id in recipient_ids_to_fetch:
    detail_url = f"{base_url}/{pst_id}/recipients/{recipient_id}"
    try:
        response = requests.get(detail_url, headers=headers)
        api_call_count += 1
        if response.status_code == 429:
            time.sleep(int(response.headers.get("Retry-After", 60)))
            continue
        response.raise_for_status()
        data = response.json()
        data["pst_id"], data["recipient_id"] = pst_id, recipient_id
        detailed_recipient_data.append(data)
        time.sleep(SECONDS_PER_REQUEST)
    except Exception as e:
        print(f"Error: {e}")

# ------------------------------------
# 5. Clean + Flatten Detailed Data
# ------------------------------------
cleaned_data = [
    r for r in detailed_recipient_data if isinstance(r, dict) and "user" in r and "template" in r
]
detailed_df = spark.createDataFrame(pd.DataFrame(cleaned_data))

# Fill void columns
for col_name in detailed_df.columns:
    if detailed_df.schema[col_name].dataType.simpleString() == "void":
        detailed_df = detailed_df.withColumn(col_name, lit("").cast(StringType()))

# Convert timestamp columns
timestamp_cols = [
    "scheduled_at", "delivered_at", "opened_at", "clicked_at", "replied_at",
    "attachment_opened_at", "macro_enabled_at", "data_entered_at",
    "qr_code_scanned", "reported_at", "bounced_at"
]
for col_name in timestamp_cols:
    if col_name in detailed_df.columns:
        detailed_df = detailed_df.withColumn(col_name, col(col_name).cast(TimestampType()))

# Flatten nested fields
detailed_df = detailed_df \
    .withColumn("user_id", col("user.id")) \
    .withColumn("user_first_name", col("user.first_name")) \
    .withColumn("user_last_name", col("user.last_name")) \
    .withColumn("user_email", col("user.email")) \
    .withColumn("template_id", col("template.id")) \
    .withColumn("template_name", col("template.name")) \
    .drop("user", "template")

# ------------------------------------
# 6. Join + Save Final Data to Named Parquet Directory
# ------------------------------------
final_df = detailed_df.join(
    test_df.drop("template_name", "started_at_ts"),
    on="pst_id",
    how="inner"
)

final_df.coalesce(1).write.mode("overwrite").parquet(recipients_path)
print(f"✅ Final recipient dataset written to: {recipients_path}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
