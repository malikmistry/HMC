# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "920a12cc-7104-4013-a2a3-d7baa57e9e3f",
# META       "default_lakehouse_name": "lh_raw",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "920a12cc-7104-4013-a2a3-d7baa57e9e3f"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Imports
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, concat_ws, lit, current_timestamp
from pyspark.sql.types import StringType, TimestampType
import requests, pandas as pd, time

# Setup Spark
spark = SparkSession.builder.getOrCreate()

# Auth / Config
bearer_token = mssparkutils.credentials.getSecret(
    'https://KV-DC1Dev-ADF.vault.azure.net/',
    'knowbe4-token'
)
headers = {"Authorization": f"Bearer {bearer_token}", "Accept": "application/json"}
users_url = "https://us.api.knowbe4.com/v1/users"
params = {"page": 1, "per_page": 500}
REQUESTS_PER_MINUTE = 45
SECONDS_PER_REQUEST = 60 / REQUESTS_PER_MINUTE
api_call_count = 0

# Output path (named folder to simulate single file export)
output_path = "Files/IncomingFeed/CyberSecurityDashboard/KnowBe4/knowbe4_users.parquet"

# 1. Fetch Users
all_users = []
while True:
    response = requests.get(users_url, headers=headers, params=params)
    api_call_count += 1
    if response.status_code == 429:
        time.sleep(int(response.headers.get("Retry-After", 60)))
        continue
    response.raise_for_status()
    users_page = response.json()
    if not users_page:
        break
    all_users.extend(users_page)
    if len(users_page) < params["per_page"]:
        break
    params["page"] += 1
    time.sleep(SECONDS_PER_REQUEST)

print(f"📥 Total users fetched: {len(all_users)}")

# 2. Clean + Convert
users_df = spark.createDataFrame(pd.DataFrame(all_users))

# Convert timestamps
date_fields = [
    "joined_on", "last_sign_in", "employee_start_date",
    "archived_at", "custom_date_1", "custom_date_2"
]
for date_col in date_fields:
    if date_col in users_df.columns:
        users_df = users_df.withColumn(date_col, col(date_col).cast(TimestampType()))

# Flatten array fields
if "groups" in users_df.columns:
    users_df = users_df.withColumn("groups", concat_ws(",", col("groups")))
if "aliases" in users_df.columns:
    users_df = users_df.withColumn("aliases", concat_ws(",", col("aliases")))

# Clean void columns
for field in users_df.schema.fields:
    if field.dataType.simpleString() == "void":
        users_df = users_df.withColumn(field.name, lit("").cast(StringType()))

# 3. Write to named Parquet folder (no manual rename)
users_df.coalesce(1).write.mode("overwrite").parquet(output_path)
print(f"✅ Users dataset written to directory: {output_path}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
