# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

#imports
import os
import re
import json
import time
import typing as T
from datetime import datetime, timezone
import pandas as pd
from pyspark.sql import functions as F, types as T

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from pyspark.sql import SparkSession
spark = SparkSession.getActiveSession() or SparkSession.builder.getOrCreate()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# COMMAND ----------
# ==== CONFIG (edit to taste) ==================================================
AZURE_KEY_VAULT_URI = os.environ.get("AZURE_KEY_VAULT_URI", "https://KV-DC1Dev-ADF.vault.azure.net/")
BLUEVOYANT_SECRET_NAME = os.environ.get("BLUEVOYANT_SECRET_NAME", "BlueVoyantAPIKey")

REQUEST_TIMEOUT_SECS: int = 60
PAGE_SIZE: int = 1000
WRITE_MODE = os.environ.get("BV_WRITE_MODE", "overwrite")  # overwrite | append

# Rel paths (schema/table) for path-based writes
EV_REL = "Bronze/BlueVoyantEVSummaries"
COMP_REL = "Bronze/BlueVoyantCompanies"

WRITE_RAW_JSON = True
RAW_JSON_DIR = os.environ.get(
    "BV_RAW_DIR",
    f"Files/bluevoyant/raw/{datetime.now(timezone.utc).strftime('%Y%m%d')}"
)

# Expect bronze_lh_id to be defined earlier in your env (Lakehouse base path)
# Example: bronze_lh_id = "abfss://.../Lakehouse/..."   (don't hardcode here)

# COMMAND ----------
# ==== SECRET RETRIEVAL (simple) ===============================================
try:
    import notebookutils as nbu  # Fabric modern alias
    _KV = nbu
except Exception:
    try:
        from notebookutils import mssparkutils as nbu  # legacy alias
        _KV = nbu
    except Exception:
        _KV = None

def _get_api_token() -> str:
    """Fetch BlueVoyant API token from Key Vault (preferred) or env var."""
    if _KV is not None:
        try:
            token = _KV.credentials.getSecret(AZURE_KEY_VAULT_URI, BLUEVOYANT_SECRET_NAME)
            if token:
                return token
        except Exception:
            pass
    token = os.environ.get("BlueVoyantAPIKey") or os.environ.get("BLUEVOYANT_API_TOKEN")
    if not token:
        raise RuntimeError(
            f"BlueVoyant API token not found. Configure Key Vault secret '{BLUEVOYANT_SECRET_NAME}' "
            "or set env var BlueVoyantAPIKey / BLUEVOYANT_API_TOKEN for this session."
        )
    return token

API_TOKEN = _get_api_token()

# COMMAND ----------
# ==== HTTP/GraphQL CLIENT (READ-ONLY) =========================================
BV_BASE = "https://api.bluevoyant.com/3pr/v1"
BV_QUERY_PATH = BV_BASE + "/clients/{clientUuid}/query"

class BlueVoyantClient:
    """Thin, read-only GraphQL client for BlueVoyant SCD."""
    def __init__(self, api_token: str, timeout: int = REQUEST_TIMEOUT_SECS):
        self.api_token = api_token
        self.timeout = timeout
        self.session = requests.Session()
        retry = Retry(
            total=8, connect=4, read=4, backoff_factor=0.8,
            status_forcelist=(429, 500, 502, 503, 504), respect_retry_after_header=True,
        )
        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("https://", adapter)
        self.session.headers.update({
            "Accept": "application/json",
            "X-BlueVoyant-Auth": self.api_token,
            "Content-Type": "application/json",
        })

    @staticmethod
    def _assert_read_only(graphql: str) -> None:
        if re.search(r"\bmutation\b", graphql, flags=re.IGNORECASE):
            raise ValueError("GraphQL mutations are blocked by this notebook (read-only).")

    def resolve_default_client_uuid(self) -> str:
        """Resolve default client UUID via all-zeros path; read Location header."""
        url = BV_QUERY_PATH.format(clientUuid="00000000-0000-0000-0000-000000000000")
        params = {"query": "{ __typename }"}
        r = self.session.get(url, params=params, timeout=self.timeout)
        r.raise_for_status()
        loc = r.headers.get("location") or r.headers.get("Location")
        if not loc:
            raise RuntimeError("BlueVoyant did not return a 'location' header; cannot infer client UUID.")
        m = re.search(r"/clients/([0-9a-fA-F\-]{36})/query", loc)
        if not m:
            raise RuntimeError("Could not parse client UUID from 'location' header: " + loc)
        return m.group(1)

    def graphql(self, client_uuid: str, query: str, variables: T.Optional[dict] = None) -> dict:
        """Always POST GraphQL. Includes response body on HTTP errors for diagnostics."""
        self._assert_read_only(query)
        url = BV_QUERY_PATH.format(clientUuid=client_uuid)
        payload = {"query": query}
        if variables is not None:
            payload["variables"] = variables
        resp = self.session.post(url, json=payload, timeout=self.timeout)
        try:
            resp.raise_for_status()
        except requests.HTTPError as e:
            snippet = resp.text[:2000]
            raise requests.HTTPError(
                f"HTTP {resp.status_code} from BlueVoyant. URL: {url}\nBody: {snippet}"
            ) from e
        data = resp.json()
        if isinstance(data, dict) and "errors" in data and data["errors"]:
            raise RuntimeError(f"GraphQL errors: {json.dumps(data['errors'], indent=2)[:2000]}")
        if not isinstance(data, dict) or "data" not in data:
            raise RuntimeError(f"Unexpected GraphQL response: {data}")
        return data["data"]

# Instantiate client & resolve client UUID
client = BlueVoyantClient(API_TOKEN)
CLIENT_UUID = client.resolve_default_client_uuid()

# COMMAND ----------
# Optional compatibility helper to avoid Native Engine fallback for collect_set
def collect_set_compat(col):
    """array_sort(array_distinct(collect_list(col))) — drop-in for collect_set(col)."""
    return F.array_sort(F.array_distinct(F.collect_list(col)))

# COMMAND ----------
# ==== EV: Emerging Vulnerability Summary ======================================
LIMIT = PAGE_SIZE

def build_ev_summary_query(offset: int, limit: int) -> str:
    return f"""
    query evSummaries {{
      emergingVulnerabilitySummaryInfo(
        limit: {limit}
        offset: {offset}
        filter: {{
          sortBy: [{{field: title direction: desc}}]
          minNumOfThirdPartiesIdentified: 1
        }}
      ) {{
        offset
        limit
        totalCount
        pageLength
        emergingVulnerabilitySummaries {{
          id
          title
          numOfThirdPartiesAcknowledged
          numOfThirdPartiesIdentified
          numOfThirdPartiesMitigated
          versionIdentified
          notificationDate
          notificationDetails
        }}
      }}
    }}
    """.strip()

first = client.graphql(CLIENT_UUID, build_ev_summary_query(offset=0, limit=LIMIT))
info = first["emergingVulnerabilitySummaryInfo"]
rows = info.get("emergingVulnerabilitySummaries", [])

total = int(info.get("totalCount", len(rows)))
page_len = int(info.get("pageLength", len(rows))) or len(rows)

collected = list(rows)
for offset in range(page_len, total, LIMIT):
    data = client.graphql(CLIENT_UUID, build_ev_summary_query(offset=offset, limit=LIMIT))
    more = data["emergingVulnerabilitySummaryInfo"].get("emergingVulnerabilitySummaries", [])
    collected.extend(more)

pdf = pd.DataFrame(collected)
pdf["notificationDate"] = pd.to_datetime(pdf.get("notificationDate"), errors="coerce")

sdf = spark.createDataFrame(pdf)
for c in sdf.columns:
    sdf = sdf.withColumnRenamed(c, re.sub(r"[^A-Za-z0-9_]", "_", c))

# WRITE EV (path-based, overwriteSchema)
ev_path = tbl_path(bronze_lh_id, EV_REL)
(sdf.write
    .format("delta")
    .mode(WRITE_MODE)
    .option("overwriteSchema", "true")
    .save(ev_path))

if WRITE_RAW_JSON:
    try:
        os.makedirs(RAW_JSON_DIR, exist_ok=True)
        with open(os.path.join(RAW_JSON_DIR, "emergingVulnerabilitySummaryInfo_page0.json"), "w", encoding="utf-8") as f:
            json.dump(first, f, ensure_ascii=False)
    except Exception as e:
        print(f"(non-fatal) Could not persist raw JSON: {e}")

# COMMAND ----------
# ==== Companies: minimal fields only (no troublesome objects) =================

# Step 1: Portfolios
PORTFOLIOS_Q = """
query portfolios($offset:Int!, $limit:Int!) {
  portfolioInfo(offset: $offset, limit: $limit) {
    totalCount
    pageLength
    portfolios { portfolioUuid portfolioName portfolioType }
  }
}
"""

portfolios = []
offset = 0
while True:
    d = client.graphql(CLIENT_UUID, PORTFOLIOS_Q, variables={"offset": offset, "limit": PAGE_SIZE})
    info = d.get("portfolioInfo", {})
    items = info.get("portfolios", [])
    portfolios.extend(items)
    total = int(info.get("totalCount", len(items)))
    page_len = int(info.get("pageLength", len(items))) or len(items)
    offset += page_len if page_len else PAGE_SIZE
    if len(items) == 0 or len(portfolios) >= total:
        break

# Step 2: Shape probes (for Name & RiskLevel only)
from dataclasses import dataclass

@dataclass
class Shape:
    name_field: str          # "primaryName" | "displayName" | ... | "primaryDomain"
    risk_mode: str           # "riskScore" | "score" | "none"

def _probe(fragment: str) -> bool:
    q = f"""
    query probe($offset:Int!, $limit:Int!) {{
      companyInfo(offset:$offset, limit:$limit) {{
        companies {{ {fragment} }}
      }}
    }}""".strip()
    try:
        client.graphql(CLIENT_UUID, q, variables={"offset":0,"limit":1})
        return True
    except Exception:
        return False

name_field = next((f for f in ["primaryName","displayName","legalName","companyName","name","primaryDomain"] if _probe(f)), "primaryDomain")
risk_mode  = "riskScore" if _probe("riskScore { riskLevel }") else ("score" if _probe("score { riskLevel }") else "none")
shape = Shape(name_field=name_field, risk_mode=risk_mode)

# Step 3: Minimal company query (whitelist only)
scalar_fields = [
    "bvid",
    "companyStatus",
    "escalationPath",
    "exceedsRiskTolerance",
    "exceedsRiskToleranceFirstDate",
    "firstAddedTS",
    "industryDescription",
    "numFindings",
    "primaryDomain",
    "scorePercentile",
]
parts = [f for f in scalar_fields if _probe(f)]
if _probe(shape.name_field):
    parts.append(shape.name_field)
if shape.risk_mode == "riskScore":
    parts.append("riskScore { riskLevel }")
elif shape.risk_mode == "score":
    parts.append("score { riskLevel }")
if "bvid" not in parts:
    parts.append("bvid")

fields_block = "\n          ".join(parts)
COMPANY_MIN_Q = f"""
query companies($filter: CompanyFilter, $offset:Int!, $limit:Int!) {{
  companyInfo(filter: $filter, offset: $offset, limit: $limit) {{
    totalCount
    pageLength
    companies {{
      {fields_block}
    }}
  }}
}}
""".strip()

# Step 4: Page companies
companies_by_bvid: dict[str, dict] = {}
for p in portfolios:
    p_uuid = p.get("portfolioUuid")
    if not p_uuid:
        continue
    offset = 0
    while True:
        data = client.graphql(
            CLIENT_UUID, COMPANY_MIN_Q,
            variables={"filter": {"portfolioUuids": [p_uuid]}, "offset": offset, "limit": PAGE_SIZE},
        )
        ci = data.get("companyInfo", {})
        items = ci.get("companies", [])
        for c in items:
            bvid = c.get("bvid")
            if bvid:
                companies_by_bvid[bvid] = c
        total = int(ci.get("totalCount", offset + len(items)))
        page_len = int(ci.get("pageLength", len(items))) or len(items)
        offset += page_len if page_len else PAGE_SIZE
        if offset >= total or not items:
            break

# Fallback by portfolioTypes if needed
if not companies_by_bvid:
    offset = 0
    while True:
        data = client.graphql(
            CLIENT_UUID, COMPANY_MIN_Q,
            variables={"filter": {"portfolioTypes": ["external_regular"]}, "offset": offset, "limit": PAGE_SIZE},
        )
        ci = data.get("companyInfo", {})
        items = ci.get("companies", [])
        for c in items:
            bvid = c.get("bvid")
            if bvid:
                companies_by_bvid[bvid] = c
        total = int(ci.get("totalCount", offset + len(items)))
        page_len = int(ci.get("pageLength", len(items))) or len(items)
        offset += page_len if page_len else PAGE_SIZE
        if offset >= total or not items:
            break

# Step 5: Flatten ONLY what we fetched
def _risk_level(c: dict) -> T.Optional[str]:
    if shape.risk_mode == "riskScore":
        return (c.get("riskScore") or {}).get("riskLevel")
    if shape.risk_mode == "score":
        return (c.get("score") or {}).get("riskLevel")
    return None

flat_rows = []
for c in companies_by_bvid.values():
    flat_rows.append({
        "Name": c.get(shape.name_field) or c.get("primaryDomain"),
        "RiskLevel": _risk_level(c),
        "bvid": c.get("bvid"),
        "companyStatus": c.get("companyStatus"),
        "escalationPath": c.get("escalationPath"),
        "exceedsRiskTolerance": c.get("exceedsRiskTolerance"),
        "exceedsRiskToleranceFirstDate": c.get("exceedsRiskToleranceFirstDate"),
        "firstAddedTS": c.get("firstAddedTS"),
        "industryDescription": c.get("industryDescription"),
        "numFindings": c.get("numFindings"),
        "primaryDomain": c.get("primaryDomain"),
        "scorePercentile": c.get("scorePercentile"),
    })

companies_pdf = pd.DataFrame(flat_rows).drop_duplicates(subset=["bvid"]) if flat_rows else pd.DataFrame(flat_rows)
companies_sdf = spark.createDataFrame(companies_pdf)

# Sanitize names and write
for c in companies_sdf.columns:
    companies_sdf = companies_sdf.withColumnRenamed(c, re.sub(r"[^A-Za-z0-9_]", "_", c))

comp_path = tbl_path(bronze_lh_id, COMP_REL)
(companies_sdf.write
    .format("delta")
    .mode(WRITE_MODE)
    .option("overwriteSchema", "true")
    .save(comp_path)
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
