# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

#imports
import os
import re
import json
import time
import typing as T
from datetime import datetime, timezone
import pandas as pd
from pyspark.sql import functions as F, types as T

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from pyspark.sql import SparkSession
spark = SparkSession.getActiveSession() or SparkSession.builder.getOrCreate()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# COMMAND ----------
# ==== CONFIG (edit to taste) ==================================================
AZURE_KEY_VAULT_URI = os.environ.get("AZURE_KEY_VAULT_URI", "https://KV-DC1Dev-ADF.vault.azure.net/")
BLUEVOYANT_SECRET_NAME = os.environ.get("BLUEVOYANT_SECRET_NAME", "BlueVoyantAPIKey")

REQUEST_TIMEOUT_SECS: int = 60
PAGE_SIZE: int = 1000
WRITE_MODE = os.environ.get("BV_WRITE_MODE", "overwrite")  # overwrite | append

# Rel paths (schema/table) for path-based writes
EV_REL = "Bronze/BlueVoyantEVSummaries"
COMP_REL = "Bronze/BlueVoyantCompanies"

WRITE_RAW_JSON = True
RAW_JSON_DIR = os.environ.get(
    "BV_RAW_DIR",
    f"Files/bluevoyant/raw/{datetime.now(timezone.utc).strftime('%Y%m%d')}"
)

# COMMAND ----------
# ==== SECRET RETRIEVAL (simple) ===============================================
try:
    import notebookutils as nbu  # Fabric modern alias
    _KV = nbu
except Exception:
    try:
        from notebookutils import mssparkutils as nbu  # legacy alias
        _KV = nbu
    except Exception:
        _KV = None

def _get_api_token() -> str:
    """Fetch BlueVoyant API token from Key Vault (preferred) or env var."""
    if _KV is not None:
        try:
            token = _KV.credentials.getSecret(AZURE_KEY_VAULT_URI, BLUEVOYANT_SECRET_NAME)
            if token:
                return token
        except Exception:
            pass
    token = os.environ.get("BlueVoyantAPIKey") or os.environ.get("BLUEVOYANT_API_TOKEN")
    if not token:
        raise RuntimeError(
            f"BlueVoyant API token not found. Configure Key Vault secret '{BLUEVOYANT_SECRET_NAME}' "
            "or set env var BlueVoyantAPIKey / BLUEVOYANT_API_TOKEN for this session."
        )
    return token

API_TOKEN = _get_api_token()

# COMMAND ----------
# ==== HTTP/GraphQL CLIENT (READ-ONLY) =========================================
BV_BASE = "https://api.bluevoyant.com/3pr/v1"
BV_QUERY_PATH = BV_BASE + "/clients/{clientUuid}/query"

class BlueVoyantClient:
    """Thin, read-only GraphQL client for BlueVoyant SCD."""
    def __init__(self, api_token: str, timeout: int = REQUEST_TIMEOUT_SECS):
        self.api_token = api_token
        self.timeout = timeout
        self.session = requests.Session()
        retry = Retry(
            total=8, connect=4, read=4, backoff_factor=0.8,
            status_forcelist=(429, 500, 502, 503, 504), respect_retry_after_header=True,
        )
        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("https://", adapter)
        self.session.headers.update({
            "Accept": "application/json",
            "X-BlueVoyant-Auth": self.api_token,
            "Content-Type": "application/json",
        })

    @staticmethod
    def _assert_read_only(graphql: str) -> None:
        # IMPORTANT: use clean word boundaries (no hidden control chars)
        if re.search(r"\bmutation\b", graphql, flags=re.IGNORECASE):
            raise ValueError("GraphQL mutations are blocked by this notebook (read-only).")

    def resolve_default_client_uuid(self) -> str:
        """Resolve default client UUID via all-zeros path; read Location header."""
        url = BV_QUERY_PATH.format(clientUuid="00000000-0000-0000-0000-000000000000")
        params = {"query": "{ __typename }"}
        r = self.session.get(url, params=params, timeout=self.timeout)
        r.raise_for_status()
        loc = r.headers.get("location") or r.headers.get("Location")
        if not loc:
            raise RuntimeError("BlueVoyant did not return a 'location' header; cannot infer client UUID.")
        m = re.search(r"/clients/([0-9a-fA-F\-]{36})/query", loc)
        if not m:
            raise RuntimeError("Could not parse client UUID from 'location' header: " + loc)
        return m.group(1)

    def graphql(self, client_uuid: str, query: str, variables: T.Optional[dict] = None) -> dict:
        """Always POST GraphQL. Includes response body on HTTP errors for diagnostics."""
        self._assert_read_only(query)
        url = BV_QUERY_PATH.format(clientUuid=client_uuid)
        payload = {"query": query}
        if variables is not None:
            payload["variables"] = variables
        resp = self.session.post(url, json=payload, timeout=self.timeout)
        try:
            resp.raise_for_status()
        except requests.HTTPError as e:
            snippet = resp.text[:2000]
            raise requests.HTTPError(
                f"HTTP {resp.status_code} from BlueVoyant. URL: {url}\nBody: {snippet}"
            ) from e
        data = resp.json()
        if isinstance(data, dict) and "errors" in data and data["errors"]:
            raise RuntimeError(f"GraphQL errors: {json.dumps(data['errors'], indent=2)[:2000]}")
        if not isinstance(data, dict) or "data" not in data:
            raise RuntimeError(f"Unexpected GraphQL response: {data}")
        return data["data"]

# Instantiate client & resolve client UUID
client = BlueVoyantClient(API_TOKEN)
CLIENT_UUID = client.resolve_default_client_uuid()

# COMMAND ----------
# Optional compatibility helper to avoid Native Engine fallback for collect_set
def collect_set_compat(col):
    """array_sort(array_distinct(collect_list(col))) — drop-in for collect_set(col)."""
    return F.array_sort(F.array_distinct(F.collect_list(col)))

# COMMAND ----------
# ==== EV: Emerging Vulnerability Summary ======================================
LIMIT = PAGE_SIZE

def build_ev_summary_query(offset: int, limit: int) -> str:
    return f"""
    query evSummaries {{
      emergingVulnerabilitySummaryInfo(
        limit: {limit}
        offset: {offset}
        filter: {{
          sortBy: [{{field: title direction: desc}}]
          minNumOfThirdPartiesIdentified: 1
        }}
      ) {{
        offset
        limit
        totalCount
        pageLength
        emergingVulnerabilitySummaries {{
          id
          title
          numOfThirdPartiesAcknowledged
          numOfThirdPartiesIdentified
          numOfThirdPartiesMitigated
          versionIdentified
          notificationDate
          notificationDetails
        }}
      }}
    }}
    """.strip()

first = client.graphql(CLIENT_UUID, build_ev_summary_query(offset=0, limit=LIMIT))
info = first["emergingVulnerabilitySummaryInfo"]
rows = info.get("emergingVulnerabilitySummaries", [])

total = int(info.get("totalCount", len(rows)))
page_len = int(info.get("pageLength", len(rows))) or len(rows)

collected = list(rows)
for offset in range(page_len, total, LIMIT):
    data = client.graphql(CLIENT_UUID, build_ev_summary_query(offset=offset, limit=LIMIT))
    more = data["emergingVulnerabilitySummaryInfo"].get("emergingVulnerabilitySummaries", [])
    collected.extend(more)

import pandas as pd
pdf = pd.DataFrame(collected)
pdf["notificationDate"] = pd.to_datetime(pdf.get("notificationDate"), errors="coerce")

sdf = spark.createDataFrame(pdf)
for c in sdf.columns:
    sdf = sdf.withColumnRenamed(c, re.sub(r"[^A-Za-z0-9_]", "_", c))

# WRITE EV (path-based, overwriteSchema)
ev_path = tbl_path(bronze_lh_id, EV_REL)
(sdf.write
    .format("delta")
    .mode(WRITE_MODE)
    .option("overwriteSchema", "true")
    .save(ev_path))

if WRITE_RAW_JSON:
    try:
        os.makedirs(RAW_JSON_DIR, exist_ok=True)
        with open(os.path.join(RAW_JSON_DIR, "emergingVulnerabilitySummaryInfo_page0.json"), "w", encoding="utf-8") as f:
            json.dump(first, f, ensure_ascii=False)
    except Exception as e:
        print(f"(non-fatal) Could not persist raw JSON: {e}")

# COMMAND ----------
# ==== Companies: adaptive schema probe + write =================================

# Step 1: Portfolios (PortfolioData exposes fields directly)
PORTFOLIOS_Q = """
query portfolios($offset:Int!, $limit:Int!) {
  portfolioInfo(offset: $offset, limit: $limit) {
    totalCount
    pageLength
    portfolios { portfolioUuid portfolioName portfolioType }
  }
}
"""

portfolios = []
offset = 0
while True:
    d = client.graphql(CLIENT_UUID, PORTFOLIOS_Q, variables={"offset": offset, "limit": PAGE_SIZE})
    info = d.get("portfolioInfo", {})
    items = info.get("portfolios", [])
    portfolios.extend(items)
    total = int(info.get("totalCount", len(items)))
    page_len = int(info.get("pageLength", len(items))) or len(items)
    offset += page_len if page_len else PAGE_SIZE
    if len(items) == 0 or len(portfolios) >= total:
        break

# ====== COMPANIES (minimal, user-selected fields) ============================
from dataclasses import dataclass

@dataclass
class Shape:
    name_field: str          # which name-like field exists
    risk_mode: str           # "riskScore" | "score" | "none"
    has_vendor_discovery: bool

def _probe(fragment: str) -> bool:
    q = f"""
    query probe($offset:Int!, $limit:Int!) {{
      companyInfo(offset:$offset, limit:$limit) {{
        companies {{ {fragment} }}
      }}
    }}""".strip()
    try:
        client.graphql(CLIENT_UUID, q, variables={"offset":0,"limit":1})
        return True
    except Exception:
        return False

# Resolve shapes we need for your selected columns
name_field = next((f for f in ["primaryName","displayName","legalName","companyName","name","primaryDomain"] if _probe(f)), "primaryDomain")
risk_mode  = "riskScore" if _probe("riskScore { riskLevel }") else ("score" if _probe("score { riskLevel }") else "none")
has_vd     = _probe("vendorDiscovery { vendor product }")  # needed to populate "Product"

shape = Shape(name_field=name_field, risk_mode=risk_mode, has_vendor_discovery=has_vd)

# Build the company query with only the requested fields (minimal sub-selections for OBJECTs)
# ---- Build a safe field list for exactly the fields you want ----

def probe_any(fragments: list[str]) -> str | None:
    """Return the first fragment that validates, else None."""
    for frag in fragments:
        if _probe(frag):
            return frag
    return None

# Scalars/enums are simple:
scalar_fields = [
    "attributes",
    "bvid",
    "companyStatus",
    "currentEscalatedCases",
    "escalationPath",
    "exceedsRiskTolerance",
    "exceedsRiskToleranceFirstDate",
    "firstAddedTS",
    "firstEscalated",
    "industryDescription",
    "numFindings",
    "primaryDomain",
    "scorePercentile",
]

# Object fields with candidate sub-selections (ordered from “useful guess” to safest).
# We ALWAYS include a fallback of `{ __typename }` since every object supports it.
object_candidates: dict[str, list[str]] = {
    # Many "Info"/*Scores may actually be connections or summaries; try count-like shapes first.
    "categoryScores": [
        "categoryScores { __typename }",                # safest
    ],
    "clientContacts": [
        "clientContacts { email }",
        "clientContacts { contact email }",
        "clientContacts { __typename }",
    ],
    "cpeCVE": [
        "cpeCVE { totalCount }",
        "cpeCVE { __typename }",
    ],
    "domainCountryInfo": [
        "domainCountryInfo { country code count }",
        "domainCountryInfo { items { country code count } }",
        "domainCountryInfo { __typename }",
    ],
    "findingInfo": [
        "findingInfo { totalCount }",
        "findingInfo { __typename }",
    ],
    "vendorContacts": [
        "vendorContacts { email }",
        "vendorContacts { contact email }",
        "vendorContacts { __typename }",
    ],
}

parts = []

# Safe-add scalars
for f in scalar_fields:
    if _probe(f):
        parts.append(f)

# Name column source
if _probe(shape.name_field):
    parts.append(shape.name_field)
else:
    # fallback already included: primaryDomain is in scalar_fields
    pass

# RiskLevel source
if shape.risk_mode == "riskScore":
    parts.append("riskScore { riskLevel }")
elif shape.risk_mode == "score":
    parts.append("score { riskLevel }")

# Product source (vendorDiscovery), if available
if shape.has_vendor_discovery:
    vd_frag = probe_any([
        "vendorDiscovery { vendor product }",
        "vendorDiscovery { vendor }",
        "vendorDiscovery { __typename }",
    ])
    if vd_frag:
        parts.append(vd_frag)

# Add chosen object fragments
for field, candidates in object_candidates.items():
    frag = probe_any(candidates)
    if frag:
        parts.append(frag)

# Always keep bvid to de-dup/join later
if "bvid" not in parts:
    parts.append("bvid")

fields_block = "\n          ".join(parts)
COMPANY_MIN_Q = f"""
query companies($filter: CompanyFilter, $offset:Int!, $limit:Int!) {{
  companyInfo(filter: $filter, offset: $offset, limit: $limit) {{
    totalCount
    pageLength
    companies {{
      {fields_block}
    }}
  }}
}}
""".strip()


# Page across portfolios (same as your original logic)
companies_by_bvid: dict[str, dict] = {}
for p in portfolios:
    p_uuid = p.get("portfolioUuid")
    if not p_uuid:
        continue
    offset = 0
    while True:
        data = client.graphql(
            CLIENT_UUID, COMPANY_MIN_Q,
            variables={"filter": {"portfolioUuids": [p_uuid]}, "offset": offset, "limit": PAGE_SIZE},
        )
        ci = data.get("companyInfo", {})
        items = ci.get("companies", [])
        for c in items:
            bvid = c.get("bvid")
            if bvid:
                companies_by_bvid[bvid] = c
        total = int(ci.get("totalCount", offset + len(items)))
        page_len = int(ci.get("pageLength", len(items))) or len(items)
        offset += page_len if page_len else PAGE_SIZE
        if offset >= total or not items:
            break

# Fallback: if nothing came back via portfolios, try portfolioTypes
if not companies_by_bvid:
    offset = 0
    while True:
        data = client.graphql(
            CLIENT_UUID, COMPANY_MIN_Q,
            variables={"filter": {"portfolioTypes": ["external_regular"]}, "offset": offset, "limit": PAGE_SIZE},
        )
        ci = data.get("companyInfo", {})
        items = ci.get("companies", [])
        for c in items:
            bvid = c.get("bvid")
            if bvid:
                companies_by_bvid[bvid] = c
        total = int(ci.get("totalCount", offset + len(items)))
        page_len = int(ci.get("pageLength", len(items))) or len(items)
        offset += page_len if page_len else PAGE_SIZE
        if offset >= total or not items:
            break

# ---- Flatten to your requested output columns ----
def _risk_level(c: dict) -> str | None:
    if shape.risk_mode == "riskScore":
        return (c.get("riskScore") or {}).get("riskLevel")
    if shape.risk_mode == "score":
        return (c.get("score") or {}).get("riskLevel")
    return None

def _product(c: dict) -> str | None:
    if not shape.has_vendor_discovery:
        return None
    vd = c.get("vendorDiscovery") or []
    # Join unique vendor:product pairs
    vals = []
    for v in vd:
        ven = (v.get("vendor") or "").strip()
        prod = (v.get("product") or "").strip()
        if ven and prod:
            vals.append(f"{ven}: {prod}")
        elif ven:
            vals.append(ven)
        elif prod:
            vals.append(prod)
    return ", ".join(sorted(set(vals))) if vals else None

flat_rows = []
for c in companies_by_bvid.values():
    flat_rows.append({
        "Name": c.get(shape.name_field) or c.get("primaryDomain"),
        "Product": _product(c),
        "RiskLevel": _risk_level(c),
        "attributes": c.get("attributes"),
        "bvid": c.get("bvid"),
        "clientContacts": c.get("clientContacts"),
        "companyStatus": c.get("companyStatus"),
        "currentEscalatedCases": c.get("currentEscalatedCases"),
        "escalationPath": c.get("escalationPath"),
        "exceedsRiskTolerance": c.get("exceedsRiskTolerance"),
        "exceedsRiskToleranceFirstDate": c.get("exceedsRiskToleranceFirstDate"),
        "firstAddedTS": c.get("firstAddedTS"),
        "firstEscalated": c.get("firstEscalated"),
        "industryDescription": c.get("industryDescription"),
        "numFindings": c.get("numFindings"),
        "primaryDomain": c.get("primaryDomain"),
        "scorePercentile": c.get("scorePercentile"),
    })


# Build pandas df
companies_pdf = pd.DataFrame(flat_rows).drop_duplicates(subset=["bvid"]) if flat_rows else pd.DataFrame(flat_rows)

# 1) Ensure attributes is always a list of strings (or None)
def to_str_list(x):
    if x is None:
        return None
    if isinstance(x, list):
        return [str(v) for v in x if v is not None]
    return [str(x)]

if "attributes" in companies_pdf.columns:
    companies_pdf["attributes"] = companies_pdf["attributes"].apply(to_str_list)

# 2) Stringify complex/object fields so Delta doesn’t choke on NullType in nested types
json_cols = ["categoryScores", "clientContacts", "cpeCVE", "domainCountryInfo", "findingInfo", "vendorContacts"]
for col in json_cols:
    if col in companies_pdf.columns:
        companies_pdf[col] = companies_pdf[col].apply(lambda v: json.dumps(v, ensure_ascii=False) if v is not None else None)

# 3) Create Spark DF
companies_sdf = spark.createDataFrame(companies_pdf)

# 4) Force attributes to array<string>
if "attributes" in companies_sdf.columns:
    companies_sdf = companies_sdf.withColumn("attributes", F.col("attributes").cast(T.ArrayType(T.StringType())))

# 5) Sanitize column names (no second createDataFrame!)
for c in companies_sdf.columns:
    companies_sdf = companies_sdf.withColumnRenamed(c, re.sub(r"[^A-Za-z0-9_]", "_", c))
comp_path = tbl_path(bronze_lh_id, COMP_REL)
# 6) Write
(companies_sdf.write
    .format("delta")
    .mode(WRITE_MODE)
    .option("overwriteSchema", "true")
    .save(comp_path)
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
