# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import requests
import datetime
from pyspark.sql.functions import col
from concurrent.futures import ThreadPoolExecutor, as_completed

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))


# === Step 1: Read EntraUsers emails (allowed/active) ===
from pyspark.sql import functions as F

entra_df = read_delta(bronze_lh_id, "Bronze/EntraUsers")

active_emails = (
    entra_df
    .where(
        (F.col("accountEnabled") == 1) &
        (F.col("mail").isNotNull()) &
        (~F.col("mail").endswith("@apac.hmc.harvard.edu"))  # Exclude APAC emails
    )
    .select("mail")
    .rdd.flatMap(lambda row: row)
    .collect()
)


# === Step 2: Prepare constants / auth ===
import datetime
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

# Key Vault: same approach as your current code
api_key = mssparkutils.credentials.getSecret(
    'https://KV-DC1Dev-ADF.vault.azure.net/',
    'spycloud-api-key'
)

headers = {
    "accept": "application/json",
    "X-API-KEY": api_key
}

# Lookback (kept as in your code: 730 days = ~2 years)
two_years_ago = datetime.datetime.utcnow() - datetime.timedelta(days=730)


# === Step 3R: Loop over emails and fetch breach data (no title yet) ===
results = []

for email in active_emails:
    url = f"https://api.spycloud.io/enterprise-v2/breach/data/emails/{email}"
    try:
        response = requests.get(url, headers=headers, timeout=30)
    except Exception as e:
        print(f"❌ Request error for {email}: {e}")
        continue

    if response.status_code == 200:
        records = (response.json() or {}).get("results", [])
        for r in records:
            if isinstance(r, dict):
                publish_date = r.get("spycloud_publish_date")
                if publish_date:
                    try:
                        dt = datetime.datetime.fromisoformat(publish_date.replace("Z", ""))
                        if dt >= two_years_ago:
                            r["queried_email"] = email
                            # Title resolved later (Step 4R)
                            results.append(r)
                    except Exception:
                        # Ignore parsing issues per original behavior
                        pass
    else:
        print(f"❌ Failed for {email}: {response.status_code} {response.text[:200]}")


# === Step 4R: Resolve breach titles only for SEEN source_ids ===
def _to_int_safe(x):
    try:
        return int(x)
    except Exception:
        return None

seen_ids = sorted({_to_int_safe(r.get("source_id")) for r in results if r.get("source_id") is not None})
seen_ids = [sid for sid in seen_ids if sid is not None]

id_to_title = {}
not_found = set()

def fetch_title_for_id(sid: int):
    try:
        r = requests.get(
            f"https://api.spycloud.io/enterprise-v2/breach/catalog/{sid}",
            headers=headers,
            timeout=20,
        )
        if r.status_code != 200:
            return (sid, None)
        data = r.json() or {}
        # Normalize potential shapes
        obj = (data.get("results") or [data])[0]
        title = obj.get("short_title") or obj.get("title")
        return (sid, title)
    except Exception:
        return (sid, None)

MAX_WORKERS = 8
if seen_ids:
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        futs = {ex.submit(fetch_title_for_id, sid): sid for sid in seen_ids}
        for fut in as_completed(futs):
            sid, title = fut.result()
            if title:
                id_to_title[sid] = title
            else:
                not_found.add(sid)

# Enrich collected records with titles
for r in results:
    sid = _to_int_safe(r.get("source_id"))
    r["breach_title"] = id_to_title.get(sid, "NOT AVAILABLE")

print(
    f"ℹ️ Enriched {len(results)} records | titles resolved for {len(id_to_title)} unique source_ids "
    f"| unresolved ids: {len(not_found)} (e.g., {sorted(list(not_found))[:10]})"
)


# === Step 5: Convert and WRITE (full-refresh overwrite) ===
if results:
    from pyspark.sql.types import LongType, TimestampType, DateType, StringType

    df = spark.createDataFrame(results)

    # Normalize/cast dates and add ETL timestamp
    if "spycloud_publish_date" in df.columns:
        df = df.withColumn("spycloud_publish_date", F.to_date(F.col("spycloud_publish_date")))
    df = df.withColumn("ETLLoadDateTime", F.current_timestamp())

    expected_cols = [
        "breach_title","document_id","domain","email","email_domain","email_username",
        "full_name","queried_email","severity","source_id","spycloud_publish_date",
        "company_name","job_title","account_status","phone","account_signup_time",
        "first_name","industry","last_name","social_linkedin","city","company_website",
        "state","account_last_activity_time","ETLLoadDateTime"
    ]

    # Ensure expected columns exist with explicit types where possible
    for c in expected_cols:
        if c not in df.columns:
            df = df.withColumn(c, F.lit(None).cast(StringType()))

    df_out = (
        df
        .withColumn("severity", F.col("severity").cast(LongType()))
        .withColumn("source_id", F.col("source_id").cast(LongType()))
        .withColumn("spycloud_publish_date", F.col("spycloud_publish_date").cast(DateType()))
        .withColumn("ETLLoadDateTime", F.col("ETLLoadDateTime").cast(TimestampType()))
        .select(*expected_cols)
        .dropDuplicates(["document_id", "queried_email"])
    )

    # Write like the Splunk job: to a Delta path under Bronze
    target_rel = "Bronze/CyberDashboardSpyCloud"
    target_path = tbl_path(bronze_lh_id, target_rel)

    (
        df_out.write
        .mode("overwrite")
        .format("delta")
        .option("overwriteSchema", "true")
        .save(target_path)
    )

    print(f"✅ Overwrote Delta dataset at {target_path} with {df_out.count()} rows.")
else:
    print("ℹ️ No breach records to write.")



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
