# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

# 1) Raw TCP check: fails fast if there's no route or a firewall drop
import requests
print(requests.get("https://ifconfig.me").text) 

import socket
with socket.socket() as s:
    s.settimeout(5)
    s.connect(("192.168.31.100", 443))
    print("TCP 443 connected")  # you'll only see this if it actually connects


# 2) Show this runtime's public egress IP (useful to demonstrate it's not in your on-prem)
import requests
print("Egress IP:", requests.get("https://api.ipify.org", timeout=10).text)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Fabric PySpark notebook: Pull Panorama rules tagged "Exception" and load into a Spark DataFrame
# -----------------------------------------------------------------------------------------------
# What this does
# 1) Fetches firewall rules from Panorama via the XML API using X-PAN-KEY auth
# 2) Parses XML and normalizes common rule fields
# 3) Returns a Spark DataFrame and (optionally) writes to a Lakehouse table in your workspace
#
# Notes
# - Keep your Palo Alto API key in Azure Key Vault. This notebook will try mssparkutils first,
#   then fall back to an environment variable PANORAMA_X_PAN_KEY if needed.
# - Ensure your Fabric workspace/network can reach https://panorama.hmc.harvard.edu
# - If your Panorama certificate is private, you may need to provide a CA bundle or set verify=False (not recommended)

# COMMAND ----------
# --- Configuration ---
import os
from datetime import datetime

# Panorama endpoint & query
PANORAMA_BASE_URL = "https:/panorama.hmc.harvard.edu/api/"
# XPath already filters to rules with a Tag member == 'Exception'
XPATH = "/config/devices/entry[@name='localhost.localdomain']/device-group/entry[@name='Boston_Firewalls']/post-rulebase/security/rules/entry[tag/member='Exception']"

# Key Vault configuration (preferred)
# Create a Linked Service to your Key Vault named kv_link, or update these values accordingly.
KEY_VAULT_NAME = os.environ.get("KEY_VAULT_NAME", "<your-kv-name>")  # e.g., "hmc-sec-kv"
KEY_VAULT_SECRET_NAME = os.environ.get("KEY_VAULT_SECRET_NAME", "panorama-x-pan-key")

# Optional: Lakehouse table to write to (set to None to skip write)
TARGET_TABLE = None # os.environ.get("TARGET_TABLE", "Silver.Network_PanoramaExceptionRules")  # or None to skip
WRITE_MODE = os.environ.get("WRITE_MODE", "overwrite")  # overwrite | append

# HTTP options
REQUEST_TIMEOUT = (10, 120)  # (connect, read) seconds
VERIFY_TLS = True            # Set to a custom CA bundle path if needed

# COMMAND ----------
# --- Secret retrieval ---


PANORAMA_X_PAN_KEY = "LUFRPT10ZGliUDZycnc2TEszS0p6dFVsM0I5Uy9rSkU9eVN4SURBeGd6QXZJR1BRbUgzYmthVW56MDBmYWVTOXI2M0xvbFFNWEx5SlhHaStXWmUvRXUwR2RLY3d6YTUrY1VXUDdzWEQwRTZEdUgrRCtFZERvZXc9PQ=="

# Try Microsoft Fabric/Synapse style secret retrieval first
try:
    from notebookutils import mssparkutils  # Fabric/Synapse utility
    try:
        PAN_API_KEY = PANORAMA_X_PAN_KEY
        #PAN_API_KEY = mssparkutils.credentials.getSecret(KEY_VAULT_NAME, KEY_VAULT_SECRET_NAME)
    except Exception:
        PAN_API_KEY = None
except Exception:
    try:
        import mssparkutils  # sometimes available without the package path
        try:
          PAN_API_KEY = PANORAMA_X_PAN_KEY
          #PAN_API_KEY = mssparkutils.credentials.getSecret(KEY_VAULT_NAME, KEY_VAULT_SECRET_NAME)
        except Exception:
            PAN_API_KEY = None
    except Exception:
        PAN_API_KEY = None

# Fallback to environment variable
if not PAN_API_KEY:
    PAN_API_KEY = os.environ.get("PANORAMA_X_PAN_KEY")

if not PAN_API_KEY:
    raise RuntimeError(
        "Palo Alto API key not found. Configure a Key Vault linked service and secret, "
        "or set the PANORAMA_X_PAN_KEY environment variable.")

# COMMAND ----------
# --- Fetch XML from Panorama ---

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

params = {
    "type": "config",
    "action": "get",
    "xpath": XPATH,
}
headers = {
    "X-PAN-KEY": PAN_API_KEY,
}

session = requests.Session()
retries = Retry(
    total=5,
    backoff_factor=0.5,
    status_forcelist=[429, 500, 502, 503, 504],
    allowed_methods=["GET"],
)
adapter = HTTPAdapter(max_retries=retries)
session.mount("https://", adapter)
session.mount("http://", adapter)

resp = session.get(PANORAMA_BASE_URL, params=params, headers=headers, timeout=REQUEST_TIMEOUT, verify=VERIFY_TLS)

if resp.status_code != 200:
    raise RuntimeError(f"HTTP {resp.status_code} from Panorama: {resp.text[:500]}")

xml_text = resp.text

# COMMAND ----------
# --- Parse and normalize XML ---

import xml.etree.ElementTree as ET

root = ET.fromstring(xml_text)
status = root.attrib.get("status")
if status and status.lower() != "success":
    # Panorama often includes an <msg> element with details
    msg_el = root.find(".//msg")
    details = msg_el.text.strip() if (msg_el is not None and msg_el.text) else "(no message)"
    raise RuntimeError(f"Panorama response status != success: {details}")

# Helper functions to extract common Panorama rule fields

def _txt(parent, tag):
    el = parent.find(tag)
    if el is not None and el.text is not None:
        return el.text.strip()
    return None

def _members(parent, tag):
    el = parent.find(tag)
    if el is None:
        return []
    return [m.text for m in el.findall("member") if m is not None and m.text]

def _bool(text_val):
    if text_val is None:
        return None
    return str(text_val).strip().lower() in {"true", "yes", "1"}

# Panorama typically returns <response><result><rules><entry ...>...</entry>...</rules></result></response>
entries = root.findall(".//result//rules//entry")

rows = []
for e in entries:
    rule = {
        "rule_name": e.attrib.get("name"),
        "description": _txt(e, "description"),
        "action": _txt(e, "action"),
        "disabled": _bool(_txt(e, "disabled")),
        # Zones
        "from_zones": _members(e, "from"),
        "to_zones": _members(e, "to"),
        # Addresses / users
        "source_addresses": _members(e, "source"),
        "destination_addresses": _members(e, "destination"),
        "source_users": _members(e, "source-user"),
        # Apps / services / categories / tags
        "applications": _members(e, "application"),
        "services": _members(e, "service"),
        "categories": _members(e, "category"),
        "tags": _members(e, "tag"),
        # Negation flags
        "negate_source": _bool(_txt(e, "negate-source")),
        "negate_destination": _bool(_txt(e, "negate-destination")),
        # Logging & profiles (may be absent)
        "log_setting": _txt(e, "log-setting"),
        # Profile settings can vary; we do a best-effort flatten
        "profile_setting": None,
        # Audit
        "pulled_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
    }

    # Try to summarize profile-setting into a compact string if present
    ps = e.find("profile-setting")
    if ps is not None:
        # Common shapes: <profiles><virus><member>default</member></virus>...</profiles> OR group references
        parts = []
        for child in ps.iter():
            if child is ps:
                continue
            tag = child.tag
            mems = [m.text for m in child.findall("member") if m.text]
            if mems:
                parts.append(f"{tag}={','.join(mems)}")
        rule["profile_setting"] = ";".join(parts) if parts else None

    rows.append(rule)

print(f"Parsed {len(rows)} rule(s) from Panorama response.")

# COMMAND ----------
# --- Create Spark DataFrame ---

from pyspark.sql import functions as F, types as T

df = spark.createDataFrame(rows)

# Ensure stable column order
ordered_cols = [
    "rule_name", "description", "action", "disabled",
    "from_zones", "to_zones",
    "source_addresses", "destination_addresses", "source_users",
    "applications", "services", "categories", "tags",
    "negate_source", "negate_destination",
    "log_setting", "profile_setting", "pulled_at",
]

existing_cols = [c for c in ordered_cols if c in df.columns]
df = df.select(*existing_cols)

display(df)

# COMMAND ----------
# --- Optional: write to a Lakehouse table ---

if TARGET_TABLE:
    (df.write
        .mode(WRITE_MODE)
        .option("overwriteSchema", "true")
        .saveAsTable(TARGET_TABLE))
    print(f"Wrote {df.count()} row(s) to table: {TARGET_TABLE}")
else:
    print("Skipping table write (TARGET_TABLE is None).")

# COMMAND ----------
# --- Reuse tip: fetching other tags or ALL rules ---
# To fetch rules with a different tag, change the XPATH above to e.g.:
# XPATH = "/config/.../security/rules/entry[tag/member='MyOtherTag']"
# To fetch ALL rules in the post-rulebase, use:
# XPATH = "/config/devices/entry[@name='localhost.localdomain']/device-group/entry[@name='Boston_Firewalls']/post-rulebase/security/rules"
# (and consider client-side filtering on df where array_contains(df.tags, 'Exception'))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
