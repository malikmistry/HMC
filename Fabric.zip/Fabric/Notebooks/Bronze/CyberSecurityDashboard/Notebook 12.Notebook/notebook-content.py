# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))
# =========
# READ (Bronze)
# =========
exc_rel    = "Bronze/ExceptionRules"
entra_rel  = "Bronze/EntraUsers"
target_rel = "Bronze/ManualExceptions"

exc_df   = read_delta(bronze_lh_id, exc_rel)
entra_df = read_delta(bronze_lh_id, entra_rel)



# Keep only rows where user_raw is like 'domain\sam' and extract the sam
exc_clean = (
    exc_df
    .withColumn("has_bslash", F.instr(F.col("user_raw"), "\\") > 0)
    .filter(F.col("has_bslash"))  # ignore rows without backslash
    .withColumn("domain_part", F.lower(F.split("user_raw", r"\\").getItem(0)))
    .withColumn("sam", F.lower(F.split("user_raw", r"\\").getItem(1)))
    .filter(F.col("domain_part") == F.lit("domain"))  # keep only domain\*
    .drop("has_bslash", "domain_part")
)

# Build join key from Entra: left-of-@ from mail (fallback to userPrincipalName)
entra_keyed = (
    entra_df
    .withColumn("upn_or_mail", F.coalesce(F.col("mail"), F.col("userPrincipalName")))
    .withColumn("user_left_of_at", F.lower(F.split(F.col("upn_or_mail"), "@").getItem(0)))
)

# Join and construct ManualExceptions shape
out_df = (
    exc_clean.alias("e")
    .join(
        entra_keyed.alias("u"),
        F.col("e.sam") == F.col("u.user_left_of_at"),
        "left"
    )
    .select(
        F.col("e.rule").alias("Exception_Name"),
        F.col("u.mail").alias("User_Email"),
        # Name as "Surname, GivenName" per env convention
        F.concat_ws(", ", F.col("u.surname"), F.col("u.givenName")).alias("User_Name"),
        F.lit(10).alias("Risk_1_10"),
        F.col("e.rule").alias("Full_Description"),
        F.current_timestamp().alias("ETLLoadDateTime"),
    )
)

# =========
# WRITE
# =========
target_path = tbl_path(bronze_lh_id, target_rel)  # leave parameterized

(out_df.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(target_path))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
