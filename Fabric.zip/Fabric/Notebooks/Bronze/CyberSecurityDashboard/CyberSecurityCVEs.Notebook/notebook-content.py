# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# PySpark on Fabric
from pyspark.sql import functions as F, types as T
import requests, os, time, math, datetime as dt

DAYS_BACK            = 2
RESULTS_PER_PAGE     = 2000
SLEEP_SECONDS        = 1 if os.getenv("NVD_API_KEY") else 6
BRONZE_RAW_TABLE     = "Bronze.NVD_CVE_Raw"   
BRONZE_FLAT_TABLE    = "Bronze.NVD_CVE_Flat" 

# ---- Dates (UTC) ----
end   = dt.datetime.utcnow().replace(microsecond=0)
start = end - dt.timedelta(days=DAYS_BACK)

# ---- API ----
BASE = "https://services.nvd.nist.gov/rest/json/cves/2.0"
API_KEY = os.getenv("NVD_API_KEY")  
params_base = {
    "lastModStartDate": start.isoformat() + "Z",
    "lastModEndDate":   end.isoformat()   + "Z",
    "resultsPerPage": RESULTS_PER_PAGE,
}

headers = {"apiKey": API_KEY} if API_KEY else {}

# ---- Fetch first page to get total ----
r = requests.get(BASE, params={**params_base, "startIndex": 0}, headers=headers, timeout=60)
r.raise_for_status()
j = r.json()
total = j.get("totalResults", 0)
pages = math.ceil(total / RESULTS_PER_PAGE)

all_chunks = []
if total > 0:
    all_chunks.append(j)
    for p in range(1, pages):
        idx = p * RESULTS_PER_PAGE
        time.sleep(SLEEP_SECONDS)
        r = requests.get(BASE, params={**params_base, "startIndex": idx}, headers=headers, timeout=60)
        r.raise_for_status()
        all_chunks.append(r.json())

cves = []
for chunk in all_chunks:
    for v in chunk.get("vulnerabilities", []):
        cves.append(v.get("cve"))

rows = []
for cve in cves:
    rows.append(Row(
        cve_id = cve.get("id"),
        published = cve.get("published"),
        lastModified = cve.get("lastModified"),
        raw_json = json.dumps(cve, separators=(",", ":"))  # canonical JSON string
    ))

schema = T.StructType([
    T.StructField("cve_id", T.StringType(), True),
    T.StructField("published", T.StringType(), True),     # keep as string now; cast later
    T.StructField("lastModified", T.StringType(), True),
    T.StructField("raw_json", T.StringType(), True),
])

raw_df = spark.createDataFrame(rows, schema) \
    .withColumn("published_ts", F.to_timestamp("published")) \
    .withColumn("lastModified_ts", F.to_timestamp("lastModified")) \
    .drop("published", "lastModified") \
    .withColumnRenamed("published_ts", "published") \
    .withColumnRenamed("lastModified_ts", "lastModified")
    
(raw_df
 .withColumn("ingested_at_utc", F.current_timestamp())
 .write.mode("append").format("delta").saveAsTable(BRONZE_RAW_TABLE))

src = spark.table("Bronze.NVD_CVE_Raw")

# ---- Schemas ----
CvssData = T.StructType([
    T.StructField("baseScore", T.DoubleType()),
    T.StructField("baseSeverity", T.StringType()),
    T.StructField("vectorString", T.StringType()),
])

CvssMetric = T.StructType([
    T.StructField("type", T.StringType()),
    T.StructField("cvssData", CvssData),
])

Reference = T.StructType([
    T.StructField("url", T.StringType()),
    T.StructField("source", T.StringType()),
])

WeakDesc = T.StructType([
    T.StructField("lang", T.StringType()),
    T.StructField("value", T.StringType()),
])

Weakness = T.StructType([
    T.StructField("description", T.ArrayType(WeakDesc))
])

CpeMatch = T.StructType([
    T.StructField("criteria", T.StringType()),   # cpe23Uri
])

Node = T.StructType([
    T.StructField("cpeMatch", T.ArrayType(CpeMatch))
])

Configs = T.StructType([
    T.StructField("nodes", T.ArrayType(Node))
])

CveSchema = T.StructType([
    T.StructField("descriptions", T.ArrayType(WeakDesc)),
    T.StructField("metrics", T.StructType([
        T.StructField("cvssMetricV31", T.ArrayType(CvssMetric)),
        T.StructField("cvssMetricV30", T.ArrayType(CvssMetric)),
    ])),
    T.StructField("references", T.ArrayType(Reference)),
    T.StructField("weaknesses", T.ArrayType(Weakness)),
    T.StructField("configurations", Configs),
])

# ---- Parse raw_json ----
parsed = src.select(
    "cve_id", "published", "lastModified", "ingested_at_utc",
    F.from_json("raw_json", CveSchema).alias("cve")
)

# helper: ensure array<string>
def as_arr(col):
    return F.coalesce(col, F.array().cast("array<string>"))

# choose Primary CVSS if present, else first
cv31 = F.expr("""
  element_at(
    CASE WHEN size(filter(coalesce(cve.metrics.cvssMetricV31, array()), x -> x.type = 'Primary')) > 0
         THEN filter(cve.metrics.cvssMetricV31, x -> x.type = 'Primary')
         ELSE coalesce(cve.metrics.cvssMetricV31, array())
    END,
  1)
""")
cv30 = F.expr("""
  element_at(
    CASE WHEN size(filter(coalesce(cve.metrics.cvssMetricV30, array()), x -> x.type = 'Primary')) > 0
         THEN filter(cve.metrics.cvssMetricV30, x -> x.type = 'Primary')
         ELSE coalesce(cve.metrics.cvssMetricV30, array())
    END,
  1)
""")

flat = (
  parsed
  # english description → fallback to first
  .withColumn(
      "description",
      F.coalesce(
          F.element_at(
              F.transform(
                  F.filter(F.coalesce(F.col("cve.descriptions"), F.array()),
                           lambda d: d["lang"] == F.lit("en")),
                  lambda d: d["value"]
              ), 1),
          F.element_at(
              F.transform(F.coalesce(F.col("cve.descriptions"), F.array()),
                          lambda d: d["value"]), 1)
      ).cast("string")
  )
  # CVSS
  .withColumn("cvss_v31_score",   (cv31["cvssData"]["baseScore"]).cast("double"))
  .withColumn("cvss_v31_severity",(cv31["cvssData"]["baseSeverity"]).cast("string"))
  .withColumn("cvss_v31_vector",  (cv31["cvssData"]["vectorString"]).cast("string"))
  .withColumn("cvss_v30_score",   (cv30["cvssData"]["baseScore"]).cast("double"))
  .withColumn("cvss_v30_severity",(cv30["cvssData"]["baseSeverity"]).cast("string"))
  # references → array<string>
  .withColumn(
      "reference_urls",
      as_arr(F.transform(F.coalesce(F.col("cve.references"), F.array()),
                         lambda r: r["url"].cast("string")))
  )
  # cwe list
  .withColumn(
      "cwe_list",
      as_arr(F.transform(
          F.filter(F.coalesce(F.col("cve.weaknesses"), F.array()),
                   lambda w: F.size(F.coalesce(w["description"], F.array())) > 0),
          lambda w: w["description"][0]["value"].cast("string")
      ))
  )
  # cpe strings
  .withColumn("nodes", F.coalesce(F.col("cve.configurations.nodes"), F.array()))
  .withColumn("cpe_strings",
      as_arr(F.transform(
          F.flatten(F.transform(F.col("nodes"),
                                lambda n: F.coalesce(n["cpeMatch"], F.array()))),
          lambda m: m["criteria"].cast("string")
      ))
  )
  .drop("nodes", "cve")
)

flat.write.mode("append").format("delta").saveAsTable("Bronze.NVD_CVE_Flat")





# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
