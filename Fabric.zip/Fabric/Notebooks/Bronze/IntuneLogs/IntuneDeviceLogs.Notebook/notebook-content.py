# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import json, time, requests
from datetime import datetime, timedelta
from msal import ConfidentialClientApplication
from notebookutils import mssparkutils
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, TimestampType, BooleanType
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Fabric Notebook: Intune + Sign-in Logs → User/Login Summary
#
# Purpose
# -------
# Pull Azure AD sign-in logs and Intune managed devices via Microsoft Graph and
# return the requested columns:
#   User, Date, Location, IPAddress, Device, UserName, Success
#
# Notes
# -----
# - Uses app-only auth (client credential flow) with secrets from Azure Key Vault.
# - Paginates Graph responses and retries on throttling.
# - Joins sign-ins to Intune devices via deviceId ↔ azureADDeviceId (best-effort;
#   falls back to device display name when deviceId is missing).
# - Produces a Spark DataFrame you can display or write to Lakehouse/Delta.
#
# Prereqs in Fabric Notebook
# --------------------------
# 1) Attach your Lakehouse (optional if only displaying results)
# 2) Add the following libraries to the session (Manage libraries):
#    - msal
#    - requests
# 3) Make sure your KV has secrets: GraphClientId, GraphClientSecret

# -------- Imports --------
from datetime import datetime, timedelta, timezone
import time
import json
import requests
from msal import ConfidentialClientApplication
from pyspark.sql import functions as F
from pyspark.sql import types as T

# -------- Config (edit as needed) --------
KV_URL    = "https://KV-DC1Dev-ADF.vault.azure.net/"  # Key Vault URL
TENANT_ID = "385f9270-6e2d-44ab-8297-02cf20fd17ce"
BASE      = "https://graph.microsoft.com/v1.0"

# Toggle a faster, development-friendly run (smaller windows & caps)
DEV_MODE = False

# Lookbacks (prod defaults; dev overrides below)
LOOKBACK_DAYS_SIGNINS = 30  # sign-in log lookback window
LOOKBACK_DAYS_DEVICES = 90  # larger window so more devices can match

# DEV overrides: keep things snappy
if DEV_MODE:
    LOOKBACK_DAYS_SIGNINS = 3     # shrink sign-ins from 30 → 3 days (bump to 7/14 as needed)
    LOOKBACK_DAYS_DEVICES = 14    # shrink devices from 90 → 14 days    # shrink devices from 90 → 14 days

# Caps for how many records to pull (per endpoint)
MAX_ITEMS_SIGNINS = 3000 if DEV_MODE else None
MAX_ITEMS_DEVICES = 1000 if DEV_MODE else 20000

# Hint Graph about page size (per page, not a total cap)
MAX_PAGE_SIZE         = 500

# -------- Auth (app-only) --------
client_id     = mssparkutils.credentials.getSecret(KV_URL, "GraphClientId")
client_secret = mssparkutils.credentials.getSecret(KV_URL, "GraphClientSecret")
AUTHORITY = f"https://login.microsoftonline.com/{TENANT_ID}"
SCOPE     = ["https://graph.microsoft.com/.default"]

msal_app = ConfidentialClientApplication(
    client_id=client_id, authority=AUTHORITY, client_credential=client_secret
)

token = msal_app.acquire_token_for_client(scopes=SCOPE)
assert "access_token" in token, f"MSAL auth failed: {token}"

session = requests.Session()
session.headers.update({
    "Authorization": f"Bearer {token['access_token']}",
    "ConsistencyLevel": "eventual",
    "Prefer": f"odata.maxpagesize={MAX_PAGE_SIZE}",
    "Accept": "application/json"
})

# Keyset-style paginator for signIns to avoid flaky skiptoken: page by createdDateTime
PAGE_SIZE_SIGNINS = 500  # or 200 if you prefer smaller pages

def graph_get_signins_keyset(start_iso: str, select: str, max_items: int | None = None):
    collected = []
    upper_bound = None  # exclusive upper bound (oldest seen)

    while True:
        filt = f"createdDateTime ge {start_iso}"
        if upper_bound:
            filt += f" and createdDateTime lt {upper_bound}"

        params = {
            "$filter": filt,
            "$select": select,
            "$orderby": "createdDateTime desc",
            "$top": PAGE_SIZE_SIGNINS,
        }

        resp = session.get(f"{BASE}/auditLogs/signIns", params=params)
        if resp.status_code in (429, 500, 503):
            time.sleep(2)
            continue
        # Optional one-off retry if Graph returns a transient 400
        if resp.status_code == 400:
            params["$top"] = max(50, int(params["$top"]) // 2)
            resp = session.get(f"{BASE}/auditLogs/signIns", params=params)

        resp.raise_for_status()
        data = resp.json()
        batch = data.get("value", [])

        if not batch:
            break  # <-- inside while loop

        collected.extend(batch)
        if max_items is not None and len(collected) >= max_items:
            return collected[:max_items]

        # Advance keyset window to strictly older than the last row on this page
        oldest = batch[-1].get("createdDateTime")
        if not oldest or oldest == upper_bound:
            break  # <-- inside while loop
        upper_bound = oldest

        # If Graph returned fewer than requested, we’re likely at the end
        if len(batch) < params["$top"]:
            break  # <-- inside while loop

    return collected


# -------- Helpers: Graph paging + retry (with signIns keyset + daily paginator) --------

def graph_get_all(url: str, params: dict | None = None, max_retries: int = 5, max_items: int | None = None):
    """GET all pages from a Graph collection endpoint with basic retry on 429/5xx.
       On 400s, raise with Graph error details to aid debugging.
       If max_items is set, stop early once that many items are collected.
    """
    items = []
    next_url = url
    next_params = params.copy() if params else Noneurl

    while next_url:
        for attempt in range(max_retries):
            resp = session.get(next_url, params=next_params)
            if resp.status_code in (429, 503, 500):
                retry_after = int(resp.headers.get("Retry-After", 0)) or (2 ** attempt)
                time.sleep(min(retry_after, 30))
                continue
            if resp.status_code == 400:
                # Surface Graph error payload for clarity (often due to $select with unsupported props)
                try:
                    err = resp.json()
                    raise RuntimeError(f"400 Bad Request from Graph at {resp.url}: {json.dumps(err)}")
                except Exception:
                    resp.raise_for_status()
            resp.raise_for_status()
            data = resp.json()
            value = data.get("value", [])
            items.extend(value)
            if max_items is not None and len(items) >= max_items:
                return items[:max_items]
            next_url = data.get("@odata.nextLink")
            next_params = None
            break
        else:
            raise RuntimeError(f"Failed after {max_retries} retries for {url}")
    return items

# -------- Pull: Sign-in logs --------

start_signins = (datetime.now(timezone.utc) - timedelta(days=LOOKBACK_DAYS_SIGNINS)).isoformat()
signin_select = (
    "id,createdDateTime,userId,userDisplayName,userPrincipalName,ipAddress,"
    "clientAppUsed,deviceDetail,location,status"
)

signin_params = {
    "$filter": f"createdDateTime ge {start_signins}",
    "$select": signin_select,
    "$orderby": "createdDateTime desc",
}

# Prefer daily-bucket pagination in prod (covers full window reliably); keyset in dev
if DEV_MODE:
    signins = graph_get_signins_keyset(start_signins, signin_select, max_items=MAX_ITEMS_SIGNINS)
else:
    # start_signins is ISO for (now - LOOKBACK_DAYS_SIGNINS). Compute whole days count
    start_dt = datetime.fromisoformat(start_signins.replace("Z", "+00:00"))
    days = LOOKBACK_DAYS_SIGNINS
    from datetime import datetime, timedelta, timezone

def graph_get_signins_by_day(
    start_dt: datetime,
    days: int,
    select: str,
    per_day_cap: int | None = None,
    max_items: int | None = None,
):
    """
    Page sign-ins day-by-day to avoid flaky skip tokens across deep ranges.
    Uses the existing graph_get_all() to page within each day.
    """
    all_rows = []
    for i in range(days):
        day_start = (start_dt + timedelta(days=i)).astimezone(timezone.utc).replace(microsecond=0)
        day_end   = (day_start + timedelta(days=1))
        params = {
            "$filter": f"createdDateTime ge {day_start.isoformat()} and createdDateTime lt {day_end.isoformat()}",
            "$select": select,
            "$orderby": "createdDateTime desc",
        }
        day_rows = graph_get_all(f"{BASE}/auditLogs/signIns", params, max_items=per_day_cap)
        all_rows.extend(day_rows)
        if max_items is not None and len(all_rows) >= max_items:
            return all_rows[:max_items]
    return all_rows

    # Start at midnight UTC N days ago to get whole-day buckets
start_dt = (datetime.now(timezone.utc) - timedelta(days=LOOKBACK_DAYS_SIGNINS)).replace(
    hour=0, minute=0, second=0, microsecond=0
)

signins = graph_get_signins_by_day(
    start_dt=start_dt,
    days=LOOKBACK_DAYS_SIGNINS,
    select=signin_select,
    per_day_cap=None,                 # or set a daily cap if needed
    max_items=MAX_ITEMS_SIGNINS       # None for no total cap
)


# -------- Pull: Intune managed devices --------

start_devices = (datetime.now(timezone.utc) - timedelta(days=LOOKBACK_DAYS_DEVICES)).date().isoformat()
# We can't filter managedDevices by lastSeen w/ OData on v1.0; fetch minimal select then filter locally
# NOTE: 'usersLoggedOn' is not selectable on v1.0 and causes 400 Bad Request.
md_select = (
    "id,deviceName,azureADDeviceId,managedDeviceOwnerType,operatingSystem,"
    "osVersion,complianceState,lastSyncDateTime"
)

managed_devices = graph_get_all(
    f"{BASE}/deviceManagement/managedDevices",
    {"$select": md_select, "$orderby": "lastSyncDateTime desc"},
    max_items=MAX_ITEMS_DEVICES
)

# -------- Normalize → Spark DataFrames --------

# Mobile-only toggle
MOBILE_ONLY = True
MOBILE_OS = {"iOS", "iPadOS", "Android", "AndroidForWork", "Android (corporate-owned)"}

# Flatten sign-ins
signin_rows = []
for s in signins:
    dd = (s.get("deviceDetail") or {})
    loc = (s.get("location") or {})
    st  = (s.get("status") or {})

    # Compose a human-friendly location string (City, State/Region, Country)
    parts = [
        (loc.get("city") or "").strip() or None,
        (loc.get("state") or loc.get("state") or "").strip() or None,
        (loc.get("countryOrRegion") or "").strip() or None,
    ]
    # remove None, keep order
    loc_str = ", ".join([p for p in parts if p]) if any(parts) else None

    signin_rows.append({
        "User": s.get("userPrincipalName"),
        "Date": s.get("createdDateTime"),
        "Location": loc_str,
        "City": (loc.get("city") or None),
        "State": (loc.get("state") or None),
        "Country": (loc.get("countryOrRegion") or None),
        "IPAddress": s.get("ipAddress"),
        "DeviceDisplayName": dd.get("displayName"),
        "DeviceId": dd.get("deviceId"),
        "UserName": s.get("userDisplayName"),
        # Success definition: errorCode == 0 → True
        "Success": (st.get("errorCode") == 0),
        "DeviceOS_signin": dd.get("operatingSystem"),
    })

signin_schema = T.StructType([
    T.StructField("User", T.StringType()),
    T.StructField("Date", T.StringType()),  # will cast to timestamp below
    T.StructField("Location", T.StringType()),
    T.StructField("City", T.StringType()),
    T.StructField("State", T.StringType()),
    T.StructField("Country", T.StringType()),
    T.StructField("IPAddress", T.StringType()),
    T.StructField("DeviceDisplayName", T.StringType()),
    T.StructField("DeviceId", T.StringType()),
    T.StructField("UserName", T.StringType()),
    T.StructField("Success", T.BooleanType()),
    T.StructField("DeviceOS_signin", T.StringType()),
])

signin_df = spark.createDataFrame(signin_rows, schema=signin_schema) if signin_rows else spark.createDataFrame([], schema=signin_schema)

# Flatten managed devices
md_rows = []
for d in managed_devices:
    md_rows.append({
        "azureADDeviceId": d.get("azureADDeviceId"),
        "deviceName": d.get("deviceName"),
        "operatingSystem": d.get("operatingSystem"),
        "osVersion": d.get("osVersion"),
        "lastSyncDateTime": d.get("lastSyncDateTime"),
    })

md_schema = T.StructType([
    T.StructField("azureADDeviceId", T.StringType()),
    T.StructField("deviceName", T.StringType()),
    T.StructField("operatingSystem", T.StringType()),
    T.StructField("osVersion", T.StringType()),
    T.StructField("lastSyncDateTime", T.StringType()),
])

md_df = spark.createDataFrame(md_rows, schema=md_schema) if md_rows else spark.createDataFrame([], schema=md_schema)

# Cast timestamps and prep for join
signin_df = signin_df.withColumn("Date", F.to_timestamp("Date"))
md_df = md_df.withColumn("lastSyncDateTime", F.to_timestamp("lastSyncDateTime"))

# Join on deviceId ↔ azureADDeviceId (GUID). Left join keeps all sign-ins
joined = (signin_df
    .join(md_df, signin_df.DeviceId == md_df.azureADDeviceId, "left")
    .withColumn(
        "Device",
        F.coalesce(F.col("DeviceDisplayName"), F.col("deviceName"))
    )
    .withColumn(
        "DeviceOS",
        F.coalesce(F.col("operatingSystem"), F.col("DeviceOS_signin"))
    )
)

# ---- Diagnostics: counts before mobile filter ----
pre_filter_count = joined.count()

# Optional: mobile-only filter (broaden to catch null-OS mobile names)
if MOBILE_ONLY:
    mobile_name_regex = "iphone|ipad|android|pixel|samsung|galaxy|oneplus|xiaomi|huawei"

    # 1) Identify mobile devices in Intune by OS or name pattern
    md_mobile_df = (md_df
        .filter(
            F.col("operatingSystem").isin(list(MOBILE_OS)) |
            F.lower(F.col("deviceName")).rlike(mobile_name_regex)
        )
        .select("azureADDeviceId")
        .where(F.col("azureADDeviceId").isNotNull())
        .distinct()
    )

    # 2) Keep sign-ins whose DeviceId matches a known mobile Intune device (left-semi join)
    mobile_by_id = joined.join(md_mobile_df, joined.DeviceId == md_mobile_df.azureADDeviceId, "left_semi")

    # 3) PLUS sign-ins that look mobile by OS or Device name (covers rows with null DeviceId)
    mobile_by_traits = joined.filter(
        (F.col("DeviceOS").isin(list(MOBILE_OS))) |
        (F.lower(F.col("Device")).rlike(mobile_name_regex))
    )

    # 4) Union and de-dup
    joined = (mobile_by_id
              .unionByName(mobile_by_traits)
              .dropDuplicates(["User", "Date", "IPAddress", "Device"]))

# Final projection with requested columns
result_df = joined.select(
    F.col("User"),
    F.col("Date"),
    F.col("City"),
    F.col("State"),
    F.col("Country"),
    F.col("IPAddress"),
    F.col("Device"),
    F.col("UserName"),
    F.col("Success")
)



df_out = (result_df
    .withColumn("LoginDate", F.to_date("Date"))           # partition column
    .withColumn("ETLLoadDateTIme", F.current_timestamp())   # audit
)

target_table = "Bronze.IntuneLogins"  # change as desired
(df_out
     .write
     .format("delta")
     .mode("overwrite")  # or "append" if you manage incremental loads
     .saveAsTable(target_table)
)
print(f"Wrote {df_out.count()} rows to {target_table}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
