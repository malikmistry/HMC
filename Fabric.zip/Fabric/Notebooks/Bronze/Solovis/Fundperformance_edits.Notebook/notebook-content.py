# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "0d258a24-e449-43e6-a029-4a56ec727d07"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# ----------- Set the namespace for the Lakehouse
spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_curated")
spark.sql("SET spark.sql.caseSensitive = TRUE")
# -----------
# SQL query
# spark.sql("Create table Silver.FundPerformance(FundPerformanceId Long,FundId String,ClassificationId Integer,FXRateId String,AsOfDate Date,NAVDate Date, \
# MarketValueLocal Double,MarketValueUSD Double,LastValuationAmountLocal Double,LastValuationAmountUSD Double,LastValuationDate Date,LastValuationNAVDate Date,PercentOfGIA Double,MVForwardDelta Double,\
# AdjustedMV Double,PercentAdjustedGIA Double,etlloadDateTime Date)")

# spark.sql("""Insert into lh_curated.Silver.FundPerformance(FundPerformanceId,FundId,ClassificationId,AsOfDate,NAVDate,MarketValueLocal,
#  MarketValueUSD,LastValuationAmountLocal,LastValuationAmountUSD,LastValuationDate,LastValuationNAVDate,
#  PercentOfGIA)
#  select FundPerformanceId,FundId,ClassificationId,AsOfDate,NAVDate,MarketValueLocal,
#  MarketValueUSD,LastValuationAmountLocal,LastValuationAmountUSD,LastValuationDate,LastValuationNAVDate,
#  PercentOfGIA from lh_curated.Silver.TempFundperformance""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType, DoubleType
spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_curated")
spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "LakehouseSilver")
spark.sql("SET spark.sql.caseSensitive = TRUE")

df_currency =  spark.sql(""" select CurrencyId,FXRate as CurrencyRate
                            from lh_curated.Silver.FXRate
                            where FXDate = (select max(FXDate) from lh_curated.Silver.FXRate )  """)
                                             
                                                       
df_currency.createOrReplaceTempView("CurrencyTable")

                                                     


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from datetime import datetime,date
from delta.tables import DeltaTable
import pyspark.sql.functions as F
import pandas as pd

# ----------- Set the namespace for the Lakehouse
#spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_curated")
#spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_Bronze")
spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_curated")
spark.sql("SET spark.sql.caseSensitive = TRUE")
# -----------
# Calculate Moveforward delta

                                 
df =  spark.sql("""WITH other_funds as(SELECT FundName,upper(f.FundId) as FundId,ft.CurrencyId,
                                        CASE WHEN FundName != 'HMC Internal - House' AND ft.FundTradeTypeId IN(3) THEN (SUM((ftf.Amount*1000000) * c.CurrencyRate))
                                             WHEN FundName != 'HMC Internal - House' AND ft.FundTradeTypeId IN(1,4) THEN -(SUM((ftf.Amount*1000000) * c.CurrencyRate))
                                        END AS MVForwardDelta
                                        FROM lh_bronze.Bronze.CrimsonXFundTrade ft
                                        JOIN lh_bronze.Bronze.CrimsonXFund f ON f.FundId = ft.FundId
                                        JOIN lh_bronze.Bronze.CrimsonXFundTradeForecastedTransaction ftf ON ftf.FundTradeId = ft.FundTradeId
                                        AND ftf.ExposureDate > CURRENT_DATE AND ft.IsDeleted = 0 AND ftf.IsDeleted = 0 AND ft.FundTradeTypeId <> 2
                                        JOIN lh_bronze.Bronze.CrimsonXFundTradeType ty ON ft.FundTradeTypeId = ty.FundTradeTypeId
                                        JOIN CurrencyTable c ON c.CurrencyId = ft.CurrencyId
                                        GROUP BY f.FundName,f.FundId,ft.CurrencyId,ft.FundTradeTypeId),
                  tempcalc as(
                                        SELECT SUM(oft.MVForwardDelta) mvother FROM other_funds oft)  ,
                  hmcinternal as(
                                        SELECT FundName ,upper(f.FundId) as FundId,ft.CurrencyId,
                                        CASE WHEN SUM(tc.mvother) > 0 THEN  -(SUM((ftf.Amount*1000000) * c.CurrencyRate)) --there needs to be currency conversion
                                        END AS MVForwardDelta
                                        FROM lh_bronze.Bronze.CrimsonXFundTrade ft
                                        JOIN lh_bronze.Bronze.CrimsonXFund f ON f.FundId = ft.FundId
                                        JOIN lh_bronze.Bronze.CrimsonXFundTradeForecastedTransaction ftf ON ftf.FundTradeId = ft.FundTradeId
                                        AND ftf.ExposureDate > CURRENT_DATE AND ft.IsDeleted = 0 AND ftf.IsDeleted = 0 AND ft.FundTradeTypeId <> 2
                                        JOIN CurrencyTable c ON c.CurrencyId = ft.CurrencyId
                                        ,tempcalc tc 
                                        WHERE f.FundName ='HMC Internal - House'
                                        GROUP BY f.FundName,f.FundId,ft.CurrencyId)

                                        SELECT FundName,(MVForwardDelta) as MVForwardDelta,FundId  FROM other_funds 
                                        UNION  
                                        SELECT FundName,(MVForwardDelta) as MVForwardDelta,FundId  FROM  hmcinternal 
                                        """)

#navDate = pd.Timestamp(date.today()).to_period('M').end_time.strftime('%Y-%m-%d') 
navDate ='2025-05-31'
print(navDate)
#display(df)

# Calculate AdjustedMV 
df2 = spark.table("lh_curated.Silver.FundPerformance") \
    .filter(F.col("NAVDate") == navDate) 
df2 = df2.drop("MVForwardDelta","AdjustedMV","PercentAdjustedGIA","etlloadDateTime")
#display(df2)
df3 = df2.join(df , on = "FundId" ,how="left")
df3 = df3.dropDuplicates()
#display(df3)

df3 = df3.withColumn("AdjustedMV", F.when((F.col("MarketValueUSD")) > 0 ,(F.col("MarketValueUSD")) + F.col("MVForwardDelta")).otherwise(0))
#display(df3)

#Calculate totalmarketvalue for the NavDate
df4 = spark.sql("""select sum((MarketValueUSD)) as totalmarketvalue from lh_curated.Silver.FundPerformance where NAVDate = DATE('2025-05-31')   """ )
df3 = df3.join(df4 ,how="inner")

# calculate PercentAdjustedGIA for the NavDate
df3 = df3.withColumn("PercentAdjustedGIA", F.when(F.col("AdjustedMV") > 0 ,F.col("AdjustedMV") /F.col( "totalmarketvalue") ).otherwise(0))
df3 = df3.withColumn("etlloadDateTime", F.lit(date.today()))
df3 = df3.drop("totalmarketvalue","FundName")
display(df3)

#Append to the FundPerformance table
#spark.sql("delete from lh_curated.Silver.FundPerformance where NAVDate = DATE('2025-05-31') AND AdjustedMV IS NULL")

lakehousePath = "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465"
tableName = "FundPerformance" 

deltaTablePath = f"{lakehousePath}/Tables/Silver/{tableName}" 
df3.write.format("delta").mode("append").option("mergeSchema", "true").save(deltaTablePath)





# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_curated")
# spark.sql("SET spark.sql.caseSensitive = TRUE")
#spark.sql("delete from lh_curated.Silver.FundPerformance where NAVDate = DATE('2025-05-31')  AND AdjustedMV IS NULL AND  MVForwardDelta is NULL and PercentAdjustedGIA is NULL AND etlloadDateTime IS null")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
