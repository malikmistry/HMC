# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# ### Notebook History
# - **2025-11-25**: **Initial Version**: **Developer**: Added data preprocessing step for missing values.
# - **2025-11-20**: **Tkt 123456**: **Vasu**: Tuned Data Ingestion.
# - **2025-11-15**: **Tkt 987654**: **Mike**: Initial model training with baseline parameters.

# CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### Parameters

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# --- Function to Traverse Cash Directory to get all other cash accounts
from pyspark.sql.functions import col
from datetime import datetime,date,timezone

spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_bronze")
spark.sql("SET spark.sql.caseSensitive = TRUE")

def getCashAccounts():
    dfCashTag = spark.sql("""SELECT TagSetId, Category TagSetCategory, Id TagId, ParentId TagIdParent, Description TagDescription
                            FROM lh_bronze.Bronze.SolovisTagsets
                            WHERE Category = 'Asset Class - GIA'
                            AND   Description = 'Net Cash'  """)  # -- id = 11 

    dfAllTags = spark.sql("""SELECT TagSetId, Category TagSetCategory, Id TagId, ParentId TagIdParent, Description TagDescription
                            FROM lh_bronze.Bronze.SolovisTagsets tsi
                            WHERE tsi.Category = 'Asset Class - GIA' 
                            and   tsi.Description != 'HMC Internal - House'
                            and   NOT(tsi.Description LIKE 'HMC Internal%Offset%' OR tsi.Description LIKE 'HMC Internal%Fin. Costs%')
                            and   not tsi.Description = 'HMC Internal - SUS (Fin. Costs)'  """)  # -- id = 11 

    dfAll = dfAllTags.alias("AllTags")
    BaseTagLevel = dfCashTag.alias("base")
    # base = dfCashTag
    dfAllCashTags = BaseTagLevel
    PrevTagLevel = BaseTagLevel

    # Iteratively find indirect reports
    while True:
        prev_alias = PrevTagLevel.alias("prev")

        NextTagLevel = dfAll.join(
            prev_alias,
            col("AllTags.TagIdParent") == col("prev.TagId"),
            "inner"
        ).select(
            col("AllTags.TagSetId"),
            col("AllTags.TagSetCategory"),
            col("AllTags.TagId"),
            col("AllTags.TagIdParent"),
            col("AllTags.TagDescription")
        )
        
        NewTagRows = NextTagLevel.subtract(dfAllCashTags)  # prevent duplicates
        if NewTagRows.count() == 0:
            break
        dfAllCashTags = dfAllCashTags.union(NewTagRows)
        PrevTagLevel = NewTagRows

    return dfAllCashTags


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Gather all the active book mappings

# Internal ActiveBook
dfInternalActiveBook =  spark.sql("""SELECT 
    si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, f.FundId
	, sc.ShareClassId
    , 'Internal ActiveBook' ActiveBookType
FROM   lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.CrimsonXFund f ON upper(si.AssetClassGia) = upper(f.FundName)
		JOIN lh_bronze.Bronze.CrimsonXShareClass sc ON upper(f.FundId) = upper(sc.FundId)
WHERE  (si.AssetClassGia LIKE 'HMC Internal%')
			and   NOT(si.AssetClassGia LIKE 'HMC Internal%Offset%' OR si.AssetClassGia LIKE 'HMC Internal%Fin. Costs%' or si.AssetClassGia like 'HMC Internal - SUS (Notional Adj)' or si.AssetClassGia = 'HMC Internal - SUS (Fin. Costs)')
		AND    sc.IsDefault = 1
UNION ALL
SELECT 
    si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, f.FundId
	, sc.ShareClassId
    , 'Internal ActiveBook' ActiveBookType
FROM   lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.CrimsonXFund f ON f.FundName ='HMC Internal - SUS'
		JOIN lh_bronze.Bronze.CrimsonXShareClass sc ON upper(f.FundId) = upper(sc.FundId)
WHERE  (si.AssetClassGia = 'HMC Internal - SUS (Fin. Costs)' 
			or si.AssetClassGia = 'HMC Internal - SUS (Notional Adj)')
		AND    sc.IsDefault = 1
		""")

# General Expenses
dfGeneralExpenses =  spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, f.FundId
	, sc.ShareClassId
	, 'General Expenses' ActiveBookType
FROM   lh_bronze.Bronze.SolovisInvestments si 
			JOIN lh_bronze.Bronze.SolovisEntities se ON si.HoldingId = se.Id
			JOIN lh_bronze.Bronze.CrimsonXFund f ON se.Label = f.FundName
			JOIN lh_bronze.Bronze.CrimsonXShareClass sc ON f.FundId = sc.FundId
WHERE  se.Label = 'General Expense - Absolute Return'
		AND    sc.IsDefault = 1
		""")

# External ActiveBook
dfExternalActiveBook =  spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, xref.FundIdCrimsonX FundId
	, xref.ShareClassIdCrimsonX ShareClassId
	, 'External ActiveBook' ActiveBookType 
FROM   lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.SolovisEntities se ON si.HoldingId = se.Id
		JOIN lh_bronze.Bronze.SolovisExternalActiveBook xref ON upper(xref.AssetClassGIA) = upper(se.Label)
																	OR upper(xref.AssetClassGIA) = upper(si.AssetClassGia)
		JOIN lh_bronze.Bronze.CrimsonXFund f ON UPPER(f.FundId) = UPPER(xref.FundIdCrimsonX)
""")

# Cash Offsets
dfCashOffset =  spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, '6dd56666-f892-4148-b62a-d7a150ae4053' FundId
	, '79834536-1fd2-47d1-b296-aba5ebf6163a' ShareClassId
	, 'Cash Offsets' ActiveBookType
FROM lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.CrimsonXShareClass sc ON upper(sc.ShareClassId) = '79834536-1FD2-47D1-B296-ABA5EBF6163A'
WHERE  (si.AssetClassGia LIKE 'HMC Internal%Offset%' OR si.AssetClassGia LIKE 'HMC Internal%Fin. Costs%')
		AND NOT si.AssetClassGia = 'HMC Internal - SUS (Fin. Costs)'
		""")

# Cash Accounts
dfCashAccounts = getCashAccounts()
dfCashAccounts.createOrReplaceTempView("CashTags")

dfCashOther = spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, '6dd56666-f892-4148-b62a-d7a150ae4053' FundId
	, '52542eee-1eed-4192-a24d-bb6ded34ef14' ShareClassId
	, 'Cash' ActiveBookType	   
FROM CashTags ct
		JOIN lh_bronze.Bronze.SolovisInvestments si ON ct.TagId = si.AssetClassGiaTagId
		JOIN lh_bronze.Bronze.CrimsonXFund f ON f.FundName ='HMC Internal - SUS'
WHERE
	-- Keep the original roots
	ct.TagDescription = 'Net Cash'
	OR (
		-- Include all except undesired internal entries
		ct.TagDescription != 'HMC Internal - House'
		AND NOT (
			ct.TagDescription LIKE 'HMC Internal%Offset%' 
			OR ct.TagDescription LIKE 'HMC Internal%Fin. Costs%'
		)
		AND ct.TagDescription != 'HMC Internal - SUS (Fin. Costs)'
	)
""")

# Stock Distributions
dfStockDistributions = spark.sql("""
SELECT si.ResourceId as InvestmentResourceId
	   , si.Id as InvestmentId
	   , '392a50f7-6a5a-410c-8e2d-5c77e02117c2' as FundId
	   , '16022be1-2057-4f96-9b1c-f0c3c43b1231' as ShareClassId
	   , 'Stock Distribution' as ActiveBookType
FROM lh_bronze.Bronze.SolovisInvestments si
		  JOIN lh_bronze.Bronze.SolovisEntities se ON si.HoldingId = se.Id
          JOIN lh_bronze.Bronze.SolovisTagsets tag ON tag.Category = 'Special Entity Type' -- AND Description LIKE '%Fund'
												AND CASE WHEN se.SpecialEntityType = 'External Drawdown Fund' THEN 6
												         WHEN se.SpecialEntityType = 'Public Equity' THEN 17
														 WHEN se.SpecialEntityType = 'Outsider' THEN 16
														 WHEN se.SpecialEntityType = 'External Managed Fund' THEN 11
														 ELSE -999 END = tag.Id
where si.AssetClassGia = 'Private Equity Stock Dist.'
""")

# Funds
# dfFunds =  spark.sql("""SELECT 
# 	si.ResourceId InvestmentResourceId
# 	, si.Id InvestmentId
# 	, lower(xf.HMCObjectIdCrimsonX) FundId
# 	, lower(xsc.HMCObjectIdCrimsonX) ShareClassId
# 	, 'Fund' ActiveBookType
# FROM lh_bronze.Bronze.SolovisInvestments si
# 		JOIN lh_bronze.Bronze.SolovisEntities se ON si.HoldingId = se.Id
# 		JOIN lh_bronze.Bronze.HMCDataWarehousevwSourceReferenceFlatten_CrimsonX xsc ON xsc.ReferenceId = si.ResourceId
# 																		AND xsc.HMCObjectType = 'Share Class'
# 		JOIN lh_bronze.Bronze.HMCDataWarehousevwSourceReferenceFlatten_CrimsonX xf ON xf.ReferenceId = si.HoldingId
# 																		AND xf.HMCObjectType = 'Fund'
# """)

dfFunds =  spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, lower(xf.FundId) as FundId
	, lower(xsc.ShareClassId) ShareClassId
	, 'Fund' ActiveBookType
FROM lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.SolovisEntities se ON si.HoldingId = se.Id
		JOIN lh_bronze.Bronze.CrimsonXFund  xf ON lower(xf.FundId) = lower(se.CrimsonFundId)
		LEFT JOIN lh_bronze.Bronze.SolovisActiveBookFundMapping xsc ON xsc.InvestmentResourceId = si.ResourceId
""")

dfActiveBook = dfInternalActiveBook \
	.union(dfGeneralExpenses) \
	.union(dfExternalActiveBook) \
	.union(dfCashOffset) \
	.union(dfCashOther) \
	.union(dfStockDistributions)

# Remove the duplicate active book records to only get funds
dfFunds = dfFunds.join(dfActiveBook, on=['InvestmentResourceId', 'InvestmentId'], how='left_anti')

dfActiveBookFundMapping = dfActiveBook \
    .union(dfFunds)
dfActiveBookFundMapping.createOrReplaceTempView("dfActiveBookFundMapping")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# <mark>**Insert the Mappings that don't exist and that don't need a share class**</mark>

# CELL ********************

spark.sql("""INSERT INTO lh_bronze.Bronze.SolovisActiveBookFundMapping
(InvestmentResourceId, InvestmentId, FundId, ShareClassId, ActiveBookType)
SELECT dabfm.InvestmentResourceId
       , dabfm.InvestmentId
       , dabfm.FundId
       , dabfm.ShareClassId
       , dabfm.ActiveBookType
FROM dfActiveBookFundMapping dabfm
        LEFT JOIN lh_bronze.Bronze.SolovisActiveBookFundMapping abfm ON abfm.InvestmentResourceId = dabfm.InvestmentResourceId
where dabfm.ShareClassId IS NOT NULL
        AND abfm.FundId IS NULL""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Create df that will generate the new shareclassids
dfBlankInvestmentResourceId  =  spark.sql("""SELECT 
	CAST(InvestmentResourceId as int) as InvestmentResourceId
	,CAST(InvestmentId as int) as InvestmentId
	,FundId
	,uuid() AS ShareClassId
	,ActiveBookType 
FROM dfActiveBookFundMapping af
WHERE af.ShareClassId IS NULL
""")
dfActiveBookFundMapping.createOrReplaceTempView("dfBlankInvestmentResourceId")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Persist the Active Book and Fund Mappings in Bronze
dfBlankInvestmentResourceId.write.format("delta") \
    .mode("append") \
    .saveAsTable("lh_bronze.Bronze.SolovisActiveBookFundMapping")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# **<mark>INSERT NEW SHARECLASS IDS RECORD TO SILVER.SHARECLASS</mark>**

# CELL ********************


from datetime import timezone
bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

shareclass_path = f"{curated_lh_id}/Tables/Silver/ShareClass"
df_shareclass = spark.read.format("delta").load(shareclass_path)
df_shareclass.createOrReplaceTempView("df_shareclass")
etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

dfnewShareClassIds  =  spark.sql("""
with cte_newshareclass as (
    SELECT  map.ShareClassId
    ,map.FundId
    ,inv.Label as ShareClassName
    ,NULL AS  EffectiveDate
    ,CAST(0 as BOOLEAN) AS  IsDefault
    ,NULL AS  IlliquidPct
    ,CAST('{etlloadtime}' AS TIMESTAMP) AS ETLLoadDateTime
    FROM dfBlankInvestmentResourceId map
    INNER JOIN lh_bronze.Bronze.SolovisInvestments inv
    ON map.InvestmentResourceId = inv.ResourceId
)

    SELECT b.* FROM df_shareclass a
    LEFT JOIN cte_newshareclass b
        ON a.FundId  = b.FundId 
        AND a.ShareClassName = b.ShareClassName
    WHERE a.FundId IS NULL AND a.ShareClassName IS NULL
""")
dfnewShareClassIds.createOrReplaceTempView("dfnewShareClassIds")

dfnewShareClassIds.show(10)

#if working then insert
dfnewShareClassIds.write.format("delta").mode("append").save(f"{curated_lh_id}/Tables/Silver/ShareClass")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# **<mark>Seeing missed shareclasses and not sure why.  Adding a catch all at the end.</mark>**

# CELL ********************

dfMissedShareClasses = spark.sql("""
SELECT abfm.ShareClassId
	   , abfm.FundId
	   , si.Label as ShareClassName
	   , NULL as EffectiveDate
	   , CAST(0 as BOOLEAN) AS  IsDefault
       , NULL AS  IlliquidPct
	   , CURRENT_TIMESTAMP
from lh_bronze.Bronze.SolovisActiveBookFundMapping abfm
		JOIN lh_bronze.Bronze.SolovisInvestments si ON si.ResourceId = abfm.InvestmentResourceId 
		LEFT JOIN lh_curated.Silver.ShareClass sc ON abfm.ShareClassId = sc.ShareClassId
where sc.ShareClassId IS NULL
""")

display(dfMissedShareClasses.count())

spark.sql("""
INSERT INTO lh_curated.Silver.ShareClass
(ShareClassId, FundId, ShareClassName, EffectiveDate, IsDefault, IlliquidPct, ETLLoadDateTime)
SELECT abfm.ShareClassId
	   , abfm.FundId
	   , si.Label
	   , NULL as EffectiveDate
	   , CAST(0 as BOOLEAN) AS  IsDefault
       , NULL AS  IlliquidPct
	   , CURRENT_TIMESTAMP
from lh_bronze.Bronze.SolovisActiveBookFundMapping abfm
		JOIN lh_bronze.Bronze.SolovisInvestments si ON si.ResourceId = abfm.InvestmentResourceId 
		LEFT JOIN lh_curated.Silver.ShareClass sc ON abfm.ShareClassId = sc.ShareClassId
where sc.ShareClassId IS NULL
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create or clear the ProcessFundChanges table to be used by the calculator
from pyspark.sql.types import StructType, StructField, StringType, TimestampType
from pyspark.sql.functions import lit, current_timestamp

# Define schema explicitly
schema = StructType([
    StructField("FundId", StringType(), False),
    StructField("ETLLoadDateTime", TimestampType(), False)
])

# Create empty DataFrame with schema
dfProcessFundChanges = spark.createDataFrame([], schema)

# Write to table (will create the table even though it's empty)
dfProcessFundChanges.write.format("delta").mode("overwrite").saveAsTable("Bronze.ProcessFundChanges")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# %%sql
# CREATE TABLE Bronze.SolovisActiveBookFundMapping(
# 	InvestmentResourceId int NOT NULL,
# 	InvestmentId int NOT NULL,
# 	FundId varchar(144) NOT NULL,
# 	ShareClassId varchar(144) NOT NULL,
# 	ActiveBookType varchar(200) NOT NULL
# )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# %%sql
# insert into Bronze.SolovisActiveBookFundMapping1
# (InvestmentResourceId, InvestmentId, FundId, ShareClassId, ActiveBookType)
# SELECT count(*)
# FROM Bronze.SolovisActiveBookFundMapping

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
