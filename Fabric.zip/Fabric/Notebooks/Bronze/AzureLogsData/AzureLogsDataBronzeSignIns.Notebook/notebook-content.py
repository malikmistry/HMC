# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# 0) Imports & config
import json, time, requests,base64, re
from datetime import datetime, timedelta, timezone
from pyspark.sql import functions as F
from msal import ConfidentialClientApplication
from delta.tables import DeltaTable
from msal import ConfidentialClientApplication
from collections import defaultdict

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# =========
# IMPORTS
# =========
import json, time, re
from datetime import datetime, timedelta, timezone

import requests
from msal import ConfidentialClientApplication

from pyspark.sql import functions as F

# =========
# IO HELPERS
# =========
def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

def json_to_df(records: list):
    rdd = sc.parallelize([json.dumps(x) for x in records])
    return spark.read.json(rdd)

# Helper to ensure columns exist (NULL if absent)
def ensure_cols(df, cols: dict[str, str]):
    for name, dtype in cols.items():
        if name not in df.columns:
            df = df.withColumn(name, F.lit(None).cast(dtype))
    return df

# =========
# CONFIG (leave parameterized)
# =========
KV_URL = "https://KV-DC1Dev-ADF.vault.azure.net/"  # Key Vault holding Graph secrets
TENANT_ID = "385f9270-6e2d-44ab-8297-02cf20fd17ce"
BASE = "https://graph.microsoft.com/v1.0"

# Window & user filters
LOOKBACK_DAYS = 30
INCLUDE_UPNS = []  # set [] for all users
EXCLUDE_UPNS = []

# Enrichment toggles (not used in this minimal pass, but kept for compatibility)
ENABLE_DIRECTORY_ENRICHMENT = True
ENABLE_INTUNE_ENRICHMENT = False   # set True if you have Intune + permission

# Graph $selects (unused here; we fetch full payload)
SIGNINS_SELECT = (
    "id,createdDateTime,userPrincipalName,userDisplayName,ipAddress,"
    "status,location,deviceDetail"
)
DEVICE_SELECT = "id,deviceId,displayName,operatingSystem,operatingSystemVersion"
INTUNE_SELECT = (
    "id,azureADDeviceId,deviceName,deviceType,manufacturer,model,"
    "operatingSystem,osVersion,complianceState,lastSyncDateTime,userPrincipalName"
)

# =========
# AUTH (MSAL app-only)
# =========
client_id = mssparkutils.credentials.getSecret(KV_URL, "GraphClientId")
client_secret = mssparkutils.credentials.getSecret(KV_URL, "GraphClientSecret")
AUTHORITY = f"https://login.microsoftonline.com/{TENANT_ID}"
SCOPE = ["https://graph.microsoft.com/.default"]

msal_app = ConfidentialClientApplication(
    client_id=client_id,
    authority=AUTHORITY,
    client_credential=client_secret,
)

token = msal_app.acquire_token_for_client(scopes=SCOPE)
assert "access_token" in token, f"MSAL auth failed: {token}"

session = requests.Session()
session.headers.update({
    "Authorization": f"Bearer {token['access_token']}",
    # Helps with large result sets & paging
    "ConsistencyLevel": "eventual",
    "Prefer": "odata.maxpagesize=1000",
})

# =========
# HELPERS
# =========
def iso_utc(dt: datetime) -> str:
    return dt.replace(microsecond=0, tzinfo=timezone.utc).isoformat().replace("+00:00", "Z")

def fetch_all(url: str, params: dict | None = None) -> list:
    items = []
    next_url = url
    next_params = params
    page = 0
    retries = 0

    while next_url:
        try:
            r = session.get(next_url, params=next_params, timeout=60)
        except requests.RequestException as e:
            print(f"Graph request error on page {page}: {e}. Returning collected items.")
            break

        # Throttle handling
        if r.status_code == 429:
            delay = int(r.headers.get("Retry-After", "5") or 5)
            time.sleep(delay)
            continue

        # Transient server errors: retry a few times
        if r.status_code in (502, 503, 504):
            if retries < 3:
                time.sleep(2 ** retries * 2)
                retries += 1
                continue
            print(f"Graph transient {r.status_code} after retries. Returning collected items.")
            break

        # Skiptoken sometimes becomes invalid -> 400. Keep what we have.
        if r.status_code == 400 and "$skiptoken=" in next_url:
            print("Graph returned 400 for a $skiptoken page. Stopping pagination and returning collected items.")
            break

        # Other non-OK statuses:
        if not r.ok:
            if page == 0:
                # First page failing should still raise so the job fails loudly
                r.raise_for_status()
            else:
                # Later page failed: stop paging, keep what we already pulled
                print(f"Graph returned {r.status_code} on page {page}. Stopping pagination and returning collected items.")
                break

        # OK — consume page
        data = r.json()
        items.extend(data.get("value", []))

        # Advance
        next_url = data.get("@odata.nextLink")
        next_params = None
        page += 1
        retries = 0

    return items


# GUID normalizer for deviceId (skips "{PII Removed}" and other junk)
UUID_RE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
def normalize_device_id(x: str | None) -> str | None:
    if not x:
        return None
    s = str(x).strip().strip("{}")
    return s if UUID_RE.match(s) else None

def cleaned_device_ids(raw_list):
    # Pull deviceId, normalize to GUID, drop None, then sort
    raw_ids = ((r.get("deviceDetail") or {}).get("deviceId") for r in raw_list)
    return sorted({d for d in (normalize_device_id(x) for x in raw_ids) if d})

# =========
# CORE: Fetch ALL sign-in fields (no $select) and return as-is
# =========
def build_signins_full_df(since: datetime):
    # Build $filter
    parts = [f"createdDateTime ge {iso_utc(since)}"]
    if INCLUDE_UPNS:
        ors = " or ".join([f"userPrincipalName eq '{u}'" for u in INCLUDE_UPNS])
        parts.append(f"({ors})")
    if EXCLUDE_UPNS:
        ands = " and ".join([f"userPrincipalName ne '{u}'" for u in EXCLUDE_UPNS])
        parts.append(ands)
    odata_filter = " and ".join(parts)

    # IMPORTANT: no $select => get full payload
    params = {"$top": "1000", "$filter": odata_filter}

    raw = fetch_all(f"{BASE}/auditLogs/signIns", params=params)

    if not raw:
        # minimal empty schema so write doesn't fail
        empty_schema = "id string, createdDateTime string"
        return spark.createDataFrame([], schema=empty_schema), raw

    df0 = json_to_df(raw)

    # Respect EXCLUDE_UPNS post-read (in case server didn't filter)
    if EXCLUDE_UPNS:
        df0 = df0.filter(~F.col("userPrincipalName").isin(EXCLUDE_UPNS))

    return df0, raw

# =========
# RUN
# =========
since = datetime.now(timezone.utc) - timedelta(days=LOOKBACK_DAYS)
signins_df, raw_list = build_signins_full_df(since)

# Optional: add an ingest marker
signins_df = signins_df.withColumn("ingestedAt", F.current_timestamp())

# =========
# WRITE
# =========
target_rel = "Bronze/AzureSignIns"  # as requested (keeps this exact name)
target_path = tbl_path(bronze_lh_id, target_rel)  # leave parameterized

(signins_df.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(target_path))

print("Wrote rows:", signins_df.count())
print("Wrote path:", target_path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
