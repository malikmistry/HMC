# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# 0) Imports & config
import json, time, requests,base64, re
from datetime import datetime, timedelta, timezone
from pyspark.sql import functions as F
from msal import ConfidentialClientApplication
from delta.tables import DeltaTable
from msal import ConfidentialClientApplication

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# =========
# IMPORTS
# =========
import json, time, re
from datetime import datetime, timedelta, timezone

import requests
from msal import ConfidentialClientApplication

from pyspark.sql import functions as F

# =========
# IO HELPERS
# =========
def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

def json_to_df(records: list):
    rdd = sc.parallelize([json.dumps(x) for x in records])
    return spark.read.json(rdd)

# =========
# CONFIG (leave parameterized)
# =========
KV_URL = "https://KV-DC1Dev-ADF.vault.azure.net/"  # Key Vault holding Graph secrets
TENANT_ID = "385f9270-6e2d-44ab-8297-02cf20fd17ce"
BASE = "https://graph.microsoft.com/v1.0"

# Window & user filters
LOOKBACK_DAYS = 30
INCLUDE_UPNS = []  # set [] for all users
EXCLUDE_UPNS = []

# Enrichment toggles
ENABLE_DIRECTORY_ENRICHMENT = True
ENABLE_INTUNE_ENRICHMENT = False   # set True if you have Intune + permission

# Graph $selects
SIGNINS_SELECT = (
    "id,createdDateTime,userPrincipalName,userDisplayName,ipAddress,"
    "status,location,deviceDetail"
)
DEVICE_SELECT = "id,deviceId,displayName,operatingSystem,operatingSystemVersion"
INTUNE_SELECT = (
    "id,azureADDeviceId,deviceName,deviceType,manufacturer,model,"
    "operatingSystem,osVersion,complianceState,lastSyncDateTime,userPrincipalName"
)

# =========
# AUTH (MSAL app-only)
# =========
client_id = mssparkutils.credentials.getSecret(KV_URL, "GraphClientId")
client_secret = mssparkutils.credentials.getSecret(KV_URL, "GraphClientSecret")
AUTHORITY = f"https://login.microsoftonline.com/{TENANT_ID}"
SCOPE = ["https://graph.microsoft.com/.default"]

msal_app = ConfidentialClientApplication(
    client_id=client_id,
    authority=AUTHORITY,
    client_credential=client_secret,
)

token = msal_app.acquire_token_for_client(scopes=SCOPE)
assert "access_token" in token, f"MSAL auth failed: {token}"

session = requests.Session()
session.headers.update({
    "Authorization": f"Bearer {token['access_token']}",
    # Helps with large result sets & paging
    "ConsistencyLevel": "eventual",
    "Prefer": "odata.maxpagesize=1000",
})

# =========
# HELPERS
# =========
def iso_utc(dt: datetime) -> str:
    return dt.replace(microsecond=0, tzinfo=timezone.utc).isoformat().replace("+00:00", "Z")

def fetch_all(url: str, params: dict | None = None) -> list:
    items = []
    next_url = url
    next_params = params
    page = 0
    retries = 0

    while next_url:
        try:
            r = session.get(next_url, params=next_params, timeout=60)
        except requests.RequestException as e:
            print(f"Graph request error on page {page}: {e}. Returning collected items.")
            break

        # Throttle handling
        if r.status_code == 429:
            delay = int(r.headers.get("Retry-After", "5") or 5)
            time.sleep(delay)
            continue

        # Transient server errors: retry a few times
        if r.status_code in (502, 503, 504):
            if retries < 3:
                time.sleep(2 ** retries * 2)
                retries += 1
                continue
            print(f"Graph transient {r.status_code} after retries. Returning collected items.")
            break

        # Skiptoken sometimes becomes invalid -> 400. Keep what we have.
        if r.status_code == 400 and "$skiptoken=" in next_url:
            print("Graph returned 400 for a $skiptoken page. Stopping pagination and returning collected items.")
            break

        # Other non-OK statuses:
        if not r.ok:
            if page == 0:
                # First page failing should still raise so the job fails loudly
                r.raise_for_status()
            else:
                # Later page failed: stop paging, keep what we already pulled
                print(f"Graph returned {r.status_code} on page {page}. Stopping pagination and returning collected items.")
                break

        # OK — consume page
        data = r.json()
        items.extend(data.get("value", []))

        # Advance
        next_url = data.get("@odata.nextLink")
        next_params = None
        page += 1
        retries = 0

    return items


# GUID normalizer for deviceId (skips "{PII Removed}" and other junk)
UUID_RE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
def normalize_device_id(x: str | None) -> str | None:
    if not x:
        return None
    s = str(x).strip().strip("{}")
    return s if UUID_RE.match(s) else None

def cleaned_device_ids(raw_list):
    # Pull deviceId, normalize to GUID, drop None, then sort
    raw_ids = ((r.get("deviceDetail") or {}).get("deviceId") for r in raw_list)
    return sorted({d for d in (normalize_device_id(x) for x in raw_ids) if d})

# =========
# CORE: Fetch + Shape
# =========
def build_signins_df(since: datetime):
    # Build $filter
    parts = [f"createdDateTime ge {iso_utc(since)}"]
    if INCLUDE_UPNS:
        ors = " or ".join([f"userPrincipalName eq '{u}'" for u in INCLUDE_UPNS])
        parts.append(f"({ors})")
    if EXCLUDE_UPNS:
        ands = " and ".join([f"userPrincipalName ne '{u}'" for u in EXCLUDE_UPNS])
        parts.append(ands)
    odata_filter = " and ".join(parts)

    params = {"$top": "1000", "$select": SIGNINS_SELECT, "$filter": odata_filter}
    raw = fetch_all(f"{BASE}/auditLogs/signIns", params=params)

    if not raw:
        empty_schema = (
            "id string, timestamp timestamp, success boolean, who string, ipAddress string, "
            "city string, state string, country string, deviceClass string, deviceOS string, "
            "deviceBrowser string, trustType string, aadDeviceId string, deviceDisplayName string, "
            "dirOS string, dirOSVersion string, md_deviceName string, md_deviceType string, "
            "md_manufacturer string, md_model string, md_os string, md_osVersion string, "
            "md_complianceState string, md_lastSyncDateTime string, md_userPrincipalName string"
        )
        return spark.createDataFrame([], schema=empty_schema), raw

    df0 = json_to_df(raw)
    if EXCLUDE_UPNS:
        df0 = df0.filter(~F.col("userPrincipalName").isin(EXCLUDE_UPNS))

    df = (
        df0
        .withColumn("timestamp", F.to_timestamp("createdDateTime"))
        .withColumn("success", (F.col("status.errorCode") == F.lit(0)))  # 0 == success
        .withColumn("who", F.coalesce("userPrincipalName", "userDisplayName"))
        .withColumn("aadDeviceId",   F.col("deviceDetail.deviceId"))
        .withColumn("deviceOS",      F.col("deviceDetail.operatingSystem"))
        .withColumn("deviceBrowser", F.col("deviceDetail.browser"))
        .withColumn("trustType",     F.col("deviceDetail.trustType"))
        .withColumn("city",          F.col("location.city"))
        .withColumn("state",         F.col("location.state"))
        .withColumn("country",       F.col("location.countryOrRegion"))
        .withColumn(
            "deviceClass",
            F.when(F.lower(F.col("deviceOS")).rlike("ios|iphone|ipad|android"), F.lit("mobile"))
             .when(F.lower(F.col("deviceOS")).rlike("windows|mac|linux|chrome"), F.lit("desktop"))
             .otherwise(F.lit(None))
        )
        .select(
            "id","timestamp","success","who","ipAddress",
            "city","state","country",
            "aadDeviceId","deviceClass","deviceOS","deviceBrowser","trustType"
        )
    )

    return df, raw

# =========
# DIRECTORY ENRICHMENT
# =========
def enrich_with_directory_devices(df_base, raw_list):
    if not ENABLE_DIRECTORY_ENRICHMENT:
        return df_base

    ids = cleaned_device_ids(raw_list)  # ✅ filtered before sorting
    if not ids:
        return df_base

    def fetch_device(device_id: str):
        url = f"{BASE}/devices(deviceId='{device_id}')?$select={DEVICE_SELECT}"
        for _ in range(3):
            try:
                resp = session.get(url, timeout=30)
            except requests.RequestException as e:
                print(f"Graph /devices network error for {device_id}: {e}. Skipping.")
                return None

            if resp.status_code == 429:
                time.sleep(int(r.headers.get("Retry-After", "5")) or 5)
                continue

            if resp.status_code in (400, 404):
                return None  # bad ID or not found; skip

            if resp.ok:
                return resp.json()

            try:
                resp.raise_for_status()
            except requests.HTTPError as e:
                print(f"Graph /devices error for {device_id}: {e}. Skipping.")
                return None
        return None

    rows = []
    for d in ids[:5000]:
        info = fetch_device(d)
        if info:
            rows.append(info)

    if not rows:
        return df_base

    df_devices = (
        json_to_df(rows)
        .select(
            F.col("deviceId").alias("aadDeviceId"),
            F.col("displayName").alias("deviceDisplayName"),
            F.col("operatingSystem").alias("dirOS"),
            F.col("operatingSystemVersion").alias("dirOSVersion"),
        )
    )

    out = (
        df_base.alias("s")
        .join(df_devices.alias("d"), on="aadDeviceId", how="left")
        .select(
            "id","timestamp","success","who","ipAddress","city","state","country",
            "deviceClass","deviceOS","deviceBrowser","trustType",
            "aadDeviceId","deviceDisplayName","dirOS","dirOSVersion"
        )
    )
    return out

# =========
# INTUNE ENRICHMENT (optional)
# =========
def enrich_with_intune(df_in, raw_list):
    if not ENABLE_INTUNE_ENRICHMENT:
        return df_in

    ids = cleaned_device_ids(raw_list)  # ✅ filtered before sorting
    if not ids:
        return df_in

    rows = []
    for d in ids[:2000]:
        url = f"{BASE}/deviceManagement/managedDevices"
        params = {"$filter": f"azureADDeviceId eq '{d}'", "$select": INTUNE_SELECT}
        r = session.get(url, params=params, timeout=30)

        if r.status_code == 429:
            time.sleep(int(r.headers.get("Retry-After", "5")) or 5)
            r = session.get(url, params=params, timeout=30)

        if r.status_code == 403:
            print("Intune enrichment skipped: missing DeviceManagementManagedDevices.Read.All (403).")
            return df_in  # global permission issue; bail out entirely

        if r.status_code == 400:
            # bad filter value just for this device — skip it
            try:
                msg = r.json().get("error", {}).get("message", "")
            except Exception:
                msg = r.text
            print(f"Intune 400 for {d}: {msg}. Skipping this device.")
            continue

        if not r.ok:
            print(f"Intune non-OK {r.status_code} for {d}. Skipping this device.")
            continue

        rows.extend(r.json().get("value", []))

    if not rows:
        return df_in

    df_md = (
        json_to_df(rows)
        .select(
            F.col("azureADDeviceId").alias("aadDeviceId"),
            F.col("deviceName").alias("md_deviceName"),
            F.col("deviceType").alias("md_deviceType"),
            F.col("manufacturer").alias("md_manufacturer"),
            F.col("model").alias("md_model"),
            F.col("operatingSystem").alias("md_os"),
            F.col("osVersion").alias("md_osVersion"),
            F.col("complianceState").alias("md_complianceState"),
            F.col("lastSyncDateTime").alias("md_lastSyncDateTime"),
            F.col("userPrincipalName").alias("md_userPrincipalName"),
        )
    )

    out = (
        df_in.alias("s")
        .join(df_md.alias("m"), on="aadDeviceId", how="left")
        .withColumn(
            "deviceClass",
            F.when(F.lower(F.col("md_deviceType")).rlike("iphone|ipad|android"), F.lit("mobile"))
             .when(F.lower(F.col("md_deviceType")).rlike("desktop|windows"), F.lit("desktop"))
             .otherwise(F.col("deviceClass"))
        )
    )
    return out

# =========
# RUN
# =========
since = datetime.now(timezone.utc) - timedelta(days=LOOKBACK_DAYS)
base_df, raw_list = build_signins_df(since)

# Enrichments
out_df = enrich_with_directory_devices(base_df, raw_list)
out_df = enrich_with_intune(out_df, raw_list)

# Add constant source tag
out_df = out_df.withColumn("Source", F.lit("Azure").cast("string"))

# =========
# WRITE
# =========
target_rel = "Bronze/AzureLogsData"
target_path = tbl_path(bronze_lh_id, target_rel)  # leave parameterized

(out_df.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(target_path))

#CREATE TABLE [Bronze].[AzureLogsData](
#	[id] [varchar](8000) NULL,
#	[timestamp] [datetime2](6) NULL,
#	[success] [bit] NULL,
#	[who] [varchar](8000) NULL,
#	[ipAddress] [varchar](8000) NULL,
#	[city] [varchar](8000) NULL,
#	[state] [varchar](8000) NULL,
#	[country] [varchar](8000) NULL,
#	[deviceClass] [varchar](8000) NULL,
#	[deviceOS] [varchar](8000) NULL,
#	[deviceBrowser] [varchar](8000) NULL,
#	[trustType] [varchar](8000) NULL,
#	[aadDeviceId] [varchar](8000) NULL,
#	[deviceDisplayName] [varchar](8000) NULL,
#	[dirOSVersion] [varchar](8000) NULL
#) ON [PRIMARY]


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
