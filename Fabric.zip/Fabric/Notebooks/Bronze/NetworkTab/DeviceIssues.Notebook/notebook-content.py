# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import time, requests
import json, os, nbformat as nbf
from datetime import datetime, timedelta, timezone
from msal import ConfidentialClientApplication
from notebookutils import mssparkutils
from pyspark.sql import Row, functions as F
from pyspark.sql import types as T
from pyspark.sql.types import (
    StructType, StructField, StringType, TimestampType, BooleanType
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# COMMAND ----------
# New Notebook: CyberSecurityDeviceIssues
#
# Purpose:
#   - Pull Intune managed devices + sign-ins from Microsoft Graph
#   - Classify devices into issue buckets:
#       * Unused device
#       * End-of-Life device
#       * End-of-Support device
#       * Non-conforming device
#       * Old devices (>5 years)
#   - Output: 2-column table [Device Issues, Count] written to Silver

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

# Detail table (new)
silver_rel_detail = "Silver/CyberSecurityDeviceIssuesDetail"

# -------- Config (edit as needed) --------
KV_URL    = "https://KV-DC1Dev-ADF.vault.azure.net/"  # Key Vault URL
TENANT_ID = "385f9270-6e2d-44ab-8297-02cf20fd17ce"
BASE      = "https://graph.microsoft.com/v1.0"

DEV_MODE = False

LOOKBACK_DAYS_SIGNINS = 90
LOOKBACK_DAYS_DEVICES = 365

if DEV_MODE:
    LOOKBACK_DAYS_SIGNINS = 14
    LOOKBACK_DAYS_DEVICES = 365

MAX_ITEMS_SIGNINS = 5000 if DEV_MODE else None
MAX_ITEMS_DEVICES = 2000 if DEV_MODE else 20000
MAX_PAGE_SIZE     = 500

# COMMAND ----------
# Auth (app-only) via Key Vault & MSAL

client_id     = mssparkutils.credentials.getSecret(KV_URL, "GraphClientId")
client_secret = mssparkutils.credentials.getSecret(KV_URL, "GraphClientSecret")

AUTHORITY = f"https://login.microsoftonline.com/{TENANT_ID}"
SCOPE     = ["https://graph.microsoft.com/.default"]

msal_app = ConfidentialClientApplication(
    client_id=client_id, authority=AUTHORITY, client_credential=client_secret
)

token = msal_app.acquire_token_for_client(scopes=SCOPE)
assert "access_token" in token, f"MSAL auth failed: {token}"

session = requests.Session()
session.headers.update({
    "Authorization": f"Bearer {token['access_token']}",
    "ConsistencyLevel": "eventual",
    "Prefer": f"odata.maxpagesize={MAX_PAGE_SIZE}",
    "Accept": "application/json"
})

# COMMAND ----------
# Helper: generic paging

def graph_get_all(url: str, params: dict | None = None,
                  max_retries: int = 5, max_items: int | None = None):
    items, next_url = [], url
    next_params = params.copy() if params else None
    while next_url:
        for attempt in range(max_retries):
            resp = session.get(next_url, params=next_params)
            if resp.status_code in (429, 503, 500):
                retry_after = int(resp.headers.get("Retry-After", 0)) or (2 ** attempt)
                time.sleep(min(retry_after, 30))
                continue
            if resp.status_code == 400:
                try:
                    err = resp.json()
                    raise RuntimeError(f"400 Bad Request at {resp.url}: {json.dumps(err)}")
                except Exception:
                    resp.raise_for_status()
            resp.raise_for_status()
            data = resp.json()
            value = data.get("value", [])
            items.extend(value)
            if max_items is not None and len(items) >= max_items:
                return items[:max_items]
            next_url = data.get("@odata.nextLink")
            next_params = None
            break
        else:
            raise RuntimeError(f"Failed after {max_retries} retries for {url}")
    return items

def graph_get_signins_by_day(start_dt, days, select, per_day_cap=None, max_items=None):
    all_rows = []
    for i in range(days):
        day_start = (start_dt + timedelta(days=i)).astimezone(timezone.utc).replace(microsecond=0)
        day_end   = (day_start + timedelta(days=1))
        params = {
            "$filter": f"createdDateTime ge {day_start.isoformat()} and createdDateTime lt {day_end.isoformat()}",
            "$select": select,
            "$orderby": "createdDateTime desc",
        }
        day_rows = graph_get_all(f"{BASE}/auditLogs/signIns", params, max_items=per_day_cap)
        all_rows.extend(day_rows)
        if max_items is not None and len(all_rows) >= max_items:
            return all_rows[:max_items]
    return all_rows

# COMMAND ----------
# Pull sign-ins & Intune managed devices

start_dt = (datetime.now(timezone.utc) - timedelta(days=LOOKBACK_DAYS_SIGNINS)).replace(
    hour=0, minute=0, second=0, microsecond=0
)

signin_select = (
    "id,createdDateTime,userId,userDisplayName,userPrincipalName,ipAddress,"
    "clientAppUsed,deviceDetail,location,status"
)

signins = graph_get_signins_by_day(
    start_dt=start_dt,
    days=LOOKBACK_DAYS_SIGNINS,
    select=signin_select,
    per_day_cap=None,
    max_items=MAX_ITEMS_SIGNINS
)

md_select = (
    "id,deviceName,azureADDeviceId,managedDeviceOwnerType,operatingSystem,"
    "osVersion,complianceState,lastSyncDateTime,model,manufacturer,enrolledDateTime,"
    "userPrincipalName,userDisplayName"
)


managed_devices = graph_get_all(
    f"{BASE}/deviceManagement/managedDevices",
    {"$select": md_select, "$orderby": "lastSyncDateTime desc"},
    max_items=MAX_ITEMS_DEVICES
)

# COMMAND ----------
# Sign-ins -> DF

signin_rows = []
for s in signins:
    dd = (s.get("deviceDetail") or {})
    st = (s.get("status") or {})
    signin_rows.append({
        "User":              s.get("userPrincipalName"),
        "Date":              s.get("createdDateTime"),
        "DeviceDisplayName": dd.get("displayName"),
        "DeviceId":          dd.get("deviceId"),
        "UserName":          s.get("userDisplayName"),
        "Success":           (st.get("errorCode") == 0),
    })

signin_schema = T.StructType([
    T.StructField("User",              T.StringType()),
    T.StructField("Date",              T.StringType()),
    T.StructField("DeviceDisplayName", T.StringType()),
    T.StructField("DeviceId",          T.StringType()),
    T.StructField("UserName",          T.StringType()),
    T.StructField("Success",           T.BooleanType()),
])

signin_df = (
    spark.createDataFrame(signin_rows, schema=signin_schema)
    if signin_rows else spark.createDataFrame([], schema=signin_schema)
).withColumn("Date", F.to_timestamp("Date"))

# COMMAND ----------
# Managed devices -> DF

md_rows = []
for d in managed_devices:
    md_rows.append({
        "azureADDeviceId":   d.get("azureADDeviceId"),
        "deviceName":        d.get("deviceName"),
        "operatingSystem":   d.get("operatingSystem"),
        "osVersion":         d.get("osVersion"),
        "complianceState":   d.get("complianceState"),
        "lastSyncDateTime":  d.get("lastSyncDateTime"),
        "model":             d.get("model"),
        "manufacturer":      d.get("manufacturer"),
        "enrolledDateTime":  d.get("enrolledDateTime"),
        "userPrincipalName": d.get("userPrincipalName"),
        "userDisplayName":   d.get("userDisplayName"),
    })


md_schema = T.StructType([
    T.StructField("azureADDeviceId",   T.StringType()),
    T.StructField("deviceName",        T.StringType()),
    T.StructField("operatingSystem",   T.StringType()),
    T.StructField("osVersion",         T.StringType()),
    T.StructField("complianceState",   T.StringType()),
    T.StructField("lastSyncDateTime",  T.StringType()),
    T.StructField("model",             T.StringType()),
    T.StructField("manufacturer",      T.StringType()),
    T.StructField("enrolledDateTime",  T.StringType()),
    T.StructField("userPrincipalName", T.StringType()),
    T.StructField("userDisplayName",   T.StringType()),
])


md_df = (
    spark.createDataFrame(md_rows, schema=md_schema)
    if md_rows else spark.createDataFrame([], schema=md_schema)
)

md_df = (
    md_df
    .withColumn("lastSyncDateTime", F.to_timestamp("lastSyncDateTime"))
    .withColumn("enrolledDateTime", F.to_timestamp("enrolledDateTime"))
)

# COMMAND ----------
# Join sign-ins + devices, compute last sign-in per device

signins_with_key = signin_df.withColumn(
    "DeviceKey",
    F.coalesce("DeviceId", "DeviceDisplayName")
)

devices_with_key = md_df.withColumn(
    "DeviceKey",
    F.coalesce("azureADDeviceId", "deviceName")
)

last_signin_per_device = (
    signins_with_key
        .groupBy("DeviceKey")
        .agg(F.max("Date").alias("lastSigninDate"))
)

devices_enriched = (
    devices_with_key
        .join(last_signin_per_device, "DeviceKey", "left")
        .select(
            "DeviceKey",
            "deviceName",
            "azureADDeviceId",
            "userPrincipalName",
            "userDisplayName",
            "operatingSystem",
            "osVersion",
            "complianceState",
            "lastSyncDateTime",
            "model",
            "manufacturer",
            "enrolledDateTime",
            "lastSigninDate"
        )
)


devices_enriched.cache()

# COMMAND ----------
# Add age & last-signin metrics

UNUSED_DAYS      = 90   # >= this many days since last sign-in → Unused
OLD_DEVICE_YEARS = 5    # > this many years since enrollment → Old device

now_ts = F.current_timestamp()

devices_enriched = (
    devices_enriched
        .withColumn(
            "days_since_last_signin",
            F.when(F.col("lastSigninDate").isNotNull(),
                   F.datediff(now_ts, F.col("lastSigninDate")))
             .otherwise(None)
        )
        .withColumn(
            "device_age_years",
            F.when(F.col("enrolledDateTime").isNotNull(),
                   F.datediff(now_ts, F.col("enrolledDateTime")) / F.lit(365.0))
             .otherwise(None)
        )
)

# COMMAND ----------
# Define EOL / EOS / Non-conforming rules
# TODO: adjust these to your exact policies.

os_lower  = F.lower(F.col("operatingSystem"))
ver_lower = F.lower(F.col("osVersion"))

# Example Windows/macOS "old" versions (placeholder only!)
is_old_windows10 = os_lower.like("%windows%") & ver_lower.rlike("10\\.0\\.1(6|7)")
is_old_macos     = os_lower.like("%mac%") & ver_lower.rlike("10\\.|11\\.")

# End-of-Life
is_eol = (
    is_old_windows10 |
    is_old_macos
    # extend / replace with your reference table if needed
)

# End-of-Support – using same rule for now
is_eos = is_eol  # TODO: refine if you distinguish these

# Non-conforming
is_nonconforming = (
    (F.lower(F.col("complianceState")) != F.lit("compliant")) |
    (os_lower.isNull()) |
    (~os_lower.rlike("windows|macos|ios|ipados|android"))
)

# COMMAND ----------
# Issue flags per device

is_unused = (
    F.col("lastSigninDate").isNull() |
    (F.col("days_since_last_signin") >= F.lit(UNUSED_DAYS))
)

is_old_device = (
    F.col("device_age_years").isNotNull() &
    (F.col("device_age_years") > F.lit(OLD_DEVICE_YEARS))
)

devices_flagged = (
    devices_enriched
        .withColumn("Unused_device_flag",          is_unused.cast("boolean"))
        .withColumn("End_of_Life_device_flag",     is_eol.cast("boolean"))
        .withColumn("End_of_Support_device_flag",  is_eos.cast("boolean"))
        .withColumn("Non_conforming_device_flag",  is_nonconforming.cast("boolean"))
        .withColumn("Old_device_gt5yrs_flag",      is_old_device.cast("boolean"))
)

# Optional: a human-readable "issues" column listing all applied flags

issues_expr = F.array_remove(
    F.array(
        F.when(F.col("Unused_device_flag"),          F.lit("Unused device")),
        F.when(F.col("End_of_Life_device_flag"),     F.lit("End-of-Life device")),
        F.when(F.col("End_of_Support_device_flag"),  F.lit("End-of-Support device")),
        F.when(F.col("Non_conforming_device_flag"),  F.lit("Non-conforming device")),
        F.when(F.col("Old_device_gt5yrs_flag"),      F.lit("Old devices (>5 years)")),
    ),
    None 
)

devices_detail_df = (
    devices_flagged
        .withColumn("issues", F.array_join(issues_expr, "; "))
)


devices_detail_df = (
    devices_flagged
        .withColumn("issues", F.array_join(issues_expr, "; "))
)

# COMMAND ----------
# Write detail table to Silver

target_path_detail = tbl_path(curated_lh_id, silver_rel_detail)

detail_out = (
    devices_detail_df
        .withColumn("etl_load_datetime", F.current_timestamp())
        .select(
            "DeviceKey",
            "deviceName",
            "azureADDeviceId",
            "userPrincipalName",
            "userDisplayName",
            "operatingSystem",
            "osVersion",
            "complianceState",
            "lastSyncDateTime",
            "model",
            "manufacturer",
            "enrolledDateTime",
            "lastSigninDate",
            "days_since_last_signin",
            "device_age_years",
            "Unused_device_flag",
            "End_of_Life_device_flag",
            "End_of_Support_device_flag",
            "Non_conforming_device_flag",
            "Old_device_gt5yrs_flag",
            "issues",
            "etl_load_datetime"
        )
)



(
    detail_out.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .save(target_path_detail)
)

# COMMAND ----------
# OPTIONAL: derive the 5-row summary (like your screenshot) from the detail table

summary_df = (
    detail_out
        .select("DeviceKey", "Unused_device_flag", "End_of_Life_device_flag",
                "End_of_Support_device_flag", "Non_conforming_device_flag",
                "Old_device_gt5yrs_flag")
        .withColumn("Unused device",          F.col("Unused_device_flag").cast("int"))
        .withColumn("End-of-Life device",     F.col("End_of_Life_device_flag").cast("int"))
        .withColumn("End-of-Support device",  F.col("End_of_Support_device_flag").cast("int"))
        .withColumn("Non-conforming device",  F.col("Non_conforming_device_flag").cast("int"))
        .withColumn("Old devices (>5 years)", F.col("Old_device_gt5yrs_flag").cast("int"))
)

# Melt-like aggregation: count distinct DeviceKey per issue column
issue_cols = [
    "Unused device",
    "End-of-Life device",
    "End-of-Support device",
    "Non-conforming device",
    "Old devices (>5 years)",
]

summary_rows = []
for issue in issue_cols:
    # count devices where this issue = 1
    cnt = (
        summary_df
            .filter(F.col(issue) == 1)
            .select("DeviceKey")
            .distinct()
            .count()
    )
    summary_rows.append(Row(**{"Device Issues": issue, "Count": cnt}))

device_issues_summary_df = spark.createDataFrame(summary_rows)

# COMMAND ----------
# Write to Silver Delta table

#target_path = tbl_path(curated_lh_id, silver_rel)

#device_issues_out = (
#    device_issues_df
#        .withColumn("etl_load_datetime", F.current_timestamp())
#        .select("Device Issues", "Count", "etl_load_datetime")
#)

#(
#    device_issues_out.write
#        .format("delta")
#        .mode("overwrite")
#        .option("overwriteSchema", "true")
#        .save(target_path)
#)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
