# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import json
from delta.tables import DeltaTable
from pyspark.sql.functions import lit, col, explode, to_timestamp, last_day, regexp_extract
from pyspark.sql.utils import AnalysisException
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.types import StructType, StructField, StringType, DoubleType
from urllib.parse import urlparse, parse_qs
from calendar import monthrange
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "{\"JobAuditKey\":1088,\"TaskKey\":203,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":null,\"SourceTableName\":null,\"SinkTableName\":null,\"SinkSchemaName\":\"Bronze\",\"NotebookKeyNotebookKey\":\"19\",\"NotebookName\":\"APIBottomUpBronze\",\"SinkLakehouseName\":\"lh_bronze\",\"RawStoragePath\":\"HMCReport\",\"RawStorageFileName\":\"FundLevelCalc.json\",\"RelativeUrl\":\"hmc-report/api/v1/BottomUp/FundLevelCalc?caseId=3&useBetaSummaryGia=false&asOfDate=7/15/2025&numYears=10&calculationMethodology=1&fundCycleMethodology=0&fundCycleModelId=1\"}"
NotebookName = "APIBottomUpBronze"
LakehouseName = "lh_bronze"
RawLHId = "920a12cc-7104-4013-a2a3-d7baa57e9e3f"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
RawLHId = ""
TaskList = ""
NotebookName = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

tasklist = json.loads(f"{TaskList}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Defensive filtering (only select existing columns)
def select_existing(df, column_list):
    existing = [col for col in column_list if col in df.columns]
    return df.select(existing) if existing else spark.createDataFrame([], StructType([]))

def delta_table_exists(path: str) -> bool:
    return DeltaTable.isDeltaTable(spark, path)

def delete_if_exists(path: str, condition: str):
    if delta_table_exists(path):
        spark.sql(f"DELETE FROM delta.`{path}` WHERE {condition}")

def write_delta(df, path: str, mode: str = "append"):
    df.write.format("delta").mode(mode).save(path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def process_task(task):
    try:

        #  Read raw JSON input
        source_path = f"{raw_lh_basepath}/Files/{task['RawStoragePath']}/{task['RawStorageFileName']}"
        df_json = spark.read.json(source_path)
        url = task['RelativeUrl']

        # Extract metadata (BottomUpRunDetails)
        bottomup_run_details_cols = [
            "caseId", "useBetaSummaryGia", "asOfDate", "numYears",
            "calculationMethodology", "FundCycleMethodology", "fundCycleModelId", "apiSource"
        ]

        # Parse query string params from URL
        parsed_query = parse_qs(urlparse(url).query)
        normalized_query = {k.lower(): v[0] for k, v in parsed_query.items()}
        def get_param(key): return normalized_query.get(key.lower(), None)

        bottomup_run_details = {col: get_param(col) for col in bottomup_run_details_cols}

        schema = StructType([StructField(col, StringType(), True) for col in bottomup_run_details_cols])
        row_data = [[bottomup_run_details.get(col, None) for col in bottomup_run_details_cols]]
        df_bottomup_rundetails = spark.createDataFrame(row_data, schema=schema)

        # Convert dates to timestamp
        for date_col in ["asOfDate", "ReportDate"]:
            if date_col in df_bottomup_rundetails.columns:
                df_bottomup_rundetails = df_bottomup_rundetails.withColumn(
                    date_col, to_timestamp(col(date_col), "M/d/yyyy")
                )

        # Extract apiSource from URL path
        df_bottomup_rundetails = df_bottomup_rundetails.withColumn(
            "apiSource",
            regexp_extract(lit(url), r"/([^/?]+)\?", 1)
        )

        # Write BottomUpRunDetails to Bronze
        bottomuprundet_path = f"{bronze_lh_basepath}/Tables/Bronze/BottomUpRunDetails"
        df_bottomup_rundetails.write.mode("overwrite").format("delta").save(bottomuprundet_path)

        # Capture AsOfDate
        as_of_date = df_bottomup_rundetails.select("asOfDate").first()["asOfDate"] \
            if "asOfDate" in df_bottomup_rundetails.columns else None

        #  JSON with AsOfDate + fix stockDistributions
        df_json = df_json.withColumn("AsOfDate", lit(as_of_date))
        df_json = df_json.withColumn("stockDistributions", col("stockDistributions").cast("string").cast(DoubleType()))


        # Decide ReportFrequency based on API source
        api_source_to_frequency = {"FundLevelCalc": "Year", "FundLevelCalcMonthly": "Month"}
        api_source = df_bottomup_rundetails.select("apiSource").first()["apiSource"] \
            if "apiSource" in df_bottomup_rundetails.columns else None
        frequency_label = api_source_to_frequency.get(api_source)

        reportfreq = spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/ReportFrequency")
        df_json = df_json.withColumn("ReportFrequency", lit(frequency_label))
        df_json = df_json.join(reportfreq, df_json["ReportFrequency"] == reportfreq["Description"], how="left")


        # Define BottomUp core table schema

        bottomup_cols = [
            "AsOfDate", "monthcomponents", "rowId", "fundId", "budgetStrategyId", "entityBudgetStrategyId",
            "budgetCategoryId", "budgetCategoryName", "calcType", "calcTypeId", "previousFundUnfundedThreshold",
            "inceptionDate", "defaultInvestPeriod", "defaultFundLife", "startingAge", "inceptionFiscalyear",
            "terminationFiscalYear", "commitment", "originalCommitment", "marketValue", "unfunded",
            "entityInvestmentStatus", "firmId", "firmName", "entityId", "entityName", "callModelName",
            "distributionModelName", "returnModelName", "targetPct", "callAmt", "distAmt",
            "year", "isCoinvest", "cfyClosedCommit", "fundCycleYears", "secondarySales", "stockDistributions",
            "budgetPace", "fundRaiseUnfundedPercent", "nextFundRaiseDate", "ReportFrequencyId"
        ]
        df_bottomup = df_json.select(*[c for c in bottomup_cols if c in df_json.columns])


        # Explode YearComponents (only if FundLevelCalc)

        if task["RawStorageFileName"] == "FundLevelCalc.json":
            df_year_exploded = df_json.select(
                col("rowId"),
                explode("yearComponents").alias("yearComp"),
                col("unfunded"), col("secondarySales"), col("stockDistributions"),
                col("budgetPace"), col("targetPct"), col("ReportFrequencyId")
            )
            df_bottomup_year = df_year_exploded.select(
                col("rowId"),
                col("yearComp.age").alias("age"),
                col("yearComp.year").alias("year"),
                col("yearComp.budgetCommit").alias("budgetCommit"),
                col("yearComp.allocatedCommit").alias("allocatedCommit"),
                col("yearComp.existingCommit").alias("existingCommit"),
                col("yearComp.commit").alias("commit"),
                col("yearComp.originalCommit").alias("originalCommit"),
                col("yearComp.callPct").alias("callPct"),
                col("yearComp.callAmt").alias("callAmt"),
                col("yearComp.distPct").alias("distPct"),
                col("yearComp.distAmt").alias("distAmt"),
                col("yearComp.fmvPct").alias("fmvPct"),
                col("yearComp.fmvAmt").alias("fmvAmt"),
                col("yearComp.mktVal").alias("mktVal"),
                col("unfunded"), col("secondarySales"), col("stockDistributions"),
                col("budgetPace"), col("targetPct"),
                col("yearComp.unfundedPercent").alias("unfundedPercent"),
                col("ReportFrequencyId")
            )

        # Explode MonthComponents (only if FundLevelCalcMonthly)
       
        if task["RawStorageFileName"] == "FundLevelCalcMonthly.json":
            df_month_exploded = df_json.select(
                col("rowId"),
                explode("monthComponents").alias("monthComp"),
                col("ReportFrequencyId")
            )
            df_bottomup_month = df_month_exploded.select(
                col("rowId"),
                col("monthComp.date").alias("date"),
                col("monthComp.age").alias("age"),
                col("monthComp.annualCallPct").alias("CallPct"),
                col("monthComp.monthlyCallAmt").alias("CallAmt"),
                col("monthComp.annualDistPct").alias("DistPct"),
                col("monthComp.monthlyDistAmt").alias("DistAmt"),
                col("monthComp.monthlyFmvAmt").alias("FmvAmt"),
                col("monthComp.monthlyFmvPct").alias("FmvPct"),
                col("monthComp.endMktVal").alias("MktVal"),
                col("monthComp.endUnfunded").alias("Unfunded"),
                col("monthComp.endUnfundedPct").alias("UnfundedPct"),
                col("monthComp.fiscalYear").alias("fiscalYear"),
                col("ReportFrequencyId")
            )


        # Merge into BottomUp table
        target_path = f"{bronze_lh_basepath}/Tables/Bronze/BottomUp"
        report_frequency_current = df_bottomup.select("ReportFrequencyId").first()["ReportFrequencyId"] \
            if "ReportFrequencyId" in df_bottomup.columns else None
        is_end_of_month = as_of_date and as_of_date.day == monthrange(as_of_date.year, as_of_date.month)[1]

        df_bottomup.createOrReplaceTempView("source")
        join_condition = " AND ".join([f"t.{c} <=> s.{c}" for c in df_bottomup.columns])

        if is_end_of_month:
            spark.sql(f"""
                MERGE INTO delta.`{target_path}` AS t
                USING source AS s
                ON {join_condition}
                WHEN NOT MATCHED THEN
                INSERT *
            """)
        else:
            if DeltaTable.isDeltaTable(spark, target_path):
                spark.sql(f"""
                    DELETE FROM delta.`{target_path}`
                    WHERE AsOfDate != last_day(AsOfDate)
                    AND ReportFrequencyId = {report_frequency_current}
                """)
            spark.sql(f"""
                MERGE INTO delta.`{target_path}` AS t
                USING source AS s
                ON {join_condition}
                WHEN NOT MATCHED THEN
                INSERT *
            """)

        # Write Year or Month Components
        if task["RawStorageFileName"] == "FundLevelCalc.json":
            path = f"{bronze_lh_basepath}/Tables/Bronze/BottomUpYearComponent"
            delete_if_exists(path, f"ReportFrequencyId = {report_frequency_current}")
            write_mode = "append"
            write_delta(df_bottomup_year, path, write_mode)

        if task["RawStorageFileName"] == "FundLevelCalcMonthly.json":
            path = f"{bronze_lh_basepath}/Tables/Bronze/BottomUpMonthComponent"
            delete_if_exists(path, f"ReportFrequencyId = {report_frequency_current}")
            write_mode = "append"
            write_delta(df_bottomup_month, path, write_mode)

        print("complete")

    except Exception as e:
        raise RuntimeError(f"Task {task['TaskKey']} failed: {str(e)}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([BronzeLHId, RawLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        raw_lh_basepath = get_basepath(WorkspaceId, RawLHId)
        # Process the task
        result = process_task(task_item)

    except Exception as e:
        print(f"Error processing task: {e}")
        # mssparkutils.notebook.exit(f"FAILED: {e}")
        raise Exception


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
