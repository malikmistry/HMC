# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from datetime import datetime, timezone
from pyspark.sql import Row
from pyspark.sql import types as T
from pyspark.sql import functions as F
import requests
import json

ENVIRONMENTS = ["dev1", "prod1"]
BASE_FMT     = "https://smartsearch2-{}.azurewebsites.net/eval/"
RUNTIME_PATHS = ["runtime","retrieval_only_runtime","person_names","retrieval","quality"]
REQ_TIMEOUT  = 300
EVALS_TBL    = "lh_bronze.Bronze.AivyEvals"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.conf.set("spark.sql.caseSensitive", "true")

schema = T.StructType([
    T.StructField("metric_name",   T.StringType(),     True),
    T.StructField("metric_type",   T.StringType(),     True),
    T.StructField("metric_value",  T.DoubleType(),     True),
    T.StructField("metadata",      T.StringType(),     True),
    T.StructField("evalTimestamp", T.TimestampType(),  True),
    T.StructField("source_env",    T.StringType(),     True),
    T.StructField("success",       T.BooleanType(),    True),
])

if not spark.catalog.tableExists(EVALS_TBL):
    print(f"[DDL] Creating table {EVALS_TBL}")
    (spark.createDataFrame([], schema=schema)
    .write.format("delta")
    .option("overwriteSchema", "true")
    .partitionBy("evalTimestamp")
    .mode("overwrite")
    .saveAsTable(EVALS_TBL)
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Generic runtime and Thrive Evals

# CELL ********************

def run_once_and_append():
    eval_ts = datetime.now(timezone.utc)
    rows = []

    for env in ENVIRONMENTS:
        for path in RUNTIME_PATHS:
            
            url = BASE_FMT.format(env) + path
            success = False
            metric_type = None
            metric_value = None
            metadata_str = None

            max_retries = 3
            for attempt in range(max_retries):
                try:
                    resp = requests.get(url, timeout=REQ_TIMEOUT)

                    if resp.status_code >= 400:
                        metadata_str = json.dumps({"http_status": resp.status_code, "body": resp.text})
                        break
                    
                    payload = resp.json()
                    success = True
                    metric_type  = payload.get("metric_type")
                    metric_value = payload.get("value")
                    metadata_str = json.dumps(payload.get("metadata", payload))
                    break

                except requests.exceptions.RequestException as e:
                    print(f"Attempt {attempt + 1} failed for {url}: {e}")
                    if attempt == max_retries - 1:
                        metadata_str = json.dumps({"error": f"{type(e).__name__}: {str(e)}"})
                    else:
                        time.sleep(2 ** attempt)
                
                except json.JSONDecodeError:
                    metadata_str = json.dumps({"error": "Invalid JSON", "body": resp.text})
                    break

            rows.append(Row(
                metric_name=path,
                metric_type=metric_type,
                metric_value=float(metric_value) if isinstance(metric_value, (int, float)) else None,
                metadata=metadata_str,
                evalTimestamp=eval_ts,
                source_env=env,
                success=success,
            ))

    df = spark.createDataFrame(rows, schema=schema)
    df.write.format("delta").mode("append").saveAsTable(EVALS_TBL)

run_once_and_append()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
