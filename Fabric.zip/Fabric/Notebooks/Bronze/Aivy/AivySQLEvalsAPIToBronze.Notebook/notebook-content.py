# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from datetime import datetime, timezone
from pyspark.sql import Row
from pyspark.sql import types as T
from pyspark.sql import functions as F
import requests
import json

ENVIRONMENTS = ["dev1"] #, "prod1" is removed until prod deployment. Last update > 11/06/2025
SQL_EVAL_URL_FMT = "https://smartsearch2-{}.azurewebsites.net/eval/sql"
EVALS_TBL    = "lh_bronze.Bronze.AivyEvals"
REQ_TIMEOUT = 300
USER_MESSAGES = [
    "Tell me how much we invested with Thrive Capital (Firm) - for each of their funds show vintage year, committed, funded, returned, NAV, unfunded, TVPI, DPI",
    "Review performance data for the past month and flag any anomalies or large, uncharacteristic movements that may suggest data input errors",
    "Generate a summary of performance by asset class, manager, and benchmark, and highlight top contributors and detractors for 6/30/2025",
    "Summarize cash flows and their net impact on liquidity over the past 15 days",
    "Summarize outstanding and upcoming capital calls and distributions across all private funds, flagging those due within effective date ten business days",
    "Generate a list of existing or existing exit funds in Crimson that do not have a final valuation for 6/30/2025",
    "What are our top 20 funds with highest one-year custom risk benchmark return?",
    "Show one-year gross strategy alpha for all Hedge Fund Multi-Strats. Use most recent value from 2025",
    "What is the combined 3 yr trailing net return for all the funds under Altimeter entries",
    "Give me our largest redemptions in 2025",
    "Give me calls and distributions per year, 2021-2025 for all venture funds with 2020 vintage. Show only years totals, do not show individual funds",
    "Provide a list of entities that have had cash flows > $10M USD in the last 5 years, exclude HMC internal entities",
    "What are our subscriptions for Holocene?",
    "When did we make our first investment with Holocene?",
    "What are the next 5 redemption notification dates coming up for Marcus Loveland's funds? How much is available for each?",
    "How many active VC entities do we have in portfolio?",
    "How many active VC funds to we have in portfolio?",
    "What's the current NAV of all Altimeter funds",
    "Show the NAV of our portfolio by asset class and strategy",
    "What are the top funds by NAV where Rick is the primary owner",
    "What is project Net IR for Advent GPE VIII fund?",
    "What are the combined multiples for all hedge fund multi-strat funds?",
    "What is the TVPI for all funds owned by Thrive Capital (Firm)?",
    "How much was paid in and out from Altimeter Growth IV (Fund)?",
    "What are our commitment made in 2024? Group by strategy",
    "What are our commitments in 2025 to universe called something like \"crypto ld\"?",
    "Compare management fee (tier 1) and carry for our 20 largest venture funds. Include NAV. Don't show rows with null values",
    "Give me fees and carry for all funds owned by QRT (Firm)",
    "What is the total redemptions from Hedge Fund Credit (Universe) in 2025?",
    "Show me the NAV and total number of funds in universes that have \"biotech\" in their names",
    "Show me the number of rows in all tables you know about",
    "Compare Altimeter Growth Capital III (Fund) returns to performance index returns"
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.conf.set("spark.sql.caseSensitive", "true")

schema = T.StructType([
    T.StructField("metric_name",   T.StringType(),     True),
    T.StructField("metric_type",   T.StringType(),     True),
    T.StructField("metric_value",  T.DoubleType(),     True),
    T.StructField("metadata",      T.StringType(),     True),
    T.StructField("evalTimestamp", T.TimestampType(),  True),
    T.StructField("source_env",    T.StringType(),     True),
    T.StructField("success",       T.BooleanType(),    True),
])

if not spark.catalog.tableExists(EVALS_TBL):
    print(f"[DDL] Creating table {EVALS_TBL}")
    (spark.createDataFrame([], schema=schema)
    .write.format("delta")
    .option("overwriteSchema", "true")
    .partitionBy("evalTimestamp")
    .mode("overwrite")
    .saveAsTable(EVALS_TBL)
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def run_sql_evals_and_append():
    eval_ts = datetime.now(timezone.utc)
    rows = []

    for env in ENVIRONMENTS:
        url = SQL_EVAL_URL_FMT.format(env)

        for message in USER_MESSAGES:
            success = False
            metric_value = None
            metadata_str = None
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    resp = requests.post(
                        url,
                        params={"user_question": message},
                        timeout=REQ_TIMEOUT,
                    )

                    if resp.status_code >= 400:
                        metadata_str = json.dumps(
                            {
                                "http_status": resp.status_code,
                                "body": resp.text,
                                "query": message,
                            }
                        )
                        break

                    try:
                        payload = resp.json()
                    except json.JSONDecodeError:
                        if attempt < max_retries - 1:
                            time.sleep(2 ** attempt)
                            continue
                        payload = {"success": False, "value": None, "metadata": {}}

                    metric_type = payload.get("metric_type")
                    metric_value = payload.get("value")
                    success = True if metric_value == 100 else False
                    metadata = payload.get("metadata", {}) or {}
                    metadata["query"] = message
                    metadata_str = json.dumps(metadata)
                    break

                except requests.exceptions.RequestException as e:
                    print(f"  Attempt {attempt + 1} failed: {e}")
                    if attempt == max_retries - 1:
                        metadata_str = json.dumps(
                            {"error": f"{type(e).__name__}: {str(e)}", "query": message}
                        )
                    else:
                        time.sleep(2 ** attempt)

            rows.append(
                {
                    "metric_name": "sql_eval",
                    "metric_type": metric_type,
                    "metric_value": metric_value,
                    "metadata": metadata_str,
                    "evalTimestamp": eval_ts,
                    "source_env": env,
                    "success": success,
                }
            )


        df = spark.createDataFrame(rows, schema=schema)
        print(f"added {df.count()} rows")
        df.write.format("delta").mode("append").saveAsTable(EVALS_TBL)

run_sql_evals_and_append()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
