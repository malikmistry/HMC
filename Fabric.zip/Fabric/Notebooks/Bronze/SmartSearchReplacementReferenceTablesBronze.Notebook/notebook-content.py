# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


from pyspark.sql.types import StructType, StructField, IntegerType, StringType
lh_bronze_basepath = get_basepath(WorkspaceId,BronzeLHId)
target_path = f'{lh_bronze_basepath}/Tables/Bronze/AlphaType'
# Define schema
schema = StructType([
    StructField("Id", IntegerType(), False),
    StructField("Description", StringType(), False)
])

# Create data
data = [
    (1, "GrossAlpha"),
    (2, "GrossManagerAlpha"),
    (3, "GrossStrategyAlpha"),
    (4, "NetAlpha")
]

# Create DataFrame
df = spark.createDataFrame(data, schema)

# Show the result
df.show()

# Write as Delta table to ABFSS
df.write.format("delta").mode("overwrite").save(target_path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


from pyspark.sql.types import StructType, StructField, IntegerType, StringType
lh_silver_basepath = get_basepath(WorkspaceId,CuratedLHId)
target_path = f'{lh_silver_basepath}/Tables/Silver/FundBenchmarkTrackRecordType'
# Define schema
schema = StructType([
    StructField("Id", IntegerType(), False),
    StructField("Description", StringType(), False)
])

# Create data
data = [
    (1, "Alpha")
,(2, "Gross Annual Return")
,(3, "Standard Deviation")
,(4, "Sharpe Ratio")
,(5, "Max Drawdown")
,(6, "Beta")
,(7, "Correlation")
,(8, "IR")
,(9, "Tracking Error")

]

# Create DataFrame
df = spark.createDataFrame(data, schema)

# Show the result
df.show()

# Write as Delta table to ABFSS
df.write.format("delta").mode("overwrite").save(target_path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


from pyspark.sql.types import StructType, StructField, IntegerType, StringType
lh_bronze_basepath = get_basepath(WorkspaceId,BronzeLHId)
target_path = f'{lh_bronze_basepath}/Tables/Bronze/FundBenchmarkTrackRecordType'
# Define schema
schema = StructType([
    StructField("Id", IntegerType(), False),
    StructField("Description", StringType(), False)
])

# Create data
data = [
    (1, "Alpha")
,(2, "Gross Annual Return")
,(3, "Standard Deviation")
,(4, "Sharpe Ratio")
,(5, "Max Drawdown")
,(6, "Beta")
,(7, "Correlation")
,(8, "IR")
,(9, "Tracking Error")

]

# Create DataFrame
df = spark.createDataFrame(data, schema)

# Show the result
df.show()

# Write as Delta table to ABFSS
df.write.format("delta").mode("overwrite").save(target_path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


from pyspark.sql.types import StructType, StructField, IntegerType, StringType
lh_bronze_basepath = get_basepath(WorkspaceId,BronzeLHId)
target_path = f'{lh_bronze_basepath}/Tables/Bronze/FundStatisticReferenceType'
# Define schema
schema = StructType([
    StructField("FundStatisticReferenceTypeId", IntegerType(), False),
    StructField("Description", StringType(), False),
    StructField("IndexId", StringType(), False)
])

# Create data
data = [
    (1, "Fund", ""),
    (2, "Custom Risk Benchmark", ""),
    (3, "Cash Index", "67373f19-577e-4b9c-a590-2b73f9ea2b5a"), #67373f19-577e-4b9c-a590-2b73f9ea2b5a	44d519ba-9a21-ea11-8133-0050569a56ba
    (4, "MSCI ACWI", "e4a151b5-511d-4de9-9b87-d22bd05753f6"), #e4a151b5-511d-4de9-9b87-d22bd05753f6	8ed419ba-9a21-ea11-8133-0050569a56ba
    (5, "Unknown", ""),
    (6, "CSFB HY", "1ae2093c-f9a7-413e-836d-0090a2348038"), #1ae2093c-f9a7-413e-836d-0090a2348038	5cd419ba-9a21-ea11-8133-0050569a56ba
    (7, "S&P 500", "6250d8a4-0bd4-401c-8e2d-4f4f86b57ac1") #6250d8a4-0bd4-401c-8e2d-4f4f86b57ac1	11d519ba-9a21-ea11-8133-0050569a56ba
]

# Create DataFrame
df = spark.createDataFrame(data, schema)

# Show the result
df.show()

# Write as Delta table to ABFSS
df.write.format("delta").mode("overwrite").save(target_path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************



from pyspark.sql.types import StructType, StructField, IntegerType, StringType
lh_bronze_basepath = get_basepath(WorkspaceId,BronzeLHId)
target_path = f'{lh_bronze_basepath}/Tables/Bronze/LiquidityOption'
# Define schema
schema = StructType([
    StructField("LiquidityOptionId", IntegerType(), False),
    StructField("Description", StringType(), False)
])

# Create data
data = [
    (0, "Undefined"),
    (1, "Default"),
    (2, "Apply Gates"),
    (3, "Default with Planned Redemptions"),
    (4, "Apply Gates with Planned Redemptions"),
    (5, "Default 3 Year Forward"),
    (6, "Apply Gates 3 Year Forward")
]

# Create DataFrame
df = spark.createDataFrame(data, schema)

# Show the result
df.show()

# Write as Delta table to ABFSS
df.write.format("delta").mode("overwrite").save(target_path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
