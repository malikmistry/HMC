# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# MARKDOWN ********************

# ### Manual Run Notebook. Run this notebook once. This is not part of any orchestration.

# CELL ********************

spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


from pyspark.sql.types import StructType, StructField, IntegerType, StringType
lh_bronze_basepath = get_basepath(WorkspaceId,BronzeLHId)
target_path = f'{lh_bronze_basepath}/Tables/Bronze/FundType'
# Define schema
schema = StructType([
    StructField("FundTypeId", IntegerType(), False),
    StructField("Description", StringType(), False)
])


# Create data
data = [
    (0, "Existing"),
    (1, "Incremental"),
    (2, "Allocated"),
    (3, "SidePocket"),
    (4, "PublicDrawdown"),
    (5, "Uncategorized")
]


# Create DataFrame
df = spark.createDataFrame(data, schema)

# Show the result
df.show()

# Write as Delta table to ABFSS
df.write.format("delta").mode("overwrite").save(target_path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


from pyspark.sql.types import StructType, StructField, IntegerType, StringType
lh_bronze_basepath = get_basepath(WorkspaceId,BronzeLHId)
target_path = f'{lh_bronze_basepath}/Tables/Bronze/ReportFrequency'
# Define schema
schema = StructType([
    StructField("ReportFrequencyId", IntegerType(), False),
    StructField("Description", StringType(), False)
])


# Create data
data = [
    (1, "Year"),
    (2, "Month")
]

# Create DataFrame
df = spark.createDataFrame(data, schema)

# Show the result
df.show()

# Write as Delta table to ABFSS
df.write.format("delta").mode("overwrite").save(target_path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
