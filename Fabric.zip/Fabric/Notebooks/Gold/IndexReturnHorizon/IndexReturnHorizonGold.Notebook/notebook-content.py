# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from decimal import Decimal
import requests
from datetime import date, datetime, timedelta
from requests.exceptions import HTTPError, ConnectionError, Timeout, RequestException
from pyspark.sql.types import StructType, StructField, DecimalType, DateType, StringType, IntegerType, LongType
from pyspark.sql.functions import to_date, lower
from delta.tables import DeltaTable
from pyspark.sql import functions as F, types as T

spark.conf.set('spark.sql.caseSensitive', True)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

# standard parameters passed in via MDF, default values are for development
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None
IndexHorizonReturnUrl = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_basepath)

curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_basepath)

if IndexHorizonReturnUrl == None:
    #todo: account for passing this in from MDF
    print("IndexHorizonReturnUrl Parameter is None.  Defaulting to dev URL")
    IndexHorizonReturnUrl = "https://winfunctionappdotnet-dev1.azurewebsites.net/api/CalculateIndexHorizonReturn?code=p5FkTa6fWird5I9Dz7gBvYPc3utum2xmwcCxmH6jyttrAzFu6juKfA=="


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

horizon_time_periods = [
    (1, "CYTD"),
    (2, "FYTD"),
    (5, "OneYear"),
    (6, "ThreeYear"),
    (7, "FiveYear"),
    (8, "SevenYear"),
    (9, "TenYear"),
    (11, "FifteenYear"),
    (12, "TwentyYear"),
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def getActiveIndices(lh_path):

    spark.read.format("delta").load(f"{lh_path}/Tables/Silver/Index").createOrReplaceTempView("vwIndices")

    df_active_indices = spark.sql("""
        SELECT DISTINCT IndexId, DisplayName, Frequency
        FROM vwIndices
        where IsActive = 1 AND NOT Frequency IS NULL  
    """)


    #xxx
    #df_active_indices = df_active_indices.filter(col("IndexId") == "18b7c764-774f-4a80-aad7-0edebc0207c3")
    #df_active_indices = df_active_indices.limit(10)

    return df_active_indices

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def calcIndexReturns(request_data):

    # print("IN calcIndexReturns, request")
    # print(request_data)

    start_time = datetime.now()

    data = http_post(IndexHorizonReturnUrl, request_data)

    # print("IN calcIndexReturns, result")
    # print(data)

    # Convert only the value field; keep None as None
    for rec in data:
        v = rec.get("indexReturnValue")
        if isinstance(v, float):
            rec["indexReturnValue"] = Decimal(str(v))  # preserve precision

    schema = T.StructType([
        T.StructField("indexId", T.StringType(), True),
        T.StructField("indexReturnValue", T.DecimalType(38, 11), True),
        T.StructField("timePeriod", T.IntegerType(), True),
        T.StructField("error", T.StringType(), True),
        T.StructField("detailsKey", T.StringType(), True),
        T.StructField("useIndexCurrency", T.BooleanType(), True),
        T.StructField("currency", T.IntegerType(), True)
    ])

    df_results = spark.createDataFrame(data, schema=schema)

    end_time = datetime.now()
    elapsed = end_time - start_time  # Returns a timedelta
    print("calcFundReturns elapsed time:", elapsed)    

    return df_results

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def getIndexRequest(indices, endDate):
    id_list = [str(r[0]) for r in indices] 
    index_request = { "Requests": [
    {
            "endDate": f"{endDate}",
            "isAnnualize": "false",
            "timePeriods": ["CYTD","FYTD","OneYear","ThreeYear","FiveYear","SevenYear","TenYear","FifteenYear","TwentyYear"],
            "indexes": id_list,
            "useIndexCurrency": "false",
            "currency": 1
     }
    ]
    }

    return index_request

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def end_of_prior_month(d: date) -> date:
    first_of_month = d.replace(day=1)
    return first_of_month - timedelta(days=1)

def end_of_prior_quarter(d: date) -> date:
    # Q1=Jan–Mar, Q2=Apr–Jun, Q3=Jul–Sep, Q4=Oct–Dec
    q = ((d.month - 1) // 3) + 1
    if q == 1:
        return date(d.year - 1, 12, 31)
    elif q == 2:
        return date(d.year, 3, 31)
    elif q == 3:
        return date(d.year, 6, 30)
    else:  # q == 4
        return date(d.year, 9, 30)

def getEndDateForFrequency(freq: int, today: date | None = None) -> date:
    if today is None:
        today = date.today()
    if freq == 8:   # for daily, use prior day
        return today - timedelta(days=1)
    if freq == 2:   # for monthly, use end of prior month
        return end_of_prior_month(today)
    if freq == 3:   # for quarterly, use end of prior quarter
        return end_of_prior_quarter(today)
    return today    # default/fallback

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# this is newer logic including using outer loop over frequencies

start_time = datetime.now()
print(f"IndexHorizonReturnSilver: {start_time.strftime('%Y-%m-%d %H:%M:%S')}" )

indicesOfInterest = getActiveIndices(curated_lh_basepath)

print(f"Index Count = {indicesOfInterest.count()}")

batch_size = 100

indices = indicesOfInterest.collect()

periods = ["CYTD","FYTD","OneYear","ThreeYear","FiveYear","SevenYear","TenYear","FifteenYear","TwentyYear"]

tp_map = F.create_map(*[x for k, v in horizon_time_periods for x in (F.lit(k), F.lit(v))])

# AsOfDate is used to keep when the computations were run
AsOfDate = date.today()
print (AsOfDate)

allIndexHorizonData = None

# ---- OUTER LOOP: group by Frequency ----
freq_values = (
    indicesOfInterest
        .select("Frequency")
        .distinct()
        .collect()
)
freq_values = sorted([r["Frequency"] for r in freq_values])

print(freq_values)

for freq in freq_values:
    print(f"\n=== Processing Frequency = {freq} ===")
    grp_df = indicesOfInterest.filter(F.col("Frequency") == freq)
    grp_count = grp_df.count()
    print(f"Group count = {grp_count}")
    
    endDateForFrequency = getEndDateForFrequency(freq)
    print(f"Date = {endDateForFrequency}")

    grp_indices = grp_df.collect()

    for i in range(0, len(grp_indices), batch_size):
        print(f"Processing indices {i + 1} through {min(i + batch_size, len(grp_indices))} (Frequency={freq})...")
        batch_indices = grp_indices[i:i + batch_size]

        batch_request = getIndexRequest(batch_indices, endDateForFrequency)

        batch_start_time = datetime.now()
        batch_ids = [row["IndexId"] for row in batch_indices]

        one_batch_horizon_returns = calcIndexReturns(batch_request)

        one_batch_horizon_returns = one_batch_horizon_returns.withColumn(
            "timePeriod",
            F.coalesce(F.element_at(tp_map, F.col("timePeriod").cast("int")), F.lit("Unknown"))
        )

        # --- Returns (Decimal 38,11)
        vals = (one_batch_horizon_returns.groupBy("indexId")
                .pivot("timePeriod", periods)
                .agg(F.first("indexReturnValue", ignorenulls=True))
                .select("indexId", *periods))
        for p in periods:
            vals = vals.withColumn(p, F.col(p).cast(T.DecimalType(38, 11)))

        # --- Errors
        errs = (one_batch_horizon_returns.groupBy("indexId")
                .pivot("timePeriod", periods)
                .agg(F.first("error", ignorenulls=True)))
        for p in periods:
            errs = errs.withColumnRenamed(p, f"{p}Error")

        # --- detailsKey
        det = (one_batch_horizon_returns.groupBy("indexId")
                .pivot("timePeriod", periods)
                .agg(F.first("detailsKey", ignorenulls=True)))
        for p in periods:
            det = det.withColumnRenamed(p, f"{p}DetailsKey")

        # --- useIndexCurrency (bool per period)
        uic = (one_batch_horizon_returns.groupBy("indexId")
                .pivot("timePeriod", periods)
                .agg(F.first("useIndexCurrency", ignorenulls=True)))
        for p in periods:
            uic = (uic.withColumnRenamed(p, f"{p}UseIndexCurrency")
                    .withColumn(f"{p}UseIndexCurrency", F.col(f"{p}UseIndexCurrency").cast("boolean")))

        # --- currency (int per period)
        curr = (one_batch_horizon_returns.withColumn("currency", F.col("currency").cast("int"))
                .groupBy("indexId")
                .pivot("timePeriod", periods)
                .agg(F.first("currency", ignorenulls=True)))

        for p in periods:
            # curr = (curr.withColumnRenamed(p, f"{p}CurrencyId")
            #         .withColumn(f"{p}Currency", F.col(f"{p}CurrencyId").cast("int")))
            curr = curr.withColumnRenamed(p, f"{p}CurrencyId")

        # --- Join all pivoted pieces
        wide = (vals
                .join(errs, "indexId", "left")
                .join(det,  "indexId", "left")
                .join(uic,  "indexId", "left")
                .join(curr, "indexId", "left"))

        df_oneBatch = wide

        df_oneBatch = df_oneBatch.withColumn("EndDate", F.lit(endDateForFrequency))
        df_oneBatch = df_oneBatch.withColumn("AsOfDate", F.lit(AsOfDate))
        df_oneBatch = df_oneBatch.withColumn("ETLLoadDateTime", F.lit(datetime.now()))
        df_oneBatch = df_oneBatch.withColumn("Frequency", F.lit(freq))

        if allIndexHorizonData is None:
            allIndexHorizonData = df_oneBatch
        else:
            allIndexHorizonData = allIndexHorizonData.unionByName(df_oneBatch, allowMissingColumns=True)

        batch_end_time = datetime.now()
        print("Batch elapsed time:", batch_end_time - batch_start_time)

if not allIndexHorizonData is None:
    print(f"final count =  {allIndexHorizonData.count()}")
else:
    print("No Data!")

print("showing schema for delta table Gold.IndexReturnHorizon")
path = f"{curated_lh_basepath}/Tables/Gold/IndexReturnHorizon"
spark.read.format("delta").load(path).printSchema()

print(f"Deleting old data for date {AsOfDate}")
delta_table = DeltaTable.forPath(spark, f"{curated_lh_basepath}/Tables/Gold/IndexReturnHorizon")
delta_table.delete(condition = F.col("AsOfDate").__eq__(AsOfDate))


# ==================================================================================================================================
# now get currency ISO code instead of ID
df_currency = spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Silver/Currency")
df_currency = df_currency.select("CurrencyId", "ISOCode")
currency_cols = [
    "CYTDCurrency", "FYTDCurrency", "OneYearCurrency", "ThreeYearCurrency",
    "FiveYearCurrency", "SevenYearCurrency", "TenYearCurrency",
    "FifteenYearCurrency", "TwentyYearCurrency"
]
df_final = allIndexHorizonData
for col_name in currency_cols:
    df_final = (
        df_final
        .join(
            df_currency.withColumnRenamed("CurrencyId", f"{col_name}Id")
                       .withColumnRenamed("ISOCode", f"{col_name}"),
            on=f"{col_name}Id",
            how="left"
        )
    )
    #xxx df_final = df_final.drop(f"{col_name}Id")

df_final = df_final.withColumnRenamed("Frequency", "FrequencyId")

# now get frequency description instead of ID
df_frequency = spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Silver/Frequency")
df_frequency = df_frequency.select("FrequencyId", "Description")
df_final = (
    df_final
    .join(
        df_frequency.withColumnRenamed("Description", "Frequency"),
        on="FrequencyId",
        how="left"
    )
)
#xxx df_final = df_final.drop("FrequencyId")

df_final.show(11)

#raise SystemExit("xxx")

df_final.write.format("delta").mode("append").save(f"{curated_lh_basepath}/Tables/Gold/IndexReturnHorizon")
spark.catalog.refreshTable("Gold.IndexReturnHorizon")

end_time = datetime.now()
elapsed = end_time - start_time  # Returns a timedelta
print("Total elapsed time:", elapsed)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.sql("SELECT * FROM lh_curated.Gold.IndexReturnHorizon LIMIT 100")
display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# spark.conf.set('spark.sql.caseSensitive', True)

# spark.sql(""" DROP TABLE Gold.IndexReturnHorizon """)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC DESCRIBE TABLE Gold.IndexReturnHorizon

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# new 11/25/2025
spark.sql("""
CREATE TABLE if not exists Gold.IndexReturnHorizon (
    IndexId varchar(36) NOT NULL,
    EndDate date NOT NULL,
    AsOfDate date NOT NULL,
    CYTD decimal(38,11),
    CYTDError VARCHAR(200),
    CYTDDetailsKey VARCHAR(200),
    FYTD decimal(38,11),
    FYTDError VARCHAR(200),
    FYTDDetailsKey VARCHAR(200),
    OneYear decimal(38,11),
    OneYearError VARCHAR(200),
    OneYearDetailsKey VARCHAR(200),
    ThreeYear decimal(38,11),
    ThreeYearError VARCHAR(200),
    ThreeYearDetailsKey VARCHAR(200),
    FiveYear decimal(38,11),
    FiveYearError VARCHAR(200),
    FiveYearDetailsKey VARCHAR(200),
    SevenYear decimal(38,11),
    SevenYearError VARCHAR(200),
    SevenYearDetailsKey VARCHAR(200),
    TenYear decimal(38,11),
    TenYearError VARCHAR(200),
    TenYearDetailsKey VARCHAR(200),
    FifteenYear decimal(38,11),
    FifteenYearError VARCHAR(200),
    FifteenYearDetailsKey VARCHAR(200),
    TwentyYear decimal(38,11),
    TwentyYearError VARCHAR(200),
    TwentyYearDetailsKey VARCHAR(200),
    ETLLoadDateTime TIMESTAMP NOT NULL,
    CYTDCurrencyId INT NOT NULL,
    CYTDCurrency VARCHAR(10) NOT NULL,
    FYTDCurrencyId INT NOT NULL,
    FYTDCurrency VARCHAR(10) NOT NULL,
    OneYearCurrencyId INT NOT NULL,
    OneYearCurrency VARCHAR(10) NOT NULL,
    ThreeYearCurrencyId INT NOT NULL,
    ThreeYearCurrency VARCHAR(10) NOT NULL,
    FiveYearCurrencyId INT NOT NULL,
    FiveYearCurrency VARCHAR(10) NOT NULL,
    SevenYearCurrencyId INT NOT NULL,
    SevenYearCurrency VARCHAR(10) NOT NULL,
    TenYearCurrencyId INT NOT NULL,
    TenYearCurrency VARCHAR(10) NOT NULL,
    FifteenYearCurrencyId INT NOT NULL,
    FifteenYearCurrency VARCHAR(10) NOT NULL,
    TwentyYearCurrencyId INT NOT NULL,
    TwentyYearCurrency VARCHAR(10) NOT NULL,
    FrequencyId INT NOT NULL,
    Frequency VARCHAR(20) NOT NULL
)
USING DELTA
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# xxx experimenting with interogating Fabric for version numbers, etc
import pyspark
import platform
import sys
import os
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

info = {}

# Spark and JVM info
info["spark_version"] = spark.version
info["py4j_version"] = pyspark.__version__
info["jvm_version"] = spark._jvm.System.getProperty("java.runtime.version")

# Hadoop / environment info
info["hadoop_version"] = spark._jsc.hadoopConfiguration().get("fs.azure.account.auth.type")

# All Spark configuration (namespaced: system, Fabric, cluster)
info["spark_configs"] = {
    k: v for k, v in spark.sparkContext.getConf().getAll()
}

# Python environment info
info["python_version"] = sys.version
info["platform"] = platform.platform()

# Try reading any Fabric-specific environment vars
info["env_vars"] = {
    key: val for key, val in os.environ.items()
    if "FABRIC" in key.upper() or "SPARK" in key.upper() or "LAKEHOUSE" in key.upper()
}

# Display cleanly
import json
print(json.dumps(info, indent=2))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
