# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql.types import DecimalType, DateType, StringType, IntegerType, LongType, TimestampType
from pyspark.sql import Window
import pandas as pd
from datetime import datetime, date, timezone
import time
import requests
from requests.exceptions import HTTPError, ConnectionError, Timeout, RequestException
from delta.tables import DeltaTable

spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set('spark.sql.parquet.vorder.default', 'true')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
print(etlloadtime)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

# This cell isfor testing
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
CalculatorUrl = "https://winfunctionappdotnet-dev1.azurewebsites.net"
CalculatorCode = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Gold.DrawdownFundAnalytic (
# MAGIC     FundId                          VARCHAR(36)           NOT NULL,
# MAGIC     ClassificationId                VARCHAR(36)           NOT NULL,
# MAGIC     CurrencyId                      INT              NOT NULL,
# MAGIC     FXDate                          DATE             NOT NULL,
# MAGIC     FXRate                          DECIMAL(38,15)   NOT NULL,
# MAGIC     CommitmentAmountLocal           DECIMAL(38,2),
# MAGIC     FundedAmountLocal               DECIMAL(38,2),
# MAGIC     UnfundedAdjustmentAmountLocal   DECIMAL(38,2),
# MAGIC     RecallableAmountLocal           DECIMAL(38,2),
# MAGIC     FundedAmountUSD                 DECIMAL(38,2),
# MAGIC     InAmountLocal                   DECIMAL(38,2),
# MAGIC     InAmountUSD                     DECIMAL(38,2),
# MAGIC     OutAmountLocal                  DECIMAL(38,2),
# MAGIC     OutAmountUSD                    DECIMAL(38,2),
# MAGIC     UnfundedAmountLocal             DECIMAL(38,2),
# MAGIC     UnfundedAmountUSD               DECIMAL(38,2),
# MAGIC     AsOfDate                        DATE             NOT NULL,
# MAGIC     CommitmentAmountUSD             DECIMAL(38,2),
# MAGIC     UnfundedAdjustmentAmountUSD     DECIMAL(38,2),
# MAGIC     RecallableAmountUSD             DECIMAL(38,2),
# MAGIC     MarketValueLocal                DECIMAL(38,2),
# MAGIC     TxCount                         INT,
# MAGIC     DrawdownFundAnalyticId          BIGINT           NOT NULL,
# MAGIC     ETLLoadDateTime                 TIMESTAMP        NOT NULL
# MAGIC ) 


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, LongType, DateType, DecimalType
)

# Explicit schema definition
drawdown_schema = StructType([
    StructField("FundId", StringType(), True),
    StructField("ClassificationId", StringType(), True),  
    StructField("CurrencyId", IntegerType(), True),            
    StructField("FXDate", DateType(), True),
    StructField("FXRate", DecimalType(38, 15), True),
    StructField("CommitmentAmountLocal", DecimalType(38, 2), True),
    StructField("FundedAmountLocal", DecimalType(38, 2), True),
    StructField("UnfundedAdjustmentAmountLocal", DecimalType(38, 2), True),
    StructField("RecallableAmountLocal", DecimalType(38, 2), True),
    StructField("FundedAmountUSD", DecimalType(38, 2), True),
    StructField("InAmountLocal", DecimalType(38, 2), True),
    StructField("InAmountUSD", DecimalType(38, 2), True),
    StructField("OutAmountLocal", DecimalType(38, 2), True),
    StructField("OutAmountUSD", DecimalType(38, 2), True),
    StructField("UnfundedAmountLocal", DecimalType(38, 2), True),
    StructField("UnfundedAmountUSD", DecimalType(38, 2), True),    
    StructField("AsOfDate", DateType(), True),
    StructField("CommitmentAmountUSD", DecimalType(38, 2), True),
    StructField("UnfundedAdjustmentAmountUSD", DecimalType(38, 2), True),
    StructField("RecallableAmountUSD", DecimalType(38, 2), True),
    StructField("MarketValueLocal", DecimalType(38, 2), True),
    StructField("TxCount", IntegerType(), True),               # 64-bit int
    StructField("DrawdownFundAnalyticId", LongType(), True), # 32-bit int
    StructField("ETLLoadDateTime", TimestampType(), True) # 32-bit int
])


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# def loadDrawdownFundAnalytics(processDate, bronze_lh_path, curated_lh_path, drawdown_schema):
#     print(f"start/loadDrawdownFundAnalytics")

#     navDate = pd.Timestamp(processDate).to_period('M').end_time.strftime('%Y-%m-%d')
#     window_spec = Window.orderBy(F.lit(1))

#     # Paths
#     drawdown_path = f"{curated_lh_path}/Tables/Gold/DrawdownFundAnalytic"
#     currency_path = f"{curated_lh_path}/Tables/Silver/FXRate"
#     cashflow_path = f"{curated_lh_path}/Tables/Silver/CashflowTransactionDetail"
#     fund_path = f"{curated_lh_path}/Tables/Silver/Fund"
#     entity_path = f"{curated_lh_path}/Tables/Silver/Entity"
#     firm_path = f"{curated_lh_path}/Tables/Silver/Firm"
#     classification_path = f"{curated_lh_path}/Tables/Silver/Classification"
#     fundperf_path = f"{curated_lh_path}/Tables/Gold/FundPerformance"
#     txibor_path = f"{curated_lh_path}/Tables/Silver/Transaction"
#     fundstruct_path = f"{bronze_lh_path}/Tables/Bronze/CrimsonXFundStructure"
#     commitment_path = f"{curated_lh_path}/Tables/Silver/FundCommitment"


#     if not table_exists(drawdown_path):
#         max_id = 0
#         destination_schema = None
#     else:
#         max_id_df = spark.read.format("delta").load(drawdown_path) \
#             .select(F.max("DrawdownFundAnalyticId").alias("max_id"))
#         max_id = max_id_df.collect()[0]["max_id"] or 0
#         destination_schema = spark.read.format("delta").load(drawdown_path).schema
#         drawdown_schema = destination_schema  # keep schema reference

#     # Max currency rate date
#     max_currencyratedate_df = spark.read.format("delta").load(currency_path).select(F.max("FXDate").alias("FXDate"))
#     max_currencyratedate = max_currencyratedate_df.collect()[0]["FXDate"] or date.today()

#     # multicurrency_df = spark.sql("""select FundId
#     #                                 from lh_curated.Silver.CashflowTransactionDetail ctd
#     #                                 GROUP BY FundId
#     #                                 HAVING COUNT(DISTINCT CurrencyId) > 1
#     #                              """)

#     # Cashflows
#     cashflow_df = spark.read.format("delta").load(cashflow_path) \
#         .filter((F.col("ExposureDate") <= F.lit(processDate).cast("date")) & (~F.col("CashflowTransactionTypeId").isin(5, 13))) \
#         .select(
#             "FundId",
#             "CashflowTransactionTypeId",
#             "CommitmentEffectLocal",
#             "FundedAmountLocal",
#             "UnfundedAdjustmentLocal",
#             "RecallableAmountLocal",
#             "FundedAmountUSD"
#         )
    
#     # Commitments
#     commitment_df = spark.read.format("delta").load(commitment_path) \
#         .filter(F.col("CommitmentDate") <= F.lit(processDate).cast("date")) \
#         .groupBy("FundId","CurrencyId") \
#         .agg(F.sum("CommitmentAmount").alias("CommitmentAmountLocal"))

#     #display(commitment_df.filter(F.col("FundId") == "00a0f46d-ff95-4110-aa12-60ae485d9979"))

#     # FundStructure
#     fundstruct_df = spark.read.format("delta").load(fundstruct_path) \
#         .select("FundStructureId", F.col("Description").alias("FundStructure"))

#     # Fund table + FundStructure
#     fund_df = spark.read.format("delta").load(fund_path) \
#         .join(fundstruct_df, "FundStructureId", "left") \
#         .filter(F.col("FundStructure") != "Open-Ended") \
#         .select("FundId", "EntityId", "FundStructureId", "FundStructure", "FundCurrencyId")

#     # Entity
#     entity_df = spark.read.format("delta").load(entity_path).select("EntityId", "FirmId")

#     # Firm
#     firm_df = spark.read.format("delta").load(firm_path) \
#         .filter(~F.col("FirmName").like("Harvard Management%")) \
#         .select("FirmId")

#     # Classification
#     classification_df = spark.read.format("delta").load(classification_path).select("FundId", "ClassificationId")

#     # Currency rate for max date
#     currency_df = spark.read.format("delta").load(currency_path) \
#         .select("CurrencyId", "FXDate", "FXRate")
#     max_fxdate = currency_df.agg(F.max("FXDate").alias("max_fxdate")).collect()[0]["max_fxdate"]
#     currency_df = currency_df.filter(F.col("FXDate") == max_fxdate)
#     #print(currency_df.count())
#     # Joins
#     df = cashflow_df.alias("cf") \
#         .join(fund_df.alias("f"),
#               F.lower(F.col("cf.FundId").cast("string")) == F.lower(F.col("f.FundId").cast("string")),
#               "inner") \
#         .join(entity_df.alias("e"),
#               F.lower(F.col("f.EntityId").cast("string")) == F.lower(F.col("e.EntityId").cast("string")),
#               "inner") \
#         .join(firm_df.alias("fm"),
#               F.lower(F.col("e.FirmId").cast("string")) == F.lower(F.col("fm.FirmId").cast("string")),
#               "inner") \
#         .join(currency_df.alias("c"),
#               F.lower(F.col("f.FundCurrencyId").cast("string")) == F.lower(F.col("c.CurrencyId").cast("string")),
#               "inner") \
#         .join(classification_df.alias("cl"),
#               F.lower(F.col("f.FundId").cast("string")) == F.lower(F.col("cl.FundId").cast("string")),
#               "inner") \
#         .join(commitment_df.alias("cm"), (F.col("cf.FundId") ==  F.col("cm.FundId")) & (F.col("c.CurrencyId") == F.col("cm.CurrencyId")), "left")
    
#     # display(df)

#     # Aggregate cashflows
#     result_df = (
#         df.groupBy("cf.FundId", "ClassificationId", "c.CurrencyId", "FXDate", "FXRate","CommitmentAmountLocal")
#         .agg(            
#             F.sum("FundedAmountLocal").alias("FundedAmountLocal"),
#             F.sum("UnfundedAdjustmentLocal").alias("UnfundedAdjustmentAmountLocal"),
#             F.sum("RecallableAmountLocal").alias("RecallableAmountLocal"),
#             F.sum("FundedAmountUSD").alias("FundedAmountUSD")
#         )
#     )

#     #display(result_df.filter(F.col("cf.FundId") == "00a0f46d-ff95-4110-aa12-60ae485d9979"))

# #    result_df = result_df.alias("r") \
# #        .join(commitment_df.alias("c"), (F.col("r.FundId") ==  F.col("c.FundId")) & (F.col("r.CurrencyId") == F.col("c.CurrencyId")))

#     # TxCount
#     txcount_df = cashflow_df.groupBy("FundId").agg(
#         F.count(F.when(~F.col("CashflowTransactionTypeId").isin(5, 13, 14, 15), F.lit(1))).alias("TxCount")
#     )

#     # Market Value
#     marketvalue_df = spark.read.format("delta").load(fundperf_path) \
#         .filter(F.col("NAVDate") == F.lit(navDate).cast("date")) \
#         .select("FundId", "MarketValueLocal")

#     # Paid in/out
#     tx_df = spark.read.format("delta").load(txibor_path) \
#         .filter(F.col("ExposureDate") <= processDate) \
#         .withColumnRenamed("ExposureDate", "AsOfDate") \
#         .select("FundId", "TransactionAmountInLocal", "TransactionAmountInUSD",
#                 "TransactionAmountOutLocal", "TransactionAmountOutUSD") \
#         .groupBy("FundId") \
#         .agg(
#             F.sum("TransactionAmountInLocal").alias("InAmountLocal"),
#             F.sum("TransactionAmountInUSD").alias("InAmountUSD"),
#             F.sum("TransactionAmountOutLocal").alias("OutAmountLocal"),
#             F.sum("TransactionAmountOutUSD").alias("OutAmountUSD")

#         )


#     result_df = result_df.join(tx_df, "FundId", "left") \
#         .withColumn("AsOfDate", F.lit(processDate)) \
#         .withColumn("ETLLoadDateTime", F.lit(etlloadtime).cast(TimestampType())) 

#     # USD columns
#     result_df = result_df \
#         .withColumn("CommitmentAmountUSD", F.col("CommitmentAmountLocal") * F.col("FXRate")) \
#         .withColumn("UnfundedAdjustmentAmountUSD", F.col("UnfundedAdjustmentAmountLocal") * F.col("FXRate")) \
#         .withColumn("RecallableAmountUSD", F.col("RecallableAmountLocal") * F.col("FXRate"))\

#     print('result_df - USD columns')

#     # Targeted funds filter
#     targetedFunds_df = result_df \
#         .join(marketvalue_df, "FundId", "left") \
#         .join(txcount_df, "FundId", "left") \
#         .filter(
#             (F.col("CommitmentAmountLocal") != 0) &
#             ((F.coalesce(F.col("MarketValueLocal"), F.lit("0.00")) != 0) |
#              (F.coalesce(F.col("TxCount"), F.lit(0)) == 0))
#         ) \
#         .select("FundId", "MarketValueLocal", "TxCount")

#     result_df = result_df.join(
#         targetedFunds_df.select("FundId", "MarketValueLocal", "TxCount"),
#         "FundId",
#         "inner"
#     )


#     # Add DrawdownFundAnalyticId
#     result_df = result_df.withColumn("DrawdownFundAnalyticId", F.row_number().over(window_spec) + max_id)

#     #display(result_df.filter(F.col("cf.FundId") == "00a0f46d-ff95-4110-aa12-60ae485d9979"))

#     # Align schema with default values
#     default_values = {
#         StringType(): F.lit("").cast(StringType()),
#         IntegerType(): F.lit(0).cast(IntegerType()),
#         LongType(): F.lit(0).cast(LongType()),
#         DateType(): F.lit(None).cast(DateType()),
#         DecimalType(38, 2): F.lit(0).cast(DecimalType(38, 2)),
#         DecimalType(38, 6): F.lit(0).cast(DecimalType(38, 6)),
#         DecimalType(38, 15): F.lit(0).cast(DecimalType(38, 15)),
#         TimestampType(): F.lit(etlloadtime).cast(TimestampType()) 
#     }

#     aligned_df = result_df.filter(
#         F.col("FundId").isNotNull() &
#         F.col("ClassificationId").isNotNull() &
#         F.col("CurrencyId").isNotNull() &
#         F.col("FXRate").isNotNull() &
#         F.col("FXDate").isNotNull() &
#         F.col("AsOfDate").isNotNull() &
#         F.col("DrawdownFundAnalyticId").isNotNull()
#     )

#     for field in drawdown_schema:
#         if field.name not in result_df.columns:
#             aligned_df = aligned_df.withColumn(field.name, default_values.get(type(field.dataType), F.lit(None)))
#         else:
#             aligned_df = aligned_df.withColumn(field.name, F.col(field.name).cast(field.dataType))

#     aligned_df = aligned_df.select([f.name for f in drawdown_schema])

#     rows_to_append_count = aligned_df.count()
#     aligned_df.write \
#         .format("delta") \
#         .mode("append") \
#         .save(drawdown_path)

#     print(f"Data successfully written to DrawdownFundAnalytic. Total rows: {rows_to_append_count}")
#     print(f"end/loadDrawdownFundAnalytics")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def removeDrawdownFundAnalyticsForDate(processDate, curated_lh_path):
    print(f"start/removeDrawdownFundAnalyticsForDate")

    # ABFSS path for DrawdownFundAnalytic table
    drawdown_path = f"{curated_lh_path}/Tables/Gold/DrawdownFundAnalytic"
    if table_exists(drawdown_path):
         # Load DeltaTable from ABFSS path
        ddfA_dt = DeltaTable.forPath(spark, drawdown_path)

        # Count rows matching the delete condition
        rowsToDelete = ddfA_dt.toDF().filter(F.col("AsOfDate") == processDate).count()

        # Delete rows
        ddfA_dt.delete(F.col("AsOfDate") == processDate)

        # No refresh needed for path-based access
        print(f"Rows with AsOfDate = {processDate} successfully deleted from DrawdownFundAnalytic. Total rows deleted: {rowsToDelete}")

        print(f"end/removeDrawdownFundAnalytics")
    else:
        print('Drawdown table does not exist, skipping remove process')

   


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# def calculateDrawdownAnalytics(processDate, curated_lh_path):
#     print(f"start/calculateDrawdownAnalytics: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

#     # Delta table path
#     drawdown_path = f"{curated_lh_path}/Tables/Gold/DrawdownFundAnalytic"

#     # --- Call Azure Function ---
#     azure_function_url = (
#         "https://winfunctionappdotnet-dev1.azurewebsites.net/api/CalculateCurrentFundDrawdowns"
#         "?code=WWV8xGVmimbtQe5JyypeIUv7jfUepY29yJz_YoA1Y-l_AzFuAYXaBw=="
#         f"&processDate={processDate.strftime('%Y-%m-%d')}"
#     )
#     #f"&processDate={processDate.strftime('%Y-%m-%d')}"
#     print(f"Calling Azure Function: {azure_function_url}")

#     try:
#         response = requests.get(azure_function_url, timeout=300)
#         response.raise_for_status()
#         data = response.json()
#         print(f"Call complete. Records returned: {len(data)}")
#     except (HTTPError, ConnectionError, Timeout, RequestException) as e:
#         print(f"Azure Function call failed: {e}")
#         raise

#     if not data:
#         raise ValueError("No data returned from Calculator API.")

#     # --- Create DataFrame ---
#     source_df = spark.createDataFrame(data).withColumn("AsOfDate", F.lit(processDate))
    
#     # --- Read Delta table once (for schema + merge) ---
#     delta_table = DeltaTable.forPath(spark, drawdown_path)
#     delta_df = delta_table.toDF()   # Convert to DataFrame for schema
#     delta_schema = delta_df.schema

#     # --- Align schema with Delta table ---
#     # Rename columns to match Delta table (case-sensitive)
#     for field in delta_schema:
#         for col in source_df.columns:
#             if col.lower() == field.name.lower() and col != field.name:
#                 source_df = source_df.withColumnRenamed(col, field.name)

#     # Fill missing columns with default values
#     default_values = {
#         DecimalType(38,2): F.lit(0).cast(DecimalType(38,2)),
#         DecimalType(25,7): F.lit(0).cast(DecimalType(25,7)),
#         DecimalType(18,6): F.lit(0).cast(DecimalType(18,6)),
#         DecimalType(38,15): F.lit(0).cast(DecimalType(38,15)),
#         DecimalType(38,6): F.lit(0).cast(DecimalType(38,2)),  # <- check this, looks like a typo
#         StringType(): F.lit("").cast(StringType()),
#         IntegerType(): F.lit(0).cast(IntegerType()),
#         LongType(): F.lit(0).cast(LongType()),
#         DateType(): F.lit(None).cast(DateType())
#     }

#     for field in delta_schema:
#         if field.name not in source_df.columns:
#             source_df = source_df.withColumn(
#                 field.name,
#                 default_values.get(type(field.dataType), F.lit(None))
#             )

#     # Select columns in the same order as Delta table
#     aligned_df = source_df.select([f.name for f in delta_schema])

#     # Filter invalid rows
#     aligned_df = aligned_df.filter(
#         F.col("FundId").isNotNull() &
#         F.col("AsOfDate").isNotNull() &
#         F.col("UnfundedAmountLocal").isNotNull()
#     )

#     delta_table.alias("target").merge(
#         aligned_df.alias("source"),
#             "target.FundId = source.FundId AND target.AsOfDate = source.AsOfDate AND target.FundId != '3b4dc7c9-0cc8-4d7f-878a-d25dceb69cb3'"
#         ).whenMatchedUpdate(
#         set={

#             "UnfundedAmountLocal" : "source.UnfundedAmountLocal",
#             "UnfundedAmountUSD" : "source.UnfundedAmountUSD"
#         }
#     ).execute()

#     # --- Merge into Delta table ---
#     # (
#     #     delta_table.alias("target")
#     #     .merge(
#     #         aligned_df.alias("source"),
#     #         "target.FundId = source.FundId AND target.AsOfDate = source.AsOfDate"
#     #     )
#     #     .whenMatchedUpdate(
#     #         set={col: f"source.{col}" for col in aligned_df.columns if col not in ("FundId", "AsOfDate")}
#     #     )        
#     #     .execute()
#     #     #.whenNotMatchedInsertAll()  # <-- You might want this if new rows should be inserted
#     # )

#     print(f"Data successfully merged into {drawdown_path}")
#     print(f"end/calculateDrawdownAnalytics")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### REGULAR LOAD
# For Regular and Historical Load all cells above this needs to run. For Historical Load do not load the 1 cell below (FOR REGULAR LOAD USING CALCULATOR APP).

# CELL ********************

# # ----------------- FOR REGULAR LOAD USING CALCULATOR APP --------------------------- #

# # Set your process date
# processDate = date.today()  # e.g. 2025-09-17
# #For manual/test
# processDate_str = "2025-10-21"
# # processDate = datetime.strptime(processDate_str, "%Y-%m-%d").date()

# # Retry settings for calculateDrawdownAnalytics
# max_retries = 5
# retry_delay_seconds = 60
# print(f"ProcessDate: {processDate}")
# # Run steps (pass etlloadtime_str into load function)
# removeDrawdownFundAnalyticsForDate(processDate, curated_lh_basepath)
# loadDrawdownFundAnalytics(processDate, bronze_lh_basepath, curated_lh_basepath, drawdown_schema)

# #For comparison
# etlloadtime_clean = etlloadtime.replace("T", " ").replace("Z", "")

# drawdown_path = f"{curated_lh_basepath}/Tables/Gold/DrawdownFundAnalytic"

# for attempt in range(1, max_retries + 1):
#     try:
#         # Efficient existence check using pushed-down filters and casting the literal to timestamp
#         print(f"ETLLoadDateTime:{etlloadtime}")
#         df_check = (
#             spark.read.format("delta").load(drawdown_path)
#             .filter(F.col("AsOfDate") == F.lit(processDate))
#             .filter(
#                 F.col("ETLLoadDateTime") == 
#                 F.to_timestamp(F.lit(etlloadtime_clean), "yyyy-MM-dd HH:mm:ss")
#             )
#         )
#         # use limit(1).count() to avoid a full scan count()
#         if df_check.limit(1).count() == 0:
#             print(f"[Attempt {attempt}] No rows yet for AsOfDate={processDate} with ETLLoadDateTime={etlloadtime}.")
#             if attempt < max_retries:
#                 print(f"Retrying in {retry_delay_seconds} seconds...")
#                 time.sleep(retry_delay_seconds)
#                 continue
#             else:
#                 raise RuntimeError("Max retries reached. Still no data available.")
#         else:
#             print(f"[Attempt {attempt}] Found matching rows for ETLLoadDateTime={etlloadtime} — proceeding to calculation.")

#         # Only run if matching data exists
#         calculateDrawdownAnalytics(processDate, curated_lh_basepath)
#         print(f"Drawdown analytics calculation succeeded on attempt {attempt}.")
#         break  # Exit loop after success

#     except Exception as e:
#         print(f"Attempt {attempt} failed with error: {e}")
#         if attempt < max_retries:
#             print(f"Retrying in {retry_delay_seconds} seconds...")
#             time.sleep(retry_delay_seconds)
#         else:
#             print("All attempts failed.")
#             raise

# print(f"Number of (calc service call) attempts: {attempt}.")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ### HISTORICAL LOAD
# 
# Comment out the two cells below if you will be running the regular load, otherwise run the two cells instead of the cell above

# CELL ********************

# ----------------- FOR HISTRICAL LOAD, NO CALCULATE APP USE --------------------------- #
def loadDrawdownFundAnalytics(processDate, bronze_lh_path, curated_lh_path, drawdown_schema):
    print(f"start/loadDrawdownFundAnalytics")

    navDate = pd.Timestamp(processDate).to_period('M').end_time.strftime('%Y-%m-%d')
    window_spec = Window.orderBy(F.lit(1))

    # Paths
    drawdown_path = f"{curated_lh_path}/Tables/Gold/DrawdownFundAnalytic"
    currency_path = f"{curated_lh_path}/Tables/Silver/FXRate"
    cashflow_path = f"{curated_lh_path}/Tables/Silver/CashflowTransactionDetail"
    fund_path = f"{curated_lh_path}/Tables/Silver/Fund"
    entity_path = f"{curated_lh_path}/Tables/Silver/Entity"
    firm_path = f"{curated_lh_path}/Tables/Silver/Firm"
    classification_path = f"{curated_lh_path}/Tables/Silver/Classification"
    fundperf_path = f"{curated_lh_path}/Tables/Gold/FundPerformance"
    txibor_path = f"{curated_lh_path}/Tables/Silver/Transaction"
    commitment_path = f"{curated_lh_path}/Tables/Silver/FundCommitment"
    #fundstruct_path = f"{bronze_lh_path}/Tables/Bronze/CrimsonXFundStructure"


    if not table_exists(drawdown_path):
        max_id = 0
        destination_schema = None
    else:
        max_id_df = spark.read.format("delta").load(drawdown_path) \
            .select(F.max("DrawdownFundAnalyticId").alias("max_id"))
        max_id = max_id_df.collect()[0]["max_id"] or 0
        destination_schema = spark.read.format("delta").load(drawdown_path).schema
        drawdown_schema = destination_schema  # keep schema reference

    # Max currency rate date
    max_currencyratedate_df = spark.read.format("delta").load(currency_path).select(F.max("FXDate").alias("FXDate"))
    max_currencyratedate = max_currencyratedate_df.collect()[0]["FXDate"] or date.today()

    # Cashflows
    cashflow_df = spark.read.format("delta").load(cashflow_path) \
        .filter((F.col("ExposureDate") <= F.lit(processDate).cast("date")) & (~F.col("CashflowTransactionTypeId").isin(5, 13))) \
        .select(
            "FundId",
            "CashflowTransactionTypeId",
            "CommitmentEffectLocal",
            "FundedAmountLocal",
            "UnfundedAdjustmentLocal",
            "RecallableAmountLocal",
            "FundedAmountUSD"
        )
    
    # Commitments
    commitment_df = spark.read.format("delta").load(commitment_path) \
        .filter(F.col("CommitmentDate") <= F.lit(processDate).cast("date")) \
        .groupBy("FundId","CurrencyId") \
        .agg(F.sum("CommitmentAmountLocal").alias("CommitmentAmountLocal"))        

    # FundStructure
    #fundstruct_df = spark.read.format("delta").load(fundstruct_path) \
    #    .select("FundStructureId", F.col("Description").alias("FundStructure"))

    # Fund table + FundStructure
    fund_df = spark.read.format("delta").load(fund_path) \
        .filter(F.col("FundStructure") != "Open-Ended") \
        .select("FundId", "EntityId", "FundStructureId", "FundStructure", "FundCurrencyId")
    # .join(fundstruct_df, "FundStructureId", "left") \
    # .filter(F.col("FundStructure") != "Open-Ended") \
    #    .select("FundId", "EntityId", "FundStructureId", "FundStructure", "FundCurrencyId")

    # Entity
    entity_df = spark.read.format("delta").load(entity_path).select("EntityId", "FirmId")
    # Firm
    firm_df = spark.read.format("delta").load(firm_path) \
        .filter(~F.col("FirmName").like("Harvard Management%")) \
        .select("FirmId")

    # Classification
    classification_df = spark.read.format("delta").load(classification_path).select("FundId", "ClassificationId")

    # Currency rate for max date
    currency_df = spark.read.format("delta").load(currency_path) \
        .select("CurrencyId", "FXDate", "FXRate")
    max_fxdate = currency_df.agg(F.max("FXDate").alias("max_fxdate")).collect()[0]["max_fxdate"]
    currency_df = currency_df.filter(F.col("FXDate") == max_fxdate)
    # Joins
    df = cashflow_df.alias("cf") \
        .join(fund_df.alias("f"),
              F.lower(F.col("cf.FundId").cast("string")) == F.lower(F.col("f.FundId").cast("string")),
              "inner") \
        .join(entity_df.alias("e"),
              F.lower(F.col("f.EntityId").cast("string")) == F.lower(F.col("e.EntityId").cast("string")),
              "inner") \
        .join(firm_df.alias("fm"),
              F.lower(F.col("e.FirmId").cast("string")) == F.lower(F.col("fm.FirmId").cast("string")),
              "inner") \
        .join(currency_df.alias("c"),
              F.lower(F.col("f.FundCurrencyId").cast("string")) == F.lower(F.col("c.CurrencyId").cast("string")),
              "inner") \
        .join(classification_df.alias("cl"),
              F.lower(F.col("f.FundId").cast("string")) == F.lower(F.col("cl.FundId").cast("string")),
              "inner") \
        .join(commitment_df.alias("cm"), (F.col("cf.FundId") ==  F.col("cm.FundId")) & (F.col("c.CurrencyId") == F.col("cm.CurrencyId")), "left")
    display(cashflow_df.count())
    display(df.count())

    # Aggregate cashflows
    result_df = (
        df.groupBy("cf.FundId", "ClassificationId", "c.CurrencyId", "FXDate", "FXRate","CommitmentAmountLocal")
        .agg(
            F.sum("FundedAmountLocal").alias("FundedAmountLocal"),
            F.sum("UnfundedAdjustmentLocal").alias("UnfundedAdjustmentAmountLocal"),
            F.sum("RecallableAmountLocal").alias("RecallableAmountLocal"),
            F.sum("FundedAmountUSD").alias("FundedAmountUSD")
        )
    )
    display(result_df.count())

    # TxCount
    txcount_df = cashflow_df.groupBy("FundId").agg(
        F.count(F.when(~F.col("CashflowTransactionTypeId").isin(5, 13, 14, 15), F.lit(1))).alias("TxCount")
    )

    # Market Value
    # "MarketValueUSD" is added for historical load
    marketvalue_df = spark.read.format("delta").load(fundperf_path) \
        .filter(F.col("NAVDate") == F.lit(navDate).cast("date")) \
        .select("FundId", "MarketValueLocal", "MarketValueUSD")

    # Paid in/out
    tx_df = spark.read.format("delta").load(txibor_path) \
        .filter(F.col("ExposureDate") <= processDate) \
        .withColumnRenamed("ExposureDate", "AsOfDate") \
        .select("FundId", "TransactionAmountInLocal", "TransactionAmountInUSD",
                "TransactionAmountOutLocal", "TransactionAmountOutUSD") \
        .groupBy("FundId") \
        .agg(
            F.sum("TransactionAmountInLocal").alias("InAmountLocal"),
            F.sum("TransactionAmountInUSD").alias("InAmountUSD"),
            F.sum("TransactionAmountOutLocal").alias("OutAmountLocal"),
            F.sum("TransactionAmountOutUSD").alias("OutAmountUSD")

        )

    #For historical load only - multiples df
    multiples_df = tx_df \
        .join(marketvalue_df, "FundId", "inner") \
        .withColumn("DPILocal", F.when(~F.col("InAmountLocal").isin(0), F.abs(F.col("OutAmountLocal")) / F.abs(F.col("InAmountLocal")))) \
        .withColumn("DPIUSD", F.when(~F.col("InAmountUSD").isin(0), F.abs(F.col("OutAmountUSD")) / F.abs(F.col("InAmountUSD")))) \
        .withColumn("TVPILocal", F.when(~F.col("InAmountLocal").isin(0), (F.abs(F.col("OutAmountLocal")) + F.abs(F.col("MarketValueLocal"))) / F.abs(F.col("InAmountLocal")))) \
        .withColumn("TVPIUSD", F.when(~F.col("InAmountUSD").isin(0), (F.abs(F.col("OutAmountUSD")) + F.abs(F.col("MarketValueUSD")) ) / F.abs(F.col("InAmountUSD")))) \
        .withColumn("RVPILocal", F.when(~F.col("InAmountLocal").isin(0), F.abs(F.col("MarketValueLocal")) / F.abs(F.col("InAmountLocal")))) \
        .withColumn("RVPIUSD", F.when(~F.col("InAmountUSD").isin(0), F.abs(F.col("MarketValueUSD")) / F.abs(F.col("InAmountUSD")))) \
        .select("FundId", "DPILocal", "DPIUSD", "TVPILocal", "TVPIUSD", "RVPILocal", "RVPIUSD")

    result_df = result_df \
        .join(multiples_df, "FundId", "left")
    display(result_df.count())

    result_df = result_df.join(tx_df, "FundId", "left") \
        .withColumn("AsOfDate", F.lit(processDate)) \
        .withColumn("ETLLoadDateTime", F.lit(etlloadtime).cast(TimestampType())) 
    display(result_df.count())

    # USD columns
    result_df = result_df \
        .withColumn("CommitmentAmountUSD", F.col("CommitmentAmountLocal") * F.col("FXRate")) \
        .withColumn("UnfundedAdjustmentAmountUSD", F.col("UnfundedAdjustmentAmountLocal") * F.col("FXRate")) \
        .withColumn("RecallableAmountUSD", F.col("RecallableAmountLocal") * F.col("FXRate"))\
        .withColumn( # for historical load
            "UnfundedAmountLocal",
            F.col("CommitmentAmountLocal") - F.col("FundedAmountLocal") + F.col("RecallableAmountLocal") + F.col("UnfundedAdjustmentAmountLocal")
        )\
        .withColumn( # for historical load
            "UnfundedAmountUSD",
            F.col("CommitmentAmountUSD") - F.col("FundedAmountUSD") + F.col("RecallableAmountUSD") + F.col("UnfundedAdjustmentAmountUSD")
        )
    print('result_df - USD columns')
    display(result_df.count())

    # Targeted funds filter
    targetedFunds_df = result_df \
        .join(marketvalue_df, "FundId", "left") \
        .join(txcount_df, "FundId", "left") \
        .filter(
            (F.col("CommitmentAmountLocal") != 0) &
            ((F.coalesce(F.col("MarketValueLocal"), F.lit("0.00")) != 0) |
             (F.coalesce(F.col("TxCount"), F.lit(0)) == 0))
        ) \
        .select("FundId", "MarketValueLocal", "TxCount")

    result_df = result_df.join(
        targetedFunds_df.select("FundId", "MarketValueLocal", "TxCount"),
        "FundId",
        "inner"
    )
    display(result_df.count())


    # Add DrawdownFundAnalyticId
    result_df = result_df.withColumn("DrawdownFundAnalyticId", F.row_number().over(window_spec) + max_id)

    # Align schema with default values
    default_values = {
        StringType(): F.lit("").cast(StringType()),
        IntegerType(): F.lit(0).cast(IntegerType()),
        LongType(): F.lit(0).cast(LongType()),
        DateType(): F.lit(None).cast(DateType()),
        DecimalType(38, 2): F.lit(0).cast(DecimalType(38, 2)),
        DecimalType(38, 6): F.lit(0).cast(DecimalType(38, 6)),
        DecimalType(38, 15): F.lit(0).cast(DecimalType(38, 15)),
        TimestampType(): F.lit(etlloadtime).cast(TimestampType()) 
    }

    aligned_df = result_df.filter(
        F.col("FundId").isNotNull() &
        F.col("ClassificationId").isNotNull() &
        F.col("CurrencyId").isNotNull() &
        F.col("FXRate").isNotNull() &
        F.col("FXDate").isNotNull() &
        F.col("AsOfDate").isNotNull() &
        F.col("DrawdownFundAnalyticId").isNotNull()
    )

    for field in drawdown_schema:
        if field.name not in result_df.columns:
            aligned_df = aligned_df.withColumn(field.name, default_values.get(type(field.dataType), F.lit(None)))
        else:
            aligned_df = aligned_df.withColumn(field.name, F.col(field.name).cast(field.dataType))

    aligned_df = aligned_df.select([f.name for f in drawdown_schema])

    rows_to_append_count = aligned_df.count()
    aligned_df.write \
        .format("delta") \
        .mode("append") \
        .save(drawdown_path)

    print(f"Data successfully written to DrawdownFundAnalytic. Total rows: {rows_to_append_count}")
    print(f"end/loadDrawdownFundAnalytics")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from datetime import datetime, date, timedelta, timezone
import time
from pyspark.sql import functions as F

# Define your date range (inclusive)
start_date_str = "2024-01-31"
end_date_str   = "2025-11-12" #date.today() #"2025-10-01"
# last date 9-16

start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date()
end_date   = datetime.strptime(end_date_str, "%Y-%m-%d").date()

# Retry settings for calculateDrawdownAnalytics
max_retries = 5
retry_delay_seconds = 60

# Loop through the date range
current_date = start_date
while current_date <= end_date:
    processDate = current_date
    print(f"\n=== Processing date: {processDate} ===")

    # Run steps (pass etlloadtime_str into load function)
    removeDrawdownFundAnalyticsForDate(processDate, curated_lh_basepath)
    loadDrawdownFundAnalytics(processDate, bronze_lh_basepath, curated_lh_basepath, drawdown_schema)

    # For comparison
    etlloadtime_clean = etlloadtime.replace("T", " ").replace("Z", "")
    drawdown_path = f"{curated_lh_basepath}/Tables/Gold/DrawdownFundAnalytic"
    current_date += timedelta(days=1)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }
