# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql import Window

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# --- Helpers (tbl_path pattern) ---
def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

jira_src = (
    read_delta(curated_lh_id, "Silver/JIRAData")
        .filter((F.col("Labels") == F.lit("SecurityProject")) & (F.col("Status") != F.lit("Done")))
        .select("Summary", "Description", "Assignee", "DueDate")
)

planner_raw = read_delta(curated_lh_id, "Silver/PlannerData")

if "normalize_owner" not in globals():
    def normalize_owner(col):
        c = F.trim(F.regexp_replace(col, r"\s+", " "))
        arr = F.split(c, r"\s+")
        # Format as "Surname, Given Names" when possible; else leave as-is
        formatted = (
            F.when(F.instr(c, ",") > 0, c)
             .when(
                 F.size(arr) >= 2,
                 F.concat_ws(", ",
                     F.element_at(arr, -1),
                     F.array_join(F.slice(arr, 1, F.size(arr) - 1), " ")
                 )
             )
             .otherwise(c)
        )
        return formatted


if "InUserPage" in planner_raw.columns:
    planner_src = planner_raw.select("Bucket", "TaskName", "Assignment", "DueDate", "InUserPage")
else:

    needed_cols = ["Bucket", "TaskName", "Assignment", "DueDate", "StartDate", "Progress"]
    missing = [c for c in needed_cols if c not in planner_raw.columns]
    if missing:
        raise ValueError(f"PlannerData is missing columns needed to compute InUserPage fallback: {missing}")

    def canon(c):
        c = F.coalesce(c, F.lit(""))
        c = F.regexp_replace(c, u"\u00A0", " ")
        c = F.regexp_replace(c, r"\s+", " ")
        c = F.trim(c)
        return F.upper(c)

    planner_tmp = (
        planner_raw
        .select(
            F.col("Bucket"),
            F.col("TaskName"),
            F.col("Assignment"),
            F.to_date("DueDate").alias("DueDate"),
            F.to_date("StartDate").alias("StartDate"),
            F.col("Progress")
        )
        .withColumn("BucketCanon",   canon(F.col("Bucket")))
        .withColumn("ProgressCanon", canon(F.col("Progress")))
    )

    w_bucket = Window.partitionBy("BucketCanon")
    due_floor = F.to_date(F.lit("1900-01-01"))

    with_max = planner_tmp.withColumn(
        "MaxCompletedStart",
        F.max(F.when(F.col("ProgressCanon") == "COMPLETED", F.col("StartDate"))).over(w_bucket)
    )

    candidate = (
        (F.col("ProgressCanon") == "COMPLETED") &
        (F.col("StartDate") == F.col("MaxCompletedStart"))
    )

    w_pick = Window.partitionBy("BucketCanon").orderBy(
        F.when(candidate, F.lit(1)).otherwise(F.lit(0)).desc(),
        F.coalesce(F.col("DueDate"), due_floor).desc()
    )

    computed = (
        with_max
        .withColumn("rn", F.row_number().over(w_pick))
        .withColumn("InUserPage", (candidate & (F.col("rn") == 1)).cast("boolean"))
        .select("Bucket", "TaskName", "Assignment", "DueDate", "InUserPage")
    )

    planner_src = computed

# --- Transforms ---
jira_norm = (
    jira_src
      .select(
          F.col("Summary").alias("SecurityTask"),
          F.col("Description").alias("Description"),
          normalize_owner(F.col("Assignee")).alias("Owner"),
          F.to_date(F.col("DueDate")).alias("Due")
      )
      .withColumn("InUserPage", F.lit(False).cast("boolean"))
)

planner_norm = (
    planner_src
      .select(
          F.col("TaskName").alias("SecurityTask"),
          F.col("Bucket").alias("Description"),
          normalize_owner(F.col("Assignment")).alias("Owner"),
          F.to_date(F.col("DueDate")).alias("Due"),
          F.col("InUserPage")
      )
)

securitytasks = jira_norm.unionByName(planner_norm)

target_rel  = "Gold/SecurityTaskList"
target_path = tbl_path(curated_lh_id, target_rel)

(securitytasks
    .select("SecurityTask", "Description", "Owner", "Due", "InUserPage")
    .write
    .format("delta")
    .mode("overwrite")            # swap to 'append' for incremental loads
    .option("overwriteSchema", "true")
    .save(target_path)
)
#CREATE TABLE [Gold].[SecurityTaskList](
#	[SecurityTask] [varchar](8000) NULL,
#	[Description] [varchar](8000) NULL,
#	[Owner] [varchar](8000) NULL,
#	[Due] [date] NULL,
#	[InUserPage] [bit] NULL
#) ON [PRIMARY]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
