# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""
NotebookName = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
# WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
# BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
# CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
# TaskList = "{\"JobAuditKey\":537,\"TaskKey\":116,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"CrimsonXFundStatistics\",\"SinkTableName\":\"FundBenchmarkTrackRecord\",\"SinkSchemaName\":\"Gold\",\"NotebookKeyNotebookKey\":\"14\",\"NotebookName\":\"FundBenchmarkTrackRecordSilver\",\"SinkLakehouseName\":\"lh_curated\"}"
# NotebookName = "FundSilver"
# LakehouseName = "lh_curated"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#we will attach the sinklakehouse to the notebook
if LakehouseName == 'lh_bronze':
    LakehouseId = BronzeLHId
elif LakehouseName == 'lh_curated':
    LakehouseId = CuratedLHId

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

  %%sql
   CREATE TABLE IF NOT EXISTS  Gold.FundBenchmarkTrackRecord(
    	FundId VARCHAR(36) NOT NULL,
    	FundBenchmarkTrackRecordTypeId int NOT NULL,
    	IndexId VARCHAR(36) NOT NULL,
       AsOfDate DATE NOT NULL,
    	CYTD decimal(38, 6),
    	FYTD decimal(38, 6),
    	ITD decimal(38, 6),
    	HMCITD decimal(38, 6),
    	OneYear decimal(38, 6),
    	ThreeYear decimal(38, 6),
    	FiveYear decimal(38, 6),
    	SevenYear decimal(38, 6),
    	TenYear decimal(38, 6)
    )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tasklist = json.loads(f"{TaskList}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def is_df_empty(df, column_name=None, excluded_value=None):
    if column_name is not None and excluded_value is not None:
        df = df.filter(col(column_name) != excluded_value)
    return df.limit(1).count() == 0

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# 
# **Process Fund Trade Silver Table**

# CELL ********************

def process_task(task,bronze_lh_id,curated_lh_id):
    try:
        source_path = f"{bronze_lh_id}/Tables/{task['SourceSchemaName']}/{task['SourceTableName']}"
        target_path = f"{curated_lh_id}/Tables/{task['SinkSchemaName']}/{task['SinkTableName']}"
        datetime_col = 'Date_Time'
        print(source_path)
        print(target_path)
        #abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXFund

        #Read table path
        bronzetimeperiod_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXTimePeriod"
        bronzefundstatisticreferencetype_path = f"{bronze_lh_id}/Tables/Bronze/FundStatisticReferenceType"



        today_date = date.today()
        today_str = date.today().strftime('%Y-%m-%d')
        #yesterday_str = (today_str - timedelta(days=1)).strftime('%Y-%m-%d')
        # Set watermark
        etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        # TRY Read source
        try:
            df_source = spark.read.format("delta").load(source_path)
            df_source.createOrReplaceTempView("src")

            df_bronzetimeperiod = spark.read.format("delta").load(bronzetimeperiod_path)
            df_bronzetimeperiod.createOrReplaceTempView("CrimsonXTimePeriod")
            df_fundstatisticreferencetype = spark.read.format("delta").load(bronzefundstatisticreferencetype_path)
            df_fundstatisticreferencetype.createOrReplaceTempView("FundStatisticReferenceType")
            truncateQuery = f"""
                TRUNCATE TABLE Gold.{task['SinkTableName']}
            """
            spark.sql(truncateQuery)
            # Spark SQL
            query = f"""

                SELECT * FROM (
                    SELECT 
                    tp.Description TimeLabel
                    ,CAST(FundId AS VARCHAR(36)) AS FundId
                    ,1 AS FundBenchmarkTrackRecordTypeId
                    ,CAST(fst.IndexId AS VARCHAR(36)) AS IndexId
                    ,AsOfDate
                    ,CAST(Alpha AS DECIMAL(38,6)) AS Alpha
                from src fs
                LEFT JOIN CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
                LEFT JOIN FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
                WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
                ) PIVOT (
                    FIRST( Alpha ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS OneYear, '3 Year' AS ThreeYear, '5 Year' AS FiveYear, '7 Year' AS SevenYear , '10 Year' AS TenYear)
                )

                UNION ALL

                SELECT * FROM (
                    SELECT 
                    tp.Description TimeLabel
                    ,CAST(FundId AS VARCHAR(36)) AS FundId
                    ,2 AS FundBenchmarkTrackRecordTypeId
                    ,CAST(fst.IndexId AS VARCHAR(36)) AS IndexId
                    ,AsOfDate
                    ,GrossReturn
                from src fs
                LEFT JOIN CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
                LEFT JOIN FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
                WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
                ) PIVOT (
                    FIRST( GrossReturn ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS OneYear, '3 Year' AS ThreeYear, '5 Year' AS FiveYear, '7 Year' AS SevenYear , '10 Year' AS TenYear)
                )

                UNION ALL

                SELECT * FROM (
                    SELECT 
                    tp.Description TimeLabel
                    ,CAST(FundId AS VARCHAR(36)) AS FundId
                    ,3 AS FundBenchmarkTrackRecordTypeId
                    ,CAST(fst.IndexId AS VARCHAR(36)) AS IndexId
                    ,AsOfDate
                    ,CAST(StandardDeviation AS DECIMAL(38,6)) AS StandardDeviation
                from src fs
                LEFT JOIN CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
                LEFT JOIN FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
                WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
                ) PIVOT (
                    FIRST( StandardDeviation ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS OneYear, '3 Year' AS ThreeYear, '5 Year' AS FiveYear, '7 Year' AS SevenYear , '10 Year' AS TenYear)
                )

                UNION ALL

                SELECT * FROM (
                    SELECT 
                    tp.Description TimeLabel
                    ,CAST(FundId AS VARCHAR(36)) AS FundId
                    ,4 AS FundBenchmarkTrackRecordTypeId
                    ,CAST(fst.IndexId AS VARCHAR(36)) AS IndexId
                    ,AsOfDate
                    ,CAST(SharpeRatio AS DECIMAL(38,6)) AS SharpeRatio
                from src fs
                LEFT JOIN CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
                LEFT JOIN FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
                WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
                ) PIVOT (
                    FIRST( SharpeRatio ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS OneYear, '3 Year' AS ThreeYear, '5 Year' AS FiveYear, '7 Year' AS SevenYear , '10 Year' AS TenYear)
                )

                UNION ALL

                SELECT * FROM (
                    SELECT 
                    tp.Description TimeLabel
                    ,CAST(FundId AS VARCHAR(36)) AS FundId
                    ,5 AS FundBenchmarkTrackRecordTypeId
                    ,CAST(fst.IndexId AS VARCHAR(36)) AS IndexId
                    ,AsOfDate
                    ,CAST(MaxDrawdown AS DECIMAL(38,6)) AS MaxDrawdown
                from src fs
                LEFT JOIN CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
                LEFT JOIN FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
                WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
                ) PIVOT (
                    FIRST( MaxDrawdown ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS OneYear, '3 Year' AS ThreeYear, '5 Year' AS FiveYear, '7 Year' AS SevenYear , '10 Year' AS TenYear)
                )

                UNION ALL

                SELECT * FROM (
                    SELECT 
                    tp.Description TimeLabel
                    ,CAST(FundId AS VARCHAR(36)) AS FundId
                    ,6 AS FundBenchmarkTrackRecordTypeId
                    ,CAST(fst.IndexId AS VARCHAR(36)) AS IndexId
                    ,AsOfDate
                    ,CAST(Beta AS DECIMAL(38,6)) AS Beta
                from src fs
                LEFT JOIN CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
                LEFT JOIN FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
                WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
                ) PIVOT (
                    FIRST( Beta ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS OneYear, '3 Year' AS ThreeYear, '5 Year' AS FiveYear, '7 Year' AS SevenYear , '10 Year' AS TenYear)
                )

                UNION ALL

                SELECT * FROM (
                    SELECT 
                    tp.Description TimeLabel
                    ,CAST(FundId AS VARCHAR(36)) AS FundId
                    ,7 AS FundBenchmarkTrackRecordTypeId
                    ,CAST(fst.IndexId AS VARCHAR(36)) AS IndexId
                    ,AsOfDate
                    ,CAST(Correlation AS DECIMAL(38,6)) AS Correlation
                from src fs
                LEFT JOIN CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
                LEFT JOIN FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
                WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
                ) PIVOT (
                    FIRST( Correlation ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS OneYear, '3 Year' AS ThreeYear, '5 Year' AS FiveYear, '7 Year' AS SevenYear , '10 Year' AS TenYear)
                )

                UNION ALL

                SELECT * FROM (
                    SELECT 
                    tp.Description TimeLabel
                    ,CAST(FundId AS VARCHAR(36)) AS FundId
                    ,8 AS FundBenchmarkTrackRecordTypeId
                    ,fst.IndexId AS IndexId
                    ,AsOfDate
                    ,CAST(InformationRatio AS DECIMAL(38,6)) AS InformationRatio
                from src fs
                LEFT JOIN CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
                LEFT JOIN FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
                WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
                ) PIVOT (
                    FIRST( InformationRatio ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS OneYear, '3 Year' AS ThreeYear, '5 Year' AS FiveYear, '7 Year' AS SevenYear , '10 Year' AS TenYear)
                )

                UNION ALL

                SELECT * FROM (
                    SELECT 
                    tp.Description TimeLabel
                    ,CAST(FundId AS VARCHAR(36)) AS FundId
                    ,9 AS FundBenchmarkTrackRecordTypeId
                    ,CAST(fst.IndexId AS VARCHAR(36)) AS IndexId
                    ,AsOfDate
                    ,CAST(TrackingError AS DECIMAL(38,6)) AS TrackingError
                from src fs
                LEFT JOIN CrimsonXTimePeriod tp ON fs.TimePeriodId = tp.TimePeriodId
                LEFT JOIN FundStatisticReferenceType fst ON fs.FundStatisticReferenceTypeId = fst.FundStatisticReferenceTypeId
                WHERE fs.GrossReturn IS NOT NULL  AND fs.FundStatisticReferenceTypeId IN (3,4,6,7)
                ) PIVOT (
                    FIRST( TrackingError ) FOR TimeLabel IN ('CYTD' AS CYTD, 'FYTD' AS FYTD, 'ITD' AS ITD, 'HMC ITD' AS HMCITD, '1 Year' AS OneYear, '3 Year' AS ThreeYear, '5 Year' AS FiveYear, '7 Year' AS SevenYear , '10 Year' AS TenYear)
                )

            """
            result_df = spark.sql(query)

            result_df.createOrReplaceTempView("result_df")
            nonull_query = f"""
            SELECT *
            FROM result_df
            WHERE NOT (
                CYTD IS NULL
                AND FYTD IS NULL
                AND ITD IS NULL
                AND HMCITD IS NULL
                AND OneYear IS NULL
                AND ThreeYear IS NULL
                AND FiveYear IS NULL
                AND SevenYear IS NULL
                AND TenYear IS NULL
            )
            """
            nonull_df = spark.sql(nonull_query)

            #result_df.show(5)
        except Exception as e:
            #raise RuntimeError(f"Source path does not exist or failed to load: {source_path}") from e
            raise e
        # Write the result as a Delta table
        nonull_df.write.format("delta").mode("append").save(target_path)
        #df_today.write.format("delta").mode("overwrite").save(target_path)
        print('Completed')
    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise RuntimeError(f"Failed") from e

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)


        # Process the task
        result = process_task(task_item,bronze_lh_basepath,curated_lh_basepath)

    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise
#abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXFundTrade

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
