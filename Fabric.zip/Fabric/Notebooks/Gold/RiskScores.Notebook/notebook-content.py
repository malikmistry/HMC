# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql.types import StructType, StructField, StringType, DecimalType
from pyspark.sql import Row

# Define the data
data = [
    ("VeryLowLimitStart", 0.0000),
    ("VeryLowLimitEnd", 20.0000),
    ("LowLimitStart", 20.0001),
    ("LowLimitEnd", 40.0000),
    ("MediumLimitStart", 40.0001),
    ("MediumLimitEnd", 60.0000),
    ("HighLimitStart", 60.0001),
    ("HighLimitEnd", 80.0000),
    ("VeryHighLimitStart", 80.0001),
    ("VeryHighLimitEnd", 100.0000)
]

# Define the schema
schema = StructType([
    StructField("LimitType", StringType(), False),
    StructField("Value", DecimalType(10,4), False)
])

# Convert float to Decimal objects to satisfy DecimalType
from decimal import Decimal
data = [(lt, Decimal(str(v))) for lt, v in data]

# Create DataFrame
df_limits = spark.createDataFrame(data, schema)

# Create schema and write to Delta
spark.sql("CREATE SCHEMA IF NOT EXISTS Silver")
df_limits.write.format("delta").mode("overwrite").saveAsTable("Silver.RiskGaugeLimits")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
