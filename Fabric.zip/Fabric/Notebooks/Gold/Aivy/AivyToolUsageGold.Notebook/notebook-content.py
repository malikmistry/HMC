# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Gold Delta table path (uses Fabric helper 'get_basepath')
WorkspaceId   = None
BronzeLHId    = None
CuratedLHId   = None
TaskList      = None
NotebookName  = None
LakehouseName = None
RawLHId       = None

print(f"Params: WorkspaceId={WorkspaceId}, BronzeLHId={BronzeLHId}, CuratedLHId={CuratedLHId}")

if WorkspaceId is None:
    # Example defaults (replace with your IDs if needed)
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId  = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

# Resolve base lakehouse path; get_basepath is provided by notebook_utils in Fabric
curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

def tbl_path(base, rel): 
    return f"{base}/Tables/{rel}" 

# Gold table location (single output table)
gold_rel  = "Gold/AivyToolUsage"
gold_path = tbl_path(curated_lh_id, gold_rel)
print("Gold Delta path:", gold_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

DELTA_REL    = "Silver/AivyChatHistory"        # tables folder relative path
DELTA_PATH   = tbl_path(curated_lh_id, DELTA_REL)

print("Silver Delta path     :", DELTA_PATH)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

silver_df = spark.read.format("delta").load(DELTA_PATH)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Step 2.1 (optional): Filter to a user and/or specific conversationIds while testing

from pyspark.sql import functions as F

USER_FILTER = 'mundadam'                 # e.g., "mundadam" or None to skip
KEEP_CONVS  = [
    "3e54dd83-b90c-428f-befb-777313ed0942",
    "2b6bfecf-2a2c-4451-a439-dd4bc29598e1",
    "cad87805-6d99-43f9-95b8-d761511b390c",
    "cd6c1139-4c3d-4328-a369-6bb2f95c887f",
    "0a0c0b1d-8c0a-453d-a151-42f86a4eab99",
    "a67862d8-efd3-49c2-b185-65eb7b4edaca",
    "2a1ded0c-85e6-48da-9d5e-4e48678b17be",
    "ef013376-cb83-4678-bf33-e03fd63f6a73"
]
                  # e.g., ["conv-1","conv-2"] or [] to skip

df_scoped = silver_df
if USER_FILTER:
    df_scoped = df_scoped.where(F.col("conversationUserId") == USER_FILTER)
if KEEP_CONVS:
    df_scoped = df_scoped.where(F.col("conversationId").isin(KEEP_CONVS))

print("Rows after optional filters:", df_scoped.count())
display(df_scoped.select("conversationId","conversationUserId","messageId","metadata_source","messageRole_category").limit(10))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Step 3: Build per-message flags 

from pyspark.sql import functions as F

# Choose/derive conv_user_key
has_conv_user_key = "conv_user_key" in silver_df.columns
has_conv   = "conversationId" in silver_df.columns
has_user   = "conversationUserId" in silver_df.columns

if has_conv_user_key:
    conv_expr = F.col("conv_user_key").cast("string")
    conv_note = "Using existing column conv_user_key"
elif has_conv and has_user:
    conv_expr = F.concat_ws("|",
                            F.col("conversationId").cast("string"),
                            F.col("conversationUserId").cast("string"))
    conv_note = "Derived conv_user_key = conversationId|conversationUserId"
elif has_conv:
    conv_expr = F.col("conversationId").cast("string")
    conv_note = "Fallback conv_user_key = conversationId (conversationUserId missing)"
else:
    conv_expr = F.sha2(F.coalesce(F.col("messageId").cast("string"), F.lit("")), 256)
    conv_note = "Fallback conv_user_key = sha256(messageId) (no conversation columns found)"

print("conv_user_key strategy:", conv_note)

# Normalize fields
prepared_df = (
    silver_df
      .withColumn("conv_user_key_norm", conv_expr)
      .withColumn("metadata_source_norm", F.lower(F.coalesce(F.col("metadata_source").cast("string"), F.lit(""))))
      .withColumn("message_content_norm", F.lower(F.coalesce(F.col("messageContent").cast("string"), F.lit(""))))
      .withColumn("message_role_norm",   F.lower(F.coalesce(F.col("messageRole_category").cast("string"), F.lit(""))))
)

# Mutually exclusive SmartSearch rules:
smart1_cond = (
    (F.col("metadata_source_norm") == F.lit("smart-search-2")) &
    F.col("message_content_norm").contains("reading data in crimson")
)
smart2_cond = (
    (F.col("metadata_source_norm") == F.lit("smart-search-2")) &
    (~smart1_cond)   # any smart-search-2 that is NOT SmartSearch1
)

msg_flags_df = prepared_df.select(
    F.col("messageId").cast("string").alias("messageId"),
    F.col("conversationId").cast("string").alias("conversationId"),
    F.col("conversationUserId").cast("string").alias("conversationUserId"),
    F.col("conv_user_key_norm").alias("conv_user_key"),

    smart1_cond.alias("SmartSearch1_msg"),
    smart2_cond.alias("SmartSearch2_msg"),
    (F.col("metadata_source_norm") == F.lit("web")).alias("Web_Search_msg"),
    (F.col("message_role_norm") == F.lit("attachment")).alias("Attachment_msg"),
    (F.col("metadata_source_norm") == F.lit("email")).alias("Ask_Aivy_msg"),
)

# Preview messages and verify exclusivity
display(
    msg_flags_df.select(
        "conversationId","messageId","conv_user_key",
        "SmartSearch1_msg","SmartSearch2_msg",
        "Web_Search_msg","Attachment_msg","Ask_Aivy_msg"
    ).orderBy("conversationId","messageId").limit(50)
)

# Sanity: ensure no message has both SmartSearch1 and SmartSearch2
both_true = msg_flags_df.where(F.col("SmartSearch1_msg") & F.col("SmartSearch2_msg")).count()
print({"smartsearch_both_true_messages": both_true})


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F

# Step 4: Conversation-level rollup from msg_flags_df

by_conv_df = (
    msg_flags_df
      .groupBy("conv_user_key")
      .agg(
          F.max("SmartSearch1_msg").alias("SmartSearch1"),
          F.max("SmartSearch2_msg").alias("SmartSearch2"),
          F.max("Web_Search_msg").alias("WebSearch"),
          F.max("Attachment_msg").alias("Attachment"),
          F.max("Ask_Aivy_msg").alias("AskAivy"),
      )
)

conv_flags_df = (
    by_conv_df
      .withColumn("InternalSearch", F.col("SmartSearch1") | F.col("SmartSearch2"))
      # None ignores Ask Aivy: only true if SS1, SS2, Web, Attachment are all false
      .withColumn(
          "None",
          ~(
              F.col("SmartSearch1") |
              F.col("SmartSearch2") |
              F.col("WebSearch")   |
              F.col("Attachment")   |
              (F.col("SmartSearch1") | F.col("SmartSearch2"))  # Internal Search (redundant but explicit)
          )
      )
      .select(
          "conv_user_key",
          "InternalSearch",
          "SmartSearch1",
          "SmartSearch2",
          "WebSearch",
          "Attachment",
          "AskAivy",
          "None"
      )
)

# Preview
display(conv_flags_df.orderBy("conv_user_key").limit(50))

# Verifications for your two rules
print({
    "internal_search_rule_violations":
        conv_flags_df.where(F.col("InternalSearch") != (F.col("SmartSearch1") | F.col("SmartSearch2"))).count(),
    "none_rule_violations_(AskAivy_ignored)":
        conv_flags_df.where(
            (F.col("None") == True) &
            ( F.col("SmartSearch1") | F.col("SmartSearch2") | F.col("WebSearch") | F.col("Attachment") |
              (F.col("SmartSearch1") | F.col("SmartSearch2")) )
        ).count()
})


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

(conv_flags_df
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(gold_path)
)

print("Wrote Delta to:", gold_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
