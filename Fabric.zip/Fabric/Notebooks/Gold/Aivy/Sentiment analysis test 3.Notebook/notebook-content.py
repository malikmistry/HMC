# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from delta.tables import DeltaTable
from pyspark.sql import functions as F, types as T
import os, json, time, requests
import pandas as pd

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

KV_URL = "https://KV-DC1Dev-ADF.vault.azure.net/"
os.environ['OPENAI_API_KEY'] = mssparkutils.credentials.getSecret(KV_URL, "OpenAI-API-Key")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Gold Delta table path (uses Fabric helper 'get_basepath')
WorkspaceId   = None
BronzeLHId    = None
CuratedLHId   = None
TaskList      = None
NotebookName  = None
LakehouseName = None
RawLHId       = None

print(f"Params: WorkspaceId={WorkspaceId}, BronzeLHId={BronzeLHId}, CuratedLHId={CuratedLHId}")

if WorkspaceId is None:
    # Example defaults (replace with your IDs if needed)
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId  = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

# Resolve base lakehouse path; get_basepath is provided by notebook_utils in Fabric
curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

def tbl_path(base, rel): 
    return f"{base}/Tables/{rel}" 

# Gold table location (single output table)
gold_rel  = "Gold/AivyConversationUserSentiment"
gold_path = tbl_path(curated_lh_id, gold_rel)
print("Gold Delta path:", gold_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Severity order: lower = more severe
REASON_TRIPLETS = [
    ("incorrect",         "Incorrect",            1),
    ("missing_info",      "Missing Information",  2),
    ("misinterpretation", "Misinterpretation",    3),
    ("rewording",         "Re-wording",           4),
]

# Map raw key -> label
REASON_LABEL_MAP = F.create_map(
    *[x for kv in [(F.lit(k), F.lit(v)) for k, v, _ in REASON_TRIPLETS] for x in kv]
)

# Map label -> order (we apply after overwriting ReasonCategory to the label)
REASON_ORDER_MAP = F.create_map(
    *[x for kv in [(F.lit(v), F.lit(o)) for _, v, o in REASON_TRIPLETS] for x in kv]
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

## Final step 1

# --------- Config ---------
SOURCE_TABLE      = "Silver.aivychathistory"
COL_CONV_ID       = "conversationId"
COL_USER_ID       = "conversationUserId"
COL_DISPLAYNAME   = "DisplayName"
COL_MSG_ID        = "messageId"
COL_ROLE          = "messageRole_category"
COL_ROLE_USER_VAL = "User"
COL_TEXT          = "messageContent"
COL_MSG_CREATED   = "messageCreatedAt"
COL_CONV_CREATED  = "conversationCreatedAt"

# --------- 0) Read source once ---------
chat = spark.table(SOURCE_TABLE).select(
    COL_CONV_ID, COL_USER_ID, COL_MSG_ID, COL_TEXT, COL_MSG_CREATED, COL_ROLE, COL_DISPLAYNAME, COL_CONV_CREATED
)

# --------- 1) State rollup (user-only) ---------
user_msgs = chat.filter(F.col(COL_ROLE) == F.lit(COL_ROLE_USER_VAL))

with_hash = user_msgs.withColumn(
    "msg_hash", F.sha2(F.coalesce(F.col(COL_TEXT), F.lit("")), 256)
)

ordered = (
    with_hash
    .groupBy(COL_CONV_ID, COL_USER_ID)
    .agg(
        F.sort_array(
            F.collect_list(
                F.struct(
                    F.col(COL_MSG_CREATED).alias("ts"),
                    F.col(COL_MSG_ID).alias("mid"),
                    F.col("msg_hash").alias("h")
                )
            )
        ).alias("arr")
    )
    .withColumn("concat_hashes", F.concat_ws("|", F.expr("transform(arr, x -> x.h)")))
    .withColumn("LastUserMessageCount", F.size(F.col("arr")))
    .withColumn("LastUserHashAgg", F.sha2(F.col("concat_hashes"), 256))
    .select(
        F.col(COL_CONV_ID).alias("ConversationId"),
        F.col(COL_USER_ID).alias("UserId"),
        "LastUserMessageCount","LastUserHashAgg"
    )
)

# --------- 2) Meta per conversation (from Silver) ---------
meta = (
    chat.groupBy(COL_CONV_ID, COL_USER_ID)
        .agg(
            F.min(COL_CONV_CREATED).alias("ConversationCreatedAt"),
            F.min(F.when(F.col(COL_ROLE)==COL_ROLE_USER_VAL, F.col(COL_MSG_CREATED))).alias("FirstUserMessageAt"),
            F.max(F.when(F.col(COL_ROLE)==COL_ROLE_USER_VAL, F.col(COL_MSG_CREATED))).alias("LastUserMessageAt"),
            F.max(F.col(COL_DISPLAYNAME)).alias("DisplayName")
        )
        .select(
            F.col(COL_CONV_ID).alias("ConversationId"),
            F.col(COL_USER_ID).alias("UserId"),
            "ConversationCreatedAt","FirstUserMessageAt","LastUserMessageAt","DisplayName"
        )
)

# --------- 3) Assemble state+meta and conv_user_key ---------
state_meta = (
    ordered.alias("s")
    .join(meta.alias("m"), on=["ConversationId","UserId"], how="left")
    .withColumn("conv_user_key", F.concat_ws("|", F.col("ConversationId").cast("string"), F.col("UserId").cast("string")))
    .withColumn("RunAt", F.current_timestamp())
)

# --------- 4) Create table if missing (with empty LLM columns), else MERGE safely ---------
gold_exists = DeltaTable.isDeltaTable(spark, gold_path)

if not gold_exists:
    # Create with final schema; LLM columns present but NULL (so later runs can fill them)
    create_df = (
        state_meta
        .withColumn("SentimentLabel", F.lit(None).cast(T.StringType()))
        .withColumn("Confidence", F.lit(None).cast(T.DoubleType()))
        .withColumn("ReasonCategory", F.lit(None).cast(T.StringType()))
        .withColumn("ReasonDetails", F.lit(None).cast(T.StringType()))
        .withColumn("MostDissatisfiedMessageId", F.lit(None).cast(T.StringType()))
        .withColumn("MostDissatisfiedMessageScore", F.lit(None).cast(T.DoubleType()))
        .withColumn("MostDissatisfiedMessageSnippet", F.lit(None).cast(T.StringType()))
        .withColumn("ReasonCategoryOrder", F.lit(None).cast(T.IntegerType()))
    )
    (create_df
        .write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema","true")
        .save(gold_path))
    print("Created Delta table at", gold_path)

else:
    tgt_df = spark.read.format("delta").load(gold_path)
    tgt_cols = {c.lower(): c for c in tgt_df.columns}

    G_COUNT_COL = tgt_cols.get("lastusermessagecount", tgt_cols.get("last_user_msg_count", "LastUserMessageCount"))
    G_HASH_COL  = tgt_cols.get("lastuserhashagg",     tgt_cols.get("last_user_hash_agg", "LastUserHashAgg"))

    # Build the source ("s") for merge with the exact target column names for state
    result_partial = (
        state_meta
        .withColumnRenamed("LastUserMessageCount", G_COUNT_COL)
        .withColumnRenamed("LastUserHashAgg", G_HASH_COL)
    )
    try:
        spark.sql(f"ALTER TABLE delta.`{gold_path}` ADD COLUMNS (ReasonCategoryOrder INT)")
    except Exception as e:
        if "already exists" not in str(e).lower():
            raise

    # Merge logic:
    # - When keys match AND (state changed OR meta is missing), update only state/meta + conv_user_key + RunAt
    # - On insert, populate all state/meta + conv_user_key; LLM columns remain NULL (or whatever default table has)
    tgt = DeltaTable.forPath(spark, gold_path)

    update_cond = f"(t.{G_COUNT_COL} <> s.{G_COUNT_COL} OR t.{G_HASH_COL} <> s.{G_HASH_COL} " \
                  f"OR t.ConversationCreatedAt IS NULL OR t.FirstUserMessageAt IS NULL " \
                  f"OR t.LastUserMessageAt IS NULL OR t.DisplayName IS NULL OR t.conv_user_key IS NULL)"

    (tgt.alias("t")
        .merge(
            result_partial.alias("s"),
            "t.ConversationId = s.ConversationId AND t.UserId = s.UserId"
        )
        .whenMatchedUpdate(
            condition=update_cond,
            set={
                G_COUNT_COL:           f"s.{G_COUNT_COL}",
                G_HASH_COL:            f"s.{G_HASH_COL}",
                "ConversationCreatedAt":"COALESCE(t.ConversationCreatedAt, s.ConversationCreatedAt)",
                "FirstUserMessageAt":  "COALESCE(t.FirstUserMessageAt,   s.FirstUserMessageAt)",
                "LastUserMessageAt":   "GREATEST(COALESCE(t.LastUserMessageAt, TIMESTAMP'1970-01-01'), COALESCE(s.LastUserMessageAt, TIMESTAMP'1970-01-01'))",
                "DisplayName":         "COALESCE(t.DisplayName, s.DisplayName)",
                "conv_user_key":       "COALESCE(t.conv_user_key, s.conv_user_key)",
                "RunAt":               "current_timestamp()"
            }
        )
        .whenNotMatchedInsert(values={
            "ConversationId":         "s.ConversationId",
            "UserId":                 "s.UserId",
            G_COUNT_COL:              f"s.{G_COUNT_COL}",
            G_HASH_COL:               f"s.{G_HASH_COL}",
            "ConversationCreatedAt":  "s.ConversationCreatedAt",
            "FirstUserMessageAt":     "s.FirstUserMessageAt",
            "LastUserMessageAt":      "s.LastUserMessageAt",
            "DisplayName":            "s.DisplayName",
            "conv_user_key":          "s.conv_user_key",
            "RunAt":                  "s.RunAt"
        })
        .execute())

    print("Merged state+meta changes into", gold_path)

# Peek
display(
    spark.read.format("delta").load(gold_path)
         .orderBy(F.col("RunAt").desc())
         .limit(20)
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ===== Step 2L (LLM-only targets) =====

# --- Source: user-side only ---
chat = spark.table(SOURCE_TABLE)
user_msgs_all = (
    chat
    .filter(F.col(COL_ROLE) == F.lit(COL_ROLE_USER_VAL))
    .select(COL_CONV_ID, COL_USER_ID, COL_MSG_ID, COL_TEXT, COL_MSG_CREATED)
)

if user_msgs_all.rdd.isEmpty():
    print("Step 2L: No USER messages. Nothing to score.")
    # still create empty views so Step 4 can exit cleanly
    spark.createDataFrame([], user_msgs_all.schema.add("clean_text", T.StringType())) \
         .createOrReplaceTempView("msgs_to_score_view_llm")
    spark.createDataFrame([], T.StructType([
        T.StructField(COL_CONV_ID, T.StringType()),
        T.StructField(COL_USER_ID, T.StringType()),
        T.StructField("LastUserMessageCount", T.IntegerType()),
        T.StructField("LastUserHashAgg", T.StringType()),
    ])).createOrReplaceTempView("conv_state_next_view_llm")
else:
    # --- Rollup for current snapshot (count + stable hash) ---
    with_hash = user_msgs_all.withColumn(
        "msg_hash", F.sha2(F.coalesce(F.col(COL_TEXT), F.lit("")), 256)
    )
    rollup_today = (
        with_hash
        .groupBy(COL_CONV_ID, COL_USER_ID)
        .agg(
            F.sort_array(
                F.collect_list(F.struct(
                    F.col(COL_MSG_CREATED).alias("ts"),
                    F.col(COL_MSG_ID).alias("mid"),
                    F.col("msg_hash").alias("h")
                ))
            ).alias("arr")
        )
        .withColumn("concat_hashes", F.concat_ws("|", F.expr("transform(arr, x -> x.h)")))
        .withColumn("user_msg_count_now", F.size(F.col("arr")))
        .withColumn("user_hash_agg_now", F.sha2(F.col("concat_hashes"), 256))
        .selectExpr(
            f"{COL_CONV_ID} as {COL_CONV_ID}",
            f"{COL_USER_ID} as {COL_USER_ID}",
            "user_msg_count_now",
            "user_hash_agg_now"
        )
    )

    # --- Determine targets using current Gold (robust to old/new column names) ---
    gold_exists = DeltaTable.isDeltaTable(spark, gold_path)
    if not gold_exists:
        # First-ever run: score everything we see today
        targets_conv_llm = rollup_today.select(COL_CONV_ID, COL_USER_ID).distinct()
    else:
        state_df_raw = spark.read.format("delta").load(gold_path)
        c = {x.lower(): x for x in state_df_raw.columns}

        # Map to canonical names regardless of legacy/new schema
        state_df = state_df_raw.select(
            F.col("ConversationId").alias(COL_CONV_ID),
            F.col("UserId").alias(COL_USER_ID),
            F.col(c.get("lastusermessagecount", c.get("last_user_msg_count"))).alias("LastUserMessageCount"),
            F.col(c.get("lastuserhashagg",     c.get("last_user_hash_agg"))).alias("LastUserHashAgg"),
            F.col(c.get("sentimentlabel",      c.get("l_label"))).alias("SentimentLabel")
        )

        cmp = rollup_today.alias("n").join(state_df.alias("s"), on=[COL_CONV_ID, COL_USER_ID], how="left")

        targets_conv_llm = (
            cmp.filter(
                # new conversation (no state row yet)
                F.col("s.LastUserMessageCount").isNull() |
                # changed user message count/hash
                (F.col("n.user_msg_count_now") != F.col("s.LastUserMessageCount")) |
                (F.col("n.user_hash_agg_now")  != F.col("s.LastUserHashAgg")) |
                # not yet LLM-labeled
                F.col("s.SentimentLabel").isNull()
            )
            .select(f"n.{COL_CONV_ID}", f"n.{COL_USER_ID}")
            .distinct()
        )

    target_count = targets_conv_llm.count()
    total_convs  = rollup_today.select(COL_CONV_ID).distinct().count()
    print(f"Step 2L: {target_count} conversation(s) need LLM scoring (out of {total_convs}).")

    # --- Build message packets to score (ordered) ---
    if target_count == 0:
        msgs_to_score_llm = spark.createDataFrame([], user_msgs_all.schema.add("clean_text", T.StringType()))
        conv_state_next_llm = spark.createDataFrame([], T.StructType([
            T.StructField(COL_CONV_ID, T.StringType()),
            T.StructField(COL_USER_ID, T.StringType()),
            T.StructField("LastUserMessageCount", T.IntegerType()),
            T.StructField("LastUserHashAgg", T.StringType()),
        ]))
    else:
        msgs_to_score_llm = (
            user_msgs_all.alias("m")
            .join(targets_conv_llm.alias("t"), on=[COL_CONV_ID, COL_USER_ID], how="inner")
            .withColumn("clean_text", F.trim(F.col(COL_TEXT)))
            .orderBy(F.col(COL_CONV_ID), F.col(COL_MSG_CREATED), F.col(COL_MSG_ID))
        )

        conv_state_next_llm = (
            rollup_today.alias("n")
            .join(targets_conv_llm.alias("t"), on=[COL_CONV_ID, COL_USER_ID], how="inner")
            .selectExpr(
                f"n.{COL_CONV_ID} as {COL_CONV_ID}",
                f"n.{COL_USER_ID} as {COL_USER_ID}",
                # expose the new state column names for Step 4 to upsert
                "user_msg_count_now as LastUserMessageCount",
                "user_hash_agg_now  as LastUserHashAgg"
            )
        )

    msgs_to_score_llm.createOrReplaceTempView("msgs_to_score_view_llm")
    conv_state_next_llm.createOrReplaceTempView("conv_state_next_view_llm")
    print("Views ready: msgs_to_score_view_llm, conv_state_next_view_llm")
    display(msgs_to_score_llm.limit(30))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ===== Step 3 (LLM-only): Conversation-level LLM judge -> MERGE into Gold =====
import os, json, time, requests
import pandas as pd
from pyspark.sql import functions as F
from delta.tables import DeltaTable

# --- prefer LLM-only views if present; otherwise fallback to non-LLM views (if any exist) ---
def _safe_load_view(primary: str, fallback: str):
    try:
        return spark.table(primary)
    except Exception:
        return spark.table(fallback)

msgs_df         = _safe_load_view("msgs_to_score_view_llm", "msgs_to_score_view")
conv_state_next = _safe_load_view("conv_state_next_view_llm", "conv_state_next_view")

if msgs_df.rdd.isEmpty():
    print("Step 4: nothing to score (LLM views are empty).")
else:
    # --- 1) Build one packet per conversation: ordered user messages (IDs + timestamps + compacted text) ---
    def is_payload_like(txt: str) -> bool:
        if not txt:
            return False
        t = txt.lower()
        return ("```" in t) or (len(txt) > 1200) or (txt.count("\n") > 30) or ("http://" in t) or ("https://" in t)

    grouped = (
        msgs_df.select(
            F.col(COL_CONV_ID).alias("cid"),
            F.col(COL_USER_ID).alias("uid"),
            F.col(COL_MSG_ID).alias("id"),
            F.col(COL_MSG_CREATED).alias("ts"),
            F.col("clean_text").alias("text"),
            F.col(COL_TEXT).alias("orig_text"),
        )
        .groupBy("cid", "uid")
        .agg(F.sort_array(F.collect_list(F.struct("ts","id","text","orig_text"))).alias("msgs"))
    ).toPandas()

    def to_packet(rows):
        out = []
        for r in rows:
            t = r["text"] or ""
            content = "[TASK PAYLOAD REDACTED]" if is_payload_like(t) else t
            out.append({"id": r["id"], "ts": str(r["ts"]), "text": content})
        return out

    grouped["packet"] = grouped["msgs"].apply(to_packet)

    # --- 2) OpenAI call (JSON mode) ---
    OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not set for this notebook/session.")

    OPENAI_CHAT_URL = "https://api.openai.com/v1/chat/completions"
    MODEL = os.environ.get("OPENAI_CHAT_MODEL", "gpt-4o-mini")
    HEADERS = {"Content-Type": "application/json", "Authorization": f"Bearer {OPENAI_API_KEY}"}

    SYSTEM_PROMPT = """You are a strict evaluator of a conversation's USER-ONLY messages to infer satisfaction with the chatbot's answers.
Input: an ordered list of the user's messages only (no assistant messages).
Goals:
1) Decide final conversation label: "satisfied", "dissatisfied", or "unclear".
   - Prefer signals from the later messages.
   - If later messages show "thanks/that worked", label satisfied unless contradicted later.
   - If messages are mostly task payload (code/data/URLs) without a clear reaction, label "unclear".
2) Identify the single most dissatisfied user message (its messageId) if any.
3) If dissatisfied, choose ONE reason category:
   - rewording (same info, better wording/structure)
   - missing_info (info incomplete/missing)
   - misinterpretation (assistant misunderstood names/entities/context)
   - incorrect (answer wrong/contradictory/causes errors)

Rules: Use ONLY the given user messages. Ignore task payload. Prefer "unclear" over guessing. Weigh recency more.

Return STRICT JSON ONLY:
{
  "label": "satisfied|dissatisfied|unclear",
  "confidence": 0..1,
  "most_dissat_msg_id": "<messageId or null>",
  "most_dissat_confidence": 0..1,
  "reason_category": "rewording|missing_info|misinterpretation|incorrect|none",
  "reason_details": "<=160 chars"
}
"""

    def call_llm_conv_openai(packet: list, retries: int = 2, backoff: float = 2.0) -> dict:
        body = {
            "model": MODEL,
            "temperature": 0,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": json.dumps({"user_messages": packet}, ensure_ascii=False)},
            ],
        }
        for attempt in range(retries + 1):
            r = requests.post(OPENAI_CHAT_URL, headers=HEADERS, json=body, timeout=60)
            if r.status_code == 200:
                try:
                    return json.loads(r.json()["choices"][0]["message"]["content"])
                except Exception as e:
                    return {"label":"unclear","confidence":0.4,"most_dissat_msg_id":None,
                            "most_dissat_confidence":0.0,"reason_category":"none",
                            "reason_details": f"parse_error: {type(e).__name__}"}
            if r.status_code in (429, 500, 502, 503, 504) and attempt < retries:
                time.sleep(backoff * (2 ** attempt))
                continue
            try:
                detail = r.json()
            except Exception:
                detail = {"raw": r.text[:400]}
            return {"label":"unclear","confidence":0.4,"most_dissat_msg_id":None,
                    "most_dissat_confidence":0.0,"reason_category":"none",
                    "reason_details": f"call_error: HTTP {r.status_code}: {str(detail)[:180]}"}

    # --- 3) One call per conversation; normalize outputs -> lowercase working cols ---
    REASON_CATEGORIES = {"rewording","missing_info","misinterpretation","incorrect","none"}
    rows = []
    for _, rec in grouped.iterrows():
        conv_id = rec["cid"]
        user_id = rec["uid"]
        packet  = rec["packet"]

        obj = call_llm_conv_openai(packet)
        label = str(obj.get("label","unclear")).lower().strip()
        if label not in ("satisfied","dissatisfied","unclear"): label = "unclear"
        cat   = str(obj.get("reason_category","none")).lower().strip()
        if cat not in REASON_CATEGORIES: cat = "none"
        det   = str(obj.get("reason_details","")).strip()[:160]
        conf  = float(obj.get("confidence", 0.0))
        most_id   = obj.get("most_dissat_msg_id", None)
        most_conf = float(obj.get("most_dissat_confidence", 0.0))

        rows.append({
            COL_CONV_ID: conv_id,
            COL_USER_ID: user_id,
            "SentimentLabel": label,
            "Confidence": conf,
            "MostDissatisfiedMessageId": most_id,
            "MostDissatisfiedMessageScore": most_conf if most_id else None,
            "ReasonCategory": cat,
            "ReasonDetails": det
        })

    conv_out = spark.createDataFrame(pd.DataFrame(rows))

    # --- Convert raw ReasonCategory -> label, then set numeric order ---
    conv_out = (
        conv_out
        .withColumn("ReasonCategory", F.coalesce(REASON_LABEL_MAP.getItem(F.col("ReasonCategory")), F.col("ReasonCategory")))
        .withColumn("ReasonCategoryOrder", REASON_ORDER_MAP.getItem(F.col("ReasonCategory")).cast("int"))
    )


    # --- 4) Fill snippet for the chosen message ---
    snips = (
        msgs_df
        .select(
            F.col(COL_CONV_ID).alias("cid"),
            F.col(COL_USER_ID).alias("uid"),
            F.col(COL_MSG_ID).alias("join_msg_id"),
            F.substring(F.col(COL_TEXT), 1, 160).alias("MostDissatisfiedMessageSnippet")
        )
        .dropDuplicates(["cid","uid","join_msg_id"])
    )

    co = conv_out.alias("co"); sn = snips.alias("sn")
    conv_out = (
        co.join(
            sn,
            (co[COL_CONV_ID] == sn["cid"]) &
            (co[COL_USER_ID] == sn["uid"]) &
            (co["MostDissatisfiedMessageId"] == sn["join_msg_id"]),
            "left"
        )
        .drop("cid","uid","join_msg_id")
    )

    # --- 5) Join updated state (from Step 2L); then rename keys to PascalCase for MERGE ---
    o = conv_out.alias("o")
    n = conv_state_next.select(
            F.col(COL_CONV_ID).alias("cid"),
            F.col(COL_USER_ID).alias("uid"),
            "LastUserMessageCount","LastUserHashAgg"
        ).alias("n")

    result_partial = (
        o.join(n, (o[COL_CONV_ID]==n["cid"]) & (o[COL_USER_ID]==n["uid"]), "inner")
         .select(
            o[COL_CONV_ID].alias("ConversationId"),
            o[COL_USER_ID].alias("UserId"),
            n["LastUserMessageCount"],
            n["LastUserHashAgg"],
            o["SentimentLabel"], o["Confidence"],
            o["MostDissatisfiedMessageId"], o["MostDissatisfiedMessageScore"], o["MostDissatisfiedMessageSnippet"],
            o["ReasonCategory"], o["ReasonDetails"],o["ReasonCategoryOrder"]
         )
         .withColumn("RunAt", F.current_timestamp())
    )

    # --- 6) MERGE into Gold (PascalCase) ---
    tgt = DeltaTable.forPath(spark, gold_path)  # or DeltaTable.forName(spark, "Gold.AivyConversationUserSentiment")
    (tgt.alias("t")
       .merge(result_partial.alias("s"),
              "t.ConversationId = s.ConversationId AND t.UserId = s.UserId")
       .whenMatchedUpdate(set={
           "LastUserMessageCount":          "s.LastUserMessageCount",
           "LastUserHashAgg":               "s.LastUserHashAgg",
           "SentimentLabel":                "s.SentimentLabel",
           "Confidence":                    "s.Confidence",
           "MostDissatisfiedMessageId":     "s.MostDissatisfiedMessageId",
           "MostDissatisfiedMessageScore":  "s.MostDissatisfiedMessageScore",
           "MostDissatisfiedMessageSnippet":"s.MostDissatisfiedMessageSnippet",
           "ReasonCategory":                "s.ReasonCategory",
           "ReasonDetails":                 "s.ReasonDetails",
           "ReasonCategoryOrder":           "s.ReasonCategoryOrder",
           "RunAt":                         "s.RunAt"
       })
       .whenNotMatchedInsert(values={
           "ConversationId":                "s.ConversationId",
           "UserId":                        "s.UserId",
           "LastUserMessageCount":          "s.LastUserMessageCount",
           "LastUserHashAgg":               "s.LastUserHashAgg",
           "SentimentLabel":                "s.SentimentLabel",
           "Confidence":                    "s.Confidence",
           "MostDissatisfiedMessageId":     "s.MostDissatisfiedMessageId",
           "MostDissatisfiedMessageScore":  "s.MostDissatisfiedMessageScore",
           "MostDissatisfiedMessageSnippet":"s.MostDissatisfiedMessageSnippet",
           "ReasonCategory":                "s.ReasonCategory",
           "ReasonDetails":                 "s.ReasonDetails",
           "ReasonCategoryOrder":           "s.ReasonCategoryOrder",
           "RunAt":                         "s.RunAt"
       })
       .execute())

    print("Step 4: Conversation-level LLM results merged into Gold (OpenAI).")
    display(
        spark.read.format("delta").load(gold_path)
             .orderBy(F.col("RunAt").desc())
             .limit(20)
    )


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
