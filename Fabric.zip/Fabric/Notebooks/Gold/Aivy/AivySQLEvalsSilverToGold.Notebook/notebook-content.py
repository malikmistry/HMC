# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F, types as T
from delta.tables import DeltaTable
from notebookutils import credentials
import requests
import json
import datetime

####################
spark.conf.set('spark.sql.caseSensitive', True)
####################

EVAL_SILVER_TBL = "lh_curated.Silver.AivyEvals"
EVAL_GOLD_SQL_TBL = "lh_curated.Gold.AivyEvalsSqlFact"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


if not spark.catalog.tableExists(EVAL_GOLD_SQL_TBL):
    (
        spark.createDataFrame([], schema=T.StructType([
            T.StructField("eval_timestamp",  T.TimestampType(), True),
            T.StructField("eval_timestamp_boston",  T.TimestampType(), True),
            T.StructField("eval_date",       T.DateType(),      True),
            T.StructField("source_env",      T.StringType(),    True),
            T.StructField("metric_name",     T.StringType(),    True),
            T.StructField("metric_type",     T.StringType(),    True),
            T.StructField("metric_value",    T.DoubleType(),    True),
            T.StructField("question",        T.StringType(),    True),
            T.StructField("time_taken_sec",  T.DoubleType(),    True),
            T.StructField("retry_count",        T.IntegerType(),   True),
            T.StructField("metadata_json",        T.StringType(),   True),
            T.StructField("success",         T.BooleanType(),   True),
            T.StructField("ingested_at",     T.TimestampType(), True),
            T.StructField("gold_row_id",     T.StringType(),    True),
        ]))
        .write.format("delta")
        .partitionBy("eval_date")
        .mode("overwrite")
        .saveAsTable(EVAL_GOLD_SQL_TBL)
    )

try:
    watermark_ts = spark.table(EVAL_GOLD_SQL_TBL).select(F.max("eval_timestamp").alias("mx")).first().mx
except Exception:
    watermark_ts = None

src = spark.table(EVAL_SILVER_TBL).where(F.col("metric_name") == "sql_eval")
if watermark_ts is not None:
    src = src.filter(F.col("eval_timestamp") > F.lit(watermark_ts))
MAX_LENGTH = 10000
new_rows = (
    src.select(
        F.col("eval_timestamp"),
        F.from_utc_timestamp(F.col("eval_timestamp"), "America/New_York").alias("eval_timestamp_boston"),
        F.col("eval_date"),
        F.col("source_env"),
        F.col("metric_name"),
        F.col("metric_type").cast("string"),
        F.col("metric_value").cast("double"),
        F.get_json_object("metadata_json", "$.query").alias("question"),
        F.get_json_object("metadata_json", "$.response_time").cast("double").alias("time_taken_sec"),
        F.get_json_object("metadata_json", "$.retry_count").cast("int").alias("retry_count"),
        F.substring(F.col("metadata_json"), 1, MAX_LENGTH).alias("metadata_json"),
        F.col("success"),
        F.current_timestamp().alias("ingested_at"),
    )
    .withColumn(
        "gold_row_id",
        F.sha2(F.concat_ws("|",
            F.col("eval_timestamp").cast("string"),
            F.col("source_env"),
            F.coalesce(F.col("question"), F.lit(""))
        ), 256)
    )
)

DeltaTable.forName(spark, EVAL_GOLD_SQL_TBL) \
    .alias("t") \
    .merge(new_rows.alias("s"), "t.gold_row_id = s.gold_row_id") \
    .whenNotMatchedInsertAll() \
    .execute()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
