# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse_name": "",
# META       "default_lakehouse_workspace_id": "",
# META       "known_lakehouses": []
# META     }
# META   }
# META }

# CELL ********************

# Import required libraries
from pyspark.sql import functions as F
from delta.tables import DeltaTable
from datetime import datetime, date, timedelta, timezone

spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
print(etlloadtime)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
Tasklist = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tasklist = json.loads(f"[{TaskList}]")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


def process_task(lh_bronze_basepath, lh_curated_basepath, task):
    source_path = f"{lh_bronze_basepath}/Tables/{task['SourceSchemaName']}/{task['SourceTableName']}"
    target_path = f"{lh_curated_basepath}/Tables/{task['SinkSchemaName']}/{task['SinkTableName']}"

    # mapping of TimePeriodId to column names
    time_period_map = {
        1: "CYTD",
        2: "FYTD",
        3: "ITD",
        4: "HMCITD",
        5: "OneYear",
        6: "ThreeYear",
        7: "FiveYear",
        8: "SevenYear",
        9: "TenYear",
        11: "FifteenYear",
        12: "TwentyYear"
    }
    #read base data from Bronze
    stats_df = (
        spark.read.format("delta").load(source_path)
        .filter(
            (F.col("CustomRiskBenchmark").isNotNull()) &
            (F.col("FundStatisticReferenceTypeId") == 1) &
            (F.col("FundId").isNotNull())            
        )
        .select(
            F.col("FundId"),
            F.col("TimePeriodId"),
            F.col("CustomRiskBenchmark").alias("Value"),
            F.col("AsOfDate")
        )
    )

    #pivot
    pivoted_df = (
        stats_df
        .groupBy("FundId", "AsOfDate")
        .pivot("TimePeriodId", list(time_period_map.keys()))
        .agg(F.first("Value"))
    )

    #rename columns using the mapping
    for tp_id, col_name in time_period_map.items():
        if str(tp_id) in pivoted_df.columns:
            pivoted_df = pivoted_df.withColumnRenamed(str(tp_id), col_name)

    # add AsOfDate + ETLLoadDateTime
    pivoted_df = (
        pivoted_df
        .withColumn("ETLLoadDateTime", lit(etlloadtime))
    )


    # Ensure target table exists
    if DeltaTable.isDeltaTable(spark, target_path):
        target = DeltaTable.forPath(spark, target_path)

        # Merge on FundId + AsOfDate (assuming these uniquely identify a record)
        (
            target.alias("t")
            .merge(
                pivoted_df.alias("s"),
                "t.FundId = s.FundId AND t.AsOfDate = s.AsOfDate"
            )
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute()
        )
    else:
        # First-time write, just create the table
        pivoted_df.write.format("delta").mode("overwrite").save(target_path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)
        process_task(bronze_lh_basepath,curated_lh_basepath,task_item)
    except Exception as e:
        # mssparkutils.notebook.exit(f"FAILED: {e}")
        raise


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
