# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%pip install openai>=1.42.0

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F, types as T
from openai import OpenAI

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

KV_URL = "https://KV-DC1Dev-ADF.vault.azure.net/"
os.environ['OPENAI_API_KEY'] = mssparkutils.credentials.getSecret(KV_URL, "OpenAI-API-Key")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# ---------- inputs ----------
# assumes bronze_lh_id / curated_lh_id are already set via get_basepath(...)
tenable_rel    = "Silver/SecurityRecordedAlertsTenable"
wiz_rel        = "Silver/SecurityRecordedAlertsWiz"
bluevoyant_rel = "Silver/SecurityRecordedAlertsBlueVoyant"

gold_rel = "Gold/SecurityRecordedAlerts"



# Added IsResolved to the target schema
TARGET_COLS = ["Type","RecordedAlerts","Description","RiskLevel","Reported","Resolved","IsResolved"]

def ensure_types(df):
    # normalize RiskLevel case and compute IsResolved (boolean)
    return (
        df
        .withColumn("Reported", F.col("Reported").cast(T.TimestampType()))
        .withColumn("Resolved", F.col("Resolved").cast(T.TimestampType()))
        # Standardize RiskLevel casing; e.g., HIGH -> High
        .withColumn(
            "RiskLevel",
            F.when(F.col("RiskLevel").isNull(), F.lit(None).cast(T.StringType()))
             .otherwise(F.initcap(F.lower(F.trim(F.col("RiskLevel")))))
        )
        # True when there's a date in Resolved, else False
        .withColumn("IsResolved", F.col("Resolved").isNotNull())
        .select(*TARGET_COLS)
    )

# ---------- read Silver sources from lh_curated ----------
tenable_df    = ensure_types(read_delta(curated_lh_id, tenable_rel))
wiz_df        = ensure_types(read_delta(curated_lh_id, wiz_rel))
bluevoyant_df = ensure_types(read_delta(curated_lh_id, bluevoyant_rel))

# ---------- union & distinct ----------
gold_df = (
    tenable_df
    .unionByName(wiz_df, allowMissingColumns=True)
    .unionByName(bluevoyant_df, allowMissingColumns=True)
    .dropDuplicates()
)

# ---------- OpenAI: add DescriptionHuman (Network only) ----------
NEW_COL = "DescriptionHuman"
if NEW_COL not in TARGET_COLS:
    TARGET_COLS = TARGET_COLS + [NEW_COL]

# Collect distinct Network descriptions
net_descs_df = (
    gold_df
    .filter(F.col("Type") == "Network")
    .select("Description")
    .where(F.col("Description").isNotNull())
    .distinct()
)

raw_list = [r["Description"] for r in net_descs_df.collect()]

client = OpenAI()
MODEL_NAME = "gpt-4o-mini"
BATCH_SIZE = 100  # safe size to avoid truncation

def batched(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i+n]

if raw_list:
    sys_msg = (
        """Rewrite each security or network alert title into ONE short, natural sentence in plain English.
        Avoid repeating the title verbatim or sounding like patch notes. Explain the actual risk.
        If an ID like GHSA/CVE/CTX appears, say it's a vulnerability/advisory ID (no extra detail).
        Keep it under ~20 words. No markdown."""
    )

    all_rewrites = []
    for batch in batched(raw_list, BATCH_SIZE):
        user_msg = (
            f"Rewrite each item into one sentence. Return ONLY valid JSON of the form "
            "{\"rewrites\": [ ... ]} in the same order as input.\n\nINPUT:\n"
            + json.dumps(batch, ensure_ascii=False)
        )

        resp = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {"role": "system", "content": sys_msg},
                {"role": "user", "content": user_msg},
            ],
            temperature=0.3,
            response_format={"type": "json_object"},
        )

        content = resp.choices[0].message.content
        parsed = json.loads(content)
        rewrites = parsed.get("rewrites", [])
        # defensively align lengths
        if len(rewrites) != len(batch):
            rewrites = (rewrites + batch)[:len(batch)]
        all_rewrites.extend(rewrites)

    # one-to-one with raw_list now
    human_list = all_rewrites

    # Build mapping DF and join back to gold_df
    mapping_df = spark.createDataFrame(
        list(zip(raw_list, human_list)),
        schema=T.StructType([
            T.StructField("Description", T.StringType(), True),
            T.StructField("_human_tmp", T.StringType(), True),
        ])
    )

    gold_df = (
        gold_df
        .join(mapping_df, on="Description", how="left")
        .withColumn(
            NEW_COL,
            F.when(F.col("Type") == "Network",
                   F.coalesce(F.col("_human_tmp"), F.col("Description")))
             .otherwise(F.col("Description"))
        )
        .drop("_human_tmp")
        .select(*TARGET_COLS)
    )
else:
    gold_df = gold_df.withColumn(NEW_COL, F.col("Description")).select(*TARGET_COLS)
# --- end batching block ---


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# ---------- write to Gold in lh_curated ----------
target_path = tbl_path(curated_lh_id, gold_rel)

(gold_df.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(target_path)
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
