# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.types import *
import json
from delta.tables import DeltaTable
from datetime import datetime, timezone, date, timedelta
from pyspark.sql.types import (
StructType, StructField, StringType, DateType, BooleanType,
DecimalType, IntegerType, ArrayType
)

spark.conf.set("spark.sql.caseSensitive","true")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
print(etlloadtime)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "[{\"JobAuditKey\":3278,\"TaskKey\":315,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Silver\",\"SourceTableName\":\"UserRating\",\"SinkTableName\":\"GroupRating\",\"SinkSchemaName\":\"Gold\",\"NotebookKeyNotebookKey\":\"71\",\"NotebookName\":\"GroupRatingGold\",\"SinkLakehouseName\":\"lh_curated\",\"RawStoragePath\":null,\"RawStorageFileName\":null,\"RelativeUrl\":null}]"
NotebookName = "GroupRatingGold"
LakehouseName = "lh_curated"
RawLHId = "920a12cc-7104-4013-a2a3-d7baa57e9e3f"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList =''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

if TaskList.strip().startswith("[") and TaskList.strip().endswith("]"):
    tasklist = json.loads(f"{TaskList}")
else:
    tasklist = json.loads(f"[{TaskList}]")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


def process_task(task):
    try:
        # Define paths
        userrating_path = f"{curated_lh_basepath}/Tables/Silver/UserRating"
        entity_path = f"{curated_lh_basepath}/Tables/Silver/Entity"
        hmcuser_path = f"{curated_lh_basepath}/Tables/Silver/HMCUser"
        target_path = f"{curated_lh_basepath}/Tables/Gold/GroupRating"
        target_table = "GroupRating"

        try:
            ddl_path = f"{curated_lh_basepath}/Files/DDLScripts/Gold"
            execute_ddl(target_table, ddl_path)
        except:
            print("No DDL Script")

        # Load Silver data
        df_user_raw = spark.read.format("delta").load(userrating_path)
        df_entity = spark.read.format("delta").load(entity_path)
        df_hmcuser = spark.read.format("delta").load(hmcuser_path)

        print(f"[LOAD] UserRating (raw): {df_user_raw.count()} rows")
        print(f"[LOAD] Entity: {df_entity.count()} rows")
        print(f"[LOAD] HMCUser (all): {df_hmcuser.count()} rows")

        #building entity rating ranges (2 years back) from all userrating rows
        df_entityranges = (
            df_user_raw.select("EntityId", "EffectiveDate").distinct()
            .withColumn("EndDate", F.col("EffectiveDate"))
            .withColumn("StartDate", F.add_months(F.col("EffectiveDate"), -24))
            .select("EntityId", "EndDate", "StartDate")
        )
        print(f"[DEBUG] EntityRanges count: {df_entityranges.count()}")

        #join userrating within each 2-year window
        df_inrange = (
            df_entityranges.alias("er")
            .join(df_user_raw.alias("ur"),
                (F.col("er.EntityId") == F.col("ur.EntityId")) &
                (F.col("ur.EffectiveDate").between(F.col("er.StartDate"), F.col("er.EndDate"))),
                "inner")
            .select(
                F.col("er.EntityId").alias("EntityId"),
                F.col("ur.RatedByUserId").alias("RatedByUserId"),
                F.col("er.StartDate").alias("StartDate"),
                F.col("er.EndDate").alias("EndDate"),
                F.col("ur.EffectiveDate").alias("UserEffectiveDate"),
                F.col("ur.InvestmentEdgeRating"),
                F.col("ur.OrganizationalEdgeRating"),
                F.col("ur.TrackRecordRating")
            )
        )
        print(f"[DEBUG] In-range join count: {df_inrange.count()}")

        #kep only the latest rating per user-window
        w_latest_user = Window.partitionBy(
            "EntityId", "RatedByUserId", "StartDate", "EndDate"
        ).orderBy(F.col("UserEffectiveDate").desc())

        df_latest_per_user = (
            df_inrange.withColumn("rn", F.row_number().over(w_latest_user))
                    .filter(F.col("rn") == 1)
                    .drop("rn")
        )
        print(f"[DEBUG] Latest per user-window (rn=1) count: {df_latest_per_user.count()}")

        #join to keep only active users
        df_hmcuser_active = df_hmcuser.filter(F.col("IsActive") == 1).select("HMCUserId")
        df_latest_per_user_active = df_latest_per_user.join(
            df_hmcuser_active,
            df_latest_per_user.RatedByUserId == df_hmcuser_active.HMCUserId,
            "inner"
        ).drop("HMCUserId")
        print(f"[DEBUG] rn=1 filtered to active users: {df_latest_per_user_active.count()}")

        #avg per entity per date range
        df_group = (
            df_latest_per_user_active.groupBy("EntityId", "EndDate", "StartDate")
            .agg(
                F.avg("InvestmentEdgeRating").alias("InvestmentEdgeRating"),
                F.avg("OrganizationalEdgeRating").alias("OrganizationalEdgeRating"),
                F.avg("TrackRecordRating").alias("TrackRecordRating"),
                (F.avg("InvestmentEdgeRating") * 0.4 +
                F.avg("OrganizationalEdgeRating") * 0.3 +
                F.avg("TrackRecordRating") * 0.3).alias("OverallRating"),
                F.count("*").alias("RatingCount")
            )
            .withColumnRenamed("EndDate", "EffectiveDate")
        )
        print(f"[DEBUG] Grouped entity averages: {df_group.count()} rows")

        #flag latest record per entity - only if entity has rating in last 24 months
        df_latest_flag = (
            df_group.groupBy("EntityId").agg(F.max("EffectiveDate").alias("LatestDate"))
        )

        # Get the global latest EffectiveDate across all entities
        global_latest_date = df_group.agg(F.max("EffectiveDate")).collect()[0][0]
        cutoff_date = F.add_months(F.lit(global_latest_date), -24)

        df_group = (
            df_group.join(df_latest_flag, "EntityId", "left")
            .withColumn(
                "HasRecentRating",
                F.when(F.col("LatestDate") >= cutoff_date, True).otherwise(False)
            )
            .withColumn("IsLatest",
                F.when(
                    (F.col("HasRecentRating") == True) &
                    (F.col("EffectiveDate") == F.col("LatestDate")),
                    True
                ).otherwise(False)
            ).drop("LatestDate", "HasRecentRating")
            .withColumnRenamed("EffectiveDate", "AsOfDate")
        )

        print("Computed IsLatest flag")

        #deal Team ratings
        df_entity = df_entity.withColumn(
            "DealTeam",
            F.expr("""
                array_distinct(
                    filter(array(PrimaryOwner, SecondaryOwner, TertiaryOwner, Associate), x -> x is not null)
                )
            """)
        ).select("EntityId", "DealTeam")

        df_group = df_group.join(df_entity, "EntityId", "left")
        print("Joined DealTeam info")

        #compute normalization and percentiles
        stats = df_group.agg(
            F.min("OverallRating").alias("minOverall"),
            F.max("OverallRating").alias("maxOverall"),
            F.stddev("OverallRating").alias("stdOverall")
        ).collect()[0]

        min_val = stats["minOverall"] or 0
        max_val = stats["maxOverall"] or 1
        std_val = stats["stdOverall"] or 0

        df_group = df_group.withColumn(
            "NormalizedOverallRating",
            F.round(((F.col("OverallRating") - F.lit(min_val)) / (F.lit(max_val - min_val))) * 100, 2)
        )

        df_group = df_group.withColumn(
            "Percentile",
            F.round(F.percent_rank().over(Window.orderBy("OverallRating")), 6)
        ).withColumn("MinPercentile", F.lit(0.0)) \
        .withColumn("MaxPercentile", F.lit(1.0)) \
        .withColumn("StdDev", F.lit(std_val))

        #initialize DealTeam rating columns to zero
        df_group = (
            df_group
            .withColumn("DealTeamInvestmentEdgeRating", F.lit(0).cast(DecimalType(38, 2)))
            .withColumn("DealTeamOrganizationalEdgeRating", F.lit(0).cast(DecimalType(38, 2)))
            .withColumn("DealTeamTrackRecordRating", F.lit(0).cast(DecimalType(38, 2)))
            .withColumn("DealTeamOverallRating", F.lit(0).cast(DecimalType(38, 2)))
            .withColumn("DealTeamNormalizedOverallRating", F.lit(None).cast(DecimalType(38, 2)))
        )
        print("Computed normalization and placeholder DealTeam ratings")

        # Schema enforcement and writing
        df_final = df_group.select(
            F.col("EntityId").cast(StringType()).alias("EntityId"),
            F.col("AsOfDate").cast(DateType()).alias("AsOfDate"),
            F.col("IsLatest").cast(BooleanType()).alias("IsLatest"),
            F.round(F.col("InvestmentEdgeRating"), 2).cast(DecimalType(38, 2)).alias("InvestmentEdgeRating"),
            F.round(F.col("OrganizationalEdgeRating"), 2).cast(DecimalType(38, 2)).alias("OrganizationalEdgeRating"),
            F.round(F.col("TrackRecordRating"), 2).cast(DecimalType(38, 2)).alias("TrackRecordRating"),
            F.round(F.col("OverallRating"), 2).cast(DecimalType(38, 2)).alias("OverallRating"),
            F.round(F.col("NormalizedOverallRating"), 2).cast(DecimalType(38, 2)).alias("NormalizedOverallRating"),
            F.round(F.col("Percentile"), 6).cast(DecimalType(38, 6)).alias("Percentile"),
            F.col("MinPercentile").cast(DecimalType(38, 6)).alias("MinPercentile"),
            F.col("MaxPercentile").cast(DecimalType(38, 6)).alias("MaxPercentile"),
            F.round(F.col("StdDev"), 11).cast(DecimalType(38, 11)).alias("StdDev"),
            F.col("DealTeam").alias("DealTeam"),
            F.col("DealTeamInvestmentEdgeRating").alias("DealTeamInvestmentEdgeRating"),
            F.col("DealTeamOrganizationalEdgeRating").alias("DealTeamOrganizationalEdgeRating"),
            F.col("DealTeamTrackRecordRating").alias("DealTeamTrackRecordRating"),
            F.col("DealTeamOverallRating").alias("DealTeamOverallRating"),
            F.col("DealTeamNormalizedOverallRating").alias("DealTeamNormalizedOverallRating"),
            F.col("RatingCount").cast(IntegerType()).alias("RatingCount")
        )

        print(f"Final record count before write: {df_final.count()}")

        truncateQuery = f"TRUNCATE TABLE {task['SinkSchemaName']}.{task['SinkTableName']}"
        print("Executing truncate query")
        spark.sql(truncateQuery)

        df_final.write.format("delta").mode("append").save(target_path)
        print("Gold.GroupRating successfully written")

    except Exception as e:
        print(f"Error building Gold.GroupRating: {e}")
        raise


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)

        # Process the task
        result = process_task(task_item)


    except Exception as e:
        print(f"Error processing task: {e}")
        raise Exception


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
