# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.types import *
import json
from delta.tables import DeltaTable
from datetime import datetime, timezone, date, timedelta

spark.conf.set("spark.sql.caseSensitive","true")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
print(etlloadtime)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "[{\"JobAuditKey\":3088,\"TaskKey\":315,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Silver\",\"SourceTableName\":\"UserRating\",\"SinkTableName\":\"GroupRating\",\"SinkSchemaName\":\"Gold\",\"NotebookKeyNotebookKey\":\"71\",\"NotebookName\":\"GroupRatingGold\",\"SinkLakehouseName\":\"lh_curated\",\"RawStoragePath\":null,\"RawStorageFileName\":null,\"RelativeUrl\":null}]"
NotebookName = "GroupRatingGold"
LakehouseName = "lh_curated"
RawLHId = "920a12cc-7104-4013-a2a3-d7baa57e9e3f"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList =''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tasklist = json.loads(TaskList)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


def process_task(task):
    try:
        userrating_path = f"{curated_lh_basepath}/Tables/Silver/UserRating"
        entity_path = f"{curated_lh_basepath}/Tables/Silver/Entity"
        target_path = f"{curated_lh_basepath}/Tables/Gold/GroupRating"
        target_table = "GroupRating"

        try:
            #use SQL logic as custom source
            ddl_path = f"{curated_lh_basepath}/Files/DDLScripts/Gold"
            execute_ddl(target_table, ddl_path) #DEV_NOTE: This will not fail for now if DDL Script does not exist
        except:
            print("No DDL Script")
        df_user = spark.read.format("delta").load(userrating_path)
        df_entity = spark.read.format("delta").load(entity_path)

        print(f"Loaded UserRating: {df_user.count()} rows")
        print(f"Loaded Entity: {df_entity.count()} rows")

        # Build DealTeam
        df_entity = df_entity.withColumn(
            "DealTeam",
            F.expr("array_distinct(filter(array(PrimaryOwner, SecondaryOwner, TertiaryOwner, Associate), x -> x is not null))")
        ).select("EntityId", "DealTeam")

        print("Built DealTeam array successfully")

        # Aggregate at entity level
        df_entity_agg = (
            df_user.groupBy("EntityId", "EffectiveDate")
            .agg(
                F.avg("InvestmentEdgeRating").alias("InvestmentEdgeRating"),
                F.avg("OrganizationalEdgeRating").alias("OrganizationalEdgeRating"),
                F.avg("TrackRecordRating").alias("TrackRecordRating"),
                F.avg("OverallRating").alias("OverallRating"),
                F.count("*").alias("RatingCount")
            )
        )

        print(f"Entity-level aggregation complete ({df_entity_agg.count()} rows)")

        # Compute IsLatest per Entity
        window_latest = df_entity_agg.groupBy("EntityId").agg(F.max("EffectiveDate").alias("LatestDate"))
        df_group = (
            df_entity_agg.join(window_latest, "EntityId", "left")
            .withColumn("IsLatest", F.col("EffectiveDate") == F.col("LatestDate"))
            .drop("LatestDate")
            .withColumnRenamed("EffectiveDate", "AsOfDate")
        )

        print("Computed IsLatest flag successfully")

        # Join with DealTeam
        df_group = df_group.join(df_entity, "EntityId", "left")

        # Explode DealTeam for DealTeam-based averages
        df_group_exploded = df_group.withColumn("DealTeamMember", F.explode_outer("DealTeam"))

        dealteam_agg = (
            df_group_exploded.groupBy("DealTeamMember")
            .agg(
                F.avg("InvestmentEdgeRating").alias("DealTeamInvestmentEdgeRating"),
                F.avg("OrganizationalEdgeRating").alias("DealTeamOrganizationalEdgeRating"),
                F.avg("TrackRecordRating").alias("DealTeamTrackRecordRating"),
                F.avg("OverallRating").alias("DealTeamOverallRating")
            )
        )

        df_group = (
            df_group.join(
                dealteam_agg,
                df_group_exploded.DealTeamMember == dealteam_agg.DealTeamMember,
                "left"
            )
            .drop(dealteam_agg.DealTeamMember)
        )

        print("Computed DealTeam-level ratings")

        # Compute normalization and percentile stats
        stats = df_group.agg(
            F.min("OverallRating").alias("minOverall"),
            F.max("OverallRating").alias("maxOverall"),
            F.stddev("OverallRating").alias("stdOverall")
        ).collect()[0]

        min_val = stats["minOverall"] or 0
        max_val = stats["maxOverall"] or 1
        std_val = stats["stdOverall"] or 0

        df_group = df_group.withColumn(
            "NormalizedOverallRating",
            F.round(((F.col("OverallRating") - F.lit(min_val)) / (F.lit(max_val - min_val))) * 100, 2)
        )

        df_group = df_group.withColumn(
            "Percentile",
            F.round(F.percent_rank().over(Window.orderBy("OverallRating")), 6)
        ).withColumn("MinPercentile", F.lit(0.0)) \
         .withColumn("MaxPercentile", F.lit(1.0)) \
         .withColumn("StdDev", F.lit(std_val))

        # Set DealTeamNormalizedOverallRating = null for now
        df_group = df_group.withColumn("DealTeamNormalizedOverallRating", F.lit(0).cast(DecimalType(38, 2)))
        display(df_group)

        print("Computed normalization and percentile stats")

        # Enforce schema
        group_rating_schema = StructType([
            StructField("EntityId", StringType(), False),
            StructField("AsOfDate", DateType(), False),
            StructField("IsLatest", BooleanType(), False),
            StructField("InvestmentEdgeRating", DecimalType(38, 2), False),
            StructField("OrganizationalEdgeRating", DecimalType(38, 2), False),
            StructField("TrackRecordRating", DecimalType(38, 2), False),
            StructField("OverallRating", DecimalType(38, 2), False),
            StructField("NormalizedOverallRating", DecimalType(38, 2), True),
            StructField("Percentile", DecimalType(38, 6), True),
            StructField("MinPercentile", DecimalType(38, 6), True),
            StructField("MaxPercentile", DecimalType(38, 6), True),
            StructField("StdDev", DecimalType(38, 11), True),
            StructField("DealTeam", ArrayType(StringType()), True),
            StructField("DealTeamInvestmentEdgeRating", DecimalType(38, 2), False),
            StructField("DealTeamOrganizationalEdgeRating", DecimalType(38, 2), False),
            StructField("DealTeamTrackRecordRating", DecimalType(38, 2), False),
            StructField("DealTeamOverallRating", DecimalType(38, 2), False),
            StructField("DealTeamNormalizedOverallRating", DecimalType(38, 2), True),
            StructField("RatingCount", IntegerType(), True)
        ])

        # Select and cast columns to schema
        df_final = (
            df_group.select(
                F.col("EntityId").cast(StringType()).alias("EntityId"),
                F.col("AsOfDate").cast(DateType()).alias("AsOfDate"),
                F.col("IsLatest").cast(BooleanType()).alias("IsLatest"),
                F.round(F.col("InvestmentEdgeRating"), 2).cast(DecimalType(38, 2)).alias("InvestmentEdgeRating"),
                F.round(F.col("OrganizationalEdgeRating"), 2).cast(DecimalType(38, 2)).alias("OrganizationalEdgeRating"),
                F.round(F.col("TrackRecordRating"), 2).cast(DecimalType(38, 2)).alias("TrackRecordRating"),
                F.round(F.col("OverallRating"), 2).cast(DecimalType(38, 2)).alias("OverallRating"),
                F.round(F.col("NormalizedOverallRating"), 2).cast(DecimalType(38, 2)).alias("NormalizedOverallRating"),
                F.round(F.col("Percentile"), 6).cast(DecimalType(38, 6)).alias("Percentile"),
                F.col("MinPercentile").cast(DecimalType(38, 6)).alias("MinPercentile"),
                F.col("MaxPercentile").cast(DecimalType(38, 6)).alias("MaxPercentile"),
                F.round(F.col("StdDev"), 11).cast(DecimalType(38, 11)).alias("StdDev"),
                F.col("DealTeam").alias("DealTeam"),
                F.round(F.col("DealTeamInvestmentEdgeRating"), 2).cast(DecimalType(38, 2)).alias("DealTeamInvestmentEdgeRating"),
                F.round(F.col("DealTeamOrganizationalEdgeRating"), 2).cast(DecimalType(38, 2)).alias("DealTeamOrganizationalEdgeRating"),
                F.round(F.col("DealTeamTrackRecordRating"), 2).cast(DecimalType(38, 2)).alias("DealTeamTrackRecordRating"),
                F.round(F.col("DealTeamOverallRating"), 2).cast(DecimalType(38, 2)).alias("DealTeamOverallRating"),
                F.lit(None).cast(DecimalType(38, 2)).alias("DealTeamNormalizedOverallRating"),  # set to null for now
                F.col("RatingCount").cast(IntegerType()).alias("RatingCount")
            )
        )

        # Filter rows violating NOT NULL constraints
        not_null_cols = [
            "EntityId", "AsOfDate", "IsLatest",
            "InvestmentEdgeRating", "OrganizationalEdgeRating",
            "TrackRecordRating", "OverallRating",
            "DealTeamInvestmentEdgeRating", "DealTeamOrganizationalEdgeRating",
            "DealTeamTrackRecordRating", "DealTeamOverallRating"
        ]

        for col in not_null_cols:
            before = df_final.count()
            df_final = df_final.filter(F.col(col).isNotNull())
            after = df_final.count()
            if before != after:
                print(f"Filtered out {before - after} rows with null in {col}")

        print(f"Final record count: {df_final.count()}")

        truncateQuery = f"""
            TRUNCATE TABLE {task['SinkSchemaName']}.{task['SinkTableName']}
        """
        print(f"Executing truncate query")
        spark.sql(truncateQuery)


        df_final.write.format("delta").mode("append").save(target_path)
        print("Gold.GroupRating successfully written")

    except Exception as e:
        print(f"Error building Gold.GroupRating: {e}")
        raise


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)

        # Process the task
        result = process_task(task_item)


    except Exception as e:
        print(f"Error processing task: {e}")
        raise Exception


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
