# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "01c1ddd8-f2c9-428e-8dd3-75fb7065259a",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "19b9b7dd-6e5f-4579-9518-d127b0f393db",
# META       "known_lakehouses": [
# META         {
# META           "id": "01c1ddd8-f2c9-428e-8dd3-75fb7065259a"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from functools import reduce

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# --- Inputs ---
silver_rels = [
    "Silver/UserNetworkAccessDataAzure",
    "Silver/UserNetworkAccessDataCitrix",
    "Silver/UserNetworkAccessGlobalProtect",
    "Silver/UserNetworkAccessIntune",    # ✅ Added Intune source
]
gold_rel = "Gold/TravelDetails"

# ---------- helpers: case-insensitive column access ----------
def col_ci(df, name):
    m = {c.lower(): c for c in df.columns}
    actual = m.get(name.lower())
    return F.col(actual) if actual else None

def col_opt(df, name, dtype=None, default=None):
    c = col_ci(df, name)
    if c is None:
        return F.lit(default).cast(dtype) if dtype else F.lit(default)
    return c.cast(dtype) if dtype else c

def any_of(df, names, dtype=None, default=None):
    cols = [col_ci(df, n) for n in names]
    cols = [c for c in cols if c is not None]
    if not cols:
        return F.lit(default).cast(dtype) if dtype else F.lit(default)
    out = F.coalesce(*cols)
    return out.cast(dtype) if dtype else out

# --- Read + project to a common Gold schema (tolerant) ---
def project_to_gold(df):
    # build fields using tolerant access
    user            = any_of(df, ["User", "user", "who", "who_token"], "string")
    ts              = any_of(df, ["timestamp", "Timestamp", "EventTime", "Date"], "timestamp")
    ts_str          = any_of(df, ["timestamp", "Timestamp", "EventTime", "Date"], "string")
    country         = any_of(df, ["country", "Country", "CountryName"], "string")
    region          = any_of(df, ["state", "State", "RegionName", "region"], "string")
    city            = any_of(df, ["city", "City", "CityName"], "string")
    location        = any_of(df, ["location", "Location"], "string")
    ip              = any_of(df, ["ipAddress", "IPAddress", "ip", "public_ip"], "string")
    device          = any_of(df, ["deviceDisplayName", "Device", "device", "DeviceName"], "string")
    whitelist       = any_of(df, ["WhiteList", "whitelist"], "boolean", False)
    greylist        = any_of(df, ["GreyList", "graylist", "greylist"], "boolean", False)
    blacklist       = any_of(df, ["BlackList", "blacklist"], "boolean", False)
    success         = any_of(df, ["success", "Success"], "boolean")
    source          = any_of(df, ["Source", "source"], "string")
    dept            = any_of(df, ["department", "Department"], "string")
    username        = any_of(df, ["UserName", "username", "displayName"], "string")

    # Date derivation: favor timestamp→date; fallback try_parsing string (YYYY-MM-DD) if needed
    date_col = F.to_date(ts)
    date_col = F.coalesce(
        date_col,
        F.to_date(ts_str, "yyyy-MM-dd"),
        F.to_date(ts_str, "yyyy-MM-dd HH:mm:ss"),
        F.to_date(ts_str)  # last resort
    )

    # Department override logic (Vendor/Admin)
    device_for_vendor = F.coalesce(device.cast("string"), F.lit(""))
    user_trim = F.trim(F.coalesce(user, F.lit("")))
    department_final = (
        F.when(device_for_vendor.rlike("(?i)(MAGICFIN|3CLOUD|DOBLER|NEARSURE|PSS)"), F.lit("Vendor"))
         .when(user_trim.rlike("(?i)adm$"), F.lit("Admin"))
         .otherwise(dept)
         .cast("string")
    )

    username_final = (
        F.when(username.isNull() | (F.length(F.trim(username)) == 0), user)
         .otherwise(username)
         .cast("string")
    )

    return (
        df.select(
            user.alias("User"),
            date_col.alias("Date"),
            country.alias("CountryName"),
            region.alias("RegionName"),
            city.alias("CityName"),
            location.alias("Location"),
            ip.alias("IPAddress"),
            device.alias("Device"),
            whitelist.alias("WhiteList"),
            greylist.alias("GreyList"),
            blacklist.alias("BlackList"),
            F.lit(False).cast("boolean").alias("Violation"),
            department_final.alias("Department"),
            username_final.alias("UserName"),
            success.alias("Success"),
            source.alias("Source"),
            any_of(df, ["LoginOutsideUS", "OutsideUS"], "boolean", False).alias("LoginOutsideUS"),
        )
    )

# --- read each silver and add a quick probe column so we can count rows per source ---
dfs = []
for rel in silver_rels:
    df = read_delta(curated_lh_id, rel)
    df = df.withColumn("_InputTable", F.lit(rel))
    dfs.append(project_to_gold(df))

# --- Row counts per source BEFORE union ---
pre_counts = [(d.select(F.count(F.lit(1)).alias("n")).collect()[0]["n"], r) for d, r in zip(dfs, silver_rels)]
print("Pre-merge row counts:")
for n, r in pre_counts:
    print(f"  {r}: {n:,}")

# --- union all sources (column-name aligned) ---
gold_df = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), dfs)

# --- sanity checks AFTER union ---
gold_by_source = gold_df.groupBy("Source").count().orderBy(F.desc("count"))
gold_by_source.show(truncate=False)

# Optional: check null rates that often mask 'missing' data
for c in ["User","Date","CountryName","RegionName","CityName","IPAddress","Device","Department","UserName","Success","Source"]:
    n = gold_df.filter(F.col(c).isNull()).count()
    print(f"{c}: {n} nulls")

# --- Whitelist tweak ---
special_users = ["leec", "mathurs", "zhaoj", "zhonga"]
cond = (F.lower(F.col("User")).isin(*special_users)) & (F.lower(F.col("CountryName")) == F.lit("singapore"))
gold_df = (
    gold_df
    .withColumn("WhiteList", F.when(cond, F.lit(True)).otherwise(F.col("WhiteList")))
    .withColumn("GreyList",  F.when(cond, F.lit(False)).otherwise(F.col("GreyList")))
)

# --- Write to Gold ---
target_path = tbl_path(curated_lh_id, gold_rel)
(gold_df.write
    .format("delta")
    .mode("overwrite")          # consider 'append' + dedupe for incremental
    .option("overwriteSchema", "true")
    .save(target_path)
)
print(f"Wrote {gold_rel} to {target_path}")




# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
