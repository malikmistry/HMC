# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "01c1ddd8-f2c9-428e-8dd3-75fb7065259a",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "19b9b7dd-6e5f-4579-9518-d127b0f393db",
# META       "known_lakehouses": [
# META         {
# META           "id": "01c1ddd8-f2c9-428e-8dd3-75fb7065259a"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F
from functools import reduce

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# --- Inputs ---
silver_rels = [
    "Silver/UserNetworkAccessDataAzure",
    "Silver/UserNetworkAccessDataCitrix",
    "Silver/UserNetworkAccessGlobalProtect",
]
gold_rel = "Gold/TravelDetails"

# --- Read + project to a common Gold schema ---
def project_to_gold(df):
    return (
        df.select(
            F.col("User").cast("string").alias("User"),
            F.to_date(F.col("timestamp")).alias("Date"),
            F.col("country").cast("string").alias("CountryName"),
            F.col("state").cast("string").alias("RegionName"),
            F.col("city").cast("string").alias("CityName"),
            F.col("location").cast("string").alias("Location"),
            F.col("ipAddress").cast("string").alias("IPAddress"),
            F.col("deviceDisplayName").cast("string").alias("Device"),
            F.coalesce(F.col("WhiteList"), F.lit(False)).alias("WhiteList"),
            F.coalesce(F.col("GreyList"),  F.lit(False)).alias("GreyList"),
            F.coalesce(F.col("BlackList"), F.lit(False)).alias("BlackList"),
            F.lit(False).cast("boolean").alias("Violation"),
            F.col("department").cast("string").alias("Department"),
            F.col("UserName").cast("string").alias("UserName"),
            F.col("success").cast("boolean").alias("Success"),
            F.col("Source").cast("string").alias("Source"),
            F.coalesce(F.col("LoginOutsideUS"), F.lit(False)).alias("LoginOutsideUS"),
        )
    )

projected = [project_to_gold(read_delta(curated_lh_id, rel)) for rel in silver_rels]

# union all three sources (column-name aligned)
gold_df = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), projected).distinct()

# --- Write to Gold ---
target_path = tbl_path(curated_lh_id, gold_rel)
(gold_df.write
    .format("delta")
    .mode("overwrite")          # switch to 'append' + dedupe if you want incremental
    .option("overwriteSchema", "true")
    .save(target_path)
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
