# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F, Window
from pyspark.sql.functions import col, last_day, current_date
from delta.tables import DeltaTable
from pyspark.sql.types import DecimalType, DateType, StringType, IntegerType, LongType, TimestampType, StructType, StructField, TimestampType
from pyspark.sql import Window
from delta.tables import DeltaTable
import pandas as pd
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta

spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

lh_bronze_basepath = get_basepath(WorkspaceId, BronzeLHId)
lh_curated_basepath = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

target_schema = StructType([
    StructField("FundId", StringType(), False),  # GUID
    StructField("CurrencyId", IntegerType(), False),
    StructField("FirmId", StringType(), False),  # GUID
    StructField("EntityId", StringType(), False),  # GUID
    StructField("NAVDate", DateType(), False),
    StructField("MarketValueLocal", DecimalType(38, 2), False),
    StructField("ClassificationId", IntegerType(), False),
    StructField("FXDate", DateType(), False),
    StructField("FXRate", DecimalType(38, 15), False),
    StructField("LastValuationAmountLocal", DecimalType(38, 2), False),
    StructField("LastValuationNAVDate", DateType(), False),
    StructField("LastValuationDate", DateType(), False),
    StructField("AsOfDate", DateType(), False),
    StructField("MarketValueUSD", DecimalType(38, 2), False),
    StructField("LastValuationAmountUSD", DecimalType(38, 2), False),
    StructField("PercentOfGIA", DecimalType(38, 6), False),
    StructField("FundPerformanceId", IntegerType(), False),
    StructField("MVForwardDelta", DecimalType(38, 2), True),
    StructField("AdjustedMV", DecimalType(38, 2), False),
    StructField("PercentAdjustedGIA", DecimalType(38, 6), False),
    StructField("T1Nav", DecimalType(38, 2), False),
    StructField("ETLLoadDateTime", TimestampType(), False)

])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


def removeFundPerformanceForDate(processDate, fund_perf_path_abfss):
    # Compute NAVDate as end of the month
    next_month = processDate + relativedelta(months=1)
    navDate = (next_month - relativedelta(days=1)).strftime('%Y-%m-%d')

    # Load Delta table using ABFSS path
    delta_table = DeltaTable.forPath(spark, fund_perf_path_abfss)

    # Count rows matching delete condition
    rowsToDelete = delta_table.toDF().filter(F.col("NAVDate") == navDate).count()

    # Delete rows with matching NAVDate
    delta_table.delete(F.col("NAVDate") == navDate)

    print(f"Rows with NAVDate = {navDate} successfully deleted from FundPerformance. Total rows deleted: {rowsToDelete}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Load source tables
#holdings_path = spark.read.format("delta").load(f"{lh_bronze_basepath}/Tables/Bronze/CrimsonXHoldingsHistory")
holdings_path = spark.read.format("delta").load(f"{lh_curated_basepath}/Tables/Silver/FundMarketValue")
fund_path = spark.read.format("delta").load(f"{lh_curated_basepath}/Tables/Silver/Fund")
entity_path = spark.read.format("delta").load(f"{lh_curated_basepath}/Tables/Silver/Entity")
firm_path = spark.read.format("delta").load(f"{lh_curated_basepath}/Tables/Silver/Firm")
classification_path = spark.read.format("delta").load(f"{lh_curated_basepath}/Tables/Silver/Classification")
valuation_path = spark.read.format("delta").load(f"{lh_bronze_basepath}/Tables/Bronze/CrimsonXFundValuation")
currency_path = spark.read.format("delta").load(f"{lh_curated_basepath}/Tables/Silver/FXRate")
fundbeta_path = spark.read.format("delta").load(f"{lh_bronze_basepath}/Tables/Bronze/HMCDataMartInvestmentFundBetaSummaryLog")

# Target table path
fund_perf_path = f"{lh_curated_basepath}/Tables/Gold/FundPerformance"

# Process date
currentDate = date.today()
processDate = date.today() #date(currentDate.year, currentDate.month, 1) - relativedelta(months=6)

def loadFundPerformance(processDate): 
    target_exists = 0
    navDate = pd.Timestamp(processDate).to_period('M').end_time.strftime('%Y-%m-%d')
    print(f"navDate: {navDate}")

    # Try to read target table
    try:
        fund_perf_df = spark.read.format("delta").load(fund_perf_path)
        max_id = fund_perf_df.select(F.max("FundPerformanceId").alias("max_id")).first()["max_id"] or 0
        target_exists = 1
        print(f"Existing FundPerformance rows: {fund_perf_df.count()}")
    except Exception as e:
        print(f"Could not load FundPerformance table. Defaulting max_id to 0. Reason: {e}")
        max_id = 0

    # Holdings aggregation
    holdings_df = (
        holdings_path
        .filter(F.col("NAVDate") == navDate)
        .select(
            F.lower(F.col("FundId")).alias("FundId"),
            F.lower(F.col("CurrencyId")).alias("CurrencyId"),
            "EndBalance", "NAVDate"
        )
        .groupBy("FundId", "CurrencyId", "NAVDate")
        .agg(F.coalesce(F.sum("EndBalance"), F.lit(0)).alias("EndBalance"))
    )

#            .filter(F.lower(F.col("PortfolioTypeId")) == 0)



    # Latest valuation per FundId
    valuation_df = valuation_path.filter(F.lower(F.col("PortfolioTypeId")) == 0)
    window_spec_val = Window.partitionBy(F.lower(F.col("FundId"))).orderBy(F.col("NavDate").desc(), F.col("ValuationDate").desc())

    valuation_df = (
        valuation_df
        .withColumn("FundId", F.lower(F.col("FundId")))
        .withColumn("rank", F.row_number().over(window_spec_val))
        .filter(F.col("rank") == 1)
        .groupBy("FundId", "NavDate", "ValuationDate")
        .agg(F.sum("ValuationAmt").alias("TotalValuationAmount"))
        .select(
            "FundId",
            F.col("TotalValuationAmount").alias("ValuationAmount"),
            F.col("NavDate").alias("LastValuationNAVDate"),
            "ValuationDate"
        )
    )

    # Joins for Fund, Entity, Firm, Classification
    fund_df = fund_path.select(F.lower(F.col("FundId")).alias("FundId"), F.lower(F.col("EntityId")).alias("EntityId"))
    entity_df = entity_path.select(F.lower(F.col("EntityId")).alias("EntityId"), F.lower(F.col("FirmId")).alias("FirmId"))
    firm_df = firm_path.select(F.lower(F.col("FirmId")).alias("FirmId"))
    classification_df = classification_path.select(F.lower(F.col("FundId")).alias("FundId"), F.lower(F.col("ClassificationId")).alias("ClassificationId"))
    
    # Latest FXRate per CurrencyId
    latest_fxdate_df = currency_path.groupBy(
        F.lower(F.col("CurrencyId")).alias("CurrencyId")
    ).agg(F.max("FXDate").alias("FXDate"))

    currency_df = (
        currency_path
        .withColumn("CurrencyId", F.lower(F.col("CurrencyId")))
        .join(latest_fxdate_df, ["CurrencyId", "FXDate"], "inner")
        .select("CurrencyId", "FXDate", "FXRate")
    )

    beta_window = Window.partitionBy("FundId").orderBy(F.col("ValuationDt").desc())

    fundbeta_latest = (
        fundbeta_path
        .withColumn("FundId", F.lower(F.col("FundId")))
        .withColumn("rank", F.row_number().over(beta_window))
        .filter(F.col("rank") == 1)
        .drop("rank")
        .select("FundId", "ValuationDt", "T1Nav")
    )

    # Final joins
    result_df = (
        holdings_df
        .join(fund_df, "FundId", "inner")
        .join(entity_df, "EntityId", "inner")
        .join(firm_df, "FirmId", "inner")
        .join(classification_df, "FundId", "inner")
        .join(currency_df, "CurrencyId", "inner")
        .join(valuation_df, "FundId", "left")
        .join(fundbeta_latest, "FundId", "left")
    )

    # Derived columns

    window_spec = Window.orderBy(F.lit(1))

    result_df = (
        result_df
        .withColumn("AsOfDate", F.lit(navDate))
        .withColumnRenamed("EndBalance", "MarketValueLocal")
        .withColumnRenamed("ValuationDate", "LastValuationDate")
        .withColumnRenamed("ValuationAmount", "LastValuationAmountLocal")
        .withColumn("MarketValueUSD", F.col("MarketValueLocal") * F.col("FXRate"))
        .withColumn("LastValuationAmountUSD", F.col("LastValuationAmountLocal") * F.col("FXRate"))
    )
    display(result_df.limit(10))

    totalGIA = result_df.select("MarketValueUSD").agg(F.sum("MarketValueUSD").alias("TotalGIA")).collect()[0]["TotalGIA"]
    result_df = result_df.withColumn("PercentOfGIA", F.col("MarketValueUSD") / F.lit(totalGIA))
    result_df = result_df.withColumn("FundPerformanceId", (F.row_number().over(window_spec) + max_id))

    # Schema alignment
    default_values = {
        "DecimalType(38,2)": F.lit(0).cast(DecimalType(38, 2)),
        "StringType()": F.lit("").cast(StringType()),
        "IntegerType()": F.lit(0).cast(IntegerType()),
        "LongType()": F.lit(0).cast(LongType()),
        "DateType()": F.lit(None).cast(DateType()),
        "DecimalType(38,6)": F.lit(None).cast(DecimalType(38,6)),
        "TimestampType()": F.lit(None).cast(TimestampType()),
    }

    aligned_df = result_df

    for field in target_schema:
        if field.name not in result_df.columns:
            aligned_df = aligned_df.withColumn(field.name, default_values[str(field.dataType)])
        else:
            aligned_df = aligned_df.withColumn(field.name, F.col(field.name).cast(field.dataType))

    aligned_df = aligned_df.select([field.name for field in target_schema])

    # Delta optimization
    if target_exists == 1:
        spark.sql(f"""
            OPTIMIZE delta.`{fund_perf_path}`
        """)

    return aligned_df


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from dateutil.relativedelta import relativedelta

final_df = None

while processDate <= currentDate:
    try:
        removeFundPerformanceForDate(processDate, fund_perf_path)
    except Exception as e:
        print(f"Failed to remove Fund Performance for {processDate}: {e}")

    append_df = loadFundPerformance(processDate)

    if final_df is None:
        final_df = append_df
    else:
        final_df = final_df.unionByName(append_df, allowMissingColumns=True)

    processDate += relativedelta(months=1)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

currency_path.createOrReplaceTempView("FXRate")
# Fund trade
spark.read.format("delta").load(f"{lh_bronze_basepath}/Tables/Bronze/CrimsonXFundTrade").createOrReplaceTempView("CrimsonXFundTrade")
# Fund info
spark.read.format("delta").load(f"{lh_bronze_basepath}/Tables/Bronze/CrimsonXFund").createOrReplaceTempView("CrimsonXFund")
# Forecasted transactions
spark.read.format("delta").load(f"{lh_bronze_basepath}/Tables/Bronze/CrimsonXFundTradeForecastedTransaction").createOrReplaceTempView("CrimsonXFundTradeForecastedTransaction")
# Fund performance
# spark.read.format("delta").load(f"{base_path}/Tables/Silver/FundPerformance").createOrReplaceTempView("FundPerformance")
# Cache final_df to speed up reuse
final_df.cache()
# Create temp view from final_df
final_df.createOrReplaceTempView("FundPerformance")
display(final_df.limit(10))

#get latest FX rate
df_latest_fx = spark.sql("""
SELECT CurrencyId, FXRate AS CurrencyRate
FROM FXRate
WHERE FXDate = (SELECT MAX(FXDate) FROM FXRate)
""")

df_latest_fx.createOrReplaceTempView("CurrencyTable")


#compute MVForwardDelta including internal fund offset
df_mv_delta = spark.sql("""
WITH other_funds AS (
    SELECT f.FundName, UPPER(f.FundId) AS FundId, ft.CurrencyId,
        CASE
            WHEN f.FundName != 'HMC Internal - House' AND ft.FundTradeTypeId IN (3)
                THEN SUM((ftf.Amount * 1000000) * c.CurrencyRate)
            WHEN f.FundName != 'HMC Internal - House' AND ft.FundTradeTypeId IN (1, 4)
                THEN -SUM((ftf.Amount * 1000000) * c.CurrencyRate)
        END AS MVForwardDelta
    FROM CrimsonXFundTrade ft
    JOIN CrimsonXFund f ON f.FundId = ft.FundId
    JOIN CrimsonXFundTradeForecastedTransaction ftf ON ftf.FundTradeId = ft.FundTradeId
    JOIN CurrencyTable c ON c.CurrencyId = ft.CurrencyId
    WHERE ftf.ExposureDate > CURRENT_DATE
      AND ft.IsDeleted = 0 AND ftf.IsDeleted = 0
      AND ft.FundTradeTypeId <> 2
    GROUP BY f.FundName, f.FundId, ft.CurrencyId, ft.FundTradeTypeId
),
tempcalc AS (
    SELECT SUM(MVForwardDelta) AS mvother FROM other_funds
),
hmcinternal AS (
    SELECT f.FundName, UPPER(f.FundId) AS FundId, ft.CurrencyId,
        CASE WHEN tc.mvother > 0 THEN -SUM((ftf.Amount * 1000000) * c.CurrencyRate) END AS MVForwardDelta
    FROM CrimsonXFundTrade ft
    JOIN CrimsonXFund f ON f.FundId = ft.FundId
    JOIN CrimsonXFundTradeForecastedTransaction ftf ON ftf.FundTradeId = ft.FundTradeId
    JOIN CurrencyTable c ON c.CurrencyId = ft.CurrencyId,
         tempcalc tc
    WHERE ftf.ExposureDate > CURRENT_DATE
      AND ft.IsDeleted = 0 AND ftf.IsDeleted = 0
      AND ft.FundTradeTypeId <> 2
      AND f.FundName = 'HMC Internal - House'
    GROUP BY f.FundName, f.FundId, ft.CurrencyId, tc.mvother
)

SELECT FundName, FundId, MVForwardDelta FROM other_funds
UNION
SELECT FundName, FundId, MVForwardDelta FROM hmcinternal
""")
df_mv_delta.createOrReplaceTempView("MVDelta")
display(df_mv_delta.limit(10))

# Filter FundPerformance using final_df
navDate = spark.sql("""
    SELECT date_format(last_day(current_date()), 'yyyy-MM-dd') AS navDate
""").collect()[0]["navDate"]
print(f"NAVdate: {navDate}")

df_perf = spark.sql(f"""
    SELECT * FROM FundPerformance
    WHERE NAVDate = '{navDate}'
""").drop("MVForwardDelta", "AdjustedMV", "PercentAdjustedGIA", "ETLLoadDateTime")

df_perf.createOrReplaceTempView("FilteredPerf")
display(df_perf.limit(10))

# Join performance with delta
df_final = spark.sql("""
SELECT
    p.*,
    d.MVForwardDelta,
    CASE
        WHEN p.MarketValueUSD > 0 THEN p.MarketValueUSD + COALESCE(d.MVForwardDelta, 0)
        ELSE 0
    END AS AdjustedMV
FROM FilteredPerf p
LEFT JOIN MVDelta d ON p.FundId = d.FundId
""")

# Compute PercentAdjustedGIA
total_mv = df_final.agg(F.sum("AdjustedMV")).first()[0]
df_result = (
    df_final.withColumn("PercentAdjustedGIA", F.col("AdjustedMV") / F.lit(total_mv))
            .withColumn("ETLLoadDateTime", F.lit(date.today()))
            .drop("FundName")
)
# Cast columns to match target schema
for field in target_schema.fields:
    df_result = df_result.withColumn(field.name, col(field.name).cast(field.dataType))

print(df_result.count())
# Append enriched results back to FundPerformance table
df_result.write.format("delta").mode("append").option("mergeSchema", "true").save(f"{lh_curated_basepath}/Tables/Gold/FundPerformance")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
