# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""
NotebookName = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "{\"JobAuditKey\":537,\"TaskKey\":116,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"CrimsonXFundStatistics\",\"SinkTableName\":\"FundProjectedAnalytics\",\"SinkSchemaName\":\"Gold\",\"NotebookKeyNotebookKey\":\"14\",\"NotebookName\":\"FundProjectedAnalyticsSilver\",\"SinkLakehouseName\":\"lh_curated\"}"
NotebookName = "FundProjectedAnalyticsSilver"
LakehouseName = "lh_curated"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#we will attach the sinklakehouse to the notebook
if LakehouseName == 'lh_bronze':
    LakehouseId = BronzeLHId
elif LakehouseName == 'lh_curated':
    LakehouseId = CuratedLHId

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

 %%sql
 CREATE TABLE IF NOT EXISTS Gold.FundProjectedAnalytics (
     FundId VARCHAR(36) NOT NULL,
     AsOfDate DATE NOT NULL,
     ProjectedNetAlpha DECIMAL(38,6),
     ProjectedStrategyAlpha DECIMAL(38,6),
     MaxTrackingError DECIMAL(38,6),
     ProjectedGrossManagerAlpha DECIMAL(38,6),
     ProjectedFees DECIMAL(38,6),
     ProjectedLiquidityCost DECIMAL(38,6),
     ProjectedNetIR DECIMAL(38,6),
     ETLLoadDateTime TIMESTAMP
 )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tasklist = json.loads(f"{TaskList}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def is_df_empty(df, column_name=None, excluded_value=None):
    if column_name is not None and excluded_value is not None:
        df = df.filter(col(column_name) != excluded_value)
    return df.limit(1).count() == 0

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# 
# **Process FundProjectedAnalytics Table**

# CELL ********************

from pyspark.sql.functions import col, lower, broadcast

def process_task(task,bronze_lh_id,curated_lh_id):
    try:
        source_path = f"{bronze_lh_id}/Tables/{task['SourceSchemaName']}/{task['SourceTableName']}"
        target_path = f"{curated_lh_id}/Tables/{task['SinkSchemaName']}/{task['SinkTableName']}"
        datetime_col = 'Date_Time'
        print(source_path)
        print(target_path)
        #abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXFund

        #df_fund_stats = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXFundStatistics")
        df_time_period = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXTimePeriod")

        #df_fund_stats.createOrReplaceTempView("CrimsonXFundStatistics")
        df_time_period.createOrReplaceTempView("CrimsonXTimePeriod")
       #df_fund_stats.createOrReplaceTempView("CrimsonXFundStatistics")


        today_date = date.today()
        today_str = date.today().strftime('%Y-%m-%d')
        #yesterday_str = (today_str - timedelta(days=1)).strftime('%Y-%m-%d')
        # Set watermark
        etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        # TRY Read source
        try:
            df_source = spark.read.format("delta").load(source_path)
            df_source.createOrReplaceTempView("src")
            #print("read done")
            truncateQuery = f"""
                TRUNCATE TABLE Gold.{task['SinkTableName']}
            """
            spark.sql(truncateQuery)

            # Spark SQL
            query = f"""
            WITH cte_maxdt as (
                        SELECT 
                        MAX(AsOfDate) maxdt
                        FROM src
                        )
            ,cte_projnetir as (
                SELECT ProjectedNetIR, FundId
                from src fs
                where ProjectedNetIR IS NOT NULL
                and fs.TimePeriodId = 1 AND fs.FundStatisticReferenceTypeId = 1
            )
            
            SELECT 
                CAST(src.FundId AS VARCHAR(36)) AS FundId
                ,AsOfDate
                ,CAST(ProjectedNetAlpha AS DECIMAL(38,6)) AS ProjectedNetAlpha
                ,CAST(ProjectedStrategyAlpha AS DECIMAL(38,6)) AS ProjectedStrategyAlpha
                ,CAST(TrackingError AS DECIMAL(38,6)) AS MaxTrackingError
                ,CAST(ProjectedManagerAlpha AS DECIMAL(38,6)) AS ProjectedGrossManagerAlpha
                ,CAST(ProjectedFees AS DECIMAL(38,6)) AS ProjectedFees
                ,CAST(ProjectedLiquidity AS DECIMAL(38,6)) AS ProjectedLiquidityCost
                ,CAST(projnetir.ProjectedNetIR AS DECIMAL(38,6)) AS ProjectedNetIR
                ,CAST('{etlloadtime}' AS TIMESTAMP) AS ETLLoadDateTime
            FROM src src
            LEFT JOIN cte_projnetir projnetir
                ON LOWER(src.FundId) = LOWER(projnetir.FundId)
            WHERE FundStatisticReferenceTypeId = 1
            AND TimePeriodId = 4
            AND AsOfDate = (SELECT maxdt FROM cte_maxdt)
            """
            result_df = spark.sql(query)
            # # Alias for join clarity
            # df_fs = df_source.alias("fs")
            # df_tp = df_time_period.alias("tp")

            # # Join to get TimePeriod info
            # df_joined = df_fs.join(
            #     df_tp,
            #     df_fs["TimePeriodId"] == df_tp["TimePeriodId"],
            #     how="inner"
            # )

            # # Extract only valid ProjectedNetIR rows
            # df_proj_netir = df_joined.filter(
            #     (col("fs.ProjectedNetIR").isNotNull()) &
            #     (col("fs.TimePeriodId") == 1) &
            #     (col("fs.FundStatisticReferenceTypeId") == 1)
            # ).select("FundId", "ProjectedNetIR")

            # # Normalize FundId for join
            # df_proj_netir = df_proj_netir.withColumn("FundId", lower(col("FundId")))
            # result_df = result_df.withColumn("FundId", lower(col("FundId")))

            # # Drop old column to avoid duplication
            # result_df = result_df.drop("ProjectedNetIR")

            # # Join ProjectedNetIR into FundPerformance
            # df_updated_result = result_df.join(
            #     broadcast(df_proj_netir), on="FundId", how="left"
            # )
            # #result_df.show(5)
        except Exception as e:
            raise e
        # Write the result as a Delta table
        result_df.show(5)
        print("inserting data...")
        result_df.write.format("delta").mode("append").save(target_path)
        #df_today.write.format("delta").mode("overwrite").save(target_path)
        print('Completed')
    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise RuntimeError(f"Failed") from e

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)


        # Process the task
        result = process_task(task_item,bronze_lh_basepath,curated_lh_basepath)

    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise
#abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXFundTrade

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
