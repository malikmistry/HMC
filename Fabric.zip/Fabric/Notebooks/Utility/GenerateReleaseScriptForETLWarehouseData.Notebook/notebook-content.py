# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

def generate_update_insert_sql(
    source_df,
    target_table,
    match_keys,
    source_alias="source",
    target_alias="target"
):
    if isinstance(match_keys, str):
        match_keys = [match_keys]
    if not match_keys:
        raise ValueError("You must provide at least one match key.")

    columns = source_df.columns

    # Step 1: Generate SELECT statements with literal values
    value_rows = []
    for row in source_df.collect():
        values = []
        for value in row:
            if value is None:
                values.append("NULL")
            elif isinstance(value, bool):
                values.append("1" if value else "0")  # BOOLEAN → BIT
            elif isinstance(value, str):
                escaped = value.replace("'", "''")
                values.append(f"'{escaped}'")
            elif isinstance(value, (int, float)):
                values.append(str(value))
            elif hasattr(value, 'strftime'):  # datetime
                values.append(f"'{value.strftime('%Y-%m-%d %H:%M:%S')}'")
            else:
                escaped = str(value).replace("'", "''")
                values.append(f"'{escaped}'")
        value_rows.append(f"SELECT {', '.join(values)}")

    source_cte = "\nUNION ALL\n".join(value_rows)
    column_list = ", ".join(columns)

    # Step 2: Join condition
    join_condition = " AND ".join([
        f"{target_alias}.{k} = {source_alias}.{k}" for k in match_keys
    ])

    # Step 3: UPDATE clause (exclude match keys)
    update_set_clause = ",\n    ".join([
        f"{target_alias}.{col} = {source_alias}.{col}"
        for col in columns if col not in match_keys
    ])

    # Step 4: INSERT clause
    insert_columns = ", ".join(columns)
    insert_values = ", ".join([f"{source_alias}.{col}" for col in columns])

    # Step 5: Build full SQL with separate CTEs
    full_sql = f"""
-- ===== UPDATE EXISTING ROWS =====
WITH {source_alias} ({column_list}) AS (
{source_cte}
)
UPDATE {target_alias}
SET
    {update_set_clause}
FROM {target_table} AS {target_alias}
JOIN {source_alias}
    ON {join_condition};

-- ===== INSERT NEW ROWS =====
WITH {source_alias} ({column_list}) AS (
{source_cte}
)
INSERT INTO {target_table} ({insert_columns})
SELECT {insert_values}
FROM {source_alias}
WHERE NOT EXISTS (
    SELECT 1
    FROM {target_table} AS {target_alias}
    WHERE {join_condition}
);
""".strip()

    return full_sql

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import com.microsoft.spark.fabric
from com.microsoft.spark.fabric.Constants import Constants

data = [{"table":"etl.Job", "key":"JobKey"},
        {"table":"etl.Notebook", "key":"NotebookKey"},
        {"table":"etl.FileTask", "key":"FileTaskKey"},
        {"table":"etl.Task", "key":"TaskKey"},         
        {"table":"etl.Watermark", "key":"TaskKey"}]

for item in data:
    table = f"etlControl.{item['table']}"
    df=spark.read.synapsesql(table)

    sql = generate_update_insert_sql(
        source_df=df,
        target_table=table,
        match_keys=item['key']
    )

    print(f"-- ***** Script to update the table: {table} *****")
    print(sql)
    print("\n")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
