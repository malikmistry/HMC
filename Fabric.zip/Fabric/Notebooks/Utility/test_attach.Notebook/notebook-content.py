# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

spark.sql("SHOW DATABASES").show()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def refresh_abfss_table(abfss_path: str):
    """
    DEV Note: Test: does not work on refreshing SQL analytics endpoint
    Only works in Spark, only updates Spark's internal catalog cache
    """
    # rfresh table in Spark
    spark.sql(f"REFRESH TABLE delta.`{abfss_path}`")

    print(f"Refreshed successfully: {abfss_path}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
abfss = f"{bronze_lh_basepath}/Tables/Bronze/AlphaType"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

refresh_abfss_table(abfss)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import sempy.fabric as fabric
import notebookutils

# Get current notebook context (name and workspace)
notebook_name = "test_attach"
workspace_name = "Dev - Crimson"
workspace_id = fabric.resolve_workspace_id(workspace_name)

# Get notebook definition
definition = notebookutils.notebook.getDefinition(notebook_name, workspace_id)

import json
notebook_json = json.loads(definition)

# Check Lakehouse bindings
bindings = notebook_json.get("bindings", [])
lakehouses = [b for b in bindings if b.get("type") == "Lakehouse"]

# Output the results
if not lakehouses:
    print("No Lakehouse is attached to this notebook.")
else:
    print("Attached Lakehouses:")
    for lh in lakehouses:
        print(f"- Name: {lh['binding']['name']}")
        print(f"  ID: {lh['binding']['id']}")
        print(f"  Default: {lh.get('isDefault', False)}\n")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
