# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Create a generic HMC logging table

#e.g bronze_lh_id = 'abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558'

WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLHId = ''

#note: for DDL commands, need to attach lakehouse, so, this notebook has lh_bronze attached

def get_basepath(workspace_id, lakehouse_id) -> str: 
    lh_basepath = 	f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}" 
    return lh_basepath

# Enable case sensitivity
spark.sql("SET spark.sql.caseSensitive=true")
spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_bronze")

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

print(bronze_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# this is not working very well.  the table gets created, but, there is also an error and the cell does not continue past the table create

# schema = "Bronze"
# table = "MyLog"

# spark.sql(f"""
# DROP TABLE if EXISTS {schema}.{table}
# """)


# spark.sql(f"""
# CREATE TABLE {schema}.{table} (
#     ApplicationName VARCHAR(25) NOT NULL,
#     ErrorMessage VARCHAR(75) NOT NULL,
#     InsertTimeStamp DATE
# )
# USING DELTA LOCATION '{bronze_lh_id}/Tables/{schema}/{table}'
# """)

# spark.sql("""
# INSERT INTO MyLog VALUES ('IndexReturn', 'got BB error code', '02/25/2025')
# """)

# df = spark.sql("SELECT * FROM MyLog ")
# display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType, TimestampType
from pyspark.sql import SparkSession

# Define schema matching your SQL table
note_schema = StructType([
    StructField("ApplicationName", StringType(), False),
    StructField("ErrorMessage", StringType(), True),
    StructField("ETLLoadDateTime", TimestampType(), True)
])

# Create an empty DataFrame with the schema
empty_df = spark.createDataFrame([], schema=note_schema)

tableName = "Log"
deltaTablePath = f"{bronze_lh_id}/Tables/Bronze/{tableName}" 
print(": deltaTablePath=" + deltaTablePath)

empty_df.write.format("delta").mode("overwrite").save(deltaTablePath) 

import time
print("Waiting for 60 seconds...")
time.sleep(60)
print("Done waiting!")

# Confirm it exists... will not work unless you wait 60 seconds
spark.sql("SELECT * FROM Bronze.Log").show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
