# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
from notebookutils import mssparkutils
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def print_test():
    print('Succesfully ran notebook utils')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def execute_ddl (sink_table, lh_path_ddl):
    #Sink table should be the same with file name (<sink_table>.sql)
    # sink_table = "EntityTest"
    ddl_file_path = f"{lh_path_ddl}/{sink_table}.sql"
    print(f"DDL File Path: {ddl_file_path}")

    ddl_files = [f.path for f in mssparkutils.fs.ls(f"{lh_path_ddl}") if f.name == f"{sink_table}.sql"]

    if ddl_files:
        print(f"Executing DDL script for {sink_table}: {ddl_file_path}")

        # Read the SQL file contents
        ddl_sql = mssparkutils.fs.head(ddl_file_path)
        print(ddl_sql)

        # Execute the DDL script
        try:
            spark.sql(ddl_sql)
            print(f"DDL executed successfully for {sink_table}")
        except Exception as ddl_err:
            print(f"DDL execution warning for {sink_table}: {ddl_err}")
            # raise Exception
    else:
        print(f"WARNING: No DDL script found for {sink_table}. If this is the first time you are writing this table, the schema might not be correct")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def is_df_empty(df, column_name=None, excluded_value=None):
    if column_name is not None and excluded_value is not None:
        df = df.filter(col(column_name) != excluded_value)
    return df.limit(1).count() == 0

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def table_exists(path):
    try:
        return DeltaTable.isDeltaTable(spark, path)
    except:
        return False


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def refresh_abfss_table(abfss_path: str):
    """
    DEV Note: Test: does not work on refreshing SQL analytics endpoint
    Only works in Spark, only updates Spark's internal catalog cache
    """
    # rfresh table in Spark
    spark.sql(f"REFRESH TABLE delta.`{abfss_path}`")

    print(f"Refreshed successfully: {abfss_path}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# def refresh_lakehouse_table(table_name: str):
#     sql_stmt = f"ALTER TABLE {table_name} REFRESH"
#     spark.sql(sql_stmt)
    
#     print(f"Table refreshed successfully: {table_name}")

# will throw a parsing error, because Spark doesn't recognize REFRESH as an ALTER TABLE operation

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def resolve_template(template_str: str, context: dict) -> str:
    """
    Resolves a string template using values from a dictionary.
    template_str (str): The template string containing placeholders, e.g., "{table_name}!"
    context (dict): A dictionary mapping placeholders to their values, e.g., {"table_name": "Fund"}
    """
    try:
        # Attempt to fill in the template placeholders with values from the context dictionary
        # The **context syntax unpacks the dictionary so keys match placeholder names
        return template_str.format(**context)
    except Exception as e:
        # If an error occurs (e.g., missing placeholder in context),
        # raise a ValueError with a descriptive message including the original template and error
        raise ValueError(f"Error resolving template '{template_str}': {e}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def http_post(url, json_data):

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

    try:
        print(f"Calling: {url}")
        response = requests.post(url, json=json_data, headers=headers, timeout=600)
        response.raise_for_status()  # raises HTTPError for 4xx/5xx responses
        data = response.json()  # or response.text depending on what you need
    except HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")  # e.g., 404, 500, etc.
        print(f"Response: {response.text}")
        raise
    except ConnectionError as conn_err:
        print(f"Connection error occurred: {conn_err}")  # DNS failure, refused connection, etc.
        print(f"Response: {response.text}")
        raise
    except Timeout as timeout_err:
        print(f"Timeout error occurred: {timeout_err}")
        print(f"Response: {response.text}")
        raise
    except RequestException as req_err:
        print(f"Other request exception occurred: {req_err}")
        print(f"Response: {response.text}")
        raise
    except Exception as e:
        print(f"Unexpected error: {e}")
        print(f"Response: {response.text}")
        raise
    
    print(f"HTTP call complete. Status Code: {response.status_code}")
    if not data:
        raise ValueError("HTTP call returned no data.")

    return data

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Clean column headers to save to Delta Table
def sanitize_column_names_with_mapping(df):
    rename_map = {}
    for col in df.columns:
        sanitized = col.replace("%", "Percentage")
        sanitized = re.sub(r"[^a-zA-Z0-9_]", "_", sanitized)
        sanitized = re.sub(r"_+", "_", sanitized).strip("_")
        
        if sanitized != col:
            df = df.withColumnRenamed(col, sanitized)
            rename_map[sanitized] = col  # store reverse mapping for restoring, not used in this code but for future development

    if rename_map:
        print(f"[i] Column rename mapping: {rename_map}")
    return df

def restore_original_column_names(df, rename_map):
    for sanitized, original in rename_map.items():
        df = df.withColumnRenamed(sanitized, original)
    return df

#Functions to make sure only one HWM column exists before merge
def unify_hwm_column(df, hwm_column):
    # Identify all columns with HWM name or variants like etlloaddatetime_1
    hwm_candidates = [c for c in df.columns if c == hwm_column or c.startswith(f"{hwm_column}_")]

    if len(hwm_candidates) > 1:
        print(f"Multiple HWM columns detected: {hwm_candidates}. Unifying into one '{hwm_column}'.")

        # Create unified column using coalesce (first non-null wins)
        df = df.withColumn(hwm_column, coalesce(*[col(c) for c in hwm_candidates]))

        # Drop all other variants except the unified one
        cols_to_drop = [c for c in hwm_candidates if c != hwm_column]
        df = df.drop(*cols_to_drop)

    return df

def replace_with_delta(sql, bronze_lh_basepath, silver_lh_basepath):
    # Replace Bronze.<table> only if it appears
    sql = re.sub(
        r"\bBronze\.([A-Za-z0-9_]+)", 
        lambda m: f"delta.`{bronze_lh_basepath}/Tables/Bronze/{m.group(1)}`", 
        sql
    )
    
    # Replace Silver.<table> only if it appears
    sql = re.sub(
        r"\bSilver\.([A-Za-z0-9_]+)", 
        lambda m: f"delta.`{silver_lh_basepath}/Tables/Silver/{m.group(1)}`", 
        sql
    )
    
    return sql


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
