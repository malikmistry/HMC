# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

#TODO: figure out how to trigger a refresh of just one table
# current notebook does all tables in one command
In_TableName = None
In_SchemaName = None

WorkspaceId = ''
BronzeLhId = ''
CuratedLhId = ''

#TODO: change to use params
#todo: move to shared notebook??
#e.g bronze_lh_id = 'abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558'
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLhId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLhId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

def get_basepath(workspace_id, lakehouse_id) -> str: 
    lh_basepath = 	f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}" 
    return lh_basepath

bronze_lh_id = get_basepath(WorkspaceId, BronzeLhId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLhId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import json
import time
import logging
from datetime import datetime
import pytz
import sempy.fabric as fabric
from sempy.fabric.exceptions import FabricHTTPException, WorkspaceNotFoundException

#xxx mwmw
In_TableName = "Silver.Index"
In_TableName = "Bronze.CrimsonXCountry"
In_SchemaName = "Silver"
In_TableName = "FundTradeStatus"

#mwmw added these two lines
from pyspark.sql import SparkSession
#spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "LakehouseSilver")

# Setup logging to show only warnings and errors
logging.basicConfig(level=logging.WARNING, format='%(asctime)s - %(levelname)s - %(message)s')

# Helper function to convert UTC time to Eastern Time
def convert_to_eastern(utc_time_str):
    #mwmw: something is causing this error:
    #mwmw: An unexpected error occurred: Invalid isoformat string: '2025-03-25T11:02:32.7314109+00:00'
    #print("mwmw date 1")
    # Eastern Time Zone (ET)
    eastern = pytz.timezone('US/Eastern')

    if utc_time_str is None:
        return 'N/A'
    #print("mwmw date 2")
    utc_time = datetime.fromisoformat(utc_time_str.replace("Z", "+00:00"))
    return utc_time.astimezone(eastern).strftime('%Y-%m-%d %H:%M:%S %Z')

# Function to sync SQL endpoint with the Lakehouse
def sync_sql_endpoint(client, workspace_id, lakehouse_id):
    try:
        # Fetch SQL endpoint properties
        lakehouse_info = client.get(f"/v1/workspaces/{workspace_id}/lakehouses/{lakehouse_id}").json()
        sql_endpoint_id = lakehouse_info['properties']['sqlEndpointProperties']['id']
        
        # Set URI for the API call
        uri = f"/v1.0/myorg/lhdatamarts/{sql_endpoint_id}"

        # this worked, but, runs for all tables:
        # (This works in "Dev - Crimson")
        # payload = {"commands": [{"$type": "MetadataRefreshExternalCommand"}]}

        # this works for one specific table in DEV
        # however, in "Dev - Crimson" where we have the "Silver" schema, I cannot get this to work
        payload = {
            "commands": [
                {
                    "$type": "MetadataRefreshExternalCommand", 
                    "tableNames": [In_TableName],
                    "schemaName": In_SchemaName
                }
            ]
        }

        # use payload for all tables...
        payload = {"commands": [{"$type": "MetadataRefreshExternalCommand"}]}

        print(payload)


        # Call REST API to initiate the sync
        response = client.post(uri, json=payload)
        if response.status_code != 200:
            logging.error(f"Error initiating sync: {response.status_code} - {response.text}")
            return

        data = json.loads(response.text)

        batch_id = data["batchId"]
        progress_state = data["progressState"]

        # URL for checking the sync status
        status_uri = f"/v1.0/myorg/lhdatamarts/{sql_endpoint_id}/batches/{batch_id}"

        # Polling until the sync is complete
        while progress_state == 'inProgress':
            print("============================================================================ in loop")
            time.sleep(2)  # Polling interval
            status_response = client.get(status_uri)
            status_data = status_response.json()
            progress_state = status_data["progressState"]

            #this status_data will contain all tables, but, you will notice that the syncEndDateTime will only have a value for the specified table
            print(status_data)

        print("mwmw ============================================ 1")
        print(progress_state)
        
        # Check if the sync completed successfully
        if progress_state == 'success':
            table_details = [
                {
                    'tableName': table['tableName'],
                    'lastSuccessfulUpdate': convert_to_eastern(table.get('lastSuccessfulUpdate', 'N/A')),
                    'tableSyncState': table['tableSyncState'],
                    'sqlSyncState': table['sqlSyncState']
                }
                for table in status_data['operationInformation'][0]['progressDetail']['tablesSyncStatus']
            ]
            
            # Print extracted table details
            for detail in table_details:
                print(f"Table: {detail['tableName']}   Last Update: {detail['lastSuccessfulUpdate']}  "
                      f"Table Sync State: {detail['tableSyncState']}  SQL Sync State: {detail['sqlSyncState']}")
            
            #uncomment if you need to see all the details
            #display(status_data)
            print("mwmw ============================================ 2")
        # Handle failure
        elif progress_state == 'failure':
            logging.error(f"Sync failed: {status_data}")
    
        print("mwmw ============================================ 3")

    except FabricHTTPException as fe:
        logging.error(f"Fabric HTTP Exception: {fe}")
    except WorkspaceNotFoundException as we:
        logging.error(f"Workspace not found: {we}")
    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}")

# Main function to execute the sync
def run_sync():
    # Initialize client
    client = fabric.FabricRestClient()
    
    # Fetching environment variables directly from Spark
    #mwmw: 8:55 in video
    workspace_id = spark.conf.get("trident.workspace.id")
    lakehouse_id = spark.conf.get("trident.lakehouse.id")
    print(workspace_id)
    # getting a blank for this
    print(lakehouse_id)
    #mwmw sql connection string for lakehouse: ocjf6obnn2vujauxalhsb7ixzy-2nqrndijcwpebfxgf4ws3kmd3y.datawarehouse.fabric.microsoft.com
    #mwmw lakehour url... one of these values is the ID https://app.fabric.microsoft.com/groups/8d1661d3-1509-409e-96e6-2f2d2da983de/lakehouses/0d258a24-e449-43e6-a029-4a56ec727d07?experience=fabric-developer
    
    #mwmw: this seems to be the ID
    #lakehouse_id = "0d258a24-e449-43e6-a029-4a56ec727d07"

    # Execute the sync process
    #sync_sql_endpoint(client, workspace_id, BronzeLhId)
    sync_sql_endpoint(client, workspace_id, CuratedLhId)


#mwmw these get errors
#spark.sql("DROP TABLE IF EXISTS LH_AI_LAB.test1")
#spark.sql("CREATE TABLE IF NOT EXISTS test1 AS SELECT * FROM LH_AI_LAB.EndPointTest")

#mwmw: the APi calls used by this notebook are not officially supported my Microsoft and they advise against using them
# So, in the event this notebook suddenlhy stops working change this value to "false" 
useUnsupportedApi = "true"

if(useUnsupportedApi == "true"):
    run_sync()
else:
    time.sleep(6)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
