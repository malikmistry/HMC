# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

spark.conf.set('spark.sql.caseSensitive', True)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE lh_curated.Silver.FundValuation(
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	NAVDate date NOT NULL,
# MAGIC 	ValuationDate date NOT NULL,
# MAGIC 	ValuationTypeId int NOT NULL,
# MAGIC 	CurrencyId int NOT NULL,
# MAGIC 	ValuationAmount decimal(38, 2) NOT NULL,
# MAGIC 	ValuationAmountUSD decimal(38, 2) NOT NULL,
# MAGIC 	ETLLoadDateTime timestamp NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Reseed FundValuations
spark.sql("""TRUNCATE TABLE lh_curated.Silver.FundValuation""")

spark.sql("""
INSERT INTO Silver.FundValuation
(FundId, NAVDate, ValuationDate, ValuationTypeId, CurrencyId, ValuationAmount, ValuationAmountUSD, ETLLoadDateTime)
select FundId
	     , NavDate
		 , ValuationDate
		 , ValuationTypeId
		 , CurrencyId
		 , SUM(ValuationAmt) as ValuationAmount
		 , SUM(ValuationAmtUSD) as ValuationAmountUSD
		 , current_timestamp as ETLLoadDateTime
  from lh_bronze.Bronze.CrimsonXFundValuation
  WHERE EndDate = '9999-12-31'
			AND ValuationDate < current_date
  GROUP BY FundId
	     , NavDate
		 , ValuationDate
		 , ValuationTypeId
		 , CurrencyId
ORDER BY NavDate DESC
		 , ValuationDate DESC
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
INSERT INTO lh_curated.Silver.FundReturn
(FundId, ReturnTypeId, ReturnSourceId, FrequencyId, EndDate, ReturnValue, AsOfDate, ETLLoadDateTime)
select fr.FundId
	   , fr.ReturnTypeId
	   , fr.ReturnSourceId
	   , fr.FrequencyId
	   , fr.ReturnDate
	   , fr.ReturnValue
	   , current_date as AsOfDate
	   , current_timestamp as ETLLoadDateTime
from lh_bronze.Bronze.CrimsonXFundReturn fr
		JOIN lh_bronze.Bronze.CrimsonXFund f ON fr.FundId = f.FundId
where fr.ReturnSourceId = 2
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# spark.conf.set('spark.sql.caseSensitive', True)

# #spark.sql(""" DROP TABLE Silver.FundReturn """)

# spark.sql("""
# CREATE TABLE Silver.FundReturn (
#     FundId varchar(36) NOT NULL,
#     ReturnTypeId int NOT NULL,    
#     ReturnSourceId int NOT NULL,        
#     FrequencyId int NOT NULL,        
#     CalculationMethodologyId int,        
#     EndDate date NOT NULL,
#     ReturnValue decimal(38,11),
#     ReturnError string,
#     ReturnDetailsKey string,
#     AsOfDate date NOT NULL,
#     ETLLoadDateTime TIMESTAMP NOT NULL    
# )
# USING DELTA
# """) 

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC --DROP TABLE lh_curated.Silver.CashflowTransactionDetail
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.CashflowTransactionDetail(
# MAGIC 	CashflowTransactionDetailId bigint NOT NULL,
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	ShareClassId varchar(36) NOT NULL,
# MAGIC 	CurrencyId int NOT NULL,
# MAGIC 	FXRate decimal(38, 15) NOT NULL,
# MAGIC 	PortfolioTypeId int NOT NULL,
# MAGIC 	CashflowTransactionTypeId int NOT NULL,
# MAGIC 	CashflowTransactionSubtypeId int NOT NULL,
# MAGIC 	TransactionAmountInLocal decimal(38, 2) NOT NULL,
# MAGIC 	TransactionAmountInUSD decimal(38, 2) NOT NULL,
# MAGIC 	TransactionAmountOutLocal decimal(38, 2) NOT NULL,
# MAGIC 	TransactionAmountOutUSD decimal(38, 2) NOT NULL,
# MAGIC 	CommitmentEffectLocal decimal(38, 2) NOT NULL,
# MAGIC 	MarketValueEffectLocal decimal(38, 2) NOT NULL,
# MAGIC 	BookStartOfDay boolean NOT NULL,
# MAGIC 	ExposureDate date NOT NULL,
# MAGIC 	TradeDate date,
# MAGIC 	SettleDate date,
# MAGIC 	ReturnedAmountLocal decimal(38, 2) NOT NULL,
# MAGIC 	ReturnedAmountUSD decimal(38, 2) NOT NULL,
# MAGIC 	UnfundedAdjustmentLocal decimal(38, 2) NOT NULL,
# MAGIC 	UnfundedAdjustmentUSD decimal(38, 2) NOT NULL,
# MAGIC 	FundedAmountLocal decimal(38, 2) NOT NULL,
# MAGIC 	FundedAmountUSD decimal(38, 2) NOT NULL,
# MAGIC 	RecallableAmountLocal decimal(38, 2) NOT NULL,
# MAGIC 	RecallableAmountUSD decimal(38, 2) NOT NULL,
# MAGIC 	TransactionTypeIdSource int,
# MAGIC 	TransactionIdSource int,
# MAGIC 	CommitmentEffectUSD decimal(38, 2) NOT NULL,
# MAGIC 	MarketValueEffectUSD decimal(38, 2) NOT NULL,
# MAGIC 	TransactionTag varchar(8000),
# MAGIC 	ETLLoadDateTime Timestamp NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""TRUNCATE TABLE lh_curated.Review.CashflowTransactionDetail""")
# display(dfCashflowDetail.count())

spark.sql("""INSERT INTO lh_curated.Silver.CashflowTransactionDetail
            (CashflowTransactionDetailId
            , FundId
            , ShareClassId
            , PortfolioTypeId
            , CashflowTransactionTypeId
            , CashflowTransactionSubtypeId
            , TransactionAmountInLocal
            , TransactionAmountInUSD
            , TransactionAmountOutLocal
            , TransactionAmountOutUSD
            , CommitmentEffectLocal
            , MarketValueEffectLocal
            , BookStartOfDay
            , ExposureDate
            , TradeDate
            , SettleDate
            , CurrencyId
            , FXRate
            , ReturnedAmountLocal
            , ReturnedAmountUSD
            , UnfundedAdjustmentLocal
            , UnfundedAdjustmentUSD
            , FundedAmountLocal
            , FundedAmountUSD
            , RecallableAmountLocal
            , RecallableAmountUSD
            , TransactionTypeIdSource
            , TransactionIdSource
            , CommitmentEffectUSD
            , MarketValueEffectUSD
            , TransactionTag
            , ETLLoadDateTime)          
            SELECT ctd.CashflowTransactionDetailId
            , ctd.FundId
            , ctd.ShareClassId
            , ctd.PortfolioTypeId
            , ctd.CashflowTransactionTypeId
            , ctd.CashflowTransactionSubtypeId
            , ctd.TransactionAmountInLocal
            , ctd.TransactionAmountInUSD
            , ctd.TransactionAmountOutLocal
            , ctd.TransactionAmountOutUSD
            , ctd.CommitmentEffectLocal
            , ctd.MarketValueEffectLocal
            , ctd.BookStartOfDay
            , ctd.ExposureDate
            , ctd.TradeDate
            , ctd.SettleDate
            , ctd.CurrencyId
            , COALESCE(fx.FXRate, 1) as FXRate
            , ctd.ReturnedAmountLocal
            , ctd.ReturnedAmountUSD
            , COALESCE(ctd.UnfundedAdjustmentLocal, 0)
            , COALESCE(ctd.UnfundedAdjustmentUSD, (COALESCE(ctd.UnfundedAdjustmentLocal, 0) * COALESCE(fx.FXRate, 1)))
            , COALESCE(ctd.FundedAmountLocal, 0)
            , COALESCE(ctd.FundedAmountUSD, (COALESCE(ctd.FundedAmountLocal, 0) * COALESCE(fx.FXRate, 1)))
            , COALESCE(ctd.RecallableAmountLocal, 0)
            , COALESCE(ctd.RecallableAmountUSD, (COALESCE(ctd.RecallableAmountLocal, 0) * COALESCE(fx.FXRate, 1)))
            , ctd.TransactionTypeIdSource
            , ctd.TransactionIdSource
            , ctd.CommitmentEffectUSD
            , ctd.MarketValueEffectUSD
            , ctd.TransactionTag
            , ctd.ETLLoadDateTime
            FROM lh_bronze.Bronze.CrimsonXCashflowTransactionDetail ctd
                    LEFT JOIN lh_curated.Silver.FXRate fx ON ctd.CurrencyId = fx.CurrencyId
                                                            AND ctd.ExposureDate = fx.FXDate
           """)
# display(dffafa)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC DELETE
# MAGIC FROM lh_curated.Silver.CashflowTransactionDetail
# MAGIC WHERE CashflowTransactionTypeId in (5,13)

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


%%sql
CREATE TABLE lh_curated.Silver.IndexReturn (
	IndexId VARCHAR(36) NOT NULL,
	FrequencyId INT NOT NULL,
	ReturnDate date NOT NULL,
	CurrencyId int NOT NULL,
	LevelValue decimal(38, 11) NOT NULL, 
	ReturnValue decimal(38, 11) NOT NULL,
	ReturnComment varchar(200),
	ReturnSource varchar(50),
    ETLLoadDateTime DATETIME NOT NULL
)

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC INSERT INTO lh_curated.Silver.IndexReturn
# MAGIC (IndexId, FrequencyId, ReturnDate, CurrencyId, LevelValue, ReturnValue, ReturnComment, ReturnSource, ETLLoadDateTime)
# MAGIC SELECT IndexId
# MAGIC 	   , FrequencyId
# MAGIC 	   , AsOfDate
# MAGIC 	   , CurrencyId
# MAGIC 	   , IndexLevel
# MAGIC 	   , IndexReturn
# MAGIC 	   , ReturnComment
# MAGIC 	   , ReturnSource
# MAGIC 	   , current_timestamp
# MAGIC FROM lh_bronze.Bronze.IndexReturn

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC -- truncate table lh_curated.Silver.FXRate
# MAGIC insert into lh_curated.Silver.FXRate
# MAGIC (FXRateId, CurrencyId, FXDate, FXRate, ETLLoadDateTime, IsLatest)
# MAGIC select CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) as int)  as FXRateId
# MAGIC 	   , CAST(CurrencyId as int) as CurrencyId
# MAGIC 	   , CAST(CurrencyRateDate as date) as FXDate
# MAGIC 	   , CAST(CurrencyRate as DECIMAL(38, 15)) as FXRate
# MAGIC 	   , CURRENT_TIMESTAMP as ETLLoadDateTime
# MAGIC 	   , CAST(IsLast as int) as IsLatest
# MAGIC from lh_bronze.Bronze.CrimsonXCurrencyRate

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC -- DROP TABLE lh_bronze.Bronze.CrimsonXHoldingsHistory
# MAGIC CREATE TABLE lh_bronze.Bronze.CrimsonXHoldingsHistory(
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	ShareClassId varchar(36) NOT NULL,
# MAGIC 	NAVDate date NOT NULL,
# MAGIC 	LotDate date NOT NULL,
# MAGIC 	PortfolioTypeId int NOT NULL,
# MAGIC 	StartDate date NOT NULL,
# MAGIC 	EndDate date NOT NULL,
# MAGIC 	CurrencyId int NOT NULL,
# MAGIC 	OpenBalance decimal(38, 2),
# MAGIC 	EndBalance decimal(38, 2),
# MAGIC 	UpdateTimestamp timestamp NOT NULL,
# MAGIC 	UpdateByHMCUserId varchar(256) NOT NULL,
# MAGIC 	OpenBalanceUSD decimal(38, 2),
# MAGIC 	EndBalanceUSD decimal(38, 2),
# MAGIC 	ETLLoadDateTime timestamp NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC truncate table lh_bronze.Bronze.CrimsonXHoldingsHistory

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC INSERT INTO lh_bronze.Bronze.CrimsonXHoldingsHistory
# MAGIC (FundId
# MAGIC 	   , ShareClassId
# MAGIC 	   , NAVDate
# MAGIC 	   , LotDate
# MAGIC 	   , PortfolioTypeId
# MAGIC 	   , StartDate
# MAGIC 	   , EndDate
# MAGIC 	   , CurrencyId
# MAGIC 	   , OpenBalance
# MAGIC 	   , EndBalance
# MAGIC 	   , UpdateTimestamp
# MAGIC 	   , UpdateByHMCUserId
# MAGIC 	   , OpenBalanceUSD
# MAGIC 	   , EndBalanceUSD
# MAGIC 	   , ETLLoadDateTime)
# MAGIC SELECT FundId
# MAGIC 	   , ShareClassId
# MAGIC 	   , NAVDate
# MAGIC 	   , LotDate
# MAGIC 	   , PortfolioTypeId
# MAGIC 	   , StartDate
# MAGIC 	   , EndDate
# MAGIC 	   , CurrencyId
# MAGIC 	   , OpenBalance
# MAGIC 	   , EndBalance
# MAGIC 	   , UpdateTimestamp
# MAGIC 	   , UpdateByHMCUserId
# MAGIC 	   , OpenBalanceUSD
# MAGIC 	   , EndBalanceUSD
# MAGIC 	   , ETLLoadDateTime
# MAGIC FROM lh_bronze.Bronze.CrimsonXHoldings

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql(""" DROP TABLE IF EXISTS lh_curated.Silver.FundMarketValue """)

spark.sql("""
    CREATE TABLE lh_curated.Silver.FundMarketValue (
        FundId VARCHAR(36) NOT NULL
        , NAVDate DATE NOT NULL
        , CurrencyId INT NOT NULL
        , OpenBalance DECIMAL(35, 2) NOT NULL
        , EndBalance DECIMAL(35, 2) NOT NULL
        , OpenBalanceUSD DECIMAL(35, 2) NOT NULL
        , EndBalanceUSD DECIMAL(35, 2) NOT NULL
        , ETLLoadDateTime TIMESTAMP NOT NULL
    )
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC truncate table lh_curated.Silver.FundMarketValue

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC INSERT INTO lh_curated.Silver.FundMarketValue
# MAGIC (FundId, NAVDate, CurrencyId, OpenBalance, EndBalance, OpenBalanceUSD, EndBalanceUSD, ETLLoadDateTime)
# MAGIC SELECT chh.FundId
# MAGIC     , chh.NAVDate
# MAGIC     , chh.CurrencyId
# MAGIC     , SUM(COALESCE(chh.OpenBalance, 0)) OpenBalance
# MAGIC     , SUM(COALESCE(chh.EndBalance, 0)) EndBalance
# MAGIC     , SUM(COALESCE(chh.OpenBalance, 0) * COALESCE(fx.FXRate, 1)) OpenBalanceUSD
# MAGIC     , SUM(COALESCE(chh.EndBalance, 0) * COALESCE(fx.FXRate, 1)) EndBalanceUSD
# MAGIC     , current_timestamp
# MAGIC FROM lh_bronze.Bronze.CrimsonXHoldings chh
# MAGIC         LEFT JOIN lh_curated.Silver.FXRate fx ON fx.CurrencyId = chh.CurrencyId
# MAGIC                                                     AND fx.FXDate = CASE WHEN CAST(chh.NAVDate AS DATE) = last_day(current_date) THEN CAST('2025-10-22' AS DATE) ELSE CAST(chh.NAVDate AS DATE) END
# MAGIC WHERE chh.EndDate = to_date('12/31/9999', 'MM/dd/yyyy')
# MAGIC         AND chh.PortfolioTypeId = 0
# MAGIC GROUP BY chh.FundId
# MAGIC         , chh.NAVDate
# MAGIC         , chh.CurrencyId

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE lh_bronze.Bronze.SolovisActiveBookFundMapping(
# MAGIC 	InvestmentResourceId int NOT NULL,
# MAGIC 	InvestmentId int NOT NULL,
# MAGIC 	FundId VARCHAR(36) NOT NULL,
# MAGIC 	ShareClassId VARCHAR(36) NOT NULL,
# MAGIC 	ActiveBookType VARCHAR(50) NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE lh_curated.Silver.ShareClass(
# MAGIC 	ShareClassId varchar(36) NOT NULL,
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	ShareClassName varchar(8000) NOT NULL,
# MAGIC 	EffectiveDate date,
# MAGIC 	IsDefault boolean,
# MAGIC 	IlliquidPct decimal(38, 8),
# MAGIC 	ETLLoadDateTime timestamp NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC truncate table lh_curated.Silver.ShareClass

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC INSERT INTO lh_curated.Silver.ShareClass
# MAGIC (ShareClassId,
# MAGIC 	   FundId,
# MAGIC 	   ShareClassName,
# MAGIC 	   EffectiveDate,
# MAGIC 	   IsDefault,
# MAGIC 	   IlliquidPct,
# MAGIC 	   ETLLoadDateTime)
# MAGIC SELECT ShareClassId,
# MAGIC 	   FundId,
# MAGIC 	   ShareClassName,
# MAGIC 	   EffectiveDate,
# MAGIC 	   IsDefault,
# MAGIC 	   IlliquidPct,
# MAGIC 	   ETLLoadDateTime
# MAGIC FROM lh_bronze.Bronze.CrimsonXShareClass

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.Transaction(
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	ExposureDate date NOT NULL,
# MAGIC 	TransactionTypeId int NOT NULL,
# MAGIC 	TransactionSubTypeId int NOT NULL,
# MAGIC 	TransactionAmountInLocal decimal(38, 2),
# MAGIC 	TransactionAmountInUSD decimal(38, 2),
# MAGIC 	TransactionAmountOutLocal decimal(38, 2),
# MAGIC 	TransactionAmountOutUSD decimal(38, 2),
# MAGIC 	TransactionAmountLocal decimal(38, 2),
# MAGIC 	TransactionAmountUSD decimal(38, 2),
# MAGIC 	TransactionCount bigint,
# MAGIC 	ETLLoadDateTime timestamp NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE lh_bronze.Bronze.SolovisDailyLoadMarketValues(
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	ShareClassId varchar(36) NOT NULL,
# MAGIC 	NAVDate date NOT NULL,
# MAGIC 	LotDate date NOT NULL,
# MAGIC 	PortfolioTypeId int NOT NULL,
# MAGIC 	StartDate date NOT NULL,
# MAGIC 	EndDate date NOT NULL,
# MAGIC 	CurrencyId int NOT NULL,
# MAGIC 	OpenBalance decimal(35, 2) NOT NULL,
# MAGIC 	EndBalance decimal(38, 2) NOT NULL,
# MAGIC 	UpdateTimestamp timestamp NOT NULL,
# MAGIC 	UpdateByHMCUserId varchar(8000) NOT NULL,
# MAGIC 	OpenBalanceUSD decimal(35, 2) NOT NULL,
# MAGIC 	EndBalanceUSD decimal(38, 6) NOT NULL,
# MAGIC 	ETLLoadDateTime timestamp NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE lh_bronze.Bronze.SolovisDailyLoadTransactions(
# MAGIC 	CashflowTransactionDetailId bigint NOT NULL,
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	ShareClassId varchar(36) NOT NULL,
# MAGIC 	CurrencyId int NOT NULL,
# MAGIC 	FXRate decimal(38, 15) NOT NULL,
# MAGIC 	PortfolioTypeId int NOT NULL,
# MAGIC 	CashflowTransactionTypeId int NOT NULL,
# MAGIC 	CashflowTransactionSubtypeId int NOT NULL,
# MAGIC 	TransactionAmountInLocal decimal(38, 2) NOT NULL,
# MAGIC 	TransactionAmountInUSD decimal(38, 2) NOT NULL,
# MAGIC 	TransactionAmountOutLocal decimal(38, 2) NOT NULL,
# MAGIC 	TransactionAmountOutUSD decimal(38, 2) NOT NULL,
# MAGIC 	CommitmentEffectLocal decimal(38, 2) NOT NULL,
# MAGIC 	MarketValueEffectLocal decimal(38, 2) NOT NULL,
# MAGIC 	BookStartOfDay boolean NOT NULL,
# MAGIC 	ExposureDate date NOT NULL,
# MAGIC 	TradeDate date,
# MAGIC 	SettleDate date,
# MAGIC 	ReturnedAmountLocal decimal(38, 2) NOT NULL,
# MAGIC 	ReturnedAmountUSD decimal(38, 2) NOT NULL,
# MAGIC 	UnfundedAdjustmentLocal decimal(38, 2) NOT NULL,
# MAGIC 	UnfundedAdjustmentUSD decimal(38, 2) NOT NULL,
# MAGIC 	FundedAmountLocal decimal(38, 2) NOT NULL,
# MAGIC 	FundedAmountUSD decimal(38, 2) NOT NULL,
# MAGIC 	RecallableAmountLocal decimal(38, 2) NOT NULL,
# MAGIC 	RecallableAmountUSD decimal(38, 2) NOT NULL,
# MAGIC 	TransactionTypeIdSource int,
# MAGIC 	TransactionIdSource int,
# MAGIC 	CommitmentEffectUSD decimal(38, 2) NOT NULL,
# MAGIC 	MarketValueEffectUSD decimal(38, 2) NOT NULL,
# MAGIC 	TransactionTag varchar(8000),
# MAGIC 	ETLLoadDateTime timestamp NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE Silver.FundStatisticsExcludedFunds(
# MAGIC 	FundId varchar(36) NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC INSERT INTO lh_curated.Silver.FundStatisticsExcludedFunds
# MAGIC   (FundId)
# MAGIC   VALUES('392a50f7-6a5a-410c-8e2d-5c77e02117c2'),
# MAGIC ('6dd56666-f892-4148-b62a-d7a150ae4053'),
# MAGIC ('370ce44d-1a1c-49ec-86d8-b17983cbe165'),
# MAGIC ('8635ed5a-d7c5-4f64-944b-2d4845109005'),
# MAGIC ('35057789-6384-44a7-8d72-87ffc5d8e125'),
# MAGIC ('41bcc69d-64f7-48d7-b171-9a26204e4bb2'),
# MAGIC ('706e5320-dbeb-476f-bc1a-f5a3328826d0'),
# MAGIC ('b1a2a7e5-fbd9-468e-be6d-f84191271085'),
# MAGIC ('dc9bbef9-088b-4a8d-9701-53fd33662902'),
# MAGIC ('e82b41f9-f565-472a-969f-2add7fb93f8c'),
# MAGIC ('f97fc410-a838-40d8-a208-b8af5e7e4313'),
# MAGIC ('0f21e6bd-5f03-413a-a29d-20ae4ba5b4e7'),
# MAGIC ('ff31f733-0f20-4072-a9e0-77f1bdc3faed'),
# MAGIC ('2a57501b-40a0-4e95-9f96-2e39f5b9eb9f'),
# MAGIC ('7a2cb9d0-50a7-4173-9496-2aa852066019'),
# MAGIC ('b98ae363-8620-4114-aa5d-0d06938f9362'),
# MAGIC ('ed660200-0859-4eb7-bbc4-0fd84652f825')

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
CREATE TABLE Gold.FundHorizonAlpha (
    FundId varchar(36) NOT NULL,
    StatisticTypeId int NOT NULL,    
    EndDate date NOT NULL,
    ITD decimal(38,6),
    ITDError string,
    ITDDetailsKey string,
    HMCITD decimal(38,6),
    HMCITDError string,
    HMCITDDetailsKey string,
    CYTD decimal(38,6),
    CYTDError string,
    CYTDDetailsKey string,
    FYTD decimal(38,6),
    FYTDError string,
    FYTDDetailsKey string,
    OneYear decimal(38,6),
    OneYearError string,
    OneYearDetailsKey string,
    ThreeYear decimal(38,6),
    ThreeYearError string,
    ThreeYearDetailsKey string,
    FiveYear decimal(38,6),
    FiveYearError string,
    FiveYearDetailsKey string,
    SevenYear decimal(38,6),
    SevenYearError string,
    SevenYearDetailsKey string,
    TenYear decimal(38,6),
    TenYearError string,
    TenYearDetailsKey string,
    FifteenYear decimal(38,6),
    FifteenYearError string,
    FifteenYearDetailsKey string,
    TwentyYear decimal(38,6),
    TwentyYearError string,
    TwentyYearDetailsKey string,
    AsOfDate date NOT NULL,
    ETLLoadDateTime TIMESTAMP NOT NULL
)
USING DELTA
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
CREATE TABLE Gold.FundHorizonRiskBenchmark (
    FundId varchar(36) NOT NULL,
    StatisticTypeId int NOT NULL,    
    EndDate date NOT NULL,
    ITD decimal(38,6),
    ITDError string,
    ITDDetailsKey string,
    HMCITD decimal(38,6),
    HMCITDError string,
    HMCITDDetailsKey string,
    CYTD decimal(38,6),
    CYTDError string,
    CYTDDetailsKey string,
    FYTD decimal(38,6),
    FYTDError string,
    FYTDDetailsKey string,
    OneYear decimal(38,6),
    OneYearError string,
    OneYearDetailsKey string,
    ThreeYear decimal(38,6),
    ThreeYearError string,
    ThreeYearDetailsKey string,
    FiveYear decimal(38,6),
    FiveYearError string,
    FiveYearDetailsKey string,
    SevenYear decimal(38,6),
    SevenYearError string,
    SevenYearDetailsKey string,
    TenYear decimal(38,6),
    TenYearError string,
    TenYearDetailsKey string,
    FifteenYear decimal(38,6),
    FifteenYearError string,
    FifteenYearDetailsKey string,
    TwentyYear decimal(38,6),
    TwentyYearError string,
    TwentyYearDetailsKey string,
    AsOfDate date NOT NULL,
    ETLLoadDateTime TIMESTAMP NOT NULL
)
USING DELTA
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC truncate table lh_bronze.Bronze.SolovisActiveBookFundMapping

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# --- Function to Traverse Cash Directory to get all other cash accounts
from pyspark.sql.functions import col
from datetime import datetime,date,timezone

spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_bronze")
spark.sql("SET spark.sql.caseSensitive = TRUE")

def getCashAccounts():
    dfCashTag = spark.sql("""SELECT TagSetId, Category TagSetCategory, Id TagId, ParentId TagIdParent, Description TagDescription
                            FROM lh_bronze.Bronze.SolovisTagsets
                            WHERE Category = 'Asset Class - GIA'
                            AND   Description = 'Net Cash'  """)  # -- id = 11 

    dfAllTags = spark.sql("""SELECT TagSetId, Category TagSetCategory, Id TagId, ParentId TagIdParent, Description TagDescription
                            FROM lh_bronze.Bronze.SolovisTagsets tsi
                            WHERE tsi.Category = 'Asset Class - GIA' 
                            and   tsi.Description != 'HMC Internal - House'
                            and   NOT(tsi.Description LIKE 'HMC Internal%Offset%' OR tsi.Description LIKE 'HMC Internal%Fin. Costs%')
                            and   not tsi.Description = 'HMC Internal - SUS (Fin. Costs)'  """)  # -- id = 11 

    dfAll = dfAllTags.alias("AllTags")
    BaseTagLevel = dfCashTag.alias("base")
    # base = dfCashTag
    dfAllCashTags = BaseTagLevel
    PrevTagLevel = BaseTagLevel

    # Iteratively find indirect reports
    while True:
        prev_alias = PrevTagLevel.alias("prev")

        NextTagLevel = dfAll.join(
            prev_alias,
            col("AllTags.TagIdParent") == col("prev.TagId"),
            "inner"
        ).select(
            col("AllTags.TagSetId"),
            col("AllTags.TagSetCategory"),
            col("AllTags.TagId"),
            col("AllTags.TagIdParent"),
            col("AllTags.TagDescription")
        )
        
        NewTagRows = NextTagLevel.subtract(dfAllCashTags)  # prevent duplicates
        if NewTagRows.count() == 0:
            break
        dfAllCashTags = dfAllCashTags.union(NewTagRows)
        PrevTagLevel = NewTagRows

    return dfAllCashTags


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Gather all the active book mappings

# Internal ActiveBook
dfInternalActiveBook =  spark.sql("""SELECT 
    si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, f.FundId
	, sc.ShareClassId
    , 'Internal ActiveBook' ActiveBookType
FROM   lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.CrimsonXFund f ON upper(si.AssetClassGia) = upper(f.FundName)
		JOIN lh_bronze.Bronze.CrimsonXShareClass sc ON upper(f.FundId) = upper(sc.FundId)
WHERE  (si.AssetClassGia LIKE 'HMC Internal%')
			and   NOT(si.AssetClassGia LIKE 'HMC Internal%Offset%' OR si.AssetClassGia LIKE 'HMC Internal%Fin. Costs%' or si.AssetClassGia like 'HMC Internal - SUS (Notional Adj)' or si.AssetClassGia = 'HMC Internal - SUS (Fin. Costs)')
		AND    sc.IsDefault = 1
UNION ALL
SELECT 
    si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, f.FundId
	, sc.ShareClassId
    , 'Internal ActiveBook' ActiveBookType
FROM   lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.CrimsonXFund f ON f.FundName ='HMC Internal - SUS'
		JOIN lh_bronze.Bronze.CrimsonXShareClass sc ON upper(f.FundId) = upper(sc.FundId)
WHERE  (si.AssetClassGia = 'HMC Internal - SUS (Fin. Costs)' 
			or si.AssetClassGia = 'HMC Internal - SUS (Notional Adj)')
		AND    sc.IsDefault = 1
		""")

# General Expenses
dfGeneralExpenses =  spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, f.FundId
	, sc.ShareClassId
	, 'General Expenses' ActiveBookType
FROM   lh_bronze.Bronze.SolovisInvestments si 
			JOIN lh_bronze.Bronze.SolovisEntities se ON si.HoldingId = se.Id
			JOIN lh_bronze.Bronze.CrimsonXFund f ON se.Label = f.FundName
			JOIN lh_bronze.Bronze.CrimsonXShareClass sc ON f.FundId = sc.FundId
WHERE  se.Label = 'General Expense - Absolute Return'
		AND    sc.IsDefault = 1
		""")

# External ActiveBook
dfExternalActiveBook =  spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, xref.FundIdCrimsonX FundId
	, xref.ShareClassIdCrimsonX ShareClassId
	, 'External ActiveBook' ActiveBookType 
FROM   lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.SolovisEntities se ON si.HoldingId = se.Id
		JOIN lh_bronze.Bronze.SolovisExternalActiveBook xref ON upper(xref.AssetClassGIA) = upper(se.Label)
																	OR upper(xref.AssetClassGIA) = upper(si.AssetClassGia)
		JOIN lh_bronze.Bronze.CrimsonXFund f ON UPPER(f.FundId) = UPPER(xref.FundIdCrimsonX)
""")

# Cash Offsets
dfCashOffset =  spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, '6dd56666-f892-4148-b62a-d7a150ae4053' FundId
	, '79834536-1fd2-47d1-b296-aba5ebf6163a' ShareClassId
	, 'Cash Offsets' ActiveBookType
FROM lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.CrimsonXShareClass sc ON upper(sc.ShareClassId) = '79834536-1FD2-47D1-B296-ABA5EBF6163A'
WHERE  (si.AssetClassGia LIKE 'HMC Internal%Offset%' OR si.AssetClassGia LIKE 'HMC Internal%Fin. Costs%')
		AND NOT si.AssetClassGia = 'HMC Internal - SUS (Fin. Costs)'
		""")

# Cash Accounts
dfCashAccounts = getCashAccounts()
dfCashAccounts.createOrReplaceTempView("CashTags")

dfCashOther = spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, '6dd56666-f892-4148-b62a-d7a150ae4053' FundId
	, '52542eee-1eed-4192-a24d-bb6ded34ef14' ShareClassId
	, 'Cash' ActiveBookType	   
FROM CashTags ct
		JOIN lh_bronze.Bronze.SolovisInvestments si ON ct.TagId = si.AssetClassGiaTagId
		JOIN lh_bronze.Bronze.CrimsonXFund f ON f.FundName ='HMC Internal - SUS'
WHERE
	-- Keep the original roots
	ct.TagDescription = 'Net Cash'
	OR (
		-- Include all except undesired internal entries
		ct.TagDescription != 'HMC Internal - House'
		AND NOT (
			ct.TagDescription LIKE 'HMC Internal%Offset%' 
			OR ct.TagDescription LIKE 'HMC Internal%Fin. Costs%'
		)
		AND ct.TagDescription != 'HMC Internal - SUS (Fin. Costs)'
	)
""")

# Stock Distributions
dfStockDistributions = spark.sql("""
SELECT si.ResourceId as InvestmentResourceId
	   , si.Id as InvestmentId
	   , '392a50f7-6a5a-410c-8e2d-5c77e02117c2' as FundId
	   , '16022be1-2057-4f96-9b1c-f0c3c43b1231' as ShareClassId
	   , 'Stock Distribution' as ActiveBookType
FROM lh_bronze.Bronze.SolovisInvestments si
		  JOIN lh_bronze.Bronze.SolovisEntities se ON si.HoldingId = se.Id
          JOIN lh_bronze.Bronze.SolovisTagsets tag ON tag.Category = 'Special Entity Type' -- AND Description LIKE '%Fund'
												AND CASE WHEN se.SpecialEntityType = 'External Drawdown Fund' THEN 6
												         WHEN se.SpecialEntityType = 'Public Equity' THEN 17
														 WHEN se.SpecialEntityType = 'Outsider' THEN 16
														 WHEN se.SpecialEntityType = 'External Managed Fund' THEN 11
														 ELSE -999 END = tag.Id
where si.AssetClassGia = 'Private Equity Stock Dist.'
""")

# Funds
dfFunds =  spark.sql("""SELECT 
	si.ResourceId InvestmentResourceId
	, si.Id InvestmentId
	, lower(xf.HMCObjectIdCrimsonX) FundId
	, lower(xsc.HMCObjectIdCrimsonX) ShareClassId
	, 'Fund' ActiveBookType
FROM lh_bronze.Bronze.SolovisInvestments si
		JOIN lh_bronze.Bronze.SolovisEntities se ON si.HoldingId = se.Id
		JOIN lh_bronze.Bronze.HMCDataWarehousevwSourceReferenceFlatten_CrimsonX xsc ON xsc.ReferenceId = si.ResourceId
																		AND xsc.HMCObjectType = 'Share Class'
		JOIN lh_bronze.Bronze.HMCDataWarehousevwSourceReferenceFlatten_CrimsonX xf ON xf.ReferenceId = si.HoldingId
																		AND xf.HMCObjectType = 'Fund'
""")

# dfFunds =  spark.sql("""SELECT 
# 	si.ResourceId InvestmentResourceId
# 	, si.Id InvestmentId
# 	, lower(xf.FundId) as FundId
# 	, lower(xsc.ShareClassId) ShareClassId
# 	, 'Fund' ActiveBookType
# FROM lh_bronze.Bronze.SolovisInvestments si
# 		JOIN lh_bronze.Bronze.SolovisEntities se ON si.HoldingId = se.Id
# 		JOIN lh_bronze.Bronze.CrimsonXFund xf ON lower(xf.FundId) = lower(se.CrimsonFundId)
# 		LEFT JOIN lh_bronze.Bronze.SolovisActiveBookFundMapping xsc ON xsc.InvestmentResourceId = si.ResourceId
# """)

dfActiveBook = dfInternalActiveBook \
	.union(dfGeneralExpenses) \
	.union(dfExternalActiveBook) \
	.union(dfCashOffset) \
	.union(dfCashOther) \
	.union(dfStockDistributions)

# Remove the duplicate active book records to only get funds
dfFunds = dfFunds.join(dfActiveBook, on=['InvestmentResourceId', 'InvestmentId'], how='left_anti')

dfActiveBookFundMapping = dfActiveBook \
    .union(dfFunds)
dfActiveBookFundMapping.createOrReplaceTempView("dfActiveBookFundMapping")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""INSERT INTO lh_bronze.Bronze.SolovisActiveBookFundMapping
(InvestmentResourceId, InvestmentId, FundId, ShareClassId, ActiveBookType)
SELECT dabfm.InvestmentResourceId
       , dabfm.InvestmentId
       , dabfm.FundId
       , dabfm.ShareClassId
       , dabfm.ActiveBookType
FROM dfActiveBookFundMapping dabfm""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
