# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# This notebook contains shared code that is used by other notebooks that calculate various fund horizon statistics

# CELL ********************

import decimal
import requests
from datetime import date, datetime
from requests.exceptions import HTTPError, ConnectionError, Timeout, RequestException
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, DecimalType, DateType, StringType, IntegerType, LongType
from pyspark.sql.functions import to_date, lower
from delta.tables import DeltaTable

spark.conf.set('spark.sql.caseSensitive', True)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)
bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)

statistic_irr = 0
statistic_md_return = 1
statistic_gross_return = 2

statistic_crbm_return = 3

statistic_gross_alpha = 4
statistic_gross_manager_alpha = 5
statistic_gross_strategy_alpha = 6
statistic_net_alpha = 7

horizon_time_periods = [
    (3, "ITD"),
    (4, "HMCITD"),
    (1, "CYTD"),
    (2, "FYTD"),
    (5, "OneYear"),
    (6, "ThreeYear"),
    (7, "FiveYear"),
    (8, "SevenYear"),
    (9, "TenYear"),
    (11, "FifteenYear"),
    (12, "TwentyYear"),
]

freq_monthly = 2
freq_quarterly = 3
freq_annually = 4
freq_semi_annually = 7
freq_calendar_year = 21
freq_fiscal_year = 22

fund_structure_drawdown = 1
calc_method_irr = 0


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def getActiveFunds():

    spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Silver/FundMarketValue").createOrReplaceTempView("vwFundMarketValue")

    active_fund_ids_df = spark.sql("""
        SELECT DISTINCT FundId 
        FROM vwFundMarketValue
        where NAVDate = '2025-06-30' AND (OpenBalance != 0 OR EndBalance != 0)  
    """)

    spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Silver/Fund").createOrReplaceTempView("vwFund")

    fund_df = spark.sql("""
        SELECT FundId, FundName, FundStructureId, CalculationMethodologyId, FundValuationFrequency, LastValuationDate 
        FROM vwFund  
        WHERE FundId NOT IN (SELECT FundId FROM Silver.FundStatisticsExcludedFunds) 
    """)

    fund_df = fund_df.withColumn("FundId", lower(fund_df["FundId"]))

    # display(fund_df)

    active_fund_df = fund_df.join(active_fund_ids_df, on=["FundId", "FundId"], how="left_semi")
    active_fund_count = active_fund_df.count()

    print(f"Funds with market value: {active_fund_count}")
    return active_fund_df


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def getAllFunds():

    fund_path = f"{curated_lh_basepath}/Tables/Silver/Fund"
    fund_df = spark.sql(f""" 
        SELECT FundId, FundName, FundStructureId, CalculationMethodologyId, FundValuationFrequency, LastValuationDate 
        FROM delta.`{fund_path}` 
        WHERE FundId NOT IN (SELECT FundId FROM Silver.FundStatisticsExcludedFunds) and LastValuationDate is not NULL
    """)

    fund_count = fund_df.count()

    print(f"All funds: {fund_count}")
    return fund_df

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def getChangedFunds():

    process_fund_path = f"{bronze_lh_basepath}/Tables/Bronze/ProcessFundChanges"
    process_fund_ids_df = spark.sql(f""" 
        SELECT DISTINCT FundId 
        FROM delta.`{process_fund_path}`  
    """)

    fund_path = f"{curated_lh_basepath}/Tables/Silver/Fund"
    fund_df = spark.sql(f""" 
        SELECT FundId, FundName, FundStructureId, CalculationMethodologyId, FundValuationFrequency, LastValuationDate 
        FROM delta.`{fund_path}` 
        WHERE FundId NOT IN (SELECT FundId FROM Silver.FundStatisticsExcludedFunds)
    """)

    changed_fund_df = fund_df.join(process_fund_ids_df, on=["FundId", "FundId"], how="left_semi")
    changed_fund_count = changed_fund_df.count()

    print(f"Changed funds: {changed_fund_count}")
    return changed_fund_df

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def calcFundStatistics(request_data):

    start_time = datetime.now()

    data = http_post(CalculateFundStatisticsUrl, request_data)

    def convert_floats_to_decimal(record, keys):
        for key in keys:
            if key in record and isinstance(record[key], float):
                record[key] = decimal.Decimal(str(record[key]))
        return record

    float_keys_to_convert = ["value"]  
    data["statisticValues"] = [convert_floats_to_decimal(row, float_keys_to_convert) for row in data["statisticValues"]]
    data["returnStreamValues"] = [convert_floats_to_decimal(row, float_keys_to_convert) for row in data["returnStreamValues"]]

    end_time = datetime.now()
    elapsed = end_time - start_time  # Returns a timedelta
    print("calcFundStatistics elapsed time:", elapsed)    

    return data


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def deleteHorizonReturns(fund_ids, table_name):
    print(f"Deleting from {table_name}...")
    delta_table = DeltaTable.forPath(spark, f"{curated_lh_basepath}/Tables/Gold/{table_name}")
    delta_table.delete(condition = F.col("FundId").isin(fund_ids))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def mergeHorizonReturns(fund_ids, statistics_json, table_name):

    start_time = datetime.now()

    statistics_schema = StructType([
        StructField("fundId", StringType(), False),
        StructField("statisticTypeId", IntegerType(), False),
        StructField("timePeriodId", IntegerType(), False),
        StructField("startDate", StringType(), False),  # parse later
        StructField("endDate", StringType(), False),    # parse later
        StructField("value", DecimalType(38, 6), True),
        StructField("error", StringType(), True),
        StructField("detailsKey", StringType(), True),
        StructField("detailsFingerprint", StringType(), True),
        StructField("asOfDate", DateType(), True)
    ])

    statistics_df = spark.createDataFrame(statistics_json, schema=statistics_schema)

    # Convert string to actual DateType
    statistics_df = statistics_df.withColumn("startDate", to_date("startDate", "yyyy-MM-dd"))
    statistics_df = statistics_df.withColumn("endDate", to_date("endDate", "yyyy-MM-dd"))

    print("Number of statistics rows returned:", statistics_df.count())

    deleteHorizonReturns(fund_ids, table_name)

    # statistics_df.printSchema()statistics_schema
    # statistics_df.show(truncate=False)

    horizon_df = statistics_df.select("fundId", "statisticTypeId", "endDate").distinct() \
        .withColumnsRenamed({'fundId': 'FundId', 'statisticTypeId': 'StatisticTypeId', 'endDate': 'EndDate'})

    for timePeriod in horizon_time_periods:

        time_period_id = timePeriod[0]   
        time_period_name = timePeriod[1]

        period_df = statistics_df.filter(F.col("timePeriodId").isin(time_period_id)).select(
            F.col("fundId").alias("FundId"),
            F.col("statisticTypeId").alias("StatisticTypeId"),        
            F.col("value").alias(time_period_name),
            F.col("error").alias(time_period_name + "Error"),
            F.col("detailsKey").alias(time_period_name + "DetailsKey")).alias("period")  
        horizon_df = horizon_df.join(period_df, ["FundId", "StatisticTypeId"], how="inner")

    horizon_df = horizon_df.withColumn("AsOfDate", F.lit(date.today()))
    horizon_df = horizon_df.withColumn("ETLLoadDateTime", F.lit(datetime.now()))

    # horizon_df.printSchema()
    # horizon_df.show(truncate=True)

    print(f"Merging {table_name}...")

    horizon_df.write.format("delta").mode("append").save(f"{curated_lh_basepath}/Tables/Gold/{table_name}")

    spark.catalog.refreshTable(f"Gold.{table_name}")

    end_time = datetime.now()
    elapsed = end_time - start_time  # Returns a timedelta
    print("mergeHorizonReturns elapsed time:", elapsed)    

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def deleteProcessFundChanges(fund_ids):
    print(f"Deleting from ProcessFundChanges...")
    delta_table = DeltaTable.forPath(spark, f"{bronze_lh_basepath}/Tables/Bronze/ProcessFundChanges")
    delta_table.delete(condition = F.col("FundId").isin(fund_ids))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def isLastDayOfMonth(input_date):
    next_day = input_date + timedelta(days=1)
    return next_day.day == 1

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def previousMonthEnd(input_date):
    return input_date - timedelta(days=input_date.day)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************


# CELL ********************

# from pyspark.sql.types import StructType, StructField, IntegerType, StringType

# spark.conf.set('spark.sql.caseSensitive', True)

# spark.sql(""" DROP TABLE Silver.StatisticTypes """)

# spark.sql("""
# CREATE TABLE Silver.StatisticTypes (
#     StatisticTypeId int NOT NULL,
#     Description varchar(128) NOT NULL
# )
# USING DELTA
# """) 

# statistic_types_schema = StructType([
#     StructField("StatisticTypeId", IntegerType(), True),
#     StructField("Description", StringType(), True)
# ])

# statistic_types_df = spark.createDataFrame([
#     (0, "IRR",), 
#     (1, "Modified Dietz Return",), 
#     (2, "Gross Return",), 
#     (3, "Custom Risk Benchmark Return",), 
#     (4, "Gross Alpha",), 
#     (5, "Gross Manager Alpha",), 
#     (6, "Gross Strategy Alpha",), 
#     (7, "Net Alpha",), 
# ], statistic_types_schema)

# statistic_types_df.write.format("delta").mode("append").save("Tables/Silver/StatisticTypes")

# spark.catalog.refreshTable("Silver.StatisticTypes")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# spark.conf.set('spark.sql.caseSensitive', True)

# spark.sql(""" DROP TABLE Silver.FundStatisticsExcludedFunds """)

# spark.sql("""
# CREATE TABLE Silver.FundStatisticsExcludedFunds (
#     FundId varchar(36) NOT NULL
# )
# USING DELTA
# """) 

# excluded_funds_df = spark.createDataFrame([
#     ("392a50f7-6a5a-410c-8e2d-5c77e02117c2",), # HMC Stock Distributions
#     ("6dd56666-f892-4148-b62a-d7a150ae4053",), # Net Notional AR-AP Adjustments
#     ("370ce44d-1a1c-49ec-86d8-b17983cbe165",), # Overhead Expenses - TIPS
#     ("8635ed5a-d7c5-4f64-944b-2d4845109005",), # Overhead Expenses - High Yield
#     ("35057789-6384-44a7-8d72-87ffc5d8e125",), # House Euro Equity
#     ("41bcc69d-64f7-48d7-b171-9a26204e4bb2",), # Tufnell Park Global Rates
#     ("706e5320-dbeb-476f-bc1a-f5a3328826d0",), # Iron Park Capital Investors LP
#     ("b1a2a7e5-fbd9-468e-be6d-f84191271085",), # OAL Adjustment (Historical)
#     ("dc9bbef9-088b-4a8d-9701-53fd33662902",), # Regent JV II
#     ("e82b41f9-f565-472a-969f-2add7fb93f8c",), # RE Direct A/R
#     ("f97fc410-a838-40d8-a208-b8af5e7e4313",), # Event Driven
#     ("0f21e6bd-5f03-413a-a29d-20ae4ba5b4e7",), # HURP
#     ("ff31f733-0f20-4072-a9e0-77f1bdc3faed",), # HURP
#     ("2a57501b-40a0-4e95-9f96-2e39f5b9eb9f",), # HURP
#     ("7a2cb9d0-50a7-4173-9496-2aa852066019",), # HURP
#     ("b98ae363-8620-4114-aa5d-0d06938f9362",), # HURP
#     ("ed660200-0859-4eb7-bbc4-0fd84652f825",) # HURP
# ], ["FundId"])

# excluded_funds_df.write.format("delta").mode("append").save("Tables/Silver/FundStatisticsExcludedFunds")

# spark.catalog.refreshTable("Silver.FundStatisticsExcludedFunds")

# excluded_funds = excluded_funds_df.collect()
# excluded_fund_ids = [row["FundId"] for row in excluded_funds]
# print(excluded_fund_ids)

# deleteFundHorizonReturns(excluded_fund_ids)
# deleteFundReturns(excluded_fund_ids)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
