# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     },
# META     "environment": {}
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from delta.tables import DeltaTable
# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number, lit
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId =  ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

lh_bronze_basepath = get_basepath(WorkspaceId, BronzeLHId)
lh_curated_basepath = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(lh_bronze_basepath )
display(lh_curated_basepath )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

ETLLoadDateTime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
display(ETLLoadDateTime)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC -- DROP TABLE IF EXISTS lh_curated.Silver.HMCUser;
# MAGIC 
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.HMCUser(
# MAGIC 	HMCUserId varchar(256) NOT NULL,
# MAGIC 	NetworkUserName varchar(8000),
# MAGIC 	FirstName varchar(8000) NOT NULL,
# MAGIC 	LastName varchar(8000) NOT NULL,
# MAGIC 	Initials varchar(8000) NOT NULL,
# MAGIC 	DisplayName varchar(8000) NOT NULL,
# MAGIC 	EMailAddress varchar(8000),
# MAGIC 	IsActive BOOLEAN NOT NULL,
# MAGIC 	Department varchar(8000),
# MAGIC 	JobTitle varchar(8000),
# MAGIC 	ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC 	
# MAGIC ) 

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# Check if dest table is empty
dest_count = spark.table("lh_curated.Silver.HMCUser").count()

if dest_count == 0:
    spark.sql("""
        INSERT INTO lh_curated.Silver.HMCUser (
    HMCUserId,
    NetworkUserName,
    FirstName,
    LastName,
    Initials,
    DisplayName,
    EMailAddress,
    IsActive,
    Department,
    JobTitle,
    ETLLoadDateTime
)
SELECT
    CAST(src.HMCUserId AS VARCHAR(256))   AS HMCUserId,
    src.NetworkUserName,
    src.FirstName,
    src.LastName,
    src.Initials,
    src.DisplayName,
    src.EMailAddress,
    CAST(src.IsActive AS BOOLEAN),
    NULL as Department,
    NULL as JobTitle,
    CAST(src.ETLLoadDateTime AS TIMESTAMP)
FROM lh_bronze.Bronze.CrimsonXHMCUser AS src;
          
    """)
else:
    print("Destination table is not empty — skipping MERGE.")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Get the STAGE_Users and transform to fit HMCUser table

# CELL ********************


spark.conf.set("spark.sql.caseSensitive", "true")

stageHMCUser_df = spark.table("lh_bronze.Bronze.EntraUsers") \
.filter(F.col("givenName").isNotNull() & F.col("surname").isNotNull()) \
.select(
    F.regexp_replace(F.col("userPrincipalName"), "@hmc.harvard.edu", "").alias("HMCUserId"),
    F.regexp_replace(F.col("userPrincipalName"), "@hmc.harvard.edu", "").alias("NetworkUserName"),
    F.col("givenName").alias("FirstName"),
    F.col("surname").alias("LastName"),
    F.col("mail").alias("EMailAddress"),
    F.col("accountEnabled").alias("IsActive"),
    F.col("jobTitle").alias("JobTitle"),
    F.col("department").alias("Department"),
    F.lit(ETLLoadDateTime).cast("timestamp").alias("ETLLoadDateTime")
)

stageHMCUser_df = stageHMCUser_df \
    .withColumn("Initials", F.upper(F.concat_ws("", F.substring(F.col("FirstName"), 1, 1), F.substring(F.col("LastName"), 1, 1)))) \
    .withColumn("DisplayName", F.concat_ws(" ", F.col("FirstName"), F.col("LastName")))

stageHMCUser_df.createOrReplaceTempView("stageHMCUser")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC select count(*) from stageHMCUser

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Merge user information

# CELL ********************

spark.sql("""
MERGE INTO lh_curated.Silver.HMCUser AS dest
USING stageHMCUser AS src
ON lower(trim(dest.HMCUserId)) = lower(trim(CAST(src.HMCUserId AS STRING)))

WHEN MATCHED THEN
  UPDATE SET
    dest.NetworkUserName = src.NetworkUserName,
    dest.FirstName = src.FirstName,
    dest.LastName = src.LastName,
    dest.Initials = src.Initials,
    dest.DisplayName = src.DisplayName,
    dest.EMailAddress = src.EMailAddress,
    dest.IsActive = src.IsActive,
    dest.JobTitle = src.JobTitle,
    dest.Department = src.Department,
    dest.ETLLoadDateTime = src.ETLLoadDateTime

WHEN NOT MATCHED THEN
  INSERT (
    HMCUserId,
    NetworkUserName,
    FirstName,
    LastName,
    Initials,
    DisplayName,
    EMailAddress,
    IsActive,
    JobTitle,
    Department,
    ETLLoadDateTime
  )
  VALUES (
    CAST(src.HMCUserId AS STRING),
    src.NetworkUserName,
    src.FirstName,
    src.LastName,
    src.Initials,
    src.DisplayName,
    src.EMailAddress,
    src.IsActive,
    src.JobTitle,
    src.Department,
    src.ETLLoadDateTime
  )
""")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Refresh table metadata
spark.sql("REFRESH TABLE lh_curated.Silver.HMCUser")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# from pyspark.sql.functions import lit
# from delta.tables import DeltaTable

# # Read the existing Delta table
# df = spark.read.format("delta").table("lh_curated.Silver.HMCUser")

# # Add the new column (with NULLs or default value)
# df_new = df.withColumn(    "ETLLoadDateTime", lit(ETLLoadDateTime).cast("timestamp"))



# # Overwrite the table with the new schema
# df_new.write.format("delta") \
#     .mode("append") \
#     .option("overwriteSchema", "false") \
#     .saveAsTable("lh_curated.Silver.HMCUser")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
