# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# ## Manual Run Notebook. Run this notebook once. This is not part of any orchestration.

# MARKDOWN ********************

# There is no source data, data is generated here

# CELL ********************

spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# Change the GUIDs, if it's a different environment/workspace

# PARAMETERS CELL ********************

CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# from pyspark.sql.types import StructType, StructField, IntegerType, StringType
# lh_curated_basepath = get_basepath(WorkspaceId,CuratedLHId)
# target_path = f'{lh_curated_basepath}/Tables/Silver/FundType'
# # Define schema
# schema = StructType([
#     StructField("FundTypeId", IntegerType(), False),
#     StructField("Description", StringType(), False)
# ])


# # Create data
# data = [
#     (0, "Existing"),
#     (1, "Incremental"),
#     (2, "Allocated"),
#     (3, "SidePocket"),
#     (4, "PublicDrawdown"),
#     (5, "Uncategorized")
# ]


# # Create DataFrame
# df = spark.createDataFrame(data, schema)

# # Show the result
# df.show()

# # Write as Delta table to ABFSS
# df.write.format("delta").mode("overwrite").save(target_path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


from pyspark.sql.types import StructType, StructField, IntegerType, StringType
lh_curated_basepath = get_basepath(WorkspaceId,CuratedLHId)
target_path = f'{lh_curated_basepath}/Tables/Silver/ReportFrequency'
# Define schema
schema = StructType([
    StructField("ReportFrequencyId", IntegerType(), False),
    StructField("Description", StringType(), False)
])


# Create data
data = [
    (1, "Year"),
    (2, "Month")
]

# Create DataFrame
df = spark.createDataFrame(data, schema)

# Show the result
df.show()

# Write as Delta table to ABFSS
df.write.format("delta").mode("overwrite").save(target_path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
