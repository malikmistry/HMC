# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Databricks/Synapse/Microsoft Fabric Notebook
# Title: Move BlueVoyant vendors to Silver.VendorScoreCard (lh_curated)
# ------------------------------------------------------------------
# Setup notes:
# - Attach this notebook to your TARGET Lakehouse: **lh_curated** (as default).
# - Also attach your SOURCE Lakehouse (e.g., **lh_bronze**) as a secondary, or
#   update SOURCE_LAKEHOUSE below to '' if the source table lives in the same Lakehouse.
# - This notebook reads from Bronze.BlueVoyantMock, filters out blank/null VendorName,
#   and writes a Delta table to Silver.VendorScoreCard.

# COMMAND ----------

# Parameters — adjust as needed
SOURCE_LAKEHOUSE = "lh_bronze"   # If source is in the same Lakehouse as the notebook, set to ""
SOURCE_SCHEMA    = "Bronze"
SOURCE_TABLE     = "BlueVoyantMock"

TARGET_LAKEHOUSE = "lh_curated"
TARGET_SCHEMA    = "Silver"
TARGET_TABLE     = "VendorScoreCard"

# COMMAND ----------

from pyspark.sql import functions as F
spark.conf.set("spark.sql.legacy.timeParserPolicy", "CORRECTED")


def fq(lakehouse: str, schema: str, table: str) -> str:
    """
    Build a fully-qualified table name that works in Fabric when multiple Lakehouses are attached.
    If `lakehouse` is empty, returns `schema.table`.
    Otherwise returns `lakehouse.schema.table`.
    """
    return f"{schema}.{table}" if not lakehouse else f"{lakehouse}.{schema}.{table}"

source_fqn = fq(SOURCE_LAKEHOUSE, SOURCE_SCHEMA, SOURCE_TABLE)
target_fqn = fq(TARGET_LAKEHOUSE,TARGET_SCHEMA,TARGET_TABLE)

print(f"Reading from: {source_fqn}")
print(f"Will write to: {target_fqn}")

# COMMAND ----------

# Read source table
src_df = spark.table(source_fqn)

# Filter out null/blank VendorName
curated_df = src_df.where(
    F.col("VendorName").isNotNull() & (F.length(F.trim(F.col("VendorName"))) > 0)
)

display(curated_df.limit(20))

date_cols = [
    "LastInternalReview",
    "LastExternalVendorScan",
    "LastExternalVendorReview",
    "LastDRBCPUpdate",
]

def to_date_any(col):
    c = F.when(F.trim(F.col(col)) == "", None).otherwise(F.col(col))
    return F.coalesce(
        # already date/timestamp? just cast down to date
        F.col(col).cast("date"),
        # explicit common formats
        F.to_date(c, "yyyy-MM-dd"),
        F.to_date(c, "MM/dd/yyyy"),
        F.to_date(c, "M/d/yyyy"),
        F.to_date(c, "yyyy/MM/dd"),
        F.to_date(c, "MM-dd-yyyy"),
        F.to_date(c, "M-d-yyyy"),
    )

for c in date_cols:
    if c in curated_df.columns:
        curated_df = curated_df.withColumn(c, to_date_any(c))

# (optional) quick check of inferred dtypes
print("Schema headed to Silver:")
print(curated_df.dtypes)

# Ensure target schema exists
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {TARGET_SCHEMA}")

# Write to Silver.VendorScoreCard (Delta), overwrite with schema evolution
(
    curated_df
    .write
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .format("delta")
    .saveAsTable(target_fqn)
)

print("Write complete.")

# COMMAND ----------

# Quick sanity checks
count_all = curated_df.count()
print(f"Row count written to {target_fqn}: {count_all}")

print("Preview the first few rows:")
display(spark.table(target_fqn).limit(20))




# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
