# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     },
# META     "environment": {
# META       "environmentId": "694fc784-adba-8df0-47c1-b0022607347b",
# META       "workspaceId": "00000000-0000-0000-0000-000000000000"
# META     }
# META   }
# META }

# CELL ********************

## ===== Version to filter only conversations pre-analyzed on AivyConversationUserSentiment

from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql import types as T
from delta.tables import DeltaTable

# === Tables ===
SOURCE_TABLE = "lh_curated.Silver.aivychathistory"
ACUS_TABLE   = "lh_curated.Gold.AivyConversationUserSentiment"

# === Source columns ===
COL_CONV_ID       = "conversationId"
COL_USER_ID       = "conversationUserId"   
COL_DISPLAYNAME   = "DisplayName"
COL_MSG_ID        = "messageId"
COL_ROLE          = "messageRole_category"
COL_TEXT          = "messageContent"
COL_MSG_CREATED   = "messageCreatedAt"
COL_CONV_CREATED  = "conversationCreatedAt"

# === Role values ===
COL_ROLE_USER_VAL = "User"
COL_ROLE_AIVY_VAL = "Aivy Response"

# 1) Pull the filtered acus subset
acus_filtered = (
    spark.table(ACUS_TABLE)
         .where( (F.col("SentimentLabel") == "dissatisfied") &
                 (F.col("ReasonCategory") == "Re-wording") )
         .select(
             "conv_user_key",
             "ConversationCreatedAt",
             "DisplayName",
             "SentimentLabel",
             "MostDissatisfiedMessageSnippet",
             "ReasonCategory",
             "ReasonDetails"
         )
         .dropDuplicates(["conv_user_key"])
)

# 2) Load chat history and normalize the join key
df_raw_full = (
    spark.table(SOURCE_TABLE)
         .withColumn(COL_MSG_CREATED, F.col(COL_MSG_CREATED).cast("timestamp"))
)

# If aivychathistory already has conv_user_key, use it; otherwise map conversationUserId -> conv_user_key
has_conv_user_key = "conv_user_key" in df_raw_full.columns
df_raw_with_key = (
    df_raw_full if has_conv_user_key
    else df_raw_full.withColumn("conv_user_key", F.col(COL_USER_ID))
)

# 3) Restrict chat history to ONLY rows that match the filtered acus set
#    (left_semi keeps only ach rows that have a matching conv_user_key in acus_filtered)
df_raw = df_raw_with_key.join(acus_filtered.select("conv_user_key"), on="conv_user_key", how="left_semi")

# 4) (optional) You may want ConversationCreatedAt from acus, not ach
#     If ach has reliable conversationCreatedAt you can keep your original conv_created;
#     otherwise you can later join in acus fields by conv_user_key.

# --- Your existing aggregation logic, unchanged, now runs on the filtered df_raw ---

conv_created = (
    df_raw.groupBy(COL_CONV_ID)
          .agg(F.first(F.col(COL_CONV_CREATED), ignorenulls=True).alias("ConversationCreatedAt"))
)

FILTER_DATE_STR = "2025-06-30" 
FILTER_DATE = F.to_timestamp(F.lit(FILTER_DATE_STR), "yyyy-MM-dd")
conv_meta = (
    df_raw
    .groupBy(COL_CONV_ID)
    .agg(
        F.first(F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, F.col(COL_USER_ID)), ignorenulls=True).alias(COL_USER_ID),
        F.first(F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, F.col(COL_DISPLAYNAME)), ignorenulls=True).alias("DisplayName"),
        F.sum(F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, 1).otherwise(0)).alias("user_msg_count"),
        F.sum(F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, F.length(F.col(COL_TEXT))).otherwise(0)).alias("user_char_count"),
        F.collect_list(
            F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, 
                   F.struct(F.col(COL_MSG_CREATED).alias("ts"), F.col(COL_TEXT).alias("txt")))
        ).alias("user_msgs"),

        F.sum(F.when(F.col(COL_ROLE) == COL_ROLE_AIVY_VAL, 1).otherwise(0)).alias("aivy_msg_count"),
        F.sum(F.when(F.col(COL_ROLE) == COL_ROLE_AIVY_VAL, F.length(F.col(COL_TEXT))).otherwise(0)).alias("aivy_char_count"),
        F.collect_list(
            F.when(F.col(COL_ROLE) == COL_ROLE_AIVY_VAL,
                   F.struct(F.col(COL_MSG_CREATED).alias("ts"), F.col(COL_TEXT).alias("txt")))
        ).alias("aivy_msgs")
    )
    .withColumn("user_msgs_sorted", F.expr("array_sort(user_msgs)"))
    .withColumn("user_texts_ordered", F.expr("transform(user_msgs_sorted, x -> x.txt)"))
    .withColumn("FirstUserMessageAt", F.expr("CASE WHEN size(user_msgs_sorted) > 0 THEN element_at(user_msgs_sorted, 1).ts END"))
    .withColumn("LastUserMessageAt", F.expr("CASE WHEN size(user_msgs_sorted) > 0 THEN element_at(user_msgs_sorted, size(user_msgs_sorted)).ts END"))
    .withColumn("UserTextHash", F.sha2(F.concat_ws('||', F.col("user_texts_ordered")), 256))
    
    .withColumn("aivy_msgs_sorted", F.expr("array_sort(aivy_msgs)"))
    .withColumn("aivy_texts_ordered", F.expr("transform(aivy_msgs_sorted, x -> x.txt)"))
    .withColumn("FirstAivyMessageAt", F.expr("CASE WHEN size(aivy_msgs_sorted) > 0 THEN element_at(aivy_msgs_sorted, 1).ts END"))
    .withColumn("LastAivyMessageAt", F.expr("CASE WHEN size(aivy_msgs_sorted) > 0 THEN element_at(aivy_msgs_sorted, size(aivy_msgs_sorted)).ts END"))
    .withColumn("AivyTextHash", F.sha2(F.concat_ws('||', F.col("aivy_texts_ordered")), 256))

    .join(conv_created, on=COL_CONV_ID, how="left")
    .drop("user_msgs", "user_msgs_sorted", "aivy_msgs", "aivy_msgs_sorted")
    .filter(
        (F.col("FirstUserMessageAt").isNotNull()) & (F.col("FirstUserMessageAt") > FILTER_DATE)
    )
)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(conv_meta)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql import types as T
from delta.tables import DeltaTable

SOURCE_TABLE      = "lh_curated.Silver.aivychathistory"

# Source columns
COL_CONV_ID       = "conversationId"
COL_USER_ID       = "conversationUserId"
COL_DISPLAYNAME   = "DisplayName"
COL_MSG_ID        = "messageId"
COL_ROLE          = "messageRole_category"
COL_TEXT          = "messageContent"
COL_MSG_CREATED   = "messageCreatedAt"
COL_CONV_CREATED  = "conversationCreatedAt"

# Role values
COL_ROLE_USER_VAL = "User"
COL_ROLE_AIVY_VAL = "Aivy Response"

# Define the date threshold
FILTER_DATE_STR = "2025-06-30" 
FILTER_DATE = F.to_timestamp(F.lit(FILTER_DATE_STR), "yyyy-MM-dd")

df_raw = spark.table(SOURCE_TABLE) \
               .withColumn(COL_MSG_CREATED, F.col(COL_MSG_CREATED).cast("timestamp"))

conv_created = (
    df_raw.groupBy(COL_CONV_ID)
          .agg(F.first(F.col(COL_CONV_CREATED), ignorenulls=True).alias("ConversationCreatedAt"))
)

conv_meta = (
    df_raw
    .groupBy(COL_CONV_ID)
    .agg(
        F.first(F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, F.col(COL_USER_ID)), ignorenulls=True).alias(COL_USER_ID),
        F.first(F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, F.col(COL_DISPLAYNAME)), ignorenulls=True).alias("DisplayName"),
        F.sum(F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, 1).otherwise(0)).alias("user_msg_count"),
        F.sum(F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, F.length(F.col(COL_TEXT))).otherwise(0)).alias("user_char_count"),
        F.collect_list(
            F.when(
                (F.col(COL_ROLE) == "User") | (F.col(COL_ROLE) == "Attachment"), 
                F.struct(
                    F.col(COL_MSG_CREATED).alias("ts"), 
                    F.col(COL_TEXT).alias("txt"),
                    F.col("metadata_fileName").alias("file_name") # Optional: Add filename
                )
            )
        ).alias("user_msgs"),

        F.sum(F.when(F.col(COL_ROLE) == COL_ROLE_AIVY_VAL, 1).otherwise(0)).alias("aivy_msg_count"),
        F.sum(F.when(F.col(COL_ROLE) == COL_ROLE_AIVY_VAL, F.length(F.col(COL_TEXT))).otherwise(0)).alias("aivy_char_count"),
        F.collect_list(
            F.when(F.col(COL_ROLE) == COL_ROLE_AIVY_VAL,
                   F.struct(F.col(COL_MSG_CREATED).alias("ts"), F.col(COL_TEXT).alias("txt")))
        ).alias("aivy_msgs")
    )
    .withColumn("user_msgs_sorted", F.expr("array_sort(user_msgs)"))
    .withColumn("user_texts_ordered", F.expr("transform(user_msgs_sorted, x -> x.txt)"))
    .withColumn("FirstUserMessageAt", F.expr("CASE WHEN size(user_msgs_sorted) > 0 THEN element_at(user_msgs_sorted, 1).ts END"))
    .withColumn("LastUserMessageAt", F.expr("CASE WHEN size(user_msgs_sorted) > 0 THEN element_at(user_msgs_sorted, size(user_msgs_sorted)).ts END"))
    .withColumn("UserTextHash", F.sha2(F.concat_ws('||', F.col("user_texts_ordered")), 256))
    
    .withColumn("aivy_msgs_sorted", F.expr("array_sort(aivy_msgs)"))
    .withColumn("aivy_texts_ordered", F.expr("transform(aivy_msgs_sorted, x -> x.txt)"))
    .withColumn("FirstAivyMessageAt", F.expr("CASE WHEN size(aivy_msgs_sorted) > 0 THEN element_at(aivy_msgs_sorted, 1).ts END"))
    .withColumn("LastAivyMessageAt", F.expr("CASE WHEN size(aivy_msgs_sorted) > 0 THEN element_at(aivy_msgs_sorted, size(aivy_msgs_sorted)).ts END"))
    .withColumn("AivyTextHash", F.sha2(F.concat_ws('||', F.col("aivy_texts_ordered")), 256))

    .join(conv_created, on=COL_CONV_ID, how="left")
    .drop("user_msgs", "user_msgs_sorted", "aivy_msgs", "aivy_msgs_sorted")
    
    .filter(
        (F.col("FirstUserMessageAt").isNotNull()) & (F.col("FirstUserMessageAt") > FILTER_DATE)
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

conv_meta.count()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(conv_meta.take(5))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


SUMMARY_STEMS = [
    "summar",    # summary, summarize, summarising, summarisation…
    "short",     # shorter, shorten, short
    "brief",     # brief, briefing, briefly
    "concis",    # concise, conciseness
    "recap",     # recap, recapping
    "digest",
    "tldr",
    "overview",
    "synops",    # synopsis, synopsys
    "gist",
    "simplif",   # simplify, simplification
    "fluff",     # fluff, de-fluff
    "parag",
    "again"
]

stem_pattern = "(" + "|".join(SUMMARY_STEMS) + ")"
ATTACH_PREFIX = "<<<Extracted-Content>>>"

# only match stems on non-attachment messages
contains_summary_stem = F.exists(
    "user_texts_ordered",
    lambda x: (
        ~F.trim(x).startswith(F.lit(ATTACH_PREFIX))  # NOT an attachment
        & F.lower(x).rlike(stem_pattern)             # contains one of the stems
    )
)

conv_meta_summary_spark = (
    conv_meta
    .filter(F.coalesce(contains_summary_stem, F.lit(False)))
)


# 3) Convert to pandas
pdf = conv_meta_summary_spark.toPandas()

import pandas as pd

def merge_attachments(texts):
    """
    texts: list of strings (user_texts_ordered)
    Any entry starting with '<<<' is treated as attachment content.
    All consecutive attachments are appended to the *next* non-attachment message.
    """
    if texts is None:
        return texts

    merged = []
    buffer_att = []

    for t in texts:
        if isinstance(t, str) and t.lstrip().startswith("<<<"):
            # attachment-like chunk, queue it
            buffer_att.append(t)
        else:
            # real user message
            if buffer_att:
                # append all queued attachments to the end of this user message
                t = t + "\n\n" + "\n\n".join(buffer_att)
                buffer_att = []
            merged.append(t)

    # if we had attachments but never saw a real user message after them,
    # keep them at the end so they’re not lost
    if buffer_att:
        merged.extend(buffer_att)

    return merged

# Apply transformation
pdf["user_texts_ordered"] = pdf["user_texts_ordered"].apply(merge_attachments)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

conv_meta_summary.schema.simpleString()  # or simply print(df_schema.())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

pdf.count()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(pdf)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


pdf.to_json("abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Files/Aivy/aivy_conversations_summary_new.json")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import json, os
from urllib.parse import urlparse
from notebookutils import credentials
from openai import OpenAI

KEYVAULT_SECRET_URI = "/secrets/"
OPENAI_API_KEY = credentials.getSecret("https://kv-dc1dev-adf.vault.azure.net/", "OpenAI-API-Finetuning")

MODEL_CHAT = "gpt-4.1-mini"
oai = OpenAI(api_key=OPENAI_API_KEY)

resp = oai.chat.completions.create(
    model=MODEL_CHAT,
    response_format={"type":"json_object"},
    temperature=0.0,
    messages=[
    {"role": "system", "content": "You are a helpful assistant designed to output JSON."},
    {"role":"user","content":"ping"}
    ]
)
print(resp.choices[0].message.content)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Get sample 50texts to compare the fine tuned summarizer model with base 4.1
df_first_text = conv_meta.select(F.element_at(F.col("user_texts_ordered"), 1).alias("first_user_text"))
texts_first_value_pd = df_first_text.where(F.length(F.col("first_user_text")) > 200).toPandas()
len(texts_first_value_pd)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql import types as T

# 1. Configuration
N_SAMPLE = 2500

# 2. Extract and Clean Data
# We take conv_meta, ensure the text arrays are strings, and select only the raw lists.
df_raw_export = (
    conv_meta
    # Ensure the arrays are cast to string arrays and handle nulls
    .withColumn("user_messages", F.expr("transform(coalesce(user_texts_ordered, array()), x -> cast(x as string))"))
    .withColumn("bot_messages",  F.expr("transform(coalesce(aivy_texts_ordered, array()), x -> cast(x as string))"))
    
    # Basic Filter: Ensure the conversation actually exists (at least 1 msg each)
    # You can adjust these numbers or remove them to see everything
    .filter(F.size(F.col("user_messages")) > 0)
    .filter(F.size(F.col("bot_messages")) > 0)
    
    # Select only what you need
    .select(
        F.col("conversationId"),
        F.col("user_messages"),
        F.col("bot_messages")
    )
    .limit(N_SAMPLE)
)

# 3. Display Results
print(f"Extracted {df_raw_export.count()} conversations.")
print("Displaying first 5 rows (Arrays truncated for viewability):")
df_raw_export.show(5, truncate=True)

# Optional: If you want to bring this to local Python memory to iterate manually:
# local_data = df_raw_export.collect()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(df_raw_export)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import json, re, time, pandas as pd
from typing import List, Dict, Any
from pyspark.sql import Row, types as T, functions as F
def safe_json_loads(s: str, default: dict) -> dict:
    """Safely parses a JSON string, even if malformed."""
    try:
        return json.loads(s)
    except Exception:
        m = re.search(r'\{[\s\S]*\}', s or "")
        if m:
            try: return json.loads(m.group(0))
            except Exception: pass
    return default

def build_indexed_transcript(user_msgs: List[str], bot_msgs: List[str], max_lines: int = 200) -> (str, int, int):
    """Creates a numbered transcript from user and bot message arrays."""
    u = list(user_msgs or [])
    b = list(bot_msgs or [])
    n = max(len(u), len(b))
    lines = []
    uc = bc = 0
    for i in range(n):
        if i < len(u):
            uc += 1
            lines.append(f"USER[u{uc}]: {u[i] or ''}".strip())
        if i < len(b):
            bc += 1
            lines.append(f"BOT[b{bc}]: {b[i] or ''}".strip())
        if len(lines) >= max_lines:
            break
    return "\n".join(lines), uc, bc

# The system prompt for the LLM to find the sufficient answer
SUFFICIENCY_SYSTEM = """You analyze a multi-turn USER/BOT chat.
Return JSON with:
{
  "does_user_requested_shorter" true|false,
  "initial_request": "string",
  "sufficient_level": "thanked|gave_up|moved_topic|solved|unknown",
  "sufficient_bot_index": <int|null>,    // index b# from BOT[b#] in the transcript
  "sufficient_bot_message": "string",    // brief quote/summary of that BOT message
  "evidence_user_index": <int|null>,     // index u# from USER[u#] that signals sufficiency
  "evidence_user_message": "string"
}
Rules:
- Parse all the user request and check if the user requested the BOT to summarize or make the answer shorter. Examples of user requests are
less fluff, make short, concise..IMPORTANT! IF false, then ignore the rest of the steps and output all other fields empty.
- initial_request: the first actionable user ask in the transcript.
- If the user indicates success (thanks/ack), mark 'thanked' and pick the immediately preceding BOT[b#] as sufficient.
- If the user abandons (nevermind/stop), mark 'gave_up' and set sufficient_bot_index to null.
- If the user shifts to a new, unrelated topic next, mark 'moved_topic' and choose the last BOT[b#] that concluded the prior topic if apparent, else null.
- If the task is clearly completed without explicit thanks, mark 'solved' and pick the last BOT[b#] that delivered the solution.
- If unclear, use 'unknown'.
Return ONLY JSON."""

def llm_find_sufficiency_from_arrays(user_msgs: List[str], bot_msgs: List[str], model: str) -> Dict[str, Any]:
    """
    Calls an LLM to analyze a conversation transcript and find the sufficient response.
    """
    tx, ucnt, bcnt = build_indexed_transcript(user_msgs, bot_msgs, max_lines=400)
    messages = [
        {"role":"system","content": SUFFICIENCY_SYSTEM},
        {"role":"user","content": "Transcript:\n"+tx}
    ]
    
    
    # Default return value
    default_data = {
        "does_user_requested_shorter":False,
        "initial_request":"",
        "sufficient_level":"unknown",
        "sufficient_bot_index": None,
        "sufficient_bot_message":"",
        "evidence_user_index": None,
        "evidence_user_message":""
    }
    
    for _ in range(3): # Retry loop
        try:
            resp = oai.chat.completions.create(
                model=model, 
                temperature=0.0,
                response_format={"type":"json_object"},
                messages=messages
            )
            data = safe_json_loads(resp.choices[0].message.content, default_data)
            
            # Validate indices
            sbi = data.get("sufficient_bot_index", None)
            if isinstance(sbi, int) and (sbi < 1 or sbi > bcnt): data["sufficient_bot_index"] = None
            eui = data.get("evidence_user_index", None)
            if isinstance(eui, int) and (eui < 1 or eui > ucnt): data["evidence_user_index"] = None
            
            return data
        except Exception as e:
            print(f"LLM call failed, retrying... Error: {e}")
            time.sleep(1.2)
    return default_data

def _to_int_or_none(x: Any) -> int | None:
    """Converts a value to an integer if possible, otherwise None."""
    if x is None:
        return None
    try:
        if isinstance(x, int):
            return x
        if isinstance(x, float) and x.is_integer():
            return int(x)
        s = str(x).strip().lower()
        if s in ("", "none", "null", "nan"):
            return None
        return int(float(s))
    except Exception:
        return None

# ==============================================================================
# 2. Main Processing Logic
# ==============================================================================

# Set sample size as requested
N_SAMPLE = 2500

# Disable Arrow for reliable pd.NA/None handling in .collect()
spark.conf.set("spark.sql.execution.arrow.pyspark.enabled", "false")

print(f"Sampling {N_SAMPLE} conversations for analysis...")

# Pre-filter data in Spark
conv_fixed = (
    conv_meta
    .select("conversationId", "user_texts_ordered", "aivy_texts_ordered", "LastAivyMessageAt")
    .withColumn("user_texts", F.expr("transform(coalesce(user_texts_ordered, array()), x -> cast(x as string))"))
    .withColumn("aivy_texts", F.expr("transform(coalesce(aivy_texts_ordered, array()), x -> cast(x as string))"))
    .filter(F.size(F.col("user_texts")) < 5)
    .filter(F.size(F.col("aivy_texts")) > 1) 
)

# Collect the sample to the driver
rows_sample = (
    conv_fixed
    .orderBy(F.desc("LastAivyMessageAt"))
    .limit(N_SAMPLE)
    .select("conversationId", "user_texts", "aivy_texts")
    .collect()
)

print(f"Collected {len(rows_sample)} sample conversations. Filtering for summarization...")

processed_rows = []
for r in rows_sample:
    cid = r["conversationId"]
    u_texts = r["user_texts"]
    a_texts = r["aivy_texts"]

    # Call the LLM to find the sufficient message
    llm_out = llm_find_sufficiency_from_arrays(u_texts, a_texts, model=MODEL_CHAT)

    s_level = llm_out.get("sufficient_level", "unknown")
    s_index = _to_int_or_none(llm_out.get("sufficient_bot_index"))


    if s_level in ("thanked", "solved","moved_topic") and s_index is not None and s_index > 1:
        
        # Check if index is valid (s_index is 1-based, list is 0-based)
        if s_index <= len(a_texts):
            
            # Get the 'initial_request' from the LLM, fall back to first user text
            initial_request = llm_out.get("initial_request")
            if not initial_request or initial_request.strip() == "":
                initial_request = u_texts[0]
            
            # The "bad" response is the first one
            bad_answer = a_texts[0]
            
            # The "good" response is the one the LLM identified
            good_answer = a_texts[s_index - 1] # -1 for 0-based indexing
            
            # Add to our list
            processed_rows.append(Row(
                conversationId=cid,
                initial_request=initial_request,
                bad_response=bad_answer,
                good_response=good_answer,
                sufficient_bot_index=s_index,
                sufficient_level=s_level,
                u_texts=u_texts,
                a_texts=a_texts
            ))

print(f"Found {len(processed_rows)} valid (bad_response, good_response) pairs for fine-tuning.")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

conv_meta.count()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(processed_rows)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

