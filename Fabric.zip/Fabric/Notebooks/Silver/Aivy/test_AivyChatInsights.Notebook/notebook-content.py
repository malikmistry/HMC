# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     },
# META     "environment": {
# META       "environmentId": "694fc784-adba-8df0-47c1-b0022607347b",
# META       "workspaceId": "00000000-0000-0000-0000-000000000000"
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql import types as T
from delta.tables import DeltaTable

SOURCE_TABLE      = "lh_curated.Silver.aivychathistory"

# Source columns
COL_CONV_ID       = "conversationId"
COL_USER_ID       = "conversationUserId"
COL_DISPLAYNAME   = "DisplayName"
COL_MSG_ID        = "messageId"
COL_ROLE          = "messageRole_category"
COL_TEXT          = "messageContent"
COL_MSG_CREATED   = "messageCreatedAt"
COL_CONV_CREATED  = "conversationCreatedAt"

# Role values
COL_ROLE_USER_VAL = "User"
COL_ROLE_AIVY_VAL = "Aivy Response"


df_raw = spark.table(SOURCE_TABLE) \
              .withColumn(COL_MSG_CREATED, F.col(COL_MSG_CREATED).cast("timestamp"))

conv_created = (
    df_raw.groupBy(COL_CONV_ID)
          .agg(F.first(F.col(COL_CONV_CREATED), ignorenulls=True).alias("ConversationCreatedAt"))
)

conv_meta = (
    df_raw
    .groupBy(COL_CONV_ID)
    .agg(
        F.first(F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, F.col(COL_USER_ID)), ignorenulls=True).alias(COL_USER_ID),
        F.first(F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, F.col(COL_DISPLAYNAME)), ignorenulls=True).alias("DisplayName"),
        F.sum(F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, 1).otherwise(0)).alias("user_msg_count"),
        F.sum(F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, F.length(F.col(COL_TEXT))).otherwise(0)).alias("user_char_count"),
        F.collect_list(
            F.when(F.col(COL_ROLE) == COL_ROLE_USER_VAL, 
                   F.struct(F.col(COL_MSG_CREATED).alias("ts"), F.col(COL_TEXT).alias("txt")))
        ).alias("user_msgs"),

        F.sum(F.when(F.col(COL_ROLE) == COL_ROLE_AIVY_VAL, 1).otherwise(0)).alias("aivy_msg_count"),
        F.sum(F.when(F.col(COL_ROLE) == COL_ROLE_AIVY_VAL, F.length(F.col(COL_TEXT))).otherwise(0)).alias("aivy_char_count"),
        F.collect_list(
            F.when(F.col(COL_ROLE) == COL_ROLE_AIVY_VAL,
                   F.struct(F.col(COL_MSG_CREATED).alias("ts"), F.col(COL_TEXT).alias("txt")))
        ).alias("aivy_msgs")
    )
    .withColumn("user_msgs_sorted", F.expr("array_sort(user_msgs)"))
    .withColumn("user_texts_ordered", F.expr("transform(user_msgs_sorted, x -> x.txt)"))
    .withColumn("FirstUserMessageAt", F.expr("CASE WHEN size(user_msgs_sorted) > 0 THEN element_at(user_msgs_sorted, 1).ts END"))
    .withColumn("LastUserMessageAt", F.expr("CASE WHEN size(user_msgs_sorted) > 0 THEN element_at(user_msgs_sorted, size(user_msgs_sorted)).ts END"))
    .withColumn("UserTextHash", F.sha2(F.concat_ws('||', F.col("user_texts_ordered")), 256))
    
    .withColumn("aivy_msgs_sorted", F.expr("array_sort(aivy_msgs)"))
    .withColumn("aivy_texts_ordered", F.expr("transform(aivy_msgs_sorted, x -> x.txt)"))
    .withColumn("FirstAivyMessageAt", F.expr("CASE WHEN size(aivy_msgs_sorted) > 0 THEN element_at(aivy_msgs_sorted, 1).ts END"))
    .withColumn("LastAivyMessageAt", F.expr("CASE WHEN size(aivy_msgs_sorted) > 0 THEN element_at(aivy_msgs_sorted, size(aivy_msgs_sorted)).ts END"))
    .withColumn("AivyTextHash", F.sha2(F.concat_ws('||', F.col("aivy_texts_ordered")), 256))

    .join(conv_created, on=COL_CONV_ID, how="left")
    .drop("user_msgs", "user_msgs_sorted", "aivy_msgs", "aivy_msgs_sorted")
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import json, os
from urllib.parse import urlparse
from notebookutils import credentials
from openai import OpenAI

KEYVAULT_SECRET_URI = "/secrets/"
OPENAI_API_KEY = credentials.getSecret("https://kv-dc1dev-adf.vault.azure.net/", "OpenAI-API-Finetuning")

MODEL_CHAT = "gpt-4.1"
oai = OpenAI(api_key=OPENAI_API_KEY)

resp = oai.chat.completions.create(
    model=MODEL_CHAT,
    response_format={"type":"json_object"},
    temperature=0.0,
    messages=[
    {"role": "system", "content": "You are a helpful assistant designed to output JSON."},
    {"role":"user","content":"ping"}
    ]
)
print(resp.choices[0].message.content)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import json, re, time
from typing import List, Dict, Any

def safe_json_loads(s: str, default: dict) -> dict:
    try:
        return json.loads(s)
    except Exception:
        m = re.search(r'\{[\s\S]*\}', s or "")
        if m:
            try: return json.loads(m.group(0))
            except Exception: pass
    return default

def build_indexed_transcript(user_msgs: List[str], bot_msgs: List[str], max_lines: int = 200):
    u = list(user_msgs or [])
    b = list(bot_msgs or [])
    n = max(len(u), len(b))
    lines = []
    uc = bc = 0
    for i in range(n):
        if i < len(u):
            uc += 1
            lines.append(f"USER[u{uc}]: {u[i] or ''}".strip())
        if i < len(b):
            bc += 1
            lines.append(f"BOT[b{bc}]: {b[i] or ''}".strip())
        if len(lines) >= max_lines:
            break
    return "\n".join(lines), uc, bc

SUFFICIENCY_SYSTEM = """You analyze a multi-turn USER/BOT chat.
Return JSON with:
{
  "initial_request": "string",
  "sufficient_level": "thanked|gave_up|moved_topic|solved|unknown",
  "sufficient_bot_index": <int|null>,   // index b# from BOT[b#] in the transcript
  "sufficient_bot_message": "string",   // brief quote/summary of that BOT message
  "evidence_user_index": <int|null>,    // index u# from USER[u#] that signals sufficiency
  "evidence_user_message": "string"
}
Rules:
- initial_request: the first actionable user ask in the transcript.
- If the user indicates success (thanks/ack), mark 'thanked' and pick the immediately preceding BOT[b#] as sufficient.
- If the user abandons (nevermind/stop), mark 'gave_up' and set sufficient_bot_index to null.
- If the user shifts to a new, unrelated topic next, mark 'moved_topic' and choose the last BOT[b#] that concluded the prior topic if apparent, else null.
- If the task is clearly completed without explicit thanks, mark 'solved' and pick the last BOT[b#] that delivered the solution.
- If unclear, use 'unknown'.
Return ONLY JSON."""

def llm_find_sufficiency_from_arrays(user_msgs: List[str], bot_msgs: List[str], model: str = MODEL_CHAT) -> Dict[str, Any]:
    tx, ucnt, bcnt = build_indexed_transcript(user_msgs, bot_msgs, max_lines=400)
    messages = [
        {"role":"system","content": SUFFICIENCY_SYSTEM},
        {"role":"user","content": "Transcript:\n"+tx}
    ]
    for _ in range(3):
        try:
            resp = oai.chat.completions.create(
                model=model, temperature=0.0,
                response_format={"type":"json_object"},
                messages=messages
            )
            data = safe_json_loads(resp.choices[0].message.content, {
                "initial_request":"",
                "sufficient_level":"unknown",
                "sufficient_bot_index": None,
                "sufficient_bot_message":"",
                "evidence_user_index": None,
                "evidence_user_message":""
            })
            sbi = data.get("sufficient_bot_index", None)
            if isinstance(sbi, int) and (sbi < 1 or sbi > bcnt): data["sufficient_bot_index"] = None
            eui = data.get("evidence_user_index", None)
            if isinstance(eui, int) and (eui < 1 or eui > ucnt): data["evidence_user_index"] = None
            return data
        except Exception:
            time.sleep(1.2)
    return {
        "initial_request":"",
        "sufficient_level":"unknown",
        "sufficient_bot_index": None,
        "sufficient_bot_message":"",
        "evidence_user_index": None,
        "evidence_user_message":""
    }


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import pandas as pd
from pyspark.sql import Row, types as T, functions as F

N_SAMPLE = 10
conv_fixed = (
    conv_meta
    .select("conversationId","user_texts_ordered","aivy_texts_ordered","LastAivyMessageAt")
    .withColumn("user_texts_ordered", F.expr("transform(coalesce(user_texts_ordered, array()), x -> cast(x as string))"))
    .withColumn("aivy_texts_ordered", F.expr("transform(coalesce(aivy_texts_ordered, array()), x -> cast(x as string))"))
)

rows_sample = (
    conv_fixed
    .orderBy(F.desc("LastAivyMessageAt"))
    .limit(N_SAMPLE)
    .select("conversationId","user_texts_ordered","aivy_texts_ordered")
    .collect()
)


def _to_int_or_none(x):
    if x is None:
        return None
    try:
        if isinstance(x, int):
            return x
        if isinstance(x, float) and x.is_integer():
            return int(x)
        s = str(x).strip().lower()
        if s in ("", "none", "null", "nan"):
            return None
        return int(float(s))
    except Exception:
        return None

# Avoid Arrow NA dtype surprises
spark.conf.set("spark.sql.execution.arrow.pyspark.enabled", "false")

rows = []
for r in rows_sample:
    cid = r["conversationId"]
    u = r["user_texts_ordered"] or []
    a = r["aivy_texts_ordered"] or []
    out = llm_find_sufficiency_from_arrays(u, a)

    sbi = _to_int_or_none(out.get("sufficient_bot_index"))
    eui = _to_int_or_none(out.get("evidence_user_index"))

    rows.append(Row(
        conversationId                = cid,
        initial_request               = str(out.get("initial_request","")),
        sufficient_level              = str(out.get("sufficient_level","unknown")),
        sufficient_bot_index          = sbi,
        sufficient_bot_message        = str(out.get("sufficient_bot_message","")),
        sufficient_bot_message_actual = (a[sbi-1] if (sbi is not None and 1 <= sbi <= len(a)) else None),
        evidence_user_index           = eui,
        evidence_user_message         = str(out.get("evidence_user_message","")),
        evidence_user_message_actual  = (u[eui-1] if (eui is not None and 1 <= eui <= len(u)) else None),
    ))

schema = T.StructType([
    T.StructField("conversationId", T.StringType(), False),
    T.StructField("initial_request", T.StringType(), True),
    T.StructField("sufficient_level", T.StringType(), True),
    T.StructField("sufficient_bot_index", T.IntegerType(), True),
    T.StructField("sufficient_bot_message", T.StringType(), True),
    T.StructField("sufficient_bot_message_actual", T.StringType(), True),
    T.StructField("evidence_user_index", T.IntegerType(), True),
    T.StructField("evidence_user_message", T.StringType(), True),
    T.StructField("evidence_user_message_actual", T.StringType(), True),
])

conv_sufficiency_spark = spark.createDataFrame(rows, schema=schema)

print("OK:", conv_sufficiency_spark.count(), "rows")
conv_sufficiency_spark.printSchema()

# Focus view: unsolved / moved / unknown
(conv_sufficiency_spark
  .filter(F.col("sufficient_level").isin("gave_up","moved_topic","unknown"))
  .select("conversationId","sufficient_level","initial_request",
          "sufficient_bot_index","sufficient_bot_message_actual",
          "evidence_user_index","evidence_user_message_actual")
  .orderBy(F.asc("conversationId"))
  .show(truncate=False))



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(conv_sufficiency_spark)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
