# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%pip install openai --upgrade

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#import necessary libraries

from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.types import *
from delta.tables import DeltaTable
import re
from transformers import AutoTokenizer, AutoModelForSequenceClassification, pipeline
from openai import AzureOpenAI

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# ============================================================
# Configuration
# ============================================================
# Source table 
SOURCE_TABLE      = "Silver.aivychathistory"

# Source columns
COL_CONV_ID       = "conversationId"
COL_USER_ID       = "conversationUserId"
COL_DISPLAYNAME   = "DisplayName"
COL_MSG_ID        = "messageId"
COL_ROLE          = "messageRole_category"
COL_ROLE_USER_VAL = "User"
COL_TEXT          = "messageContent"
COL_MSG_CREATED   = "messageCreatedAt"
COL_CONV_CREATED  = "conversationCreatedAt"

# Gold Delta table path (uses Fabric helper 'get_basepath')
WorkspaceId   = None
BronzeLHId    = None
CuratedLHId   = None
TaskList      = None
NotebookName  = None
LakehouseName = None
RawLHId       = None

print(f"Params: WorkspaceId={WorkspaceId}, BronzeLHId={BronzeLHId}, CuratedLHId={CuratedLHId}")

if WorkspaceId is None:
    # Example defaults (replace with your IDs if needed)
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId  = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

# Resolve base lakehouse path; get_basepath is provided by notebook_utils in Fabric
curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

def tbl_path(base, rel): 
    return f"{base}/Tables/{rel}" 

# Gold table location (single output table)
gold_rel  = "Gold/AivyConversationUserSentiment"
gold_path = tbl_path(curated_lh_id, gold_rel)
print("Gold Delta path:", gold_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ============================================================
# Model & thresholds
# ============================================================

HF_MODEL_NAME = "siebert/sentiment-roberta-large-english"

# LLM pathway (disabled by default). If you enable, we’ll use the LLM score instead of HF.
USE_LLM = False
LLM_PROVIDER = "azure-openai" 

# Score thresholds for labels on [-1, 1]
POS_THRESH = 0.20
NEG_THRESH = -0.20

# Trend thresholds (Method D) — delta vs first message
TREND_POS_DELTA = 0.20
TREND_NEG_DELTA = -0.20


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


_pipe = None
def _get_hf_pipe():
    """
    Lazily initialize a HuggingFace pipeline (cached) for per-message sentiment.
    Model: siebert/sentiment-roberta-large-english (binary POSITIVE/NEGATIVE)
    """
    global _pipe
    if _pipe is None:
        tok = AutoTokenizer.from_pretrained(HF_MODEL_NAME)
        mdl = AutoModelForSequenceClassification.from_pretrained(HF_MODEL_NAME)
        _pipe = pipeline("sentiment-analysis", model=mdl, tokenizer=tok, truncation=True)
    return _pipe

def _hf_score_to_float(label_scores):
    """
    Map HF output to [-1, 1].
    For binary models:
      POSITIVE -> +score
      NEGATIVE -> -score
    """
    if isinstance(label_scores, list) and len(label_scores) == 1 and "label" in label_scores[0]:
        label = label_scores[0]["label"].lower()
        conf  = float(label_scores[0].get("score", 1.0))
        if label.startswith("pos"): return  conf
        if label.startswith("neg"): return -conf
        return 0.0
    return 0.0

# Optional LLM scorer (disabled by default). Implement your API call here if you enable it.
def _llm_score(text: str) -> float:
    """
    Return a float in [-1, 1] from an LLM classification.
    You can implement an API call to Azure OpenAI / OpenAI, constrained to output one of:
      NEGATIVE / NEUTRAL / POSITIVE
    Then map to -1 / 0 / +1 (or probabilities if your prompt returns confidences).
    This stub returns 0.0 to keep pipeline runnable if USE_LLM=True by mistake.
    """
    # TODO: implement your API call here. Example (pseudo):
    # resp = client.chat.completions.create(model="gpt-4o-mini", messages=[...])
    # label = parse(resp)
    # return {"negative": -1.0, "neutral": 0.0, "positive": 1.0}[label]
    return 0.0

def _dampen_factual_negativity(text: str, score: float) -> float:
    """
    Reduce negative magnitude when text appears factual rather than emotional.
    """
    if text is None or score is None:
        return score
    t = text.lower()
    EMOTION_MARKERS = ["i'm unhappy", "i am unhappy", "i'm upset", "i am upset",
                       "frustrated", "annoyed", "mad", "angry", "this is useless",
                       "i hate", "terrible", "awful"]
    if any(x in t for x in EMOTION_MARKERS):
        return score
    FACTUAL_NEGATIVE_TERMS = ["loss","decline","decrease","negative return","drawdown",
                              "error rate","risk","volatility","downgrade","deficit",
                              "bug","exception","stack trace","failed test","underperformance"]
    has_factual  = any(x in t for x in FACTUAL_NEGATIVE_TERMS)
    has_personal = any(p in t for p in [" i ", " i'm", " i am", " you ", " this ", " not working", " doesn", " didn"])
    if has_factual and not has_personal and score < 0:
        return score * 0.5
    return score

def _label_from_score(s: float) -> str:
    if s is None: return "Unrated"
    if s >= POS_THRESH: return "Positive"
    if s <= NEG_THRESH: return "Negative"
    return "Neutral"

@F.udf(returnType=DoubleType())
def udf_sent_score(text):
    """
    Unified per-message sentiment scorer: uses LLM if enabled, otherwise HF model.
    Applies factual-negativity dampening.
    """
    try:
        if USE_LLM:
            base = float(_llm_score(str(text)))
        else:
            res = _get_hf_pipe()(str(text))
            base = float(_hf_score_to_float(res))
        return float(_dampen_factual_negativity(text, base))
    except Exception:
        return float(0.0)

@F.udf(returnType=StringType())
def udf_label_from_score(score):
    return _label_from_score(score)

@F.udf(returnType=StringType())
def udf_label_trend(delta):
    if delta is None: return "Unrated"
    if delta >= TREND_POS_DELTA: return "Positive"
    if delta <= TREND_NEG_DELTA: return "Negative"
    return "Neutral"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ============================================================
# Build conversation-level change detector
#  - Compute conversationCreatedAt once per conversation
#  - Compute per-(conversationId, conversationUserId) user text hash & metadata
# ============================================================
df_raw = spark.table(SOURCE_TABLE) \
              .withColumn(COL_MSG_CREATED, F.col(COL_MSG_CREATED).cast("timestamp"))

conv_created = (
    df_raw.groupBy(COL_CONV_ID)
          .agg(F.first(F.col(COL_CONV_CREATED), ignorenulls=True).alias("ConversationCreatedAt"))
)

src_user = (
    df_raw
    .filter(F.lower(F.col(COL_ROLE)) == F.lit(COL_ROLE_USER_VAL.lower()))
    .select(COL_CONV_ID, COL_USER_ID, COL_DISPLAYNAME, COL_MSG_ID, COL_TEXT, COL_MSG_CREATED)
)

conv_meta = (
    src_user
    .groupBy(COL_CONV_ID, COL_USER_ID)
    .agg(
        F.first(COL_DISPLAYNAME, ignorenulls=True).alias("DisplayName"),
        F.count(F.lit(1)).alias("user_msg_count"),
        F.sum(F.length(F.col(COL_TEXT))).alias("user_char_count"),
        F.collect_list(F.struct(F.col(COL_MSG_CREATED).alias("ts"),
                                F.col(COL_TEXT).alias("txt"))).alias("msgs")
    )
    .withColumn("msgs_sorted", F.expr("array_sort(msgs)"))
    .withColumn("user_texts_ordered", F.expr("transform(msgs_sorted, x -> x.txt)"))
    .withColumn("FirstUserMessageAt", F.expr("CASE WHEN size(msgs_sorted)>0 THEN element_at(msgs_sorted,1).ts END"))
    .withColumn("LastUserMessageAt",  F.expr("CASE WHEN size(msgs_sorted)>0 THEN element_at(msgs_sorted, size(msgs_sorted)).ts END"))
    .withColumn("UserTextHash", F.sha2(F.concat_ws('||', F.col("user_texts_ordered")), 256))
    .drop("msgs", "msgs_sorted")
    .join(conv_created, on=COL_CONV_ID, how="left")
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# ============================================================
# Decide which conversations to (re)process by comparing to the SAME Gold table
#    - If hash/counts unchanged, skip
# ============================================================
gold_exists = DeltaTable.isDeltaTable(spark, gold_path)

if gold_exists:
    existing_min = (
        spark.read.format("delta").load(gold_path)
        .select(
            F.col("conversationId").alias(COL_CONV_ID),
            F.col("userId").alias(COL_USER_ID),
            "UserTextHash", "user_msg_count", "user_char_count"
        )
    )
    to_process = (
        conv_meta.alias("m")
        .join(existing_min.alias("e"), on=[COL_CONV_ID, COL_USER_ID], how="left")
        .where(
            F.col("e.UserTextHash").isNull() |
            (F.col("m.UserTextHash") != F.col("e.UserTextHash")) |
            (F.col("m.user_msg_count") != F.col("e.user_msg_count")) |
            (F.col("m.user_char_count") != F.col("e.user_char_count"))
        )
        .select("m.*")
    )
else:
    to_process = conv_meta

if to_process.rdd.isEmpty():
    print("No new or changed conversations. Nothing to do.")
else:
    # =========================
    # Score messages only for new/changed keys
    # =========================
    keys = to_process.select(COL_CONV_ID, COL_USER_ID).distinct()

    df_user = (
        src_user
        .join(keys, on=[COL_CONV_ID, COL_USER_ID], how="inner")
        .withColumn("text_clean", F.regexp_replace(F.col(COL_TEXT), r"\s+", " "))
        .filter(F.length("text_clean") > 0)
    )

    w_order = Window.partitionBy(COL_CONV_ID, COL_USER_ID).orderBy(F.col(COL_MSG_CREATED).asc())
    w_conv  = Window.partitionBy(COL_CONV_ID, COL_USER_ID)

    df_user = (
        df_user
        .withColumn("user_msg_idx", F.row_number().over(w_order))
        .withColumn("n_user_msgs", F.count(F.lit(1)).over(w_conv))
        .withColumn("sent_score", udf_sent_score(F.col("text_clean")))   # final per-message score
        .withColumn("sent_label", udf_label_from_score(F.col("sent_score")))
    ).cache()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

    w_worst = Window.partitionBy(COL_CONV_ID, COL_USER_ID).orderBy(F.col("sent_score").asc(), F.col(COL_MSG_CREATED).asc())
    worst = (
        df_user
        .withColumn("rn_worst", F.row_number().over(w_worst))
        .filter(F.col("rn_worst") == 1)
        .select(
            COL_CONV_ID, COL_USER_ID,
            F.col(COL_MSG_ID).alias("WorstUserMessageId"),
            F.col(COL_MSG_CREATED).alias("WorstUserMessageAt"),
            # keep a short snippet to avoid very large rows
            F.expr("substring(text_clean, 1, 300)").alias("WorstUserMessageText"),
            F.col("sent_score").alias("WorstUserMessageScore")
        )
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


    # ============================================================
    # Aggregate to conversation-level methods (explicit labels only)
    # ============================================================
    counts = (
        df_user.groupBy(COL_CONV_ID, COL_USER_ID)
               .agg(F.max("n_user_msgs").alias("n_user_msgs"))
    )
    
    # Method B — per-message average across all user messages
    agg_B = (
        df_user.groupBy(COL_CONV_ID, COL_USER_ID)
               .agg(
                   F.avg("sent_score").alias("B_score"),
                   F.first(F.col(COL_DISPLAYNAME)).alias("DisplayName")
               )
               .withColumn("B_label", udf_label_from_score(F.col("B_score")))
    )

    # Method C — average excluding the first user message (Unrated if only 1)
    agg_C_pre = (
        df_user.filter(F.col("user_msg_idx") > 1)
               .groupBy(COL_CONV_ID, COL_USER_ID)
               .agg(F.avg("sent_score").alias("C_score"))
    )
    agg_C = (
        counts.join(agg_C_pre, on=[COL_CONV_ID, COL_USER_ID], how="left")
              .withColumn("C_score",
                  F.when(F.col("n_user_msgs") <= 1, F.lit(0.0))
                   .otherwise(F.col("C_score"))
              )
              .withColumn("C_label",
                  F.when(F.col("n_user_msgs") <= 1, F.lit("Unrated"))
                   .otherwise(udf_label_from_score(F.col("C_score")))
              )
    )

    # Method D — trend vs first user message (avg later - first)
    first_scores = (
        df_user.filter(F.col("user_msg_idx") == 1)
               .select(COL_CONV_ID, COL_USER_ID, F.col("sent_score").alias("first_score"))
    )
    later_avg = (
        df_user.filter(F.col("user_msg_idx") > 1)
               .groupBy(COL_CONV_ID, COL_USER_ID)
               .agg(F.avg("sent_score").alias("later_avg_score"))
    )
    agg_D_core = (
        counts.join(first_scores, on=[COL_CONV_ID, COL_USER_ID], how="left")
              .join(later_avg, on=[COL_CONV_ID, COL_USER_ID], how="left")
              .withColumn(
                  "D_score",
                  F.when(F.col("n_user_msgs") <= 1, F.lit(0.0))
                   .otherwise(F.col("later_avg_score") - F.col("first_score"))
              )
    )
    agg_D = (
        agg_D_core
        .withColumn("D_label",
            F.when(F.col("n_user_msgs") <= 1, F.lit("Unrated"))
             .otherwise(udf_label_trend(F.col("D_score")))
        )
        .select(COL_CONV_ID, COL_USER_ID, "D_score", "D_label")
    )


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ============================================================
    # Final result (ONLY for changed/new conversations) + metadata + createdAt
# ============================================================
meta = (
        to_process.select(
            COL_CONV_ID, COL_USER_ID,
            F.col("DisplayName").alias("DisplayName_meta"),
            "user_msg_count", "user_char_count",
            "FirstUserMessageAt", "LastUserMessageAt",
            "ConversationCreatedAt", "UserTextHash"
        )
    ).alias("m")

b = agg_B.alias("b")
c = agg_C.alias("c")
d = agg_D.alias("d")
w = worst.alias("w")

result_partial = (
        b.join(c, on=[COL_CONV_ID, COL_USER_ID], how="left")
         .join(d, on=[COL_CONV_ID, COL_USER_ID], how="left")
         .join(meta, on=[COL_CONV_ID, COL_USER_ID], how="left")
         .join(w, on=[COL_CONV_ID, COL_USER_ID], how="left")
         .select(
            F.col(f"b.{COL_CONV_ID}").alias("ConversationId"),
            F.col(f"b.{COL_USER_ID}").alias("UserId"),
            F.coalesce(F.col("m.DisplayName_meta"), F.col("b.DisplayName")).alias("DisplayName"),
            # Method B
            F.col("b.B_label").alias("SentimentLabel_PerMsgAvg"),
            F.col("b.B_score").alias("SentimentScore_PerMsgAvg"),
            # Method C
            F.col("c.C_label").alias("SentimentLabel_AvgExcludingFirst"),
            F.col("c.C_score").alias("SentimentScore_AvgExcludingFirst"),
            # Method D
            F.col("d.D_label").alias("SentimentLabel_TrendVSFirst"),
            F.col("d.D_score").alias("SentimentScore_TrendVSFirst"),
            # Metadata / incremental
            F.col("m.user_msg_count").alias("UserMessages"),
            F.col("m.user_char_count").alias("UserCharachter"),
            F.col("m.FirstUserMessageAt").alias("FirstUserMessageAt"),
            F.col("m.LastUserMessageAt").alias("LastUserMessageAt"),
            F.col("m.ConversationCreatedAt").alias("ConversationCreatedAt"),
            F.col("m.UserTextHash").alias("UserTextHash"),
            # Worst message details
            F.col("w.WorstUserMessageId").alias("WorstUserMessageId"),
            F.col("w.WorstUserMessageAt").alias("WorstUserMessageAt"),
            F.col("w.WorstUserMessageText").alias("WorstUserMessageText"),
            F.col("w.WorstUserMessageScore").alias("WorstUserMessageScore"),
            # Run timestamp
            F.current_timestamp().alias("RunAt")
         )
    )

display(result_partial.limit(25))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


    # ============================================================
    # Upsert to Gold (single table)
    #    - New conversations append
    #    - Changed conversations update (based on hash/counts)
    # ============================================================
if not gold_exists:
        (result_partial
            .write
            .format("delta")
            .mode("overwrite")
            .option("overwriteSchema", "true")
            .save(gold_path))
        print("Created Delta table at", gold_path)
else:
        tgt = DeltaTable.forPath(spark, gold_path)
        (tgt.alias("t")
            .merge(
                result_partial.alias("s"),
                "t.conversationId = s.conversationId AND t.userId = s.userId"
            )
            .whenMatchedUpdate(
                condition=(
                    "t.UserTextHash <> s.UserTextHash OR "
                    "t.user_msg_count <> s.user_msg_count OR "
                    "t.user_char_count <> s.user_char_count"
                ),
                set={c: f"s.{c}" for c in result_partial.columns}
            )
            .whenNotMatchedInsert(values={c: f"s.{c}" for c in result_partial.columns})
            .execute())
        print("Merged changes into", gold_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
