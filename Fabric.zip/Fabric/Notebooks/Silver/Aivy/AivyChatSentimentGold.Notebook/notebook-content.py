# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# ===============================================================
# Snapshot-Diff Incremental Sentiment @ (conversationId, userId)
# Source  : Silver.aivychathistory (full-history snapshot, overwritten each run)
# Target  : Gold.ConversationUserSentiment (incrementally upserted)
# Approach: Diff current Silver fingerprints vs existing Gold; re-score only impacted pairs
# ===============================================================

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ---------------- Parameters ----------------
SOURCE_TABLE      = "Silver.aivychathistory"
TARGET_SCHEMA     = "Gold"
TARGET_TABLE      = "AivyConversationUserSentiment"
TARGET_FULL       = f"{TARGET_SCHEMA}.{TARGET_TABLE}"
#Label Threshhold
NEG_CONV_THRESHOLD = -0.05
POS_CONV_THRESHOLD =  0.05
# Recency weighting (half-life in number of user messages; larger = slower decay)
HALF_LIFE_MSGS    = 3.0

# Column names in SOURCE_TABLE
COL_CONV_ID       = "conversationId"
COL_USER_ID       = "conversationUserId"
COL_DISPLAYNAME   = "DisplayName"
COL_MSG_ID        = "messageId"
COL_ROLE          = "messageRole_category"
COL_ROLE_USER_VAL = "User"
COL_TEXT          = "messageContent"
COL_MSG_CREATED   = "messageCreatedAt"
COL_CONV_CREATED  = "conversationCreatedAt"

# Toggle concatenated-text sentiment (off by default to save compute)
COMPUTE_CONCAT    = False
EXCLUDE_FIRST_FROM_SCORING = True

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'


curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel): 
    return f"{base}/Tables/{rel}" 

def read_delta(base, rel): 
    return spark.read.format("delta").load(tbl_path(base, rel))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

gold_rel  = f"{TARGET_SCHEMA}/{TARGET_TABLE}"
gold_path = tbl_path(curated_lh_id, gold_rel)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ---------------- Imports / setup ----------------
import nltk
nltk.download('vader_lexicon')

from nltk.sentiment import SentimentIntensityAnalyzer
from pyspark.sql import functions as F, Window as W
from delta.tables import DeltaTable

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {TARGET_SCHEMA}")
sc = spark.sparkContext

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# ---------------- VADER UDFs ----------------
sia = SentimentIntensityAnalyzer()
bc_sia = sc.broadcast(sia)

@F.udf("double")
def vader_compound(text):
    try:
        return float(bc_sia.value.polarity_scores(text or "")['compound'])
    except Exception:
        return None

@F.udf("double")
def vader_pos(text):
    try:
        return float(bc_sia.value.polarity_scores(text or "")['pos'])
    except Exception:
        return None

@F.udf("double")
def vader_neu(text):
    try:
        return float(bc_sia.value.polarity_scores(text or "")['neu'])
    except Exception:
        return None

@F.udf("double")
def vader_neg(text):
    try:
        return float(bc_sia.value.polarity_scores(text or "")['neg'])
    except Exception:
        return None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ---------------- Load Silver snapshot ----------------
src = (
    spark.table(SOURCE_TABLE)
         .select(
             F.col(COL_CONV_ID).alias("conversationId"),
             F.col(COL_USER_ID).alias("userId"),
             F.col(COL_DISPLAYNAME).alias("DisplayName"),
             F.col(COL_MSG_ID).alias("messageId"),
             F.col(COL_ROLE).alias("role"),
             F.col(COL_TEXT).alias("messageContent"),
             F.col(COL_MSG_CREATED).alias("messagecreatedAt_raw"),
             F.col(COL_CONV_CREATED).alias("conversationCreatedAt_raw")
         )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Cast timestamps (supports both timestamp strings and epoch millis)
def cast_ts(df, raw_col, out_col):
    dtype = dict(df.dtypes).get(raw_col)
    if dtype in ("bigint", "long", "int"):
        return df.withColumn(out_col, F.from_unixtime(F.col(raw_col)/1000.0).cast("timestamp"))
    else:
        return df.withColumn(out_col, F.col(raw_col).cast("timestamp"))

src = cast_ts(src, "messagecreatedAt_raw", "messagecreatedAt")
src = cast_ts(src, "conversationCreatedAt_raw", "conversationCreatedAt")

msgs = src.select(
    "conversationId","userId","DisplayName","messageId","role",
    "messageContent","messagecreatedAt","conversationCreatedAt"
)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ---------------- Build current fingerprints from Silver ----------------
# Robust fingerprints to detect changes without a state table:
# - fp_user_msg_count  : distinct User message count
# - fp_last_user_msg_ts: last user message timestamp
# - fp_sum_h_id/text   : order-insensitive hash sums over IDs and text (detect edits/re-sends)
curr_fp = (
    msgs.filter(F.col("role") == F.lit("User"))
        .groupBy("conversationId","userId")
        .agg(
            F.countDistinct("messageId").alias("fp_user_message_count"),
            F.max("messagecreatedAt").alias("fp_last_user_message_at")
        )
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# -------- READ GOLD (if exists) & DIFF TO FIND IMPACTED PAIRS --------
gold_exists = DeltaTable.isDeltaTable(spark, gold_path)

if gold_exists:
    gold_fp = (read_delta(curated_lh_id, gold_rel)
               .select(
                   "conversationId","userId",
                   F.col("user_message_count").alias("g_user_message_count"),
                   F.col("last_user_message_at").alias("g_last_user_message_at")
               ))
else:
    gold_fp = None

if gold_fp is None:
    impacted_pairs = curr_fp.select("conversationId","userId").distinct()
else:
    impacted_pairs = (
        curr_fp.alias("c")
               .join(gold_fp.alias("g"), ["conversationId","userId"], "left")
               .where(
                   F.col("g_user_message_count").isNull() |
                   (F.col("c.fp_user_message_count") != F.col("g_user_message_count")) |
                   (F.col("c.fp_last_user_message_at") != F.col("g_last_user_message_at"))
               )
               .select("conversationId","userId").distinct()
    )

impacted_count = impacted_pairs.count()
print("Impacted (conversationId,userId) pairs:", impacted_count)

if impacted_count == 0:
    print("No changes detected. Skipping recompute.")
    if gold_exists:
        display(read_delta(curated_lh_id, gold_rel).orderBy(F.col("last_user_message_at").desc()).limit(20))
else:
    # -------- SUBSET FULL HISTORY FOR IMPACTED PAIRS (User messages only) --------
    subset_user_msgs = (
        msgs.filter(F.col("role") == F.lit("User"))
            .join(impacted_pairs, ["conversationId","userId"], "inner")
            .filter(F.col("messageContent").isNotNull())
            .dropDuplicates(["messageId"])
            .select("conversationId","userId","DisplayName","messageId","messageContent","messagecreatedAt")
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Score per message   
scored = (
        subset_user_msgs
            .withColumn("sent_compound", vader_compound(F.col("messageContent")))
            .withColumn("char_len", F.length(F.col("messageContent")))
    )


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# -------- ORDERING & LAST USER SENTIMENT --------
w_asc  = W.partitionBy("conversationId","userId").orderBy(F.col("messagecreatedAt").asc(), F.col("messageId").asc())
w_desc = W.partitionBy("conversationId","userId").orderBy(F.col("messagecreatedAt").desc(), F.col("messageId").desc())

ordered = (
        scored
            .withColumn("user_msg_idx", F.row_number().over(w_asc))
            .withColumn("rn_desc",      F.row_number().over(w_desc))
    )
ordered = ordered.withColumn("is_first_user_msg", (F.col("user_msg_idx") == 1))
last_user = (
        ordered.where(F.col("rn_desc") == 1)
               .select("conversationId","userId",
                       F.col("sent_compound").alias("last_user_sentiment"))
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# -------- RECENCY WEIGHTING (exponential over message steps) --------
decay = 0.5 ** (1.0 / float(HALF_LIFE_MSGS))
max_idx = ordered.groupBy("conversationId","userId").agg(F.max("user_msg_idx").alias("max_idx"))

with_weights = (
        ordered.join(max_idx, ["conversationId","userId"], "left")
               .withColumn("steps_back", F.col("max_idx") - F.col("user_msg_idx"))
               .withColumn("w_recency",  F.pow(F.lit(decay), F.col("steps_back")))
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# -------- AGGREGATE TO ONE ROW PER (conversationId, userId) --------
agg_parts = (
    with_weights
      .groupBy("conversationId","userId")
      .agg(
          # counts/timestamps/chars over ALL messages
          F.countDistinct("messageId").alias("user_message_count"),
          F.min("messagecreatedAt").alias("first_user_message_at"),
          F.max("messagecreatedAt").alias("last_user_message_at"),
          F.sum("char_len").alias("total_user_charecters"),

          # scoring numerators/denominators, excluding first when toggle is on
          F.sum(
              F.when((~F.col("is_first_user_msg")) | (F.lit(not EXCLUDE_FIRST_FROM_SCORING)),
                     F.col("sent_compound")).otherwise(F.lit(0.0))
          ).alias("sum_sent"),
          F.sum(
              F.when((~F.col("is_first_user_msg")) | (F.lit(not EXCLUDE_FIRST_FROM_SCORING)),
                     F.lit(1)).otherwise(F.lit(0))
          ).alias("cnt_used"),
          F.sum(
              F.when((~F.col("is_first_user_msg")) | (F.lit(not EXCLUDE_FIRST_FROM_SCORING)),
                     F.col("sent_compound") * F.col("w_recency")).otherwise(F.lit(0.0))
          ).alias("sum_sent_x_w"),
          F.sum(
              F.when((~F.col("is_first_user_msg")) | (F.lit(not EXCLUDE_FIRST_FROM_SCORING)),
                     F.col("w_recency")).otherwise(F.lit(0.0))
          ).alias("sum_w")
      )
)


agg = (
    agg_parts
      .withColumn(
          "avg_user_sentiment",
          F.when(F.col("cnt_used") == 0, F.lit(None).cast("double"))
           .otherwise(F.col("sum_sent") / F.col("cnt_used"))
      )
      .withColumn(
          "recency_user_sentiment",
          F.when(F.col("sum_w") == 0, F.lit(None).cast("double"))
           .otherwise(F.col("sum_sent_x_w") / F.col("sum_w"))
      )
      .drop("sum_sent","cnt_used","sum_sent_x_w","sum_w")
      # Join only the *sentiment* from the last user message to avoid duplicate timestamp columns
      .join(
          last_user.select("conversationId","userId","last_user_sentiment"),
          ["conversationId","userId"], "left"
      )
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# -------- LABELS (overall from last; overall_recency from recency-weighted) --------
conv_user_delta = (
    agg
      .withColumn(
          "conversation_sentiment_overall",
          F.when(
              F.col("avg_user_sentiment").isNull() & F.col("recency_user_sentiment").isNull(),
              F.lit("Unrated")
          ).otherwise(
              F.when(F.col("last_user_sentiment") >= F.lit(POS_CONV_THRESHOLD), F.lit("Positive"))
               .when(F.col("last_user_sentiment") <= F.lit(NEG_CONV_THRESHOLD), F.lit("Negative"))
               .otherwise(F.lit("Neutral"))
          )
      )
      .withColumn(
          "conversation_sentiment_overall_recency",
          F.when(
              F.col("recency_user_sentiment").isNull(),
              F.lit("Unrated")
          ).otherwise(
              F.when(F.col("recency_user_sentiment") >= F.lit(POS_CONV_THRESHOLD), F.lit("Positive"))
               .when(F.col("recency_user_sentiment") <= F.lit(NEG_CONV_THRESHOLD), F.lit("Negative"))
               .otherwise(F.lit("Neutral"))
          )
      )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# -------- USERNAME  --------
name_lookup = (
        subset_user_msgs
            .groupBy("conversationId","userId")
            .agg(F.first(F.col("DisplayName"), ignorenulls=True).alias("username"))
    )
final_df = conv_user_delta.join(name_lookup, ["conversationId","userId"], "left")

# -------- FINAL COLUMN ORDER (exact spec) --------
final_df = final_df.select(
        "conversationId",
        "userId",
        "username",
        "user_message_count",
        "avg_user_sentiment",
        "last_user_sentiment",
        "recency_user_sentiment",
        "conversation_sentiment_overall",
        "conversation_sentiment_overall_recency",
        "first_user_message_at",
        "last_user_message_at",
        "total_user_charecters"
    )


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# -------- UPSERT TO GOLD BY PATH -------------------
if not gold_exists:
        (final_df
            .write
            .format("delta")
            .mode("overwrite")
            .option("overwriteSchema", "true")
            .save(gold_path))
        print("Created Delta table at", gold_path)
else:
        tgt = DeltaTable.forPath(spark, gold_path)
        (tgt.alias("t")
            .merge(
                final_df.alias("s"),
                "t.conversationId = s.conversationId AND t.userId = s.userId"
            )
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute())
        print("Merged into", gold_path)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
