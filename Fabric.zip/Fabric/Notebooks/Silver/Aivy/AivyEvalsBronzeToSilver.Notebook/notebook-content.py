# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # **Aivy Logs Dashboard: Silver Layer**
# This notebook serves as the entry point for preparing the data that powers the Aivy Logs Dashboard.
# 1.  Queries Application Insights to append historical Aivy logs to the Silver database.
# 2.  Filters and transforms the log data to create a dedicated table of evaluation metrics in the Silver database.


# CELL ********************

from pyspark.sql import functions as F, types as T
from delta.tables import DeltaTable
from notebookutils import credentials
import requests
import json
import datetime

####################
spark.conf.set('spark.sql.caseSensitive', True)
####################

EVAL_BRONZE_TBL = "lh_bronze.Bronze.AivyEvals"
EVAL_SILVER_TBL = "lh_curated.Silver.AivyEvals"


OPS_TBL    = "lh_curated.Silver.AivyLogsOps"
FAILED_TBL = "lh_curated.Silver.AivyLogsFailedOps"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## APPInsights ingestion
# - Consumes from appInsightsDB (our bronze-like az logs) and saves to silver

# CELL ********************

LOOKBACK = '2d'

DEV_APP_ID  = "b19d79f8-0a18-467b-b289-5d03e2f85345"
DEV_API_KEY = credentials.getSecret("https://KV-DC1Dev-ADF.vault.azure.net/", "insights-smartsearch2-dev1-api-key")
PROD_APP_ID  = "15515eb1-adf5-435d-a4da-4fc68eeddad0"
PROD_API_KEY = credentials.getSecret("https://KV-DC1Prd-ADF.vault.azure.net/", "insights-smartsearch2-prod1-api-key")


if not spark.catalog.tableExists(OPS_TBL):
    print(f"[DDL] Creating table {OPS_TBL}")
    (spark.createDataFrame([], schema=T.StructType([
        T.StructField("event_time",         T.TimestampType(), True),
        T.StructField("event_time_boston",  T.TimestampType(), True),
        T.StructField("event_date",         T.DateType(),      True),
        T.StructField("event_hour",         T.IntegerType(),   True),
        T.StructField("operation_id",       T.StringType(),    True),
        T.StructField("name",               T.StringType(),    True),
        T.StructField("operation",          T.StringType(),    True),
        T.StructField("result_code",        T.StringType(),    True),
        T.StructField("runtime_s",          T.DoubleType(),    True),
        T.StructField("performance_bucket", T.StringType(),    True),
        T.StructField("source_env",         T.StringType(),    True),
        T.StructField("ingested_at",        T.TimestampType(), True),
        T.StructField("silver_row_id",      T.StringType(),    True),
    ]))
    .write.format("delta")
    .option("overwriteSchema", "true")
    .partitionBy("event_date")
    .mode("overwrite")
    .saveAsTable(OPS_TBL)
    )

if not spark.catalog.tableExists(FAILED_TBL):
    print(f"[DDL] Creating table {FAILED_TBL}")
    (spark.createDataFrame([], schema=T.StructType([
        T.StructField("event_time",           T.TimestampType(), True),
        T.StructField("event_time_boston",    T.TimestampType(), True),
        T.StructField("event_date",           T.DateType(),      True),
        T.StructField("event_hour",           T.IntegerType(),   True),
        T.StructField("operation_id",         T.StringType(),    True),
        T.StructField("failed_name",          T.StringType(),    True),
        T.StructField("failed_result_code",   T.StringType(),    True),
        T.StructField("failed_duration",      T.DoubleType(),    True),
        T.StructField("exception_message",    T.StringType(),    True),
        T.StructField("exception_type",       T.StringType(),    True),
        T.StructField("source_env",           T.StringType(),    True),
        T.StructField("ingested_at",          T.TimestampType(), True),
        T.StructField("silver_row_id",        T.StringType(),    True),
    ]))
    .write.format("delta")
    .option("overwriteSchema", "true")
    .partitionBy("event_date")
    .mode("overwrite")
    .saveAsTable(FAILED_TBL)
    )

LLM_QUERY  = f"""
let lookback = {LOOKBACK};
let SearchRows =
    dependencies
    | where timestamp between (ago(lookback) .. now())
    | where name in ("POST /indexes/latest/docs/search",
        "POST /indexes('ktr_v2')/docs/search.post.search")
    | project
        event_time = timestamp,
        operation_Id,
        name,
        operation = case(
            name == "POST /indexes/latest/docs/search", "search",
            name has "/indexes('ktr_v2')/docs/search.post.search", "ktr",
            "unknown"
        ),
        result_code = tostring(resultCode),
        runtime_s = todouble((duration/1000.0)),
        performance_bucket = performanceBucket;
let LlmDepRows =
    dependencies
    | where timestamp between (ago(lookback) .. now())
    | where name in ("llm_call")
    | extend role = tostring(customDimensions.role)
    | where role in ("agent", "summarization")
    | project
        event_time = timestamp,
        operation_Id,
        name,
        operation = role,
        result_code = tostring(resultCode),
        runtime_s = todouble((duration/1000.0)),
        performance_bucket = performanceBucket;
union SearchRows, LlmDepRows
| order by event_time desc
"""

FAILED_QUERY  = f"""
let lookback = {LOOKBACK};
let FailedDeps =
    dependencies
    | where timestamp between (ago(lookback) .. now())
    | where name in ("POST /indexes/latest/docs/search",
                     "POST /indexes('ktr_v2')/docs/search.post.search",
                     "llm_call")
    | where tostring(success) =~ "false"
    | project event_time = timestamp, operation_Id, failed_name = name,
              failed_result_code = tostring(resultCode), failed_duration = todouble(duration);
let ExLatest =
    exceptions
    | where timestamp between (ago(lookback) .. now())
    | where operation_Id in (FailedDeps | project operation_Id)
    | summarize arg_max(timestamp, innermostMessage, type) by operation_Id
    | project operation_Id, exception_message = innermostMessage, exception_type = type;
FailedDeps
| join kind=leftouter ExLatest on operation_Id
"""

def fetch_api(app_id, api_key, kql):
    """Query Azure App Insights API and convert JSON to DataFrame"""
    if not app_id:
        return spark.createDataFrame([], T.StructType([]))
    
    url = f"https://api.applicationinsights.io/v1/apps/{app_id}/query"
    resp = requests.post(url, headers={"x-api-key": api_key}, json={"query": kql}, timeout=120)
    resp.raise_for_status()
    result = resp.json()

    if not result.get("tables"):
        print(f"API query for app_id {app_id[:8]}... returned no 'tables' block.")
        return spark.createDataFrame([], T.StructType([]))

    table = result["tables"][0]
    rows = table.get("rows", [])
    columns = [col["name"] for col in table["columns"]]

    if not rows:
        print(f"API query for app_id {app_id[:8]}... returned 0 rows.")
        # Create an empty DataFrame with a defined schema to prevent errors.
        schema = T.StructType([T.StructField(c, T.StringType(), True) for c in columns])
        return spark.createDataFrame([], schema)

    string_schema = T.StructType([T.StructField(c, T.StringType(), True) for c in columns])
    return spark.createDataFrame(rows, string_schema)

def filter_by_watermark(df, table, col="event_time"):
    """Find Delta table max event_time, filter incoming records above it"""
    try:
        watermark = spark.table(table).agg(F.max(col).alias("mx")).first().mx
    except Exception:
        watermark = None
    return (df if watermark is None else df.filter(F.col(col) > F.lit(watermark))), watermark

def align_schema(df, table):
    """Align df column order and types to match Delta table schema"""
    schema = spark.table(table).schema
    selects = []
    for field in schema:
        selects.append(
            F.col(field.name).cast(field.dataType).alias(field.name)
            if field.name in df.columns else
            F.lit(None).cast(field.dataType).alias(field.name)
        )
    return df.select(*selects)

def table_exists(tbl: str) -> bool:
    try:
        return spark.catalog.tableExists(tbl)
    except Exception:
        return False

def save_delta(df, title, table):
    """Create Silver table on first run (partitioned), else align & append."""
    if df.rdd.isEmpty():
        print(f"[Skip] {title}: nothing to append.")
        return
    if not table_exists(table):
        (df.write
           .format("delta")
           .partitionBy("event_date")
           .mode("append")
           .saveAsTable(table))
        print(f"[Create] {title}: created {table} with {df.count()} rows")
    else:
        df_aligned = align_schema(df, table)
        df_aligned.write.format("delta").mode("append").saveAsTable(table)
        print(f"[Append] {title}: wrote {df_aligned.count()} rows to {table}")

# --------- ingestion (fetch) ---------
dev_ops   = fetch_api(DEV_APP_ID, DEV_API_KEY,   LLM_QUERY).withColumn("source_env", F.lit("dev1"))
dev_fail  = fetch_api(DEV_APP_ID, DEV_API_KEY, FAILED_QUERY).withColumn("source_env", F.lit("dev1"))
prod_ops  = fetch_api(PROD_APP_ID, PROD_API_KEY,   LLM_QUERY).withColumn("source_env", F.lit("prod1")) if PROD_APP_ID else spark.createDataFrame([], dev_ops.schema)
prod_fail = fetch_api(PROD_APP_ID, PROD_API_KEY, FAILED_QUERY).withColumn("source_env", F.lit("prod1"))  if PROD_APP_ID else spark.createDataFrame([], dev_fail.schema)

# --------- Union DEV + PROD ---------
ops_all    = dev_ops.unionByName(prod_ops)
failed_all = dev_fail.unionByName(prod_fail)

# --------- Watermark ---------
ops_all,    ops_wm  = filter_by_watermark(ops_all,    OPS_TBL,    col="event_time")
failed_all, fail_wm = filter_by_watermark(failed_all, FAILED_TBL, col="event_time")

print(f"[Info] SILVER OPS watermark:    {ops_wm}")
print(f"[Info] SILVER FAILED watermark: {fail_wm}")

# --------- Enrich to Silver schema ---------
ops_silver = (
    ops_all
    .select(
        F.col("event_time"),
        F.col("operation_Id").alias("operation_id"),
        F.col("name").cast("string").alias("name"),
        F.col("operation").cast("string").alias("operation"),
        F.col("result_code").cast("string").alias("result_code"),
        F.col("runtime_s").cast("double").alias("runtime_s"),
        F.col("performance_bucket").cast("string").alias("performance_bucket"),
        F.col("source_env").cast("string").alias("source_env"),
    )
    .withColumn("event_time_boston", F.from_utc_timestamp(F.col("event_time"), "America/New_York"))
    .withColumn("event_date", F.to_date("event_time"))
    .withColumn("event_hour", F.hour("event_time"))
    .withColumn("ingested_at", F.current_timestamp())
    .withColumn(
        "silver_row_id",
        F.sha2(F.concat_ws("|",
            F.col("operation_id").cast("string"),
            F.col("event_time").cast("string")
        ), 256)
    )
    .select(
        "event_time", "event_time_boston", "event_date", "event_hour",
        "operation_id", "name", "operation",
        "result_code", "runtime_s", "performance_bucket",
        "source_env", "ingested_at", "silver_row_id"
    )
)

failed_silver = (
    failed_all
    .select(
        F.col("event_time"),
        F.col("operation_Id").alias("operation_id"),
        F.col("failed_name").cast("string").alias("failed_name"),
        F.col("failed_result_code").cast("string").alias("failed_result_code"),
        F.col("failed_duration").cast("double").alias("failed_duration"),
        F.col("exception_message").cast("string").alias("exception_message"),
        F.col("exception_type").cast("string").alias("exception_type"),
        F.col("source_env").cast("string").alias("source_env"),
    ).withColumn(
        "failed_result_code_extracted", F.regexp_extract("exception_message", r"\b(\d{3})\b", 1)
    )
    .withColumn(
        "failed_result_code",
        F.when(
            F.col("failed_result_code_extracted") != "",
            F.col("failed_result_code_extracted")
        ).otherwise(F.col("failed_result_code"))
    )
    .drop("failed_result_code_extracted")
    .withColumn("event_time_boston", F.from_utc_timestamp(F.col("event_time"), "America/New_York"))
    .withColumn("event_date", F.to_date("event_time"))
    .withColumn("event_hour", F.hour("event_time"))
    .withColumn("ingested_at", F.current_timestamp())
    .withColumn(
        "silver_row_id",
        F.sha2(F.concat_ws("|",
            F.col("operation_id").cast("string"),
            F.col("event_time").cast("string")
        ), 256)
    )
    .select(
        "event_time", "event_time_boston", "event_date", "event_hour",
        "operation_id", "failed_name", "failed_result_code",
        "failed_duration", "exception_message", "exception_type",
        "source_env", "ingested_at", "silver_row_id"
    )
)

save_delta(ops_silver,    "LLM operations (Silver)",    OPS_TBL)
save_delta(failed_silver, "Failed operations (Silver)", FAILED_TBL)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## Evals to silver
# - IF there are any evals ( run by bronze notebook), add them to silver

# CELL ********************

if not spark.catalog.tableExists(EVAL_SILVER_TBL):
    print(f"[DDL] Creating table {EVAL_SILVER_TBL}")
    (
        spark.createDataFrame([], schema=T.StructType([
            T.StructField("eval_timestamp",  T.TimestampType(), True),
            T.StructField("eval_timestamp_boston",  T.TimestampType(), True),
            T.StructField("eval_date",       T.DateType(),      True),
            T.StructField("eval_hour",       T.IntegerType(),   True),
            T.StructField("hour_bucket",     T.TimestampType(), True),
            T.StructField("minute_bucket",   T.TimestampType(), True),
            T.StructField("source_env",      T.StringType(),    True),
            T.StructField("metric_name",     T.StringType(),    True),
            T.StructField("metric_type",     T.StringType(),    True),
            T.StructField("metric_value",    T.DoubleType(),    True),
            T.StructField("success",         T.BooleanType(),   True),
            T.StructField("metadata_json",   T.StringType(),    True), 
            T.StructField("ingested_at",     T.TimestampType(), True),
            T.StructField("silver_row_id",   T.StringType(),    True),
        ]))
        .write.format("delta")
        .partitionBy("eval_date")
        .mode("overwrite")
        .saveAsTable(EVAL_SILVER_TBL)
    )
    
try:
    watermark_ts = spark.table(EVAL_SILVER_TBL).select(F.max("eval_timestamp").alias("mx")).first().mx
except Exception:
    watermark_ts = None

bronze_df = spark.table(EVAL_BRONZE_TBL)
if watermark_ts is not None:
    bronze_df = bronze_df.filter(F.col("evalTimestamp") > F.lit(watermark_ts))

if bronze_df.rdd.isEmpty():
    pass
else:
    renamed_metrics = (
        F.when(F.col("metric_name") == "retrieval_only_runtime", "Document retrieval runtime")
        .when(F.col("metric_name") == "retrieval", "Document retrieval completeness")
        .when(F.col("metric_name") == "quality", "Response quality (llm)")
        .when(F.col("metric_name") == "person_names", "Person names completeness")
        .when(F.col("metric_name") == "runtime", "Runtime")
        .otherwise(F.col("metric_name"))  
    )
    new_rows = (
        bronze_df.select(
            F.col("evalTimestamp").alias("eval_timestamp"),
            F.from_utc_timestamp(F.col("evalTimestamp"), "America/New_York").alias("eval_timestamp_boston"),
            F.to_date("evalTimestamp").alias("eval_date"),
            F.hour("evalTimestamp").alias("eval_hour"),
            F.date_trunc("hour", F.col("evalTimestamp")).alias("hour_bucket"),
            F.date_trunc("minute", F.col("evalTimestamp")).alias("minute_bucket"),
            F.col("source_env").cast("string").alias("source_env"),
            renamed_metrics.alias("metric_name"),
            F.col("metric_type").cast("string").alias("metric_type"),
            F.col("metric_value").cast("double").alias("metric_value"),
            F.col("success").cast("boolean").alias("success"),
            F.col("metadata").cast("string").alias("metadata_json"),
        )
        .withColumn("ingested_at", F.current_timestamp())
        .withColumn(
            "silver_row_id",
            F.sha2(F.concat_ws("|",
                F.col("eval_timestamp").cast("string"),
                F.col("source_env"),
                F.col("metric_name")
            ), 256)
        )
    )
    DeltaTable.forName(spark, EVAL_SILVER_TBL) \
    .alias("t") \
    .merge(new_rows.alias("s"), "t.silver_row_id = s.silver_row_id") \
    .whenNotMatchedInsertAll() \
    .execute()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
