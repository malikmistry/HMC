# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from delta.tables import DeltaTable
from pyspark.sql import functions as F, types as T
import os, json, time, requests
from pyspark.sql.functions import col, coalesce, lit, concat

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Silver Delta table path (uses Fabric helper 'get_basepath')
WorkspaceId   = None
BronzeLHId    = None
CuratedLHId   = None
TaskList      = None
NotebookName  = None
LakehouseName = None
RawLHId       = None

print(f"Params: WorkspaceId={WorkspaceId}, BronzeLHId={BronzeLHId}, CuratedLHId={CuratedLHId}")

if WorkspaceId is None:
    # Example defaults (replace with your IDs if needed)
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId  = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

# Resolve base lakehouse path; get_basepath is provided by notebook_utils in Fabric
curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

def tbl_path(base, rel): 
    return f"{base}/Tables/{rel}" 

# Gold table location (single output table)
silver_rel  = "Silver/AivyPromptLibraryUsage"
silver_path = tbl_path(curated_lh_id, silver_rel)
print("Silver Delta path:", silver_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Defining Bronze Path
bronze_lh_base = get_basepath(WorkspaceId, BronzeLHId)

# Bronze table paths
cpu_path  = tbl_path(bronze_lh_base, "Bronze/CrimsonXChatPromptUsage")
cpt_path  = tbl_path(bronze_lh_base, "Bronze/CrimsonXChatPromptTemplate")
cpsc_path = tbl_path(bronze_lh_base, "Bronze/CrimsonXChatPromptSubcategory")
cpc_path  = tbl_path(bronze_lh_base, "Bronze/CrimsonXChatPromptCategory")

# Read Bronze Delta tables
cpu  = spark.read.format("delta").load(cpu_path)   .alias("cpu")
cpt  = spark.read.format("delta").load(cpt_path)   .alias("cpt")
cpsc = spark.read.format("delta").load(cpsc_path)  .alias("cpsc")
cpc  = spark.read.format("delta").load(cpc_path)   .alias("cpc")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

silver_df = (
    cpu.join(cpt,  col("cpu.PromptTemplateId")        == col("cpt.ChatPromptTemplateId"),   "inner")
       .join(cpsc, col("cpt.ChatPromptSubcategoryId") == col("cpsc.ChatPromptSubcategoryId"),"inner")
       .join(cpc,  col("cpt.ChatPromptCategoryId")    == col("cpc.ChatPromptCategoryId"),   "inner")
       .select(
           col("cpu.ChatPromptUsageId").alias("ChatPromptUsageId"),
           col("cpu.HMCUserId").alias("HMCUserId"),
           col("cpu.Title").alias("Title"),
           col("cpu.LastUsed").alias("PromptUsedAt"),
           col("cpu.MetadataJson").alias("MetadataJson"),
           col("cpu.RelatedChatId").alias("RelatedChatId"),
           col("cpt.TemplateText").alias("TemplateText"),
           col("cpc.CategoryName").alias("CategoryName"),
           col("cpsc.SubcategoryName").alias("SubcategoryName")
       )
)

silver_df = silver_df.withColumn(
    "conv_user_key",
    concat(
        coalesce(col("RelatedChatId").cast("string"), lit("")),
        lit("|"),
        coalesce(col("HMCUserId").cast("string"), lit(""))
    )
)


print("Row count to write:", silver_df.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(silver_df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

cpu_count    = spark.read.format("delta").load(cpu_path).count()
silver_count = silver_df.count()
print(f"[Sanity] CPU rows={cpu_count} | Silver candidate rows={silver_count}")

if cpu_count != silver_count:
    raise ValueError(f"Row count mismatch: CPU={cpu_count} vs Silver={silver_count}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

(silver_df.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(silver_path)
)

print(f"Wrote {silver_df.count()} rows to Silver table at: {silver_path}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
