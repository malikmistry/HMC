# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F, types as T
from delta.tables import DeltaTable
from notebookutils import credentials
import requests
import json
import datetime

####################
spark.conf.set('spark.sql.caseSensitive', True)
####################

EVAL_BRONZE_TBL = "lh_bronze.Bronze.AivyEvals"
EVAL_SILVER_TBL = "lh_curated.Silver.AivyEvals"

OPS_TBL    = "lh_curated.Silver.AivyLogsOps"
FAILED_TBL = "lh_curated.Silver.AivyLogsFailedOps"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

if not spark.catalog.tableExists(EVAL_SILVER_TBL):
    print(f"[DDL] Creating table {EVAL_SILVER_TBL}")
    (
        spark.createDataFrame([], schema=T.StructType([
            T.StructField("eval_timestamp",  T.TimestampType(), True),
            T.StructField("eval_timestamp_boston",  T.TimestampType(), True),
            T.StructField("eval_date",       T.DateType(),      True),
            T.StructField("eval_hour",       T.IntegerType(),   True),
            T.StructField("hour_bucket",     T.TimestampType(), True),
            T.StructField("minute_bucket",   T.TimestampType(), True),
            T.StructField("source_env",      T.StringType(),    True),
            T.StructField("metric_name",     T.StringType(),    True),
            T.StructField("metric_type",     T.StringType(),    True),
            T.StructField("metric_value",    T.DoubleType(),    True),
            T.StructField("success",         T.BooleanType(),   True),
            T.StructField("metadata_json",   T.StringType(),    True), 
            T.StructField("ingested_at",     T.TimestampType(), True),
            T.StructField("silver_row_id",   T.StringType(),    True),
        ]))
        .write.format("delta")
        .partitionBy("eval_date")
        .mode("overwrite")
        .saveAsTable(EVAL_SILVER_TBL)
    )
    
try:
    watermark_ts = spark.table(EVAL_SILVER_TBL).select(F.max("eval_timestamp").alias("mx")).first().mx
except Exception:
    watermark_ts = None

bronze_df = spark.table(EVAL_BRONZE_TBL)
if watermark_ts is not None:
    bronze_df = bronze_df.filter(F.col("evalTimestamp") > F.lit(watermark_ts))

if bronze_df.rdd.isEmpty():
    pass
else:
    new_rows = (
        bronze_df.where(F.col("metric_name") == "sql_eval")
        .select(
            F.col("evalTimestamp").alias("eval_timestamp"),
            F.from_utc_timestamp(F.col("evalTimestamp"), "America/New_York").alias("eval_timestamp_boston"),
            F.to_date("evalTimestamp").alias("eval_date"),
            F.hour("evalTimestamp").alias("eval_hour"),
            F.date_trunc("hour", F.col("evalTimestamp")).alias("hour_bucket"),
            F.date_trunc("minute", F.col("evalTimestamp")).alias("minute_bucket"),
            F.col("source_env").cast("string").alias("source_env"),
            F.col("metric_name").alias("metric_name"),
            F.col("metric_type").cast("string").alias("metric_type"),
            F.col("metric_value").cast("double").alias("metric_value"),
            F.col("success").cast("boolean").alias("success"),
            F.col("metadata").cast("string").alias("metadata_json"),
        )
        .withColumn("ingested_at", F.current_timestamp())
        .withColumn(
            "silver_row_id",
            F.sha2(F.concat_ws("|",
                F.col("eval_timestamp").cast("string"),
                F.col("source_env"),
                F.col("metric_name")
            ), 256)
        )
    )
    DeltaTable.forName(spark, EVAL_SILVER_TBL) \
    .alias("t") \
    .merge(new_rows.alias("s"), "t.silver_row_id = s.silver_row_id") \
    .whenNotMatchedInsertAll() \
    .execute()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
