# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

#Importing all libraries needed

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, to_date

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Defining Silver and Bronze locations

BRONZE = 'lh_bronze.Bronze'
SILVER = 'lh_curated.Silver'

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Reading Bronze tables needed 

chat_df = spark.read.table(f"{BRONZE}.ChatAiDbChatHistory")
ad_df = spark.read.table(f"{SILVER}.HMCUser")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Transforming EntraUsers table to further join with ChatHistory Table to get User Name and Department 

dept_map = {
    "Human Resources": "HR",
    "Information Technology": "IT",
    "Generalist - Analysts": "Analysts",
    "Finance & Investment Ops": "Operations",
    "Generalist Team": "Generalist MD",
    "Administrative Assistants": "Admin"
}

dept_group_map = {
    "Human Resources": "3) Finance / Ops",
    "Information Technology": "4) IT",
    "Generalist - Analysts": "2) Generalist Analysts",
    "Finance & Investment Ops": "3) Finance / Ops",
    "Generalist Team": "1) Generalist MD",
    "Administrative Assistants": "3) Finance / Ops",
    "Compliance": "3) Finance / Ops",
    "Tax": "3) Finance / Ops",
    "Left HMC": "5) Left HMC",
    "Interns & Coops":"3) Finance / Ops"
}

mapping_expr = F.create_map([F.lit(x) for x in sum(dept_map.items(), ())])
group_mapping_expr = F.create_map([F.lit(x) for x in sum(dept_group_map.items(), ())])


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


ad_t = (
    ad_df
    .withColumn(
        "user_key",
        F.lower(F.trim(F.regexp_extract(F.col("HMCUserId"), r"^([^@]+)", 1)))
    )
    .withColumn(
        "department_updated",
        F.when(
            (F.col("Department") == "Generalist Team") & 
            (F.col("JobTitle") != "Managing Director"),
            F.lit("Generalist - Analysts")
        )
        .when(F.col("Department").rlike(r"^\d+$"), F.lit("Left HMC"))
        .when(F.col("department").isNull() | (F.col("department") == "NULL"), F.lit("Left HMC"))
        .otherwise(F.col("department"))
    )
    # Short form
    .withColumn(
        "department_short",
        F.coalesce(mapping_expr.getItem(F.col("department_updated")), F.col("department_updated"))
    )
    # Grouped form
    .withColumn(
        "department_group",
        F.coalesce(group_mapping_expr.getItem(F.col("department_updated")), F.col("department_short"))
    )
    .withColumn("DisplayName", F.col("DisplayName"))
    .select("user_key","department","department_short", "department_group", "DisplayName", "jobTitle")
    .dropna(subset=["user_key"])
    .dropDuplicates(["user_key"])
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Attachment Type classification
attachment_map = {
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "Excel",
    "application/json": "JSON",
    "text/plain": "Text",
    "image/jpeg": "Image",
    "text/csv": "CSV",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": "PowerPoint",
    "application/pdf": "PDF",
    "audio/mpeg": "Audio",
    "image/png": "Image",
    "NULL": "None"
}

mapping_expr = F.create_map([F.lit(x) for x in sum(attachment_map.items(), ())])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#Transforming ChatHistory to change numeric variables to categorical, enriching data

chat_t = (
    chat_df
    .withColumn(
        "user_key",
        F.lower(F.trim(F.regexp_extract(F.col("conversationUserId"), r"^([^@]+)", 1)))
    )
    .withColumn(
        "messageRole_category",
        F.when(F.col("messageRole") == 0, F.lit("User"))
         .when(F.col("messageRole").isin(2, 3), F.lit("Aivy Response"))
         .when(
             (F.col("messageRole") == 1) &
             (
                 F.col("messageContent").startswith("<<<Extracted-Content>>>")
                 | F.col("messageContent").startswith("<<<Extracted-Content-Error>>>")
             ),
             F.lit("Attachment")
         )
         .when(F.col("messageRole") == 1, F.lit("System Feedback"))
         .otherwise(F.lit("Unknown"))
    )
    .withColumn(
        "ToolUsed",
        F.when(F.col("messageRole_category") == "Attachment", F.lit("Attachment"))
         .when(F.col("metadata_source") == "smart-search-2", F.lit("Internal Search"))
         .when(F.col("metadata_source") == "web", F.lit("Web Search"))
         .otherwise(F.coalesce(F.col("metadata_source"), F.lit("None")))
    )
    .withColumn(
        "AttachmentType",
        F.when(F.col("metadata_contentType").isNull(), F.lit("None"))
         .otherwise(
             F.coalesce(mapping_expr.getItem(F.col("metadata_contentType")), F.lit("Other"))
         )
    )
    .withColumn(
        "messageContent_truncated",
        F.when(F.col("messageRole_category") == "Attachment", F.lit("Attachment content"))
         .otherwise(F.substring(F.col("messageContent"), 1, 100))
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

joined_df = (
    chat_t.alias("c")
    .join(ad_t.alias("a"), on="user_key", how="left")
    .withColumn("department_group", F.coalesce(F.col("a.department_group"), F.lit("")))
    .withColumn("department_short", F.coalesce(F.col("a.department_short"), F.lit("")))
    .withColumn("jobTitle", F.coalesce(F.col("a.jobTitle"), F.lit("Unknown")))
    .withColumn(
        "DisplayName",
        F.when(F.col("a.DisplayName").isNull(), F.col("user_key"))
         .otherwise(F.col("a.DisplayName"))
    )
    .withColumn("conversationMonth", F.to_date(F.trunc(F.col("conversationCreatedAt"), "MM")))
    .withColumn("conversationMonthLabel", F.date_format(F.col("conversationMonth"), "MMM yyyy"))
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

joined_df = (
    joined_df
    .withColumnRenamed("metadata_feedbackType","FeedbackType")
    .withColumnRenamed("metadata_feedbackReason","FeedbackReason")
    )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

joined_df = joined_df.drop("messageRole","metadata_messageId","metadata_contentType")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Target Silver table
target_table = "lh_curated.Silver.AivyChatHistory"
(
    joined_df
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(target_table)
)

print(f"Silver table created: {target_table}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
