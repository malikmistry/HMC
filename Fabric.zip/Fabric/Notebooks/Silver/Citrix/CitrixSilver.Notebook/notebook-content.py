# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Databricks / PySpark notebook: Bronze.Netscaler -> Silver.UserNetworkAccessDataCitrix
from pyspark.sql import functions as F
from functools import reduce

# ========= Config / toggles =========
DEBUG = True  # set False to skip probes

# ========= Helpers =========
def tbl_path(base, rel): 
    return f"{base}/Tables/{rel}"

def read_delta(base, rel): 
    return spark.read.format("delta").load(tbl_path(base, rel))

def col_ci(df, name):
    """Case-insensitive column resolver -> Column or None."""
    m = {c.lower(): c for c in df.columns}
    actual = m.get(name.lower())
    return F.col(actual) if actual else None

def any_of(df, names, dtype=None, default=None):
    """Coalesce across candidate names (case-insensitive)."""
    cols = [col_ci(df, n) for n in names]
    cols = [c for c in cols if c is not None]
    if not cols:
        return F.lit(default).cast(dtype) if dtype else F.lit(default)
    out = F.coalesce(*cols)
    return out.cast(dtype) if dtype else out

def null_if_blank(expr: F.Column) -> F.Column:
    """Turn '', '   ', 'null' -> NULL, else trimmed string."""
    return F.when(
        expr.isNull() | (F.length(F.trim(expr)) == 0) | (F.lower(F.trim(expr)) == F.lit("null")),
        F.lit(None)
    ).otherwise(F.trim(expr))

def unknown_if_blank(expr: F.Column) -> F.Column:
    """Return 'Unknown' if blank/NULL, else trimmed string."""
    return F.when(expr.isNull() | (F.length(F.trim(expr)) == 0), F.lit("Unknown")).otherwise(F.trim(expr))

# ========= Inputs =========
source_rel = "Bronze/Netscaler"
silver_rel = "Silver/UserNetworkAccessDataCitrix"
entra_rel  = "Bronze/EntraUsers"
codes_rel  = "Bronze/CountryCodes"

# ========= Read sources =========
src_df = read_delta(bronze_lh_id, source_rel)
entra_df = (
    read_delta(bronze_lh_id, entra_rel)
    .select(
        F.col("userPrincipalName").cast("string").alias("userPrincipalName"),
        F.col("department").cast("string").alias("department"),
        F.col("givenName").cast("string").alias("givenName"),
        F.col("surname").cast("string").alias("surname"),
    )
    .where(F.col("userPrincipalName").isNotNull())
)

codes_df = (
    read_delta(bronze_lh_id, codes_rel)
    .select(
        F.col("Country").cast("string").alias("CountryFull"),
        F.col("Azure").cast("string").alias("Azure"),
        F.col("Citrix").cast("string").alias("Citrix"),
        F.col("GlobalProtect").cast("string").alias("GlobalProtect"),
        F.col("BlackList").cast("boolean").alias("BlackList"),
        F.col("GreyList").cast("boolean").alias("GreyList"),
        F.col("WhiteList").cast("boolean").alias("WhiteList"),
    )
)

if DEBUG:
    print("Bronze Netscaler schema:")
    src_df.printSchema()

# ========= Normalize source (Netscaler) =========
# who/user token: drop "EDIT " / "EDT " prefix if present; take last token; lower-case
clean_user = F.regexp_replace(any_of(src_df, ["User"], "string"), r'^(?i)(edit|edt)\s+', '')
who_token = F.lower(
    F.when(F.instr(clean_user, ' ') > 0,
           F.element_at(F.split(F.trim(clean_user), r'\s+'), -1))
     .otherwise(F.trim(clean_user))
)

# timestamp from Date with several parsers
date_col = any_of(src_df, ["Date"], "string")
ts_direct = any_of(src_df, ["Date"], "timestamp")
ts_z   = F.to_timestamp(date_col, "yyyy-MM-dd HH:mm:ss z")    # 'EDT' style
ts_x3  = F.to_timestamp(date_col, "yyyy-MM-dd HH:mm:ss XXX")  # +05:00
ts_x2  = F.to_timestamp(date_col, "yyyy-MM-dd HH:mm:ss xx")   # +0500
ts_na  = F.to_timestamp(date_col, "yyyy-MM-dd HH:mm:ss")
timestamp_raw = F.coalesce(ts_direct, ts_z, ts_x3, ts_x2, ts_na)

# success from Status (allow a few common variants)
status_lc = F.lower(any_of(src_df, ["Status"], "string"))
success_col = (
    F.when(status_lc.isNull(), True)
     .when(status_lc.isin("success", "succeeded", "allow", "allowed", "ok", "pass"), True)
     .when(status_lc.isin("failure", "failed", "deny", "denied", "blocked", "error"), False)
     .otherwise(True)
)

# deviceDisplayName from Bronze (tolerant)
DEVICE_CANDIDATES = [
    "Device", "device", "deviceDisplayName",
    "ClientName", "ClientMachine", "ClientHostname",
    "MachineName", "ComputerName", "HostName", "hostname"
]
raw_device = any_of(src_df, DEVICE_CANDIDATES, "string")
device_display = null_if_blank(raw_device)

src_norm = (
    src_df
    .withColumn("timestamp_raw", timestamp_raw)
    .withColumn("success", success_col)
    .withColumn("who_token", who_token)
    .withColumn("who", F.col("who_token"))
    .withColumn("city", any_of(src_df, ["CityName"], "string"))
    .withColumn("state", any_of(src_df, ["RegionName"], "string"))
    .withColumn("country_raw", any_of(src_df, ["CountryName"], "string"))
    .withColumn("ipAddress", any_of(src_df, ["IPAddress"], "string"))
    .withColumn("deviceDisplayName", device_display)
    .withColumn("Source", F.lit("Netscaler"))
    .alias("l")
)

# ========= Normalize Entra =========
entra_norm = (
    entra_df
    .withColumn("upn_norm",  F.lower(F.trim(F.col("userPrincipalName"))))
    .withColumn("upn_local", F.lower(F.substring_index(F.col("userPrincipalName"), "@", 1)))
    .dropDuplicates(["upn_norm"])
    .alias("e")
)

# ========= Normalize CountryCodes =========
codes_norm = (
    codes_df
    .withColumn("name_match",  F.upper(F.trim(F.col("CountryFull"))))
    .withColumn("az_match",    F.upper(F.trim(F.col("Azure"))))
    .withColumn("citrix_match",F.upper(F.trim(F.coalesce(F.col("Citrix"), F.col("CountryFull")))))
    .withColumn("gp_match",    F.upper(F.trim(F.coalesce(F.col("GlobalProtect"), F.col("CountryFull")))))
    .withColumn("name_match", F.regexp_replace(F.col("name_match"), r"\s*\(THE\)$", ""))
    .alias("cc")
)

# ========= Join Entra (user local-part) =========
joined_le = src_norm.join(
    entra_norm,
    F.col("l.who_token") == F.col("e.upn_local"),
    how="left"
)

# ========= Country mapping =========
country_candidate_uc = F.upper(F.trim(F.col("l.country_raw")))
country_candidate_uc = F.regexp_replace(country_candidate_uc, r"\s*\(THE\)$", "")

joined_df = joined_le.join(
    F.broadcast(codes_norm),
    (country_candidate_uc == F.col("cc.az_match"))     |
    (country_candidate_uc == F.col("cc.citrix_match")) |
    (country_candidate_uc == F.col("cc.gp_match"))     |
    (country_candidate_uc == F.col("cc.name_match")),
    "left"
)

# ========= Derivations =========
country_final = F.coalesce(F.col("cc.CountryFull"), F.col("l.country_raw"))
city_u    = unknown_if_blank(F.col("l.city"))
state_u   = unknown_if_blank(F.col("l.state"))
country_u = unknown_if_blank(country_final)
location_col = F.concat_ws(", ", city_u, state_u, country_u)

# US detection (multiple synonyms)
is_us = (
    (F.upper(F.col("cc.Azure")) == "US") |
    (F.upper(F.col("cc.Citrix")).isin("US","USA")) |
    (F.upper(F.col("cc.GlobalProtect")).isin("US","USA")) |
    (F.upper(F.col("cc.CountryFull")).isin(
        "UNITED STATES", "UNITED STATES OF AMERICA", "UNITED STATES OF AMERICA (THE)")
    ) |
    (country_candidate_uc.isin("US","USA","U.S.","UNITED STATES","UNITED STATES OF AMERICA","UNITED STATES OF AMERICA (THE)"))
)
is_unknown_country = F.col("l.country_raw").isNull() | (F.length(F.trim(F.col("l.country_raw"))) == 0)
login_outside_us = F.when(is_unknown_country | is_us, F.lit(False)).otherwise(F.lit(True))

user_name = F.trim(F.concat_ws(" ", F.col("e.givenName"), F.col("e.surname")))

# ========= Final Silver select =========
silver_df = joined_df.select(
    F.col("l.timestamp_raw").alias("timestamp"),
    F.col("l.success").alias("success"),
    F.col("l.who").cast("string").alias("who"),
    F.col("l.who").cast("string").alias("User"),
    F.col("l.ipAddress").alias("ipAddress"),

    city_u.alias("city"),
    state_u.alias("state"),
    country_u.alias("country"),
    location_col.alias("location"),

    login_outside_us.alias("LoginOutsideUS"),
    F.lit(None).cast("string").alias("deviceClass"),
    F.lit(None).cast("string").alias("deviceOS"),
    F.col("l.deviceDisplayName").alias("deviceDisplayName"),  # <-- now populated from Bronze
    F.lit(None).cast("string").alias("dirOSVersion"),

    F.col("e.department").cast("string").alias("department"),
    F.coalesce(F.col("cc.BlackList"), F.lit(False)).alias("BlackList"),
    F.coalesce(F.col("cc.GreyList"),  F.lit(False)).alias("GreyList"),
    F.coalesce(F.col("cc.WhiteList"), F.lit(False)).alias("WhiteList"),
    F.col("l.Source").alias("Source"),
    user_name.alias("UserName"),
)

# ========= Write to Silver =========
target_path = tbl_path(curated_lh_id, silver_rel)
(silver_df.write
    .format("delta")
    .mode("overwrite")            # consider append + dedupe for prod
    .option("overwriteSchema", "true")
    .save(target_path)
)
print(f"Wrote {silver_rel} to {target_path}")



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
