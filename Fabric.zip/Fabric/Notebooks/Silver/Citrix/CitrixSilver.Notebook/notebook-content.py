# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def unknown_if_blank(expr: F.Column) -> F.Column:
    return F.when(expr.isNull() | (F.length(F.trim(expr)) == 0), F.lit("Unknown")) \
            .otherwise(F.trim(expr))

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))
    


# ---------- inputs ----------
source_rel = "Bronze/Netscaler"
silver_rel = "Silver/UserNetworkAccessDataCitrix"
entra_rel  = "Bronze/EntraUsers"
codes_rel  = "Bronze/CountryCodes"

# ---------- helpers ----------
def tbl_path(base, rel): return f"{base}/Tables/{rel}"
def read_delta(base, rel): return spark.read.format("delta").load(tbl_path(base, rel))

# ---------- read sources ----------
src_df   = read_delta(bronze_lh_id, source_rel)
entra_df = (
    read_delta(bronze_lh_id, entra_rel)
    .select(
        F.col("userPrincipalName").cast("string").alias("userPrincipalName"),
        F.col("department").cast("string").alias("department"),
        F.col("givenName").cast("string").alias("givenName"),
        F.col("surname").cast("string").alias("surname"),
    )
    .where(F.col("userPrincipalName").isNotNull())
)


codes_df = read_delta(bronze_lh_id, "Bronze/CountryCodes").select(
    F.col("Country").alias("CountryFull"),
    "Azure","Citrix","GlobalProtect","BlackList","GreyList","WhiteList"
)

# ---------- normalize source ----------
# Clean 'user': drop "EDIT " / "EDT " prefixes and take last token if prefixed.
clean_user = F.regexp_replace(F.col("user"), r'^(?i)(edit|edt)\s+', '')
who_token = F.lower(
    F.when(F.instr(clean_user, ' ') > 0, F.element_at(F.split(F.trim(clean_user), r'\s+'), -1))
     .otherwise(F.trim(clean_user))
)

# robust timestamp parsing
ts_z  = F.to_timestamp(F.col("when"), "yyyy-MM-dd HH:mm:ss z")   # handles "EDT", "PDT", etc.
ts_x3 = F.to_timestamp(F.col("when"), "yyyy-MM-dd HH:mm:ss XXX") # +05:00
ts_x2 = F.to_timestamp(F.col("when"), "yyyy-MM-dd HH:mm:ss xx")  # +0500
ts_na = F.to_timestamp(F.col("when"), "yyyy-MM-dd HH:mm:ss")     # no tz

timestamp_raw = F.coalesce(ts_z, ts_x3, ts_x2, ts_na)

src_norm = (
    src_df
    .withColumn("timestamp_raw", timestamp_raw)
    .withColumn("action_lc", F.lower(F.col("action")))
    .withColumn("success", F.when(F.col("action_lc") == "success", F.lit(True)).otherwise(F.lit(False)))
    .withColumn("who_token", who_token)
    .withColumn("who", F.col("who_token"))
    .withColumn("city", F.col("City").cast("string"))
    .withColumn("state", F.col("Region").cast("string"))
    .withColumn("country_raw", F.col("Country").cast("string"))
    .withColumn("ipAddress", F.col("src").cast("string"))
    .withColumn("Source", F.lit("Netscaler"))
    .alias("l")
)

# ---------- normalize Entra ----------
entra_norm = (
    entra_df
    .withColumn("upn_norm",  F.lower(F.trim(F.col("userPrincipalName"))))
    .withColumn("upn_local", F.lower(F.substring_index(F.col("userPrincipalName"), "@", 1)))
    .dropDuplicates(["upn_norm"])
    .alias("e")
)

# ---------- normalize CountryCodes (support all vendor code columns) ----------
codes_norm = (
    codes_df
    .withColumn("name_match",  F.upper(F.trim(F.col("CountryFull"))))
    .withColumn("az_match",    F.upper(F.trim(F.col("Azure"))))
    .withColumn("citrix_match",F.upper(F.trim(F.coalesce(F.col("Citrix"), F.col("CountryFull")))))
    .withColumn("gp_match",    F.upper(F.trim(F.coalesce(F.col("GlobalProtect"), F.col("CountryFull")))))
    # mild name cleanup: drop trailing " (THE)"
    .withColumn("name_match", F.regexp_replace(F.col("name_match"), r"\s*\(THE\)$", ""))
    .alias("cc")
)

# ---------- JOIN: user local-part ----------
joined_le = src_norm.join(
    entra_norm,
    F.col("l.who_token") == F.col("e.upn_local"),
    how="left"
)

# ---------- Country mapping: accept Azure OR full name OR Citrix OR GlobalProtect ----------
country_candidate_uc = F.upper(F.trim(F.col("l.country_raw")))
country_candidate_uc = F.regexp_replace(country_candidate_uc, r"\s*\(THE\)$", "")

joined_df = joined_le.join(
    F.broadcast(codes_norm),
    (country_candidate_uc == F.col("cc.az_match"))     |
    (country_candidate_uc == F.col("cc.citrix_match")) |
    (country_candidate_uc == F.col("cc.gp_match"))     |
    (country_candidate_uc == F.col("cc.name_match")),
    "left"
)

# Prefer table's full name, else raw source value
country_final = F.coalesce(F.col("cc.CountryFull"), F.col("l.country_raw"))
city_u    = unknown_if_blank(F.col("l.city"))
state_u   = unknown_if_blank(F.col("l.state"))
country_u = unknown_if_blank(country_final)

location_col = F.concat_ws(", ", city_u, state_u, country_u)

# US detection (synonyms + any matched code)
is_us = (
    (F.upper(F.col("cc.Azure")) == "US") |
    (F.upper(F.col("cc.Citrix")).isin("US","USA")) |
    (F.upper(F.col("cc.GlobalProtect")).isin("US","USA")) |
    (F.upper(F.col("cc.CountryFull")).isin("UNITED STATES", "UNITED STATES OF AMERICA", "UNITED STATES OF AMERICA (THE)")) |
    (country_candidate_uc.isin("US","USA","U.S.","UNITED STATES","UNITED STATES OF AMERICA","UNITED STATES OF AMERICA (THE)"))
)

# Unknown countries should NOT flag outside-US (match your Azure logic)
is_unknown = F.col("l.country_raw").isNull() | (F.length(F.trim(F.col("l.country_raw"))) == 0)

login_outside_us = F.when(is_unknown | is_us, F.lit(False)).otherwise(F.lit(True))

# sanitize fields
city_u    = unknown_if_blank(F.col("l.city"))
state_u   = unknown_if_blank(F.col("l.state"))
country_u = unknown_if_blank(country_final)

# build location from sanitized values
location_col = F.concat_ws(", ", city_u, state_u, country_u)


# ---------- Derivations ----------
user_name = F.trim(F.concat_ws(" ", F.col("e.givenName"), F.col("e.surname")))
who_lc = F.lower(F.col("l.who"))
user_only = F.when(
    who_lc.rlike(r'@(?:[a-z0-9-]+\.)?hmc\.harvard\.edu$'),
    F.substring_index(F.col("l.who"), "@", 1)
).otherwise(F.lit(None).cast("string"))

# ---------- Select (schema-compatible) ----------
silver_df = (
    joined_df.select(
        F.col("l.timestamp_raw").alias("timestamp"),
        F.col("l.success").alias("success"),
        F.col("l.who").cast("string").alias("who"),
        F.col("l.who").cast("string").alias("User"), 
        F.col("l.ipAddress").alias("ipAddress"),

        city_u.alias("city"),
        state_u.alias("state"),
        country_u.alias("country"),
        location_col.alias("location"),

        login_outside_us.alias("LoginOutsideUS"),
        F.lit(None).cast("string").alias("deviceClass"),
        F.lit(None).cast("string").alias("deviceOS"),
        F.lit(None).cast("string").alias("deviceDisplayName"),
        F.lit(None).cast("string").alias("dirOSVersion"),
        F.col("e.department").cast("string").alias("department"),
        F.coalesce(F.col("cc.BlackList"), F.lit(False)).alias("BlackList"),
        F.coalesce(F.col("cc.GreyList"),  F.lit(False)).alias("GreyList"),
        F.coalesce(F.col("cc.WhiteList"), F.lit(False)).alias("WhiteList"),
        F.col("l.Source").alias("Source"),
        user_name.alias("UserName"),
    )
)



# ---------- Write ----------
target_path = tbl_path(curated_lh_id, silver_rel)
(silver_df.write
    .format("delta")
    .mode("overwrite")    # switch to append + dedupe for incremental loads
    .option("overwriteSchema", "true")
    .save(target_path)
)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
