# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timezone
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import col, lit, when, expr, concat_ws, current_timestamp, lower
from datetime import datetime, date
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from typing import Optional, List, Dict, Any, Union
from pyspark.sql.functions import broadcast
import json
from delta.tables import DeltaTable
from pyspark.sql.types import DecimalType

spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "{\"JobAuditKey\":1997,\"TaskKey\":49,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":null,\"SinkTableName\":\"IndexRegionCountryExposure\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"2\",\"NotebookName\":\"Factset_IndexRegionCountryExposure_Silver\",\"SinkLakehouseName\":\"lh_curated\",\"RawStoragePath\":null,\"RawStorageFileName\":null,\"RelativeUrl\":null}"
NotebookName = "Factset_IndexRegionCountryExposure_Silver"
LakehouseName = "lh_curated"
RawLHId = "920a12cc-7104-4013-a2a3-d7baa57e9e3f"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ''
BronzeLHId = ''
CuratedLHId = ''
TaskList = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.IndexSectorIndustryExposure (
# MAGIC     IndexId VARCHAR(36) NOT NULL,
# MAGIC     Sector STRING NOT NULL,
# MAGIC     Industry STRING NOT NULL,
# MAGIC     Exposure DECIMAL(38,15) NOT NULL,
# MAGIC     AsOfDate DATE,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tasklist = json.loads(f"{TaskList}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import current_timestamp

def generate_index_sector_industry_exposure(
    bronze_lh_id: str,
    silver_lh_id: str,
    indexid_filter: str = None
) -> None:
    output_path = f"{silver_lh_id}/Tables/Silver/IndexSectorIndustryExposure"
    error_path = f"{silver_lh_id}/Tables/Silver/IndexSectorIndustryExposure_Error"
    as_of_date = date.today() 

    #load source tables
    src_ref_index = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/HMCDataWarehousevwSourceReferenceIndex")
    src_ref_flatten = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/HMCDataWarehousevwSourceReferenceFlatten_CrimsonX")\
        .filter(
            (F.col("HMCObjectSourceSystem") == "FACTSET") &
            (F.col("HMCObjectStatus") == "Active")
        )
    factset = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/Factset")
    sector_industry_class = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXSectorIndustryClassification")
    sector = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXSector")
    industry = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXSectorIndustry")

    #prepare factset
    factset = factset.select(
        "BENCHMARK_ID",
        "CONST_WEIGHT",
        "DATE",
        F.trim(F.col("FACTSET_SECTOR_CODE").cast("string")).alias("SECTOR_CODE"),
        F.trim(F.col("FACTSET_INDUSTRY_CODE").cast("string")).alias("INDUSTRY_CODE")
    )

    #join with sector/industry classifications
    factset_with_class = (
        factset.alias("fc")
        .join(sector_industry_class.alias("sic"),
              (F.col("fc.SECTOR_CODE") == F.col("sic.SectorCode")) &
              (F.col("fc.INDUSTRY_CODE") == F.col("sic.IndustryCode")),
              how="left")
        .join(sector.alias("s"), F.col("sic.SectorCode") == F.col("s.SectorCode"), how="left")
        .join(industry.alias("i"), F.col("sic.IndustryCode") == F.col("i.IndustryCode"), how="left")
        .select(
            "fc.BENCHMARK_ID",
            "fc.CONST_WEIGHT",
            "fc.DATE",
            "sic.SectorIndustryClassificationId",
            "s.SectorDescription",
            "i.IndustryDescription"
        )
    )

    #join with index reference
    factset_with_indexid = (
        factset_with_class.alias("f")
        .join(src_ref_index.alias("vri"), F.col("f.BENCHMARK_ID") == F.col("vri.IndexIdFactset"), how="inner")
        .join(src_ref_flatten.alias("vrfc"), F.col("vri.IndexId") == F.col("vrfc.HMCObjectMasterId"))
        .select(
            F.col("vrfc.HMCObjectIdCrimsonX").alias("IndexId"),
            F.col("f.SectorDescription"),
            F.col("f.IndustryDescription"),
            F.col("f.CONST_WEIGHT"),
            F.col("f.DATE")
        )
        .filter(
            F.col("SectorDescription").isNotNull() &
            F.col("IndustryDescription").isNotNull() &
            F.col("CONST_WEIGHT").isNotNull()
        )
    )

    #find latest DATE per IndexId + Sector + Industry
    latest_date_df = (
        factset_with_indexid
        .groupBy("IndexId", "SectorDescription", "IndustryDescription")
        .agg(F.max("DATE").alias("LatestDate"))
    )

    #join back to keep only rows with latest DATE
    factset_latest = (
        factset_with_indexid.alias("f")
        .join(
            latest_date_df.alias("ld"),
            (F.col("f.IndexId") == F.col("ld.IndexId")) &
            (F.col("f.SectorDescription") == F.col("ld.SectorDescription")) &
            (F.col("f.IndustryDescription") == F.col("ld.IndustryDescription")) &
            (F.col("f.DATE") == F.col("ld.LatestDate")),
            how="inner"
        )
        .drop("LatestDate")
    )

    #aggregate Exposure
    exposure_df = (
        factset_latest
        .groupBy("f.IndexId", "f.SectorDescription", "f.IndustryDescription")
        .agg(F.sum("CONST_WEIGHT").alias("Exposure"))
        .withColumnRenamed("SectorDescription", "Sector")
        .withColumnRenamed("IndustryDescription", "Industry")
        .select(
            F.lower(F.col("IndexId")).alias("IndexId"),
            F.col("Sector"),
            F.col("Industry"),
            F.coalesce(F.col("Exposure"), F.lit(0).cast(DecimalType(38, 15))).alias("Exposure"),
            F.to_timestamp(F.lit(etlloadtime), "yyyy-MM-dd'T'HH:mm:ss'Z'").alias("ETLLoadDateTime"),
            F.lit(as_of_date).cast("date").alias("AsOfDate")
        )
    )

    if indexid_filter:
        exposure_df = exposure_df.filter(F.col("IndexId") == indexid_filter)

    if not DeltaTable.isDeltaTable(spark, output_path):
        exposure_df.write.format("delta").mode("append").save(output_path)
    else:
        target = DeltaTable.forPath(spark, output_path)
        (
            target.alias("t")
            .merge(
                exposure_df.alias("s"),
                """
                t.IndexId = s.IndexId AND
                t.Sector = s.Sector AND
                t.Industry = s.Industry AND
                t.AsOfDate = s.AsOfDate
                """
            )
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute()
        )

    #generate error table for unmatched benchmark IDs
    factset_raw = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/Factset")
    error_df = (
        src_ref_index.alias("vri")
        .join(src_ref_flatten.alias("vrfc"), F.col("vri.IndexId") == F.col("vrfc.HMCObjectMasterId"))
        .filter(F.col("vri.IndexIdFactset").isNotNull())
        .join(factset_raw, F.col("vri.IndexIdFactset") == factset_raw["BENCHMARK_ID"], how="left_anti")
        .selectExpr(
            "vrfc.HMCObjectIdCrimsonX as IndexId",
            "vri.IndexIdFactset as FactsetId",
            "current_timestamp() as DateTime",
            "'Factset BENCHMARK_ID not found for IndexIdFactset' as Error"
        )
    )

    print(f"Error output count: {error_df.count()}")
    error_df.write.format("delta").mode("overwrite").save(error_path)
    print(f"Error log written to: {error_path}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    print(task_item['TaskKey'])
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)

        # Process the task
        result = generate_index_sector_industry_exposure(bronze_lh_basepath,curated_lh_basepath)

    except Exception as e:
        print(f"Error processing task: {e}")
        raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
