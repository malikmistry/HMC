# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timezone
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import col, lit, when, expr, concat_ws, current_timestamp, lower
from datetime import datetime, date
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from typing import Optional, List, Dict, Any, Union
from pyspark.sql.functions import broadcast
from collections import defaultdict
import json
from notebookutils import mssparkutils
from functools import reduce
from delta.tables import DeltaTable
from pyspark.sql.types import DecimalType


spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "{\"JobAuditKey\":1997,\"TaskKey\":49,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":null,\"SinkTableName\":\"IndexRegionCountryExposure\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"2\",\"NotebookName\":\"Factset_IndexRegionCountryExposure_Silver\",\"SinkLakehouseName\":\"lh_curated\",\"RawStoragePath\":null,\"RawStorageFileName\":null,\"RelativeUrl\":null}"
NotebookName = "Factset_IndexRegionCountryExposure_Silver"
LakehouseName = "lh_curated"
RawLHId = "920a12cc-7104-4013-a2a3-d7baa57e9e3f"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ''
BronzeLHId = ''
CuratedLHId = ''
TaskList = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

if TaskList.strip().startswith("[") and TaskList.strip().endswith("]"):
    tasklist = json.loads(f"{TaskList}")
else:
    tasklist = json.loads(f"[{TaskList}]")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.IndexRegionCountryExposure (
# MAGIC     IndexId VARCHAR(36) NOT NULL,
# MAGIC     GeographicRegion STRING NOT NULL,
# MAGIC     Country STRING NOT NULL,
# MAGIC     Exposure DECIMAL(38,15) NOT NULL,
# MAGIC     AsOfDate DATE NOT NULL,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## IndexRegionCountry

# CELL ********************



def generate_index_country_exposure(
    bronze_lh_id: str,
    silver_lh_id: str,
    etlloadtime: str,
    task,
    indexid_filter: str = None,
) -> None:
    output_path = f"{silver_lh_id}/Tables/{task['SinkSchemaName']}/{task['SinkTableName']}"
    error_path = f"{silver_lh_id}/Tables/Silver/IndexRegionCountryExposure_Error"
    as_of_date = date.today()

    print(f"[INFO] Loading source tables from Bronze layer...")
    src_ref_index = spark.read.format("delta").load(
        f"{bronze_lh_id}/Tables/Bronze/HMCDataWarehousevwSourceReferenceIndex"
    )
    print(f"[INFO] src_ref_index count: {src_ref_index.count()}")

    src_ref_flatten = (
        spark.read.format("delta")
        .load(f"{bronze_lh_id}/Tables/Bronze/HMCDataWarehousevwSourceReferenceFlatten_CrimsonX")
        .filter(
            (F.col("HMCObjectSourceSystem") == "FACTSET")
            & (F.col("HMCObjectStatus") == "Active")
        )
    )
    print(f"[INFO] src_ref_flatten count: {src_ref_flatten.count()}")

    factset = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/Factset")
    country_region = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXCountryRegion")
    geographic_strategy = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXGeographicStrategy")
    country = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXCountry")

    print(f"[INFO] FactSet count: {factset.count()}")
    print(f"[INFO] CountryRegion count: {country_region.count()}")
    print(f"[INFO] GeographicStrategy count: {geographic_strategy.count()}")
    print(f"[INFO] Country count: {country.count()}")

    # -------------------- FactSet exposures --------------------
    factset_with_index = (
        factset.alias("fc")
        .join(src_ref_index.alias("vri"), F.col("fc.BENCHMARK_ID") == F.col("vri.IndexIdFactset"))
        .join(
            src_ref_flatten.alias("vrfc"),
            F.lower(F.col("vri.IndexId")) == F.lower(F.col("vrfc.HMCObjectMasterId")),
        )
        .join(
            country.alias("c"),
            F.coalesce(
                F.when(F.trim(F.col("fc.COUNTRY_INCORP_MSCI")) != "", F.col("fc.COUNTRY_INCORP_MSCI")),
                F.when(F.trim(F.col("fc.COUNTRY_RISK")) != "", F.col("fc.COUNTRY_RISK"))
            ) == F.col("c.ISOCode2")
        )
        .select(
            F.col("vrfc.HMCObjectIdCrimsonX").alias("IndexId"),
            F.col("c.CountryID").alias("CountryID_numeric"),
            F.col("c.CountryName").alias("Country"),
            "fc.DATE",
            F.col("fc.CONST_WEIGHT").cast(DecimalType(36, 15)).alias("CONST_WEIGHT"),
        )
        .dropDuplicates(["IndexId", "CountryID_numeric", "DATE", "CONST_WEIGHT"])
    )
    print(f"[INFO] factset_with_index count: {factset_with_index.count()}")

    
    latest_date_global = (
        factset_with_index.agg(F.max("DATE").alias("LatestDate")).collect()[0]["LatestDate"]
    )
    factset_with_index = (
        factset_with_index.filter(F.col("DATE") == F.lit(latest_date_global))
    )   
    print(f"[INFO] latest_date_global: {latest_date_global}")
    print(f"[INFO] Filter FACTSET wth latest_date_global: {factset_with_index.count()}")

    # Map countries -> regions
    exposure_with_region = (
        factset_with_index.join(
            country_region.alias("cr"), F.col("CountryID_numeric") == F.col("cr.CountryID")
        )
        .join(
            geographic_strategy.alias("gs"),
            F.col("cr.RegionGeographicStrategyId") == F.col("gs.GeographicStrategyId"),
        )
        .select(
            "IndexId",
            "DATE",
            F.col("gs.Description").alias("GeographicRegion"),
            "Country",
            "CONST_WEIGHT",
        )
    )
    print(f"[INFO] exposure_with_region count: {exposure_with_region.count()}")

    # Aggregate exposures
    exposure_agg_by_date = (
        exposure_with_region.groupBy("IndexId", "GeographicRegion", "Country", "DATE")
        .agg(F.sum("CONST_WEIGHT").alias("Exposure"))
    )

    print(f"[INFO] exposure_agg_by_date count: {exposure_agg_by_date.count()}")

    exposure_latest = (
        exposure_agg_by_date
        .withColumn("Exposure", F.col("Exposure").cast(DecimalType(38,15)))
    )
    print(f"Exposure Latest Date Filter: {exposure_latest.count()}")

    # -------------------- Residual Exposure Adjustment --------------------
    combined_exposures = (
        exposure_latest.select(
            F.lower(F.col("IndexId")).alias("IndexId"),
            "GeographicRegion",
            "Country",
            "Exposure",
            F.lit(as_of_date).cast("date").alias("AsOfDate"),
            F.to_timestamp(F.lit(etlloadtime), "yyyy-MM-dd'T'HH:mm:ss'Z'").alias(
                "ETLLoadDateTime"
            ),
        )
    )
    print(f"[INFO] combined_exposures initial count: {combined_exposures.count()}")

    w = Window.partitionBy("IndexId", "AsOfDate")
    combined_exposures = combined_exposures.withColumn("Exposure", F.col("Exposure").cast(DecimalType(38, 30)))
    combined_exposures = combined_exposures.withColumn("TotalExposure", F.sum("Exposure").over(w))
    combined_exposures = combined_exposures.withColumn("Residual", F.when(F.col("TotalExposure") > 99,(F.lit(100).cast(DecimalType(38, 30)) - F.col("TotalExposure"))).otherwise(F.lit(0)))
    w2 = Window.partitionBy("IndexId", "AsOfDate").orderBy(F.col("Exposure").desc())
    combined_exposures = combined_exposures.withColumn("rn", F.row_number().over(w2))
    combined_exposures = combined_exposures.withColumn("Exposure", F.when(F.col("rn") == 1, F.col("Exposure") + F.col("Residual")).otherwise(F.col("Exposure")))
    combined_exposures = combined_exposures.withColumn("Exposure", F.when(F.col("Exposure") >= F.lit(99.9), F.lit(100.0)).otherwise(F.col("Exposure")))
    # combined_exposures = combined_exposures.filter(F.col("Exposure") != 0.0)
    combined_exposures = combined_exposures.drop("TotalExposure", "Residual", "rn")
    combined_exposures = combined_exposures.withColumn("Exposure", F.col("Exposure").cast(DecimalType(38, 15)))
    print(f"[INFO] combined_exposures final count after residual adjustment: {combined_exposures.count()}")

    # -------------------- Write to Silver --------------------
    deleteQuery = f"""
        DELETE FROM Silver.{task['SinkTableName']}
        WHERE AsOfDate = CAST('{as_of_date}' AS DATE)
    """
    spark.sql(deleteQuery)
    print(f"[INFO] Deleted existing Silver rows for AsOfDate={as_of_date}")

    combined_exposures.select(
        "IndexId", "GeographicRegion", "Country", "Exposure", "AsOfDate", "ETLLoadDateTime"
    ).write.format("delta").mode("append").save(output_path)
    print(f"[INFO] Exposure written to: {output_path}")

    # -------------------- Error Handling --------------------
    factset_bench = factset.select(F.col("BENCHMARK_ID")).distinct().alias("f")

    bench_with_vri = factset_bench.join(
        src_ref_index.alias("vri"),
        F.col("f.BENCHMARK_ID") == F.col("vri.IndexIdFactset"),
        how="left",
    )

    bench_with_flatten = bench_with_vri.join(
        src_ref_flatten.alias("vrfc"),
        F.lower(F.trim(F.col("vri.IndexId"))) == F.lower(F.trim(F.col("vrfc.HMCObjectMasterId"))),
        how="left",
    )

    error_df = (
        bench_with_flatten.filter(
            (F.col("vri.IndexIdFactset").isNull())
            | (F.col("vrfc.HMCObjectIdCrimsonX").isNull())
        )
        .selectExpr(
            "CASE WHEN vrfc.HMCObjectIdCrimsonX IS NULL THEN 'MISSING_HMCOBJECTID' ELSE vrfc.HMCObjectIdCrimsonX END as IndexId",
            "f.BENCHMARK_ID as FactsetId",
            "current_timestamp() as DateTime",
            "'Factset BENCHMARK_ID present but missing mapping in src_ref_index/src_ref_flatten' as Error",
        )
    )
    print(f"[DEBUG] error_df count: {error_df.count()}")
    error_df.write.format("delta").mode("overwrite").save(error_path)
    print(f"[INFO] Error written to: {error_path}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    print(task_item['TaskKey'])
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)

        # Process the task
        result = generate_index_country_exposure(bronze_lh_basepath,curated_lh_basepath, etlloadtime, task_item)

    except Exception as e:
        print(f"Error processing task: {e}")
        raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# mssparkutils.notebook.exit("Reached end of notebook.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
