# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timezone
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import col, lit, when, expr, concat_ws, current_timestamp, lower
from datetime import datetime, date
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from typing import Optional, List, Dict, Any, Union
from pyspark.sql.functions import broadcast
import json
from delta.tables import DeltaTable
from pyspark.sql.types import DecimalType

spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
spark.conf.set("spark.sql.precisionThreshold", 38)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "{\"JobAuditKey\":1526,\"TaskKey\":115,\"TaskType\":\"NotebookTask\",\"SinkSchemaName\":\"Silver\",\"SinkTableName\":\"IndexRegionExposure\"}"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ''
BronzeLHId = ''
CuratedLHId = ''
TaskList = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.IndexRegionExposure (
# MAGIC     IndexId VARCHAR(36) NOT NULL,
# MAGIC     GeographicRegion STRING NOT NULL,
# MAGIC     Exposure DECIMAL(38,15) NOT NULL,
# MAGIC     AsOfDate DATE NOT NULL,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tasklist = json.loads(f"[{TaskList}]")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## IndexRegion

# CELL ********************

def generate_index_region_exposure(
    bronze_lh_id: str,
    silver_lh_id: str,
    etlloadtime: str,
    task,
    indexid_filter: str = None,
) -> None:

    output_path = f"{silver_lh_id}/Tables/{task['SinkSchemaName']}/{task['SinkTableName']}"
    error_path = f"{silver_lh_id}/Tables/Silver/IndexRegionExposure_Error"
    as_of_date = date.today()

    # -------------------- Load source tables --------------------
    src_ref_index = spark.read.format("delta").load(
        f"{bronze_lh_id}/Tables/Bronze/HMCDataWarehousevwSourceReferenceIndex"
    )

    src_ref_flatten = (
        spark.read.format("delta")
        .load(f"{bronze_lh_id}/Tables/Bronze/HMCDataWarehousevwSourceReferenceFlatten_CrimsonX")
        .filter(
            (F.col("HMCObjectSourceSystem") == "FACTSET") &
            (F.col("HMCObjectStatus") == "Active")
        )
    )

    factset = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/Factset")
    country_region = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXCountryRegion")
    geographic_strategy = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXGeographicStrategy")
    country = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXCountry")

    # -------------------- FactSet exposures --------------------
    factset_with_index = (
        factset.alias("fc")
        .join(src_ref_index.alias("vri"), F.col("fc.BENCHMARK_ID") == F.col("vri.IndexIdFactset"))
        .join(
            src_ref_flatten.alias("vrfc"),
            F.lower(F.trim(F.col("vri.IndexId"))) == F.lower(F.trim(F.col("vrfc.HMCObjectMasterId")))
        )
        .join(
            country.alias("c"),
            F.coalesce(F.col("fc.COUNTRY_INCORP_MSCI"), F.col("fc.COUNTRY_RISK")) == F.col("c.ISOCode2"),
            how="left"
        )
        .select(
            F.col("vrfc.HMCObjectIdCrimsonX").alias("IndexId"),
            F.col("c.CountryID").alias("CountryID_numeric"),
            "fc.DATE",
            F.col("fc.CONST_WEIGHT").cast(DecimalType(36, 15)).alias("CONST_WEIGHT")
        )
        .dropDuplicates(["IndexId", "CountryID_numeric", "DATE", "CONST_WEIGHT"])
    )

    # Map countries -> regions
    exposure_with_region = (
        factset_with_index
        .join(country_region.alias("cr"), F.col("CountryID_numeric") == F.col("cr.CountryID"))
        .join(
            geographic_strategy.alias("gs"),
            F.col("cr.RegionGeographicStrategyId") == F.col("gs.GeographicStrategyId")
        )
        .select(
            "IndexId",
            "DATE",
            F.col("gs.Description").alias("GeographicRegion"),
            "CONST_WEIGHT"
        )
    )

    # Aggregate exposures per Index x Region x Date
    exposure_agg_by_date = (
        exposure_with_region.groupBy("IndexId", "GeographicRegion", "DATE")
        .agg(F.sum("CONST_WEIGHT").alias("Exposure"))
    )

    latest_date_global = (
        factset_with_index.agg(F.max("DATE").alias("LatestDate")).collect()[0]["LatestDate"]
    )

    # -------------------- Full Index x Region combos --------------------
    all_regions = geographic_strategy.select("Description").distinct()
    all_indexes = src_ref_flatten.select("HMCObjectIdCrimsonX").distinct()

    exposure_with_all_combos = (
        all_indexes.alias("vrfc")
        .crossJoin(all_regions.alias("gs"))
        .join(
            exposure_agg_by_date.alias("agg"),
            (F.col("vrfc.HMCObjectIdCrimsonX") == F.col("agg.IndexId")) &
            (F.col("gs.Description") == F.col("agg.GeographicRegion")),
            how="left"
        )
        .withColumn("DATE", F.coalesce(F.col("agg.DATE"), F.lit(latest_date_global)))
        .select(
            F.col("vrfc.HMCObjectIdCrimsonX").alias("IndexId"),
            F.col("gs.Description").alias("GeographicRegion"),
            "DATE",
            F.coalesce(F.col("agg.Exposure"), F.lit(0).cast(DecimalType(38, 15))).alias("Exposure")
        )
    )

    final_factset_df = (
        exposure_with_all_combos.select(
            F.lower(F.col("IndexId")).alias("IndexId"),
            "GeographicRegion",
            "Exposure",
            F.to_timestamp(F.lit(etlloadtime), "yyyy-MM-dd'T'HH:mm:ss'Z'").alias("ETLLoadDateTime"),
            F.lit(as_of_date).cast("date").alias("AsOfDate"),
            F.lit("FactSet").alias("Source")
        )
    )

    # -------------------- Manual exposures --------------------
    index_geography = spark.read.format("delta").load(
        f"{bronze_lh_id}/Tables/Bronze/HMCDataWarehouseIndexGeography"
    )

    manual_exposures = (
        index_geography.alias("ig")
        .join(
            src_ref_flatten.alias("vrfc"),
            F.lower(F.trim(F.col("ig.IndexId"))) == F.lower(F.trim(F.col("vrfc.HMCObjectMasterId")))
        )
        .join(
            geographic_strategy.alias("gs"),
            F.col("ig.GeographicStrategyId") == F.col("gs.GeographicStrategyId")
        )
        .select(
            F.lower(F.col("vrfc.HMCObjectIdCrimsonX")).alias("IndexId"),
            F.col("gs.Description").alias("GeographicRegion"),
            F.when(F.col("ig.ExposurePct").isNotNull(), F.col("ig.ExposurePct"))
            .otherwise(F.lit(0).cast(DecimalType(38, 15))).alias("Exposure"),
            F.lit(as_of_date).cast("date").alias("AsOfDate"),
            F.to_timestamp(F.lit(etlloadtime), "yyyy-MM-dd'T'HH:mm:ss'Z'").alias("ETLLoadDateTime"),
            F.lit("Manual").alias("Source")
        )
        .dropDuplicates(["IndexId", "AsOfDate", "GeographicRegion"])
    )

    # -------------------- Only fill Manual for missing/0 FactSet --------------------
    factset_totals = (
        final_factset_df.groupBy("IndexId", "AsOfDate")
        .agg(F.sum("Exposure").alias("TotalFactSetExposure"))
    )

    # Indexes with total FactSet exposure = 0
    manual_needed_indexids = factset_totals.filter(F.col("TotalFactSetExposure") == 0)\
        .select("IndexId", "AsOfDate")

    # Indexes not present in FactSet
    factset_indexids = final_factset_df.select("IndexId").distinct()
    missing_indexids = manual_exposures.select("IndexId", "AsOfDate")\
        .join(factset_indexids, "IndexId", "left_anti")

    manual_needed_indexids = manual_needed_indexids.unionByName(missing_indexids).distinct()
    manual_fallback = manual_exposures.join(manual_needed_indexids, ["IndexId", "AsOfDate"], "inner")

    # -------------------- Combine exposures --------------------
    combined_exposures = final_factset_df.unionByName(manual_fallback)

    # -------------------- Residual Exposure --------------------
    # Compute total exposure per IndexId + AsOfDate as Decimal(38,15)
    w = Window.partitionBy("IndexId", "AsOfDate")
    combined_exposures = combined_exposures.withColumn(
        "Exposure",
        F.col("Exposure").cast(DecimalType(38, 30))
    )
    combined_exposures = combined_exposures.withColumn(
        "TotalExposure",
        F.sum("Exposure").over(w)
    )

    combined_exposures.filter(F.col("TotalExposure") > F.lit(100).cast(DecimalType(38, 15))) \
                  .select("IndexId", "AsOfDate", "TotalExposure") \
                  .show(truncate=False)

    # Compute residual
    combined_exposures = combined_exposures.withColumn(
        "Residual",
        (lit(100).cast(DecimalType(38, 30)) - col("TotalExposure").cast(DecimalType(38,30)))
    )
    combined_exposures.select(
        "IndexId",
        "AsOfDate","Exposure","Residual"
    ).show(truncate=False)

    # Rank exposures per group to assign residual to largest exposure
    w2 = Window.partitionBy("IndexId", "AsOfDate").orderBy(F.col("Exposure").desc())
    combined_exposures = combined_exposures.withColumn("rn", F.row_number().over(w2))

    # Add residual to largest exposure
    combined_exposures = combined_exposures.withColumn(
        "Exposure",
        F.when(F.col("rn") == 1, (col("Exposure") + col("Residual")).cast(DecimalType(38,30)))
        .otherwise(col("Exposure"))
    )
    combined_exposures = combined_exposures.withColumn("Exposure", F.col("Exposure").cast(DecimalType(38, 15)))
    combined_exposures = combined_exposures.dropDuplicates(
        ["IndexId", "GeographicRegion", "AsOfDate"]
    )

    # Round exposures one final time to 15 decimals
    combined_exposures = combined_exposures.drop("TotalExposure", "Residual", "rn", "Source")

    # -------------------- Write to Silver --------------------
    deleteQuery = f"""
        DELETE FROM Silver.{task['SinkTableName']}
        WHERE AsOfDate = CAST('{as_of_date}' AS DATE)
    """
    spark.sql(deleteQuery)
    combined_exposures = combined_exposures.select("IndexId", "GeographicRegion", "Exposure", "AsOfDate", "ETLLoadDateTime")
    combined_exposures.write.format("delta").mode("append").save(output_path)
    
    print(f"[INFO] Exposure written to: {output_path}")

    # ------------------------------------------------------------------------
    # Error handling (FactSet BENCHMARK_IDs missing)
    error_df = (
        src_ref_index.alias("vri")
        .join(
            src_ref_flatten.alias("vrfc"),
            F.lower(F.trim(F.col("vri.IndexId"))) == F.lower(F.trim(F.col("vrfc.HMCObjectMasterId"))),
        )
        .filter(F.col("vri.IndexIdFactset").isNotNull())
        .join(factset, F.col("vri.IndexIdFactset") == factset["BENCHMARK_ID"], how="left_anti")
        .selectExpr(
            "vrfc.HMCObjectIdCrimsonX as IndexId",
            "vri.IndexIdFactset as FactsetId",
            "current_timestamp() as DateTime",
            "'Factset BENCHMARK_ID not found for IndexIdFactset' as Error",
        )
    )

    print(f"[DEBUG] error_df count: {error_df.count()}")
    error_df.write.format("delta").mode("overwrite").save(error_path)
    print(f"Error written to: {error_path}")



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)

        # Process the task
        result = generate_index_region_exposure(bronze_lh_basepath,curated_lh_basepath, etlloadtime, task_item)

    except Exception as e:
        print(f"Error processing task: {e}")
        raise

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
