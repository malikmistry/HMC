# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import json
from delta.tables import DeltaTable
from datetime import datetime, timezone
from pyspark.sql.functions import lit, col, explode, lower
from pyspark.sql.utils import AnalysisException
from pyspark.sql import SparkSession
from collections import defaultdict
from pyspark.sql import functions as F
from notebookutils import mssparkutils
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "{\"JobAuditKey\":746,\"TaskKey\":91,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"Note\",\"SinkTableName\":\"Note\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"8\",\"NotebookName\":\"NotesSilver\",\"SinkLakehouseName\":\"lh_curated\"}"
NotebookName = "NotesSilver"
LakehouseName = "lh_curated"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""
NotebookName = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

if TaskList.strip().startswith("[") and TaskList.strip().endswith("]"):
    tasklist = json.loads(f"{TaskList}")
else:
    tasklist = json.loads(f"[{TaskList}]")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Set watermark
etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
print(etlloadtime) 

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#For etl source - source is proworkspace/Notes/MetaData/{date.today():%Y%m}
#The naming above will always read from file dated today, if you need to rerun, update the etl entry then run
#After the rerun, revert to {date.today():%Y%m}
#old logic it goes to bronze as a parquet, we are loading it as delta table using the MDF Framework

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import re
def sanitize_column_names_with_mapping(df):
    rename_map = {}
    for col in df.columns:
        sanitized = col.replace("%", "Percentage")
        sanitized = re.sub(r"[^a-zA-Z0-9_]", "_", sanitized)
        sanitized = re.sub(r"_+", "_", sanitized).strip("_")
        
        if sanitized != col:
            df = df.withColumnRenamed(col, sanitized)
            rename_map[sanitized] = col  # store reverse mapping for restoring, not used in this code but for future development

    if rename_map:
        print(f"[i] Column rename mapping: {rename_map}")
    return df


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import lit
from pyspark.sql.utils import AnalysisException

def merge_operation(task, df_source, sinktablename, primary_column, hwm_column):
    try:
        target_path = f"{curated_lh_basepath}/Tables/Silver/{sinktablename}"

        # Determine primary keys
        if not primary_column or str(primary_column).strip().upper() == "NULL":
            primary_keys = [col for col in df_source.columns if col != hwm_column]
        else:
            primary_keys = [col.strip() for col in primary_column.split(",")]

        # Deduplicate by PK
        df_source = df_source.dropDuplicates(primary_keys)

        # Sanitize column names
        df_source = sanitize_column_names_with_mapping(df_source)

        # Drop ETLLoadDateTime if already present (we’ll re-add below)
        if "ETLLoadDateTime" in df_source.columns:
            df_source = df_source.drop("ETLLoadDateTime")

        # Check for empty DF
        if df_source.rdd.isEmpty():
            print(f"[{sinktablename}] Source dataframe is empty. Skipping merge.")
            return

        # Try load target
        try:
            df_target = spark.read.format("delta").load(target_path)
            target_exists = True
            print(f"[{sinktablename}] Target table exists. Count = {df_target.count()}")
        except AnalysisException:
            target_exists = False
            print(f"[{sinktablename}] Target does not exist. Will create new table.")

        # Add ETLLoadDateTime
        df_source = df_source.withColumn(hwm_column, lit(etlloadtime))

        if not target_exists:
            df_source.write.format("delta").mode("append").save(target_path)
            print(f"[{sinktablename}] Successfully created target with append.")
            return

        # Register temp view
        df_source.createOrReplaceTempView("df_source_view")

        # Columns for merge
        columns = df_source.columns
        change_condition = " OR ".join([
            f"target.{col} IS DISTINCT FROM source.{col}"
            for col in columns if col not in primary_keys and col != hwm_column
        ])

        # Build merge SQL
        merge_query = f"""
            MERGE INTO Silver.{sinktablename} AS target
            USING (
                SELECT * FROM (
                    SELECT *, ROW_NUMBER() OVER (
                        PARTITION BY {', '.join(primary_keys)}
                        ORDER BY rand()
                    ) AS rn
                    FROM df_source_view
                ) AS subquery
                WHERE rn = 1
            ) AS source
            ON ({' AND '.join([f"target.{col} = source.{col}" for col in primary_keys])})
        """

        if change_condition:
            merge_query += f"""
                WHEN MATCHED AND ({change_condition}) THEN
                    UPDATE SET {', '.join([f'target.{col} = source.{col}' for col in columns if col != hwm_column])},
                               target.{hwm_column} = '{etlloadtime}'
            """

        insert_columns = columns + ([hwm_column] if hwm_column not in columns else [])
        insert_values = [f"source.{col}" for col in columns] + ([f"'{etlloadtime}'"] if hwm_column not in columns else [])

        merge_query += f"""
            WHEN NOT MATCHED THEN
                INSERT ({', '.join(insert_columns)})
                VALUES ({', '.join(insert_values)});
        """


        # Execute merge
        spark.sql(merge_query)

        # Force execution to catch errors
        post_count = spark.sql(f"SELECT COUNT(*) as cnt FROM Silver.{sinktablename}").collect()[0]["cnt"]
        print(f"[{sinktablename}] Merge completed. Row count after merge: {post_count}")

    except Exception as e:
        print(f"[{sinktablename}] Merge FAILED: {e}")
        raise RuntimeError(f"Task {task['TaskKey']} failed during merge of {sinktablename}: {str(e)}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql.functions import explode, col, lower

def process_task(task):
    try:
        source_path = f"{bronze_lh_basepath}/Tables/{task['SourceSchemaName']}/{task['SourceTableName']}"
        target_path = f"{curated_lh_basepath}/Tables/{task['SinkSchemaName']}"
        hwm_column = 'ETLLoadDateTime'

        # Try to read source
        try:
            df_source = spark.read.format("delta").load(source_path)
            print(f"Source loaded OK: {source_path}")
            print(f"df_source count: {df_source.count()}")
        except Exception as e:
            raise RuntimeError(f"Source path does not exist or failed to load: {source_path}") from e
        
        # Notes
        df_source_note = (
            df_source
            .withColumn("NoteId", F.substring(F.col("noteId").cast("string"), 1, 36))
            .withColumn("AsOfDate", F.col("asOfDate").cast("date"))
            .withColumn("Content", F.col("content"))
            .withColumn("CreateTime", F.col("createTime").cast("timestamp"))
            .withColumn("CreatedBy", F.col("createdBy"))
            .withColumn("ModifiedBy", F.col("modifiedBy"))
            .withColumn("ModifyTime", F.col("modifyTime").cast("timestamp"))
            .withColumn("Subject", F.col("subject"))
            .withColumn("Summary", F.col("summary"))
            .withColumn("NoteType", F.col("typeCode"))
            .withColumn("NoteTypeId", F.col("typeId"))
            .withColumn("NotePath", F.col("path"))
            .drop(
                "attachments", "links",
                "noteId", "asOfDate", "content", "createTime", "createdBy",
                "modifiedBy", "modifyTime", "subject", "summary", "typeCode", "typeId", "path"
            )
            .filter(
                F.col("AsOfDate").isNotNull() &
                F.col("NoteId").isNotNull() &
                F.col("NoteTypeId").isNotNull()
            )
        )
        print(f"df_source_note count: {df_source_note.count()}")

        merge_operation(task, df_source_note, 'Note', "NoteId", hwm_column)


        # Attachments
        df_source_attachment = (
            df_source
            .select(F.explode("attachments").alias("attachment"))
            .select(
                F.substring(F.col("attachment.attachmentId").cast("string"), 1, 36).alias("AttachmentId"),
                F.substring(F.col("attachment.noteId").cast("string"), 1, 36).alias("NoteId"),
                F.col("attachment.fileName").alias("FileName"),
                F.col("attachment.fileUrl").alias("FileUrl"),
                F.col("attachment.fileSize").alias("FileSize")
            )
            .drop("attachment")  # drop nested struct
            .filter(
                F.col("AttachmentId").isNotNull() &
                F.col("NoteId").isNotNull() &
                F.col("FileName").isNotNull() &
                F.col("FileUrl").isNotNull() &
                F.col("FileSize").isNotNull()
            )
        )
        print(f"df_source_attachment count: {df_source_attachment.count()}")
        merge_operation(task, df_source_attachment, 'NoteAttachment', "NoteId,AttachmentId", hwm_column)


        # Links
        df_source_links = (
            df_source
            .select(col("noteId"), explode("links").alias("linkId"))
            .withColumn("NoteId", F.substring(F.col("noteId").cast("string"), 1, 36))
            .withColumn("LinkId", F.substring(F.col("linkId").cast("string"), 1, 36))
            .drop("noteId", "linkId")  # drop raw fields
            .filter(
                F.col("LinkId").isNotNull() &
                F.col("NoteId").isNotNull()
            )
        )
        print(f"df_source_links count: {df_source_links.count()}")
        merge_operation(task, df_source_links, 'NoteLink', "NoteId,LinkId", hwm_column)


        # Load merged targets back
        df_note = spark.read.format("delta").load(f"{target_path}/Note")  
        print(f"df_note count: {df_note.count()}")

        df_note_attachment = spark.read.format("delta").load(f"{target_path}/NoteAttachment")
        print(f"df_note_attachment count: {df_note_attachment.count()}")

        df_note_link = spark.read.format("delta").load(f"{target_path}/NoteLink")
        print(f"df_note_link count: {df_note_link.count()}")
        
        # Attachments join with Note
        df_attachments = (
            df_note_attachment.alias("a")
            .join(df_note.alias("n"), lower(F.col("a.NoteId")) == lower(F.col("n.NoteId")))
            .filter(F.col("n.NoteType") != "Document")
            .select(
                F.lit("Attachment").alias("EntryType"),
                F.col("a.NoteId"),
                F.col("a.AttachmentId").alias("Id"),
                F.col("n.NoteType"),
                F.col("n.Subject"),
                F.col("a.FileName"),
                F.col("n.Summary"),
                F.col("n.Content"),
                F.col("n.AsOfDate"),
                F.col("n.CreatedBy"),
                F.col("n.CreateTime"),
                F.col("n.ModifiedBy"),
                F.col("n.ModifyTime")
            )
        )
        print(f"df_attachments count: {df_attachments.count()}")

        # Notes CTE
        df_notes = (
            df_note
            .select(
                F.when(F.col("NoteType") == "Document", "Document")
                .otherwise("Note").alias("EntryType"),
                F.col("NoteId"),
                F.col("NoteId").alias("Id"),
                F.col("NoteType"),
                F.col("Subject"),
                F.col("Subject").alias("FileName"),
                F.col("Summary"),
                F.col("Content"),
                F.col("AsOfDate"),
                F.col("CreatedBy"),
                F.col("CreateTime"),
                F.col("ModifiedBy"),
                F.col("ModifyTime")
            )
        )
        print(f"df_notes count: {df_notes.count()}")

        # All entries
        df_all_entries = df_attachments.unionByName(df_notes)
        print(f"df_all_entries count: {df_all_entries.count()}")

        # Entries with links join
        df_join_before_filter = (
            df_all_entries.alias("ae")
            .join(
                df_note_link.alias("nl"),
                F.col("ae.NoteId") == F.col("nl.NoteId"),
                how="inner"
            )
            .drop(F.col("nl.NoteId"))  # drop duplicate from right side
        )
        print(f"df_entries_with_links BEFORE filter: {df_join_before_filter.count()}")

        df_entries_with_links = (
            df_join_before_filter
            .filter(
                F.col("LinkId").isNotNull() &
                F.col("NoteId").isNotNull() &
                F.col("EntryType").isNotNull() &
                F.col("NoteType").isNotNull() &
                F.col("CreateTime").isNotNull() &
                F.col("ModifyTime").isNotNull()
            )
            .withColumn("ETLLoadDateTime", F.lit(etlloadtime))
        )
        print(f"df_entries_with_links AFTER filter: {df_entries_with_links.count()}")

        df_entries_with_links.write \
            .format("delta") \
            .mode("overwrite") \
            .save(f"{target_path}/NotesAttachmentsDocumentsWithLinks")
        print(f"Written to {target_path}/NotesAttachmentsDocumentsWithLinks")

    except Exception as e:
        raise RuntimeError(f"Task {task['TaskKey']} failed: {str(e)}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([BronzeLHId, CuratedLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)
        # Process the task
        result = process_task(task_item)

    except Exception as e:
        print(f"Error processing task: {e}")
        raise Exception


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
