# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

from pyspark.sql.functions import col, broadcast, lower, when, trim
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
silver_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## Add ProjectedNetIr to FundPerformance

# CELL ********************

#Add PeojectedNetIR
from pyspark.sql.functions import col, lower, broadcast

# Load source tables
df_fund_stats = spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/CrimsonXFundStatistics")
df_time_period = spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/CrimsonXTimePeriod")
df_fund_perf = spark.read.format("delta").load(f"{silver_lh_basepath}/Tables/Silver/FundPerformance")

# Alias for join clarity
df_fs = df_fund_stats.alias("fs")
df_tp = df_time_period.alias("tp")

# Join to get TimePeriod info
df_joined = df_fs.join(
    df_tp,
    df_fs["TimePeriodId"] == df_tp["TimePeriodId"],
    how="inner"
)

# Extract only valid ProjectedNetIR rows
df_proj_netir = df_joined.filter(
    (col("fs.ProjectedNetIR").isNotNull()) &
    (col("fs.TimePeriodId") == 1) &
    (col("fs.FundStatisticReferenceTypeId") == 1)
).select("FundId", "ProjectedNetIR")

# Normalize FundId for join
df_proj_netir = df_proj_netir.withColumn("FundId", lower(col("FundId")))
df_fund_perf = df_fund_perf.withColumn("FundId", lower(col("FundId")))

# Drop old column to avoid duplication
df_fund_perf = df_fund_perf.drop("ProjectedNetIR")

# Join ProjectedNetIR into FundPerformance
df_updated_perf = df_fund_perf.join(
    broadcast(df_proj_netir), on="FundId", how="left"
)

# Optional: View result
df_updated_perf.select("FundId", "AsOfDate", "ProjectedNetIR").show()

# df_updated_perf = df_updated_perf.dropDuplicates(["FundId","AsOfDate"])

# Save updated FundPerformance table
df_updated_perf.write.format("delta").mode("overwrite").save(f"{silver_lh_basepath}/Tables/Silver/FundPerformance")

print('Complete: Added ProjectedNetIR to FundPerformance')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# ## Base Table for Alpha

# CELL ********************

from pyspark.sql.functions import col, lit
from functools import reduce

# Load source tables
df_fund_stats = spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/CrimsonXFundStatistics")
df_time_period = spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/CrimsonXTimePeriod")
df_fund_perf = spark.read.format("delta").load(f"{silver_lh_basepath}/Tables/Silver/FundPerformance")

df_list = []

# Alias for join clarity
df_fs = df_fund_stats.alias("fs")
df_tp = df_time_period.alias("tp")
display(df_tp)

# Join base
df_joined = df_fs.join(
    df_tp,
    df_fs["TimePeriodId"] == df_tp["TimePeriodId"],
    how="inner"
)

#GrossManagerAlpha
fund_id = "C9283CF1-94D0-4E69-D0E5-08DC7C223E5C"

gross_manager_alpha_fund = df_joined.filter(
    (col("GrossManagerAlpha").isNotNull()) &
    (col("FundStatisticReferenceTypeId") == 1) &
    (lower(col("FundId")) == lower(lit(fund_id)))
).withColumn("AlphaType", lit("GrossManagerAlpha"))\
.select(
    "AlphaType",
    col("fs.GrossManagerAlpha").alias("Alpha"),"tp.Description","fs.FundId","tp.TimePeriodId","fs.FundStatisticReferenceTypeId")\
.orderBy("FundId")
df_list.append(gross_manager_alpha_fund)


print('gross_manager_alpha_fund')
display(gross_manager_alpha_fund.limit(10))


#GrossAlpha
gross_alpha = df_joined.filter(
    (col("GrossAlphaTotal").isNotNull()) &
    (col("FundStatisticReferenceTypeId") == 1)
).withColumn("AlphaType", lit("GrossAlpha"))\
.select(
    "AlphaType",
    col("fs.GrossAlphaTotal").alias("Alpha"),
    col("tp.Description"),
    col("fs.FundId"),
    col("tp.TimePeriodId"),
    col("fs.FundStatisticReferenceTypeId"))\
.orderBy("FundId", "fs.TimePeriodId")
print('gross_alpha')
display(gross_alpha.limit(10))
df_list.append(gross_alpha)

#GrossStrategyAlpha
gross_strategy_alpha = df_joined.filter(
    (col("GrossStrategyAlpha").isNotNull()) &
    (col("FundStatisticReferenceTypeId") == 1)
).withColumn("AlphaType", lit("GrossStrategyAlpha"))\
.select(
    "AlphaType",
    col("fs.GrossStrategyAlpha").alias("Alpha"),
    "tp.Description",
    "fs.FundId",
    "tp.TimePeriodId",
    "fs.FundStatisticReferenceTypeId")\
.orderBy("FundId", "fs.TimePeriodId")
print('gross_strategy_alpha')
display(gross_strategy_alpha.limit(10))
df_list.append(gross_strategy_alpha)

#NetAlpha
net_alpha = df_joined.filter(
    (col("NetAlpha").isNotNull()) &
    (col("FundStatisticReferenceTypeId") == 1)
).withColumn("AlphaType", lit("NetAlpha"))\
.select(
    "AlphaType",
    col("fs.NetAlpha").alias("Alpha"),
    "tp.Description",
    "fs.FundId",
    "tp.TimePeriodId",
    "fs.FundStatisticReferenceTypeId")\
.orderBy("FundId", "fs.TimePeriodId")
print('net_alpha')
display(net_alpha.limit(10))
df_list.append(net_alpha)

#GrossManagerAlpha for MSCI ACWI
gross_manager_alpha_msci = df_joined.filter(
    (col("GrossManagerAlpha").isNotNull()) &
    (col("FundStatisticReferenceTypeId") == 4) &
    (lower(col("FundId")) == lower(lit(fund_id)))
).withColumn("AlphaType", lit("GrossManagerAlpha"))\
.select(
    "AlphaType",
    col("fs.GrossManagerAlpha").alias("Alpha"),"tp.Description","fs.FundId","tp.TimePeriodId","fs.FundStatisticReferenceTypeId")\
.orderBy("FundId")
print('gross_manager_alpha_msci')
display(gross_manager_alpha_msci.limit(10))
df_list.append(gross_manager_alpha_msci)

#Alpha (benchmark related)
benchmark_alpha = df_joined.filter(
    (col("Alpha").isNotNull()) &
    (col("FundStatisticReferenceTypeId").isin(3, 4, 6, 7))
).withColumn("AlphaType", lit("Alpha"))\
.select(
    "AlphaType",
    col("fs.Alpha"),"tp.Description","fs.FundId","tp.TimePeriodId","fs.FundStatisticReferenceTypeId")\
.orderBy("FundId", "fs.TimePeriodId")
print('benchmark_alpha')
display(benchmark_alpha.limit(10))
# df_list.append(benchmark_alpha)

#Combined DF
df_all = reduce(lambda df_a, df_b: df_a.unionByName(df_b), df_list)
display(df_all.limit(10))


# df_fund_alpha.write.format("delta").mode("overwrite").save(target_path_alpha)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # ALPHA TRANSFORMATIONS

# MARKDOWN ********************

# ## FundAlpha Table

# CELL ********************

#if you rerun this, you should rerun the code above too
from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType

df_alpha_type = spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/AlphaType")
target_path = f"{silver_lh_basepath}/Tables/Silver/FundAlpha"

df_alpha_type = df_alpha_type.withColumnRenamed("Id", "AlphaTypeId")

df_all_alpha = df_all.alias("a").join(
    df_alpha_type.alias("b"),
    F.col("a.AlphaType") == F.col("b.Description"),
    how="left"
)

df_all_alpha.select("AlphaType", "AlphaTypeId").distinct().show()

from pyspark.sql.functions import col, when

df_all_alpha = df_all_alpha.withColumn(
    "Alpha",
    when(col("Alpha").isNull(), 0)
    .when(col("Alpha") == "", 0)
    .when(col("Alpha") == "NULL", 0)
    .otherwise(col("Alpha"))
)

# Pivot the table to wide format
pivoted_df = (
    df_all_alpha
    .groupBy("b.AlphaTypeId", "a.FundId")
    .pivot("a.Description")
    .agg(F.first("Alpha"))
)
pivoted_df.select("AlphaTypeId").distinct().show()

# Show result
display(pivoted_df.limit(10))

# Replace spaces with underscores in all column names
for col_name in pivoted_df.columns:
    if " " in col_name:
        new_col_name = col_name.replace(" ", "_")
        pivoted_df = pivoted_df.withColumnRenamed(col_name, new_col_name)
display(pivoted_df.limit(10))

# # Get all columns that are time-period based
metric_cols = [c for c in pivoted_df.columns if c not in ("AlphaTypeId", "FundId")]

for c in metric_cols:
    pivoted_df = pivoted_df.withColumn(c, col(c).cast(DoubleType()))
pivoted_df = pivoted_df.persist()
pivoted_df.write.format("delta").mode("overwrite").save(target_path)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
