# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Before running any Create Table script, please run spark conf to set case sensitive to True

# CELL ********************

#Always run this first
spark.conf.set("spark.sql.caseSensitive","true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# - Amount = DECIMAL(38, 2)
# - FXRate/Exposure = DECIMAL(38, 15)
# - Percentage or Analytics = DECIMAL(38, 6)
# - Returns = (38, 11) - Aligning with Index Returns in sql warehouse
# - Guids = VARCHAR(36) if possible
# - Descriptions - VARCHAR(I'm ok with 8k, but would prefer whatever makes sense for that table)
# - Lookup Ids - INT
# - Large table Ids like Cashflows - BIGINT
# - Bit - BOOLEAN preferred not null to avoid tri-state boolean
# - Dates - Date avoid timestamp where possible for things like AsofDate, NAVDate, ExposureDate, etc.
# - Audit or Etl Dates - Datetime

# MARKDOWN ********************

# Create Table Statements from Notebook (Cell may be hidden)

# CELL ********************


%%sql
-- These are created via the notebook, NotebookTasks
-- CREATE TABLE IF NOT EXISTS lh_curated.Silver.FXRate (
--     FXRateId INT NOT NULL,
--     CurrencyId INT NOT NULL,
--     FXDate DATE NOT NULL,
--     FXRate DECIMAL(38,15) NOT NULL,
--     ETLLoadDateTime TIMESTAMP NOT NULL,
--     IsLatest INT NOT NULL
-- )

-- CREATE TABLE IF NOT EXISTS lh_curated.Silver.Universe (
--     UniverseId VARCHAR(36) NOT NULL,
--     UniverseName STRING NOT NULL,
--     UniverseDescription STRING,
--     ETLLoadDateTime TIMESTAMP NOT NULL
-- )


-- CREATE TABLE IF NOT EXISTS lh_curated.Silver.UniverseFunds (
--     UniverseId VARCHAR(36) NOT NULL,
--     FundId VARCHAR(36) NOT NULL,
--     ETLLoadDateTime TIMESTAMP NOT NULL
-- )

-- CREATE TABLE IF NOT EXISTS lh_curated.Silver.IndexRegionCountryExposure (
--     IndexId VARCHAR(36) NOT NULL,
--     GeographicRegion STRING NOT NULL,
--     Country STRING NOT NULL,
--     Exposure DECIMAL(38,15) NOT NULL,
--     AsOfDate DATE NOT NULL,
--     ETLLoadDateTime TIMESTAMP NOT NULL
-- )

-- CREATE TABLE IF NOT EXISTS lh_curated.Silver.IndexRegionExposure (
--     IndexId VARCHAR(36) NOT NULL,
--     GeographicRegion STRING NOT NULL,
--     Exposure DECIMAL(38,15) NOT NULL,
--     AsOfDate DATE NOT NULL,
--     ETLLoadDateTime TIMESTAMP NOT NULL
-- )

-- CREATE TABLE IF NOT EXISTS lh_curated.Silver.IndexSectorIndustryExposure (
--     IndexId VARCHAR(36) NOT NULL,
--     Sector STRING NOT NULL,
--     Industry STRING NOT NULL,
--     Exposure DECIMAL(38,15) NOT NULL,
--     AsOfDate DATE,
--     ETLLoadDateTime TIMESTAMP NOT NULL
-- )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.Entity (
# MAGIC     EntityId VARCHAR(36) NOT NULL,
# MAGIC     FirmId VARCHAR(36) NOT NULL,
# MAGIC     EntityName STRING NOT NULL,
# MAGIC     EntityStatus INT,
# MAGIC     PrimaryOwner STRING,
# MAGIC     SecondaryOwner STRING,
# MAGIC     Associate STRING,
# MAGIC     TertiaryOwner STRING,
# MAGIC     AlphaStrategyId INT,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


%%sql

CREATE TABLE IF NOT EXISTS lh_curated.Silver.Firm (
    FirmId VARCHAR(36) NOT NULL,
    FirmName STRING NOT NULL,
    ETLLoadDateTime TIMESTAMP NOT NULL
) 


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.PrivateFees (
# MAGIC     FundId VARCHAR(36) NOT NULL,
# MAGIC     InvestmentPeriodQuarters INT,
# MAGIC     HarvestPeriodQuarters INT,
# MAGIC     ExpectedExpensePct DECIMAL(38,6),
# MAGIC     CarryPct DECIMAL(38,6),
# MAGIC     FeeCarryMethodTypeId INT,
# MAGIC     PreferredRatePct DECIMAL(38,6),
# MAGIC     HasHardHurdle BOOLEAN,
# MAGIC     GPCatchUpPct DECIMAL(38,6),
# MAGIC     ClawbackTaxPct DECIMAL(38,6),
# MAGIC     UncalledCapitalPct DECIMAL(38,6),
# MAGIC     ContractualTermMatchId INT,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.PublicFees (
# MAGIC     FundId VARCHAR(36) NOT NULL,
# MAGIC     MgmtPct DECIMAL(38,6),
# MAGIC     IsHighWaterMark BOOLEAN,
# MAGIC     FeeHurdleTypeId INT,
# MAGIC     HurdlePct DECIMAL(38,6),
# MAGIC     IndexId VARCHAR(36),
# MAGIC     CarryPct DECIMAL(38,6),
# MAGIC     IsIndexHistorical BOOLEAN,
# MAGIC     IndexReturnPct DECIMAL(38,6),
# MAGIC     IndexVolPct DECIMAL(38,6),
# MAGIC     ExpenseRatio BIGINT,
# MAGIC     FeeCrystalizationTypeId INT,
# MAGIC     IsLossCarry BOOLEAN,
# MAGIC     IsClawBack BOOLEAN,
# MAGIC     FeePaymentFrequencyTypeId INT,
# MAGIC     FeePaymentTimingTypeId INT,
# MAGIC     FeeBasisTypeId INT,
# MAGIC     IsRebate BOOLEAN,
# MAGIC     FeeCarryMethodTypeId INT,
# MAGIC     ContractualTermMatchId INT,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC ) 

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.PerformanceFlash (
# MAGIC     PerformanceTypeId INT NOT NULL,
# MAGIC     StartDate DATE NOT NULL,
# MAGIC     EndDate DATE NOT NULL,
# MAGIC     AsOfDate DATE NOT NULL,
# MAGIC     NAV DECIMAL(38,6),
# MAGIC     CashFlows DECIMAL(38,6),
# MAGIC     PnL DECIMAL(38,6),
# MAGIC     Commitment DECIMAL(38,6),
# MAGIC     Unfunded DECIMAL(38,6),
# MAGIC     PercentOfGIA DECIMAL(38,6),
# MAGIC     PercentReporting DECIMAL(38,6),
# MAGIC     CategoryReturn DECIMAL(38,6),
# MAGIC     IndexReturn DECIMAL(38,6),
# MAGIC     OverUnderPerformance DECIMAL(38,6),
# MAGIC     FundId VARCHAR(36),
# MAGIC     IndexId VARCHAR(36),
# MAGIC     Level1 STRING,
# MAGIC     Level2 STRING,
# MAGIC     Level3 STRING,
# MAGIC     Level4 STRING,
# MAGIC     Level5 STRING,
# MAGIC     Level6 STRING,
# MAGIC     Level7STRING,
# MAGIC     SortOrdinal INT,
# MAGIC     Description STRING,
# MAGIC     IndexName STRING,
# MAGIC     LastValuationDate DATE,
# MAGIC     UpdateTimestamp TIMESTAMP,
# MAGIC     UpdateByHMCUserId STRING,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.PerformanceGIAReturn (
# MAGIC     PerformanceTypeId INT NOT NULL,
# MAGIC     StartDate DATE NOT NULL,
# MAGIC     EndDate DATE NOT NULL,
# MAGIC     PrivateRefreshDate DATE,
# MAGIC     AsOfDate DATE NOT NULL,
# MAGIC     WeightedAssetReturn DECIMAL(38,11),
# MAGIC     BetaReturn DECIMAL(38,11),
# MAGIC     BetaReturnFlatIlliquids DECIMAL(38,11),
# MAGIC     PublicReturn DECIMAL(38,11),
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.Index (
# MAGIC     IndexId VARCHAR(36) NOT NULL,
# MAGIC     IndexName STRING NOT NULL,
# MAGIC     DisplayName STRING,
# MAGIC     Description STRING,
# MAGIC     CurrencyId INT NOT NULL,
# MAGIC     IsRiskIndex BOOLEAN NOT NULL,
# MAGIC     BetaCategoryId INT,
# MAGIC     IsShortIndex BOOLEAN NOT NULL,
# MAGIC     IsCustomIndex BOOLEAN,
# MAGIC     Ticker STRING,
# MAGIC     Frequency INT,
# MAGIC     FinancialDataProviderId STRING,
# MAGIC     IsLevelBased BOOLEAN,
# MAGIC     ExchangeProviderId INT,
# MAGIC     IndexReturnTypeId INT NOT NULL,
# MAGIC     IsTotalReturn BOOLEAN NOT NULL,
# MAGIC     IsActive BOOLEAN,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC -- DROP TABLE lh_curated.Silver.IndexCustomBlendRecipe;
# MAGIC 
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.IndexCustomBlendRecipe (
# MAGIC     TargetIndexId VARCHAR(36) NOT NULL,
# MAGIC     SourceIndexId VARCHAR(36) NOT NULL,
# MAGIC     CurrencyIdBase INT NOT NULL,
# MAGIC     IndexContributionPct DECIMAL(38, 11) NOT NULL,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC );

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC -- SELECT * FROM lh_curated.Silver.indexcustomblendrecipe
# MAGIC 
# MAGIC SELECT * FROM lh_curated.Silver.IndexCustomBlendRecipe
# MAGIC 
# MAGIC -- DROP TABLE lh_curated.Silver.IndexCustomBlendRecipe;
# MAGIC -- DROP TABLE lh_curated.Silver.indexcustomblendrecipe;
# MAGIC 
# MAGIC -- DESCRIBE  lh_curated.Silver.indexcustomblendrecipe;
# MAGIC 
# MAGIC -- DESCRIBE  lh_curated.Silver.IndexCustomBlendRecipe;

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC -- DROP TABLE lh_curated.Silver.IndexReturn


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC CREATE TABLE lh_curated.Silver.IndexReturn (
# MAGIC 	IndexId VARCHAR(36) NOT NULL,
# MAGIC 	FrequencyId INT NOT NULL,
# MAGIC 	ReturnDate date NOT NULL,	-- was AsOfDate date NOT NULL,
# MAGIC 	CurrencyId int NOT NULL,
# MAGIC 	LevelValue decimal(38, 11) NOT NULL, -- was IndexLevel decimal(38, 11) NOT NULL,
# MAGIC 	ReturnValue decimal(38, 11) NOT NULL, -- was IndexReturn decimal(38, 11) NOT NULL,
# MAGIC 	ReturnComment varchar(200),
# MAGIC 	ReturnSource varchar(50),
# MAGIC 	-- remvoed UpdateTimeStamp TIMESTAMP NOT NULL,
# MAGIC 	--removed UpdateByHMCUserId varchar(50) NOT NULL,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F, types as T
#src = spark.table("Silver.IndexReturn_before_column_changes")
src = spark.table("Silver.IndexReturn_readonly")
tgt = (
    src
    .withColumn("IndexId",  F.col("IndexId").cast(T.VarcharType(36)))
    .withColumn("FrequencyId",  F.col("FrequencyId").cast(T.IntegerType()))
    .withColumn("ReturnDate",  F.col("AsOfDate").cast(T.DateType()))
    .withColumn("CurrencyId",  F.col("CurrencyId").cast(T.IntegerType()))
    .withColumn("LevelValue",  F.col("IndexLevel").cast(T.DecimalType(38, 11)))
    .withColumn("ReturnValue", F.col("IndexReturn").cast(T.DecimalType(38, 11)))
    .withColumn("ReturnComment", F.substring(F.col("UpdateByHMCUserId").cast("string"), 1, 200))
    .withColumn("ReturnSource",  F.substring(F.col("ReturnSource").cast("string"), 1, 50))
    .withColumn("ETLLoadDateTime", F.to_timestamp("ETLLoadDateTime"))
)
tgt = tgt.drop("IndexLevel").drop("IndexReturn").drop(" VersionNum").drop("UpdateTimeStamp").drop("UpdateByHMCUserId").drop("AsOfDate").drop("VersionNum")

ordered = [ "IndexId","FrequencyId","ReturnDate","CurrencyId","LevelValue","ReturnValue","ReturnComment","ReturnSource","ETLLoadDateTime" ]
tgt = tgt.select(*ordered)

tgt.printSchema()
#raise SystemExit("xxx")
(tgt.write
    .format("delta")
    .mode("overwrite")                 # or "append"
    .option("overwriteSchema", "false")
    .saveAsTable("Silver.IndexReturn"))
print("Done!")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC -- SELECT * FROM lh_curated.Gold.IndexReturn where CurrencyId = 1 AND ReturnDate = '2025-09-30' LIMIT 1000;
# MAGIC 
# MAGIC -- SELECT * FROM lh_curated.Gold.IndexReturn where ReturnDate >= '2025-09-01' AND NOT ReturnComment IS NULL  LIMIT 1000;
# MAGIC 
# MAGIC -- DROP TABLE Silver.IndexReturn_before_column_changes
# MAGIC 
# MAGIC -- DROP TABLE Silver.indexreturn_before_column_changes
# MAGIC 
# MAGIC -- DROP TABLE Silver.indexreturn
# MAGIC 
# MAGIC -- DROP TABLE Silver.IndexReturn_STAGE_for_compare
# MAGIC 
# MAGIC DROP TABLE Bronze.None
# MAGIC 
# MAGIC 
# MAGIC -- ALTER TABLE Silver.IndexReturn RENAME TO Silver.IndexReturn_before_column_changes
# MAGIC 
# MAGIC -- DESCRIBE Silver.IndexReturn
# MAGIC 
# MAGIC -- SELECT count(1) FROM Silver.IndexReturn
# MAGIC 


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC --DROP TABLE Silver.PrivateFeeTiers
# MAGIC 
# MAGIC CREATE TABLE Silver.PrivateFeeTiers(
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	Tier int NOT NULL,
# MAGIC 	ManagementFee decimal(38, 6) NOT NULL,
# MAGIC 	FeeTierBasisTypeId int NOT NULL,
# MAGIC 	DurationQuarters int,
# MAGIC 	ETLLoadDateTime Timestamp NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
