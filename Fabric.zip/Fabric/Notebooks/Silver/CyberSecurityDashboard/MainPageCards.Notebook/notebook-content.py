# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql import types as T

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# --------------------------------------------------------------------------------------
# Source reads (path-based)
# --------------------------------------------------------------------------------------
overall_score_df = read_delta(curated_lh_id, "Silver/CyberSecurityOverallScore")
user_risk_df    = read_delta(curated_lh_id, "Silver/CyberSecurityUserRiskData")
dept_risk_df    = read_delta(curated_lh_id, "Silver/CyberSecurityDeptRisk")
failure_rates_df= read_delta(curated_lh_id, "Silver/CyberSecurityFailureRates")

etl_timestamp = F.current_timestamp()

# --------------------------------------------------------------------------------------
# Build the CyberSecurityRiskCard rows
# --------------------------------------------------------------------------------------

# 1) Overall User Risk Score (string "Value")
overall_user = (
    overall_score_df
      .filter(F.col("OverallArea") == "User")
      .select(
          F.when(F.col("HMCTotalScore").between(F.col("VeryHighLimitStart"), F.col("VeryHighLimitEnd")), "Very High")
           .when(F.col("HMCTotalScore").between(F.col("HighLimitStart"),     F.col("HighLimitEnd")),     "High")
           .when(F.col("HMCTotalScore").between(F.col("MediumLimitStart"),   F.col("MediumLimitEnd")),   "Medium")
           .when(F.col("HMCTotalScore").between(F.col("LowLimitStart"),      F.col("LowLimitEnd")),      "Low")
           .when(F.col("HMCTotalScore").between(F.col("VeryLowLimitStart"),  F.col("VeryLowLimitEnd")),  "Very Low")
           .otherwise("Out of range")
           .alias("Value"),
          F.lit("Overall User Risk Score").alias("Title"),
          F.lit("User Risk").alias("PageCard"),
          F.lit(1).alias("SortOrder"),
          etl_timestamp.alias("ETLLoadDateTime")
      )
)

# Get target value once
target_value = (
    overall_score_df
      .filter(F.col("OverallArea") == "User")
      .select("TargetValue")
      .first()["TargetValue"]
)

# 2) User count past risk threshold (cast count to string to keep schema stable)
count_past_threshold = (
    user_risk_df
      .filter(F.col("TotalHMCUserRisk").isNotNull() & (F.col("TotalHMCUserRisk") > target_value))
      .agg(F.count(F.lit(1)).cast("string").alias("Value"))
      .withColumn("Title", F.lit("User count past risk level threshold"))
      .withColumn("PageCard", F.lit("User Risk"))
      .withColumn("SortOrder", F.lit(2))
      .withColumn("ETLLoadDateTime", etl_timestamp)
)

# 3) Riskiest monitored user
riskiest_user = (
    user_risk_df
      .orderBy(F.col("TotalHMCUserRisk").desc())
      .limit(1)
      .select(
          F.col("DisplayName").alias("Value"),
          F.lit("Riskiest monitored user").alias("Title"),
          F.lit("User Risk").alias("PageCard"),
          F.lit(3).alias("SortOrder"),
          etl_timestamp.alias("ETLLoadDateTime")
      )
)

# 4) Riskiest monitored department
riskiest_dept = (
    dept_risk_df
      .orderBy(F.col("RiskScoreAverage").desc())
      .limit(1)
      .select(
          F.col("Department").alias("Value"),
          F.lit("Riskiest monitored department").alias("Title"),
          F.lit("User Risk").alias("PageCard"),
          F.lit(4).alias("SortOrder"),
          etl_timestamp.alias("ETLLoadDateTime")
      )
)

# 5) Last phishing failure rate (format as string percentage with 2 decimals)
last_fail_rate = (
    failure_rates_df
      .select(
          F.format_number((F.col("onemonthfailurerate") * 100), 2).alias("Value"),
          F.lit("Last phishing failure rate").alias("Title"),
          F.lit("User Risk").alias("PageCard"),
          F.lit(5).alias("SortOrder"),
          etl_timestamp.alias("ETLLoadDateTime")
      )
)

# 6) Six month average failure rate
sixmo_fail_rate = (
    failure_rates_df
      .select(
          F.format_number((F.col("sixmonthfailurerate") * 100), 2).alias("Value"),
          F.lit("Six month average failure rate").alias("Title"),
          F.lit("User Risk").alias("PageCard"),
          F.lit(6).alias("SortOrder"),
          etl_timestamp.alias("ETLLoadDateTime")
      )
)

# 7) HMC access metric failures (constant "1" as string)
access_metric = spark.createDataFrame(
    [("1", "HMC access metric failures", "User Risk", 7)],
    ["Value", "Title", "PageCard", "SortOrder"]
).withColumn("ETLLoadDateTime", etl_timestamp)

# Union all rows (schema-compatible: Value is STRING everywhere)
risk_card_df = (
    overall_user
      .unionByName(count_past_threshold)
      .unionByName(riskiest_user)
      .unionByName(riskiest_dept)
      .unionByName(last_fail_rate)
      .unionByName(sixmo_fail_rate)
      .unionByName(access_metric)
)

travel_df = read_delta(curated_lh_id, "Gold/TravelDetails")

# Last 12 months cutoff (date only)
cutoff_date = F.add_months(F.current_date(), -12)

# Normalize and de-dupe by User + TravelDate (1 row per user per day)
travel_base = (
    travel_df.select(
        F.col("User").alias("User"),
        F.to_date(F.col("Date")).alias("TravelDate"),
        F.col("BlackList"),
        F.col("GreyList"),
        F.col("WhiteList"),
        F.col("Violation")
    )
    .where(F.col("TravelDate") >= cutoff_date)
    .dropDuplicates(["User", "TravelDate"])
)

def travel_count_row(condition_col, title, sort_order):
    return (
        travel_base.where(condition_col == 1)
        .agg(F.count(F.lit(1)).cast("string").alias("Value"))
        .withColumn("Title", F.lit(title))
        .withColumn("PageCard", F.lit("Travel Risk"))
        .withColumn("SortOrder", F.lit(sort_order))
        .withColumn("ETLLoadDateTime", etl_timestamp)
    )

# 1) Overall Travel Risk (constant "1")
overall_travel = spark.createDataFrame(
    [("1", "Overall Travel Risk", "Travel Risk", 1)],
    ["Value", "Title", "PageCard", "SortOrder"]
).withColumn("ETLLoadDateTime", etl_timestamp)

# 2) Users in black-listed countries (distinct users per day, last 12 months)
black_listed = travel_count_row(F.col("BlackList"), "Users in black-listed countries", 2)

# 3) Users in grey-listed countries
grey_listed  = travel_count_row(F.col("GreyList"),  "Users in grey-listed countries", 3)

# 4) Users in white-listed countries
white_listed = travel_count_row(F.col("WhiteList"), "Users in white-listed countries", 4)

# 5) Travel Violations
violations   = travel_count_row(F.col("Violation"), "Travel Violations", 5)

# Union into main card (use unionByName to align columns)
risk_card_df = (
    risk_card_df
        .unionByName(overall_travel)
        .unionByName(black_listed)
        .unionByName(grey_listed)
        .unionByName(white_listed)
        .unionByName(violations)
)

vendor_df = read_delta(curated_lh_id, "Silver/VendorScoreCard")

# 1) Overall Vendor Risk (constant "Medium")
vendor_overall = spark.createDataFrame(
    [("Medium", "Overall Vendor Risk", "Vendor Risk", 1)],
    ["Value", "Title", "PageCard", "SortOrder"]
).withColumn("ETLLoadDateTime", etl_timestamp)

# 2) Total Vendor Count (distinct VendorName)
vendor_total_count = (
    vendor_df
      .agg(F.countDistinct(F.col("VendorName")).cast("string").alias("Value"))
      .withColumn("Title", F.lit("Total Vendor Count"))
      .withColumn("PageCard", F.lit("Vendor Risk"))
      .withColumn("SortOrder", F.lit(2))
      .withColumn("ETLLoadDateTime", etl_timestamp)
)

# 3) Current at-risk companies (HMCScore > Vendor TargetValue) — Spark-native
vendor_target_df = (
    overall_score_df
      .filter(F.col("OverallArea") == "Vendor")
      .select(F.col("TargetValue").alias("VendorTargetValue"))
      .limit(1)  # keep just one row
)

# If there's no Vendor row, produce 0
if vendor_target_df.rdd.isEmpty():
    vendor_at_risk = (
        spark.createDataFrame([("0",)], ["Value"])
             .withColumn("Title", F.lit("Current at-risk companies"))
             .withColumn("PageCard", F.lit("Vendor Risk"))
             .withColumn("SortOrder", F.lit(3))
             .withColumn("ETLLoadDateTime", etl_timestamp)
    )
else:
    vendor_at_risk = (
        vendor_df
          .crossJoin(vendor_target_df)
          .where(
              F.col("HMCScore").isNotNull() &
              (F.col("HMCScore").cast("double") > F.col("VendorTargetValue").cast("double"))
          )
          .agg(F.count(F.lit(1)).cast("string").alias("Value"))
          .withColumn("Title", F.lit("Current at-risk companies"))
          .withColumn("PageCard", F.lit("Vendor Risk"))
          .withColumn("SortOrder", F.lit(3))
          .withColumn("ETLLoadDateTime", etl_timestamp)
    )


# 4) Beyond validation period %  (count of vendors beyond threshold based on RiskLevel)
# Risk-based threshold: VH/High -> 1 yr, Medium -> 2 yrs, Low/Very Low/else -> 3 yrs
risk_years = (
    F.when(F.upper(F.col("RiskLevel")).isin("VERY HIGH", "HIGH"), 1)
     .when(F.upper(F.col("RiskLevel")) == "MEDIUM", 2)
     .otherwise(3)
)

threshold_date = F.add_months(F.current_date(), -12 * risk_years)

# Parse/normalize dates (works if columns are DATE/TIMESTAMP; if strings, ensure ISO or add a format)
d_int  = F.coalesce(F.to_date(F.col("LastInternalReview")),      F.lit("1900-01-01").cast("date"))
d_scan = F.coalesce(F.to_date(F.col("LastExternalVendorScan")),  F.lit("1900-01-01").cast("date"))
d_rev  = F.coalesce(F.to_date(F.col("LastExternalVendorReview")),F.lit("1900-01-01").cast("date"))
d_drb  = F.coalesce(F.to_date(F.col("LastDRBCPUpdate")),         F.lit("1900-01-01").cast("date"))

vendor_flags = (
    vendor_df
      .select("VendorName", "RiskLevel", d_int.alias("LastInternalReview"),
              d_scan.alias("LastExternalVendorScan"), d_rev.alias("LastExternalVendorReview"),
              d_drb.alias("LastDRBCPUpdate"))
      .withColumn("ThresholdDate", threshold_date)
      # Any date after threshold? -> AnyAfter = 1 else 0
      .withColumn("MaxDate", F.greatest("LastInternalReview","LastExternalVendorScan",
                                        "LastExternalVendorReview","LastDRBCPUpdate"))
      .withColumn("AnyAfter", F.when(F.col("MaxDate") > F.col("ThresholdDate"), F.lit(1)).otherwise(F.lit(0)))
      .withColumn("AllDatesBeforeThreshold", (F.lit(1) - F.col("AnyAfter")))
)

vendor_validation = (
    vendor_flags
      .agg(F.sum("AllDatesBeforeThreshold").cast("string").alias("Value"))
      .withColumn("Title", F.lit("Beyond validation period %"))
      .withColumn("PageCard", F.lit("Vendor Risk"))
      .withColumn("SortOrder", F.lit(4))
      .withColumn("ETLLoadDateTime", etl_timestamp)
)


# Union into main card
risk_card_df = (
    risk_card_df
      .unionByName(vendor_overall)
      .unionByName(vendor_total_count)
      .unionByName(vendor_at_risk)
      .unionByName(vendor_validation)
)

# --------------------------------------------------------------------------------------
# Write to Lakehouse path (Silver) using your path helper pattern
# --------------------------------------------------------------------------------------
target_rel  = "Silver/CyberSecurityRiskCard"   # keep this in Silver to match your table name
target_path = tbl_path(curated_lh_id, target_rel)

(risk_card_df
    .select("Value", "Title", "PageCard", "SortOrder", "ETLLoadDateTime")
    .write
    .format("delta")
    .mode("overwrite")            # swap to 'append' to archive multiple ETL runs
    .option("overwriteSchema", "true")
    .save(target_path)
)

display(risk_card_df.orderBy("SortOrder"))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
