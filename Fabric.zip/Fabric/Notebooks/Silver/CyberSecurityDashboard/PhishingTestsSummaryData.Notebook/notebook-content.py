# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql.functions import col, count, trunc, date_format
from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# Step 1: Load data (Bronze)
df = read_delta(bronze_lh_id, "Bronze/KnowBe4PhishingTest")

# Step 2: Filter date (keep from 2024-11-01 onward)
min_date = F.to_timestamp(F.lit("2024-11-01"))
df_filtered = df.filter(F.col("scheduled_at") >= min_date)

# Compute the start of the current month once (session timezone)
cutoff_month_start = F.trunc(F.current_timestamp(), "MM")

# Step 3: Month bucketing + summary
df_summary = (
    df_filtered
      .withColumn("month_date", F.trunc(F.col("scheduled_at"), "MM"))                # e.g., 2025-07-01
      .filter(F.col("month_date") < cutoff_month_start)                              # ⬅️ exclude current month
      .withColumn("month_label", F.date_format(F.col("month_date"), "MMM yyyy"))     # e.g., "Jul 2025")
      .groupBy("month_date", "month_label")
      .agg(
          F.count(F.lit(1)).alias("total_tests"),
          F.count("clicked_at").alias("clicked_count"),
          F.count("attachment_opened_at").alias("attachment_opened_count")
      )
      .withColumn("year", F.year(F.col("month_date")).cast("int"))
      .withColumn("month", F.month(F.col("month_date")).cast("int"))
      .withColumn("year_month", F.date_format(F.col("month_date"), "yyyy-MM"))
      .select(
          "year_month",
          "total_tests",
          "clicked_count",
          "attachment_opened_count",
          "year",
          "month",
          "month_date",
          "month_label"
      )
      .orderBy(F.col("month_date"))
)

# Step 4: Write to Curated Lakehouse path (Delta, overwrite)
target_rel  = "Silver/CyberSecurityPhishingTestsSummary"
target_path = tbl_path(curated_lh_id, target_rel)

(df_summary.write
    .mode("overwrite")
    .format("delta")
    .option("overwriteSchema", "true")
    .save(target_path)
)

print(f"✅ Wrote phishing test monthly summary to {target_path}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
