# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Cybersecurity User Risk Pipeline (SP-aligned, using Bronze.CyberDashboardSplunk)

# ─────────────────────────────────────────────checkssecurityecx
# Imports & helpers
# ─────────────────────────────────────────────
from pyspark.sql import functions as F
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from functools import reduce
from pyspark.sql.types import DoubleType
from pyspark.sql.types import DoubleType as _DoubleType  # isinstance checks

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

def norm_email(colname="email"):
    return F.lower(F.trim(F.col(colname)))


# ─────────────────────────────────────────────
# Step 1: Load and Normalize Tables
# ─────────────────────────────────────────────
df_ad = (
    read_delta(bronze_lh_id, "Bronze/EntraUsers")
        .withColumnRenamed("mail", "email")
        .withColumnRenamed("jobTitle", "RoleRisk")
        .withColumnRenamed("department", "DepartmentRisk")
        .withColumnRenamed("accountEnabled", "Enabled")
        .withColumn("DisplayName", F.concat_ws(", ", F.col("surname"), F.col("givenName")))
        .withColumn("email", norm_email("email"))
)

df_users = (
    read_delta(bronze_lh_id, "Bronze/KnowBe4Users")
        .select(
            norm_email("email").alias("email"),
            F.col("employee_start_date"),
            F.col("phish_prone_percentage").cast("double").alias("ppp")
        )
)

df_phishing = (
    read_delta(bronze_lh_id, "Bronze/KnowBe4PhishingTest")
        .withColumnRenamed("user_email", "email")
        .withColumn("email", norm_email("email"))
)

# Combined Mimecast + Abnormal (your renamed table)
df_splunk_raw = (
    read_delta(bronze_lh_id, "Bronze/CyberDashboardSplunk")
        .withColumn("Email", norm_email("Email"))
)

# SpyCloud (raw)
df_sc = (
    read_delta(bronze_lh_id, "Bronze/CyberDashboardSpyCloud")
        .withColumn("email", norm_email("email"))
)

df_exceptions = (
    read_delta(bronze_lh_id, "Bronze/ManualExceptions")
        .withColumnRenamed("User_Email", "email")
        .withColumn("email", norm_email("email"))
)

df_limits = read_delta(bronze_lh_id, "Bronze/CyberDashboardLimits")


# ─────────────────────────────────────────────
# Step 2: Prepare Metrics (SP-aligned)
# ─────────────────────────────────────────────

# Latest KnowBe4 per user (mirrors SP "TOP 1 ORDER BY Scheduled DESC")
window_latest = Window.partitionBy("email").orderBy(F.col("scheduled_at").desc())

df_kb4_latest = (
    df_phishing
      .withColumn("row_num", F.row_number().over(window_latest))
      .filter(F.col("row_num") == 1)
      .join(df_users, "email", "left")  # brings in employee_start_date + ppp
      .withColumn(
          "PhishingRisk",
          (F.coalesce(F.col("ppp"), F.col("phish_prone_percentage").cast("double")) / F.lit(100.0))
      )
      .select("email", "PhishingRisk", "scheduled_at", "employee_start_date")
      .withColumn(
          "EmploymentMonthsRisk",
          F.coalesce(
              F.months_between(F.current_date(), F.col("employee_start_date").cast("date")),
              F.lit(0)
          )
      )
)

# Map combined table to model names used by limits & scoring
df_splunk = (
    df_splunk_raw.select(
        F.col("Email").alias("email"),
        F.col("ExternalMailsReceived").cast("double").alias("ExternalMailsReceived"),
        F.col("Spam").cast("double").alias("Spam"),
        F.col("Phishing").cast("double").alias("Phishing"),
        F.col("Malware").cast("double").alias("PrimaryEmailProtectionMalwareRisk"),
        F.col("Suspicious").cast("double").alias("PrimaryEmailProtectionSuspiciousRisk"),
        F.col("Abnormalspam").cast("double").alias("SecondaryEmailProtectionSpamRisk"),
        F.col("Abnormalphishing_credential").cast("double").alias("SecondaryEmailProtectionPhishingRisk"),
        F.col("Abnormalsocial_eng_bec").cast("double").alias("SecondaryEmailProtectionSocialEngineeringRisk"),
        F.col("Abnormalscam").cast("double").alias("SecondaryEmailProtectionSuspiciousRisk"),
        F.col("Abnormalmalware").cast("double").alias("SecondaryEmailProtectionMalwareRisk"),
        F.col("TotalHeldEmails").cast("double").alias("TotalHeldEmails"),
    )
)

# PrimaryEmailProtectionPhishingRisk = Phishing count (SP)
df_splunk = df_splunk.withColumn("PrimaryEmailProtectionPhishingRisk", F.col("Phishing"))

# Spam ratio per SP (NULL if denominator == 0 so it evaluates to Level=1 in limits)
df_splunk = df_splunk.withColumn(
    "PrimaryEmailProtectionSpamRisk",
    F.when(
        (F.col("TotalHeldEmails") + F.col("ExternalMailsReceived")) > 0,
        F.col("Spam") / (F.col("TotalHeldEmails") + F.col("ExternalMailsReceived"))
    ).otherwise(F.lit(None).cast("double"))
)

# SpyCloud: count DISTINCT breach titles per user (fallback to source_id+document_id if titles missing)
from pyspark.sql.types import ArrayType, StringType
restrict_to_active_ad = True

# 1) Build a column of titles to explode:
if "breach_titles" in df_sc.columns and isinstance(df_sc.schema["breach_titles"].dataType, ArrayType):
    titles_arr = F.col("breach_titles")  # already an array
else:
    # Single-value columns: DO NOT split on delimiters; treat as one title
    single_candidates = [c for c in ["breach_title", "breach", "source_name"] if c in df_sc.columns]
    titles_arr = F.array(F.coalesce(*[F.col(c).cast("string") for c in single_candidates]))

# 2) Explode titles that are present (non-empty after trim)
titles_from_rows = (
    df_sc.select("email", F.explode_outer(titles_arr).alias("raw_title"),
                 "source_id", "document_id")
         .withColumn("raw_title", F.when(F.length(F.trim(F.col("raw_title"))) > 0, F.col("raw_title")))
)

# 3) Per-row fallback when title is missing/empty
fallback_key = F.concat_ws("-", F.col("source_id").cast("string"), F.col("document_id").cast("string"))
effective_raw = F.coalesce(titles_from_rows["raw_title"], fallback_key)

# 4) Stronger normalization (collapse punctuation/whitespace differences)
norm = F.lower(F.trim(F.regexp_replace(effective_raw, r"\s+", " ")))

titles = (
    titles_from_rows
      .select("email", norm.alias("breach_title_norm"))
      .filter(F.col("email").isNotNull() & (F.col("breach_title_norm") != ""))
      .dropDuplicates(["email", "breach_title_norm"])
)

df_spycloud_risk = (
    titles.groupBy("email")
          .agg(F.count("*").cast("double").alias("DarkwebBreachedCredentialRisk"))
)

if restrict_to_active_ad:
    df_spycloud_risk = df_spycloud_risk.join(df_ad.select("email").distinct(), "email", "inner")

# Exceptions -> counts
df_exceptions_risk = (
    df_exceptions.groupBy("email")
        .agg(F.countDistinct("Risk_1_10").alias("SecurityExceptionRisk"))
        .withColumn("SecurityExceptionRisk", F.col("SecurityExceptionRisk").cast("double"))
)

# ─────────────────────────────────────────────
# Step 3: Build Risk Base Table
# ─────────────────────────────────────────────
df_ad_filtered = (
    df_ad.filter(
        (F.col("Enabled") == F.lit(True)) &
        F.col("email").isNotNull() &
        (F.col("email") != F.lit("sokhinaadm"))
    )
    .select("email", "DisplayName", "Enabled", "RoleRisk", "DepartmentRisk")
)

df_base = (
    df_ad_filtered
      .join(df_splunk, "email", "left")
      .join(df_kb4_latest, "email", "left")
      .join(df_spycloud_risk, "email", "left")
      .join(df_exceptions_risk, "email", "left")
)

# Placeholders like SP
df_base = (
    df_base
      .withColumn("MultipleHMCEndpointRisk", F.lit(0.0))
      .withColumn("MultipleBYODEndpointRisk", F.lit(0.0))
      .withColumn("BOYDOutofComplianceRisk", F.lit(0.0))
      .withColumn("PrivilidgedAccountRisk", F.lit(0.0))
      .withColumn("AdminstrativeAccessAccountRisk", F.lit(0.0))
)

# Fill numeric nulls (except leave SpamRatio as NULL when denom==0)
numeric_cols = [f.name for f in df_base.schema.fields if isinstance(f.dataType, _DoubleType)]
numeric_cols_wo_spamratio = [c for c in numeric_cols if c != "PrimaryEmailProtectionSpamRisk"]
if numeric_cols_wo_spamratio:
    df_base = df_base.fillna(0.0, subset=numeric_cols_wo_spamratio)

# SP-like flags (no case-duplicate of DisplayName)
df_base = (
    df_base
      .withColumn(
          "IsActive",
          F.when(F.col("Enabled") == F.lit(True), F.lit(1)).otherwise(F.lit(0))
      )
)

# ─────────────────────────────────────────────
# Step 4: Apply Risk Classifications (SP rules)
# ─────────────────────────────────────────────
def apply_limit_rules(df, column, limit_row):
    return (
        df.withColumn(
            f"{column}Level",
            F.when(F.col(column).isNull() | (F.col(column) <= F.lit(limit_row["VeryLowLimit_Decimal"])), F.lit(1))
             .when(F.col(column) <= F.lit(limit_row["LowLimit_Decimal"]), F.lit(2))
             .when(F.col(column) <= F.lit(limit_row["MediumLimit_Decimal"]), F.lit(3))
             .when(F.col(column) <= F.lit(limit_row["HighLimit_Decimal"]), F.lit(4))
             .otherwise(F.lit(5))
        )
        .withColumn(f"{column}Multiplier", F.lit(limit_row["LimitImportance"]))
        .withColumn(f"{column}AcceptableLevel", F.lit(limit_row["HMCAcceptableValue"]))
    )

def apply_string_limit_rules(df, column, limit_row):
    very_low = [x.strip() for x in (limit_row.get("VeryLowLimit_String") or "").split(",") if x.strip()]
    low      = [x.strip() for x in (limit_row.get("LowLimit_String") or "").split(",") if x.strip()]
    medium   = [x.strip() for x in (limit_row.get("MediumLimit_String") or "").split(",") if x.strip()]
    high     = [x.strip() for x in (limit_row.get("HighLimit_String") or "").split(",") if x.strip()]
    return (
        df.withColumn(
            f"{column}Level",
            F.when(F.col(column).isNull() | F.col(column).isin(very_low), F.lit(1))
             .when(F.col(column).isin(low), F.lit(2))
             .when(F.col(column).isin(medium), F.lit(3))
             .when(F.col(column).isin(high), F.lit(4))
             .otherwise(F.lit(5))
        )
        .withColumn(f"{column}Multiplier", F.lit(limit_row["LimitImportance"]))
        .withColumn(f"{column}AcceptableLevel", F.lit(limit_row["HMCAcceptableValue"]))
    )

limit_map = {
    "Longevity": "EmploymentMonthsRisk",
    "Phishing Failure": "PhishingRisk",
    "Role": "RoleRisk",
    "Department": "DepartmentRisk",
    "Primary Email Protection - Malware": "PrimaryEmailProtectionMalwareRisk",
    "Primary Email Protection - Phishing": "PrimaryEmailProtectionPhishingRisk",
    "Primary Email Protection - Spam": "PrimaryEmailProtectionSpamRisk",
    "Primary Email Protection - Suspicious": "PrimaryEmailProtectionSuspiciousRisk",
    "Secondary Email Protection - Malware": "SecondaryEmailProtectionMalwareRisk",
    "Secondary Email Protection - Phishing": "SecondaryEmailProtectionPhishingRisk",
    "Secondary Email Protection - Social Engineering": "SecondaryEmailProtectionSocialEngineeringRisk",
    "Secondary Email Protection - Spam": "SecondaryEmailProtectionSpamRisk",
    "Secondary Email Protection - Suspicious": "SecondaryEmailProtectionSuspiciousRisk",
    "Privilidged Account Access": "PrivilidgedAccountRisk",
    "Administrative Account Access": "AdminstrativeAccessAccountRisk",
    "Darkweb Breach": "DarkwebBreachedCredentialRisk",
    "Security Exceptions": "SecurityExceptionRisk",
    "Multiple Endpoints": "MultipleHMCEndpointRisk",
    "Multiple BYOD Endpoints": "MultipleBYODEndpointRisk",
    "Endpoint Out of Compliance": "BOYDOutofComplianceRisk"
}

for limit_name, metric in limit_map.items():
    row = df_limits.filter(F.col("LimitName") == F.lit(limit_name)).first()
    if row:
        row_dict = row.asDict()
        if limit_name in ["Role", "Department"]:
            df_base = apply_string_limit_rules(df_base, metric, row_dict)
        else:
            df_base = apply_limit_rules(df_base, metric, row_dict)

# ─────────────────────────────────────────────
# Step 5: Final Risk Score Calculation (SP formula)
# ─────────────────────────────────────────────
importance_sum_row = df_limits.selectExpr("SUM(LimitImportance) * 5 as divisor").first()
importance_sum = importance_sum_row["divisor"] if importance_sum_row else None
if not importance_sum or importance_sum == 0:
    raise ValueError("LimitImportance sum is missing or zero; check Bronze/CyberDashboardLimits.")

risk_components = list(limit_map.values())

df_base = df_base.withColumn(
    "TotalHMCUserRisk",
    (
        reduce(
            lambda acc, x: acc + F.col(f"{x}Level") * F.col(f"{x}Multiplier"),
            risk_components[1:],
            F.col(f"{risk_components[0]}Level") * F.col(f"{risk_components[0]}Multiplier")
        ) / F.lit(importance_sum)
    )
)

df_base = df_base.withColumn(
    "TotalHMCDefaultRisk",
    reduce(
        lambda acc, x: acc + F.col(f"{x}AcceptableLevel") * F.col(f"{x}Multiplier"),
        risk_components[1:],
        F.col(f"{risk_components[0]}AcceptableLevel") * F.col(f"{risk_components[0]}Multiplier")
    ) / F.lit(importance_sum)
)

# Aliases for SP-style names
df_base = (
    df_base
      .withColumn("HMCUserIdentifier", F.col("email"))
      .withColumn("UserName", F.col("DisplayName"))
)

# ─────────────────────────────────────────────
# Step 6: Casts matching SP intent & column ordering
# ─────────────────────────────────────────────
def cast_for_sp(df):
    counts_as_long = [
        "DarkwebBreachedCredentialRisk",
        "SecurityExceptionRisk",
        "ExternalMailsReceived",
        "TotalHeldEmails",
        "PrimaryEmailProtectionMalwareRisk",
        "PrimaryEmailProtectionPhishingRisk",
        "PrimaryEmailProtectionSuspiciousRisk",
        "SecondaryEmailProtectionMalwareRisk",
        "SecondaryEmailProtectionPhishingRisk",
        "SecondaryEmailProtectionSocialEngineeringRisk",
        "SecondaryEmailProtectionSpamRisk",
        "SecondaryEmailProtectionSuspiciousRisk",
        "MultipleHMCEndpointRisk",
        "MultipleBYODEndpointRisk",
        "BOYDOutofComplianceRisk",
        "PrivilidgedAccountRisk",
        "AdminstrativeAccessAccountRisk",
    ]
    ratios_as_double = [
        "PrimaryEmailProtectionSpamRisk",
        "PhishingRisk",
    ]
    ints_as_int = ["EmploymentMonthsRisk", "IsActive"]
    strings_as_string = ["email","HMCUserIdentifier","DisplayName","UserName","RoleRisk","DepartmentRisk"]

    for c in strings_as_string:
        if c in df.columns: df = df.withColumn(c, F.col(c).cast("string"))
    for c in ints_as_int:
        if c in df.columns: df = df.withColumn(c, F.col(c).cast("int"))
    for c in counts_as_long:
        if c in df.columns: df = df.withColumn(c, F.col(c).cast("long"))
    for c in ratios_as_double:
        if c in df.columns: df = df.withColumn(c, F.col(c).cast("double"))

    for c in df.columns:
        if c.endswith("Level"): df = df.withColumn(c, F.col(c).cast("int"))
        if c.endswith("Multiplier"): df = df.withColumn(c, F.col(c).cast("int"))
        if c.endswith("AcceptableLevel"): df = df.withColumn(c, F.col(c).cast("double"))

    if "TotalHMCUserRisk" in df.columns:
        df = df.withColumn("TotalHMCUserRisk", F.col("TotalHMCUserRisk").cast("double"))
    if "TotalHMCDefaultRisk" in df.columns:
        df = df.withColumn("TotalHMCDefaultRisk", F.col("TotalHMCDefaultRisk").cast("double"))
    return df

def order_like_sp(df):
    # Identity up front
    ordered = ["HMCUserIdentifier","DisplayName","IsActive"]
    # In SP order:
    base_metrics = [
        "EmploymentMonthsRisk",
        "PhishingRisk",
        "RoleRisk",
        "DepartmentRisk",
        "PrimaryEmailProtectionMalwareRisk",
        "PrimaryEmailProtectionPhishingRisk",
        "PrimaryEmailProtectionSpamRisk",
        "PrimaryEmailProtectionSuspiciousRisk",
        "SecondaryEmailProtectionMalwareRisk",
        "SecondaryEmailProtectionPhishingRisk",
        "SecondaryEmailProtectionSocialEngineeringRisk",
        "SecondaryEmailProtectionSpamRisk",
        "SecondaryEmailProtectionSuspiciousRisk",
        "PrivilidgedAccountRisk",
        "AdminstrativeAccessAccountRisk",
        "DarkwebBreachedCredentialRisk",
        "SecurityExceptionRisk",
        "MultipleHMCEndpointRisk",
        "MultipleBYODEndpointRisk",
        "BOYDOutofComplianceRisk",
    ]
    for m in base_metrics:
        if m in df.columns:
            ordered.append(m)
            for suffix in ["Level","Multiplier","AcceptableLevel"]:
                colname = f"{m}{suffix}"
                if colname in df.columns:
                    ordered.append(colname)
    # Totals next
    for c in ["TotalHMCUserRisk","TotalHMCDefaultRisk"]:
        if c in df.columns: ordered.append(c)
    # Remaining columns (if any)
    remainder = [c for c in df.columns if c not in ordered]
    return df.select([c for c in ordered if c in df.columns] + remainder)

# Multiply TotalHMCUserRisk by 100 if it exists
if "TotalHMCUserRisk" in df_base.columns:
    df_base = df_base.withColumn("TotalHMCUserRisk", F.col("TotalHMCUserRisk") * 100)

# Final cast, order, dedupe
df_base_final = order_like_sp(cast_for_sp(df_base)).dropDuplicates(["email"])


# ─────────────────────────────────────────────
# Step 7: Write user-level & org summary (Delta to Curated paths)
# ─────────────────────────────────────────────
user_rel  = "Silver/CyberSecurityUserRiskData"
user_path = tbl_path(curated_lh_id, user_rel)

(df_base_final.write
    .mode("overwrite")
    .format("delta")
    .option("overwriteSchema", "true")
    .save(user_path)
)

# Compute org summary from in-memory DF (no reload needed)
risk_summary = df_base_final.select(
    (F.sum("TotalHMCUserRisk") / F.count("TotalHMCUserRisk")).alias("HMCTotalUserRisk"),
    (F.sum("TotalHMCDefaultRisk") / F.count("TotalHMCUserRisk")).alias("HMCDefaultUserRisk")
)

summary_rel  = "Silver/CyberSecurityUserAndDefaultRisk"
summary_path = tbl_path(curated_lh_id, summary_rel)

(risk_summary.write
    .mode("overwrite")
    .format("delta")
    .option("overwriteSchema", "true")
    .save(summary_path)
)

print(f"✅ Wrote user risk data to {user_path}")
print(f"✅ Wrote org summary to {summary_path}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
