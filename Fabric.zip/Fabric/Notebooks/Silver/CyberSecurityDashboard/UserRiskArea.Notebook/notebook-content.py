# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql.types import StringType, DoubleType, ArrayType
from functools import reduce
from pyspark.sql import DataFrame

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# =============================
# Inputs & Base DF
# =============================
user_risk_df = read_delta(curated_lh_id, "Silver/CyberSecurityUserRiskData")

DEFAULT_ACCEPTABLE_LEVEL = 1.0
restrict_to_active_ad = True     # only count breaches for users present in base_df
min_exposures = 1                # >=1 distinct breach title => impacted

# Bronze sources
sp = read_delta(bronze_lh_id, "Bronze/CyberDashboardSpyCloud")
dashboard_df = read_delta(bronze_lh_id, "Bronze/CyberDashboardLimits")


def ensure_display_name(df):
    cols = set(df.columns)
    # Prefer "surname, givenName" (your standard)
    if {"surname", "givenName"}.issubset(cols):
        return df.withColumn("DisplayName", F.concat_ws(", ", F.col("surname"), F.col("givenName")))
    # Otherwise keep existing if present
    if "DisplayName" in cols:
        return df.withColumn("DisplayName", F.col("DisplayName"))
    if "Displayname" in cols:
        return df.withColumn("DisplayName", F.col("Displayname"))
    # Fallbacks
    fallback = next((c for c in ["name", "UserName", "userPrincipalName"] if c in cols), None)
    return df.withColumn("DisplayName", F.coalesce(F.col(fallback), F.col("email")) if fallback else F.col("email"))


# Normalize email with common fallbacks
email_candidates = [c for c in ["email", "mail", "user_email"] if c in user_risk_df.columns]
if not email_candidates:
    raise ValueError("No email-like column found in user_risk_df (expected one of: email, mail, user_email)")

base_df = user_risk_df.withColumn(
    "email",
    F.lower(F.trim(F.coalesce(*[F.col(c) for c in email_candidates])))
)
base_df = ensure_display_name(base_df)


# =============================
# Limits / Importance parsing
# =============================

# Standardize naming (RiskName vs LimitName)
if "LimitName" not in dashboard_df.columns and "RiskName" in dashboard_df.columns:
    dashboard_df = dashboard_df.withColumnRenamed("RiskName", "LimitName")

# Importance normalization
importance_col = "LimitImportance" if "LimitImportance" in dashboard_df.columns else "Importance"

def normalize_importance(colname):
    return (
        F.when(F.col(colname).cast("int").isNotNull(), F.col(colname).cast("int"))
         .otherwise(
             F.when(F.lower(F.col(colname)).contains("very low"), 1)
              .when(F.lower(F.col(colname)).contains("low"), 2)
              .when(F.lower(F.col(colname)).contains("medium"), 3)
              .when(F.lower(F.col(colname)).contains("high") & ~F.lower(F.col(colname)).contains("very"), 4)
              .when(F.lower(F.col(colname)).contains("very high"), 5)
              .otherwise(F.lit(3))
         )
    )

dashboard_df = dashboard_df.withColumn("ImportanceNorm", normalize_importance(importance_col))

def upper_bound_str(colname):
    return F.regexp_extract(F.col(colname), r'([0-9]+(?:\.[0-9]+)?)\s*$', 1).cast("double")

def first_existing(*names):
    for n in names:
        if n in dashboard_df.columns:
            return F.col(n)
    return F.lit(None).cast("double")

ub_vlow = F.coalesce(
    first_existing("VeryLowLimit_Decimal"),
    upper_bound_str("VeryLowLimit_String") if "VeryLowLimit_String" in dashboard_df.columns else
    upper_bound_str("Very_Low_Limit") if "Very_Low_Limit" in dashboard_df.columns else
    F.lit(None).cast("double")
)
ub_low  = F.coalesce(
    first_existing("LowLimit_Decimal"),
    upper_bound_str("LowLimit_String") if "LowLimit_String" in dashboard_df.columns else
    upper_bound_str("Low_Limit") if "Low_Limit" in dashboard_df.columns else
    F.lit(None).cast("double")
)
ub_med  = F.coalesce(
    first_existing("MediumLimit_Decimal"),
    upper_bound_str("MediumLimit_String") if "MediumLimit_String" in dashboard_df.columns else
    upper_bound_str("Medium_Limit") if "Medium_Limit" in dashboard_df.columns else
    F.lit(None).cast("double")
)
ub_high = F.coalesce(
    first_existing("HighLimit_Decimal"),
    upper_bound_str("HighLimit_String") if "HighLimit_String" in dashboard_df.columns else
    upper_bound_str("High_Limit") if "High_Limit" in dashboard_df.columns else
    F.lit(None).cast("double")
)

limits_parsed = dashboard_df.select(
    "LimitName",
    F.col("LimitType"),
    ub_vlow.alias("ub_vlow"),
    ub_low.alias("ub_low"),
    ub_med.alias("ub_med"),
    ub_high.alias("ub_high"),
    F.col("ImportanceNorm").alias("LimitImportance")
)


# =============================
# Build distinct dark web breach counts per email
# =============================
sp = sp.withColumn("email", F.lower(F.trim(F.col("email"))))

# Build an array column of breach titles robustly
breach_arr = None

if "breach_titles" in sp.columns:
    dt = sp.schema["breach_titles"].dataType
    if isinstance(dt, ArrayType):
        breach_arr = F.col("breach_titles")
    elif isinstance(dt, StringType):
        parsed = F.from_json(F.col("breach_titles"), ArrayType(StringType()))
        sp = sp.withColumn("breach_titles_parsed", parsed)
        breach_arr = F.when(F.size(F.col("breach_titles_parsed")) > 0, F.col("breach_titles_parsed"))

# If still no array, use singular column
if breach_arr is None and "breach_title" in sp.columns:
    breach_arr = F.array(F.col("breach_title").cast("string"))

# Last resort: split on ";" or "|"
if breach_arr is None:
    for c in ["breach", "source_name", "sources", "breaches"]:
        if c in sp.columns:
            breach_arr = F.split(F.col(c).cast("string"), r"\s*[;|]\s*")
            break

# If still None, use empty array so explode_outer yields 0 rows
if breach_arr is None:
    breach_arr = F.expr("array()")

breaches = (
    sp.select("email", F.explode_outer(breach_arr).alias("breach_title"))
      .withColumn(
          "breach_title_norm",
          F.lower(F.trim(F.regexp_replace(F.col("breach_title").cast("string"),
                                          r'^[\[\]"]+|[\[\]"]+$', "")))
      )
      .filter((F.col("email").isNotNull()) & (F.col("breach_title_norm") != ""))
      .dropDuplicates(["email", "breach_title_norm"])
)

darkweb_counts = breaches.groupBy("email").agg(
    F.count("*").alias("darkweb_breach_count")
)

if restrict_to_active_ad:
    active_users = base_df.select(F.lower(F.trim(F.col("email"))).alias("email")).distinct()
    darkweb_counts = darkweb_counts.join(active_users, "email", "inner")

base_df = (
    base_df.alias("u")
      .join(darkweb_counts.alias("d"),
            F.lower(F.trim(F.col("u.email"))) == F.col("d.email"),
            "left")
      .drop(F.col("d.email"))
      .withColumn(
          "DarkwebBreachedCredentialRisk",
          F.coalesce(F.col("darkweb_breach_count").cast("double"), F.lit(0.0))
      )
)


# =============================
# Scoring guardrails per risk
# =============================
def apply_limits_if_missing(df, metric, level, multiplier, acceptable, limit_name, default_accept=1.0):
    have_all = {level, multiplier, acceptable}.issubset(df.columns)
    if have_all:
        return df

    lim = limits_parsed.filter(F.col("LimitName") == F.lit(limit_name)).first()
    if not lim:
        v1, v2, v3, v4, imp = 1.0, 2.0, 3.0, 5.0, 3
    else:
        v1, v2, v3, v4, imp = lim["ub_vlow"], lim["ub_low"], lim["ub_med"], lim["ub_high"], lim["LimitImportance"]
        v1 = v1 if v1 is not None else 1.0
        v2 = v2 if v2 is not None else 2.0
        v3 = v3 if v3 is not None else 3.0
        v4 = v4 if v4 is not None else 5.0
        imp = int(imp) if imp is not None else 3

    return (
        df.withColumn(
            level,
            F.when(F.col(metric).isNull() | (F.col(metric) <= F.lit(v1)), F.lit(1))
             .when(F.col(metric) <= F.lit(v2), F.lit(2))
             .when(F.col(metric) <= F.lit(v3), F.lit(3))
             .when(F.col(metric) <= F.lit(v4), F.lit(4))
             .otherwise(F.lit(5))
        )
        .withColumn(multiplier, F.lit(imp))
        .withColumn(acceptable, F.lit(default_accept).cast("double"))
    )


# =============================
# Risk mappings
# =============================
risk_mappings = [
    ("EmploymentMonthsRisk", "EmploymentMonthsRiskLevel", "EmploymentMonthsRiskMultiplier", "EmploymentMonthsRiskAcceptableLevel", "Longevity"),
    ("PhishingRisk", "PhishingRiskLevel", "PhishingRiskMultiplier", "PhishingRiskAcceptableLevel", "Phishing Failure"),
    ("RoleRisk", "RoleRiskLevel", "RoleRiskMultiplier", "RoleRiskAcceptableLevel", "Role"),
    ("DepartmentRisk", "DepartmentRiskLevel", "DepartmentRiskMultiplier", "DepartmentRiskAcceptableLevel", "Department"),

    ("PrimaryEmailProtectionMalwareRisk", "PrimaryEmailProtectionMalwareRiskLevel", "PrimaryEmailProtectionMalwareRiskMultiplier", "PrimaryEmailProtectionMalwareRiskAcceptableLevel", "Primary Email Protection - Malware"),
    ("PrimaryEmailProtectionPhishingRisk", "PrimaryEmailProtectionPhishingRiskLevel", "PrimaryEmailProtectionPhishingRiskMultiplier", "PrimaryEmailProtectionPhishingRiskAcceptableLevel", "Primary Email Protection - Phishing"),
    ("PrimaryEmailProtectionSpamRisk", "PrimaryEmailProtectionSpamRiskLevel", "PrimaryEmailProtectionSpamRiskMultiplier", "PrimaryEmailProtectionSpamRiskAcceptableLevel", "Primary Email Protection - Spam"),
    ("PrimaryEmailProtectionSuspiciousRisk", "PrimaryEmailProtectionSuspiciousRiskLevel", "PrimaryEmailProtectionSuspiciousRiskMultiplier", "PrimaryEmailProtectionSuspiciousRiskAcceptableLevel", "Primary Email Protection - Suspicious"),

    ("SecondaryEmailProtectionMalwareRisk", "SecondaryEmailProtectionMalwareRiskLevel", "SecondaryEmailProtectionMalwareRiskMultiplier", "SecondaryEmailProtectionMalwareRiskAcceptableLevel", "Secondary Email Protection - Malware"),
    ("SecondaryEmailProtectionPhishingRisk", "SecondaryEmailProtectionPhishingRiskLevel", "SecondaryEmailProtectionPhishingRiskMultiplier", "SecondaryEmailProtectionPhishingRiskAcceptableLevel", "Secondary Email Protection - Phishing"),
    ("SecondaryEmailProtectionSocialEngineeringRisk", "SecondaryEmailProtectionSocialEngineeringRiskLevel", "SecondaryEmailProtectionSocialEngineeringRiskMultiplier", "SecondaryEmailProtectionSocialEngineeringRiskAcceptableLevel", "Secondary Email Protection - Social Engineering"),
    ("SecondaryEmailProtectionSpamRisk", "SecondaryEmailProtectionSpamRiskLevel", "SecondaryEmailProtectionSpamRiskMultiplier", "SecondaryEmailProtectionSpamRiskAcceptableLevel", "Secondary Email Protection - Spam"),
    ("SecondaryEmailProtectionSuspiciousRisk", "SecondaryEmailProtectionSuspiciousRiskLevel", "SecondaryEmailProtectionSuspiciousRiskMultiplier", "SecondaryEmailProtectionSuspiciousRiskAcceptableLevel", "Secondary Email Protection - Suspicious"),

    ("PrivilidgedAccountRisk", "PrivilidgedAccountRiskLevel", "PrivilidgedAccountRiskMultiplier", "PrivilidgedAccountRiskAcceptableLevel", "Privilidged Account Access"),
    ("AdminstrativeAccessAccountRisk", "AdminstrativeAccessAccountRiskLevel", "AdminstrativeAccessAccountRiskMultiplier", "AdminstrativeAccessAccountRiskAcceptableLevel", "Administrative Account Access"),
    ("DarkwebBreachedCredentialRisk", "DarkwebBreachedCredentialRiskLevel", "DarkwebBreachedCredentialRiskMultiplier", "DarkwebBreachedCredentialRiskAcceptableLevel", "Darkweb Breach"),
    ("SecurityExceptionRisk", "SecurityExceptionRiskLevel", "SecurityExceptionRiskMultiplier", "SecurityExceptionRiskAcceptableLevel", "Security Exceptions"),
    ("MultipleHMCEndpointRisk", "MultipleHMCEndpointRiskLevel", "MultipleHMCEndpointRiskMultiplier", "MultipleHMCEndpointRiskAcceptableLevel", "Multiple Endpoints"),
    ("MultipleBYODEndpointRisk", "MultipleBYODEndpointRiskLevel", "MultipleBYODEndpointRiskMultiplier", "MultipleBYODEndpointRiskAcceptableLevel", "Multiple BYOD Endpoints"),
    ("BOYDOutofComplianceRisk", "BOYDOutofComplianceRiskLevel", "BOYDOutofComplianceRiskMultiplier", "BOYDOutofComplianceRiskAcceptableLevel", "Endpoint Out of Compliance"),
]
_bad = [t for t in risk_mappings if len(t) != 5]
if _bad:
    raise ValueError(f"risk_mappings entries must be 5-tuples; found malformed: {_bad}")

for metric, level, mult, acc, name in risk_mappings:
    base_df = apply_limits_if_missing(base_df, metric, level, mult, acc, name, default_accept=DEFAULT_ACCEPTABLE_LEVEL)


# =============================
# Helpers
# =============================
def importance_label(col_):
    return (F.when(col_ == 1, "Very Low Importance")
             .when(col_ == 2, "Low Importance")
             .when(col_ == 3, "Medium Importance")
             .when(col_ == 4, "High Importance")
             .otherwise("Very High Importance"))

def accepted_level_label(col_):
    return (F.when(col_ == 1, "Very Low Risk")
             .when(col_ == 2, "Low Risk")
             .when(col_ == 3, "Medium Risk")
             .when(col_ == 4, "High Risk")
             .otherwise("Very High Risk"))

def risk_level_label(col_):
    return (F.when(col_ == 1, "Very Low Risk")
             .when(col_ == 2, "Low Risk")
             .when(col_ == 3, "Medium Risk")
             .when(col_ == 4, "High Risk")
             .otherwise("Very High Risk"))


# =============================
# Per-user, per-risk detail rows
# =============================
risk_rows = []
for metric, level, multiplier, acceptable, name in risk_mappings:
    risk_name_lit = F.lit(name)
    acceptable_col = F.coalesce(F.col(acceptable), F.lit(DEFAULT_ACCEPTABLE_LEVEL)).cast(DoubleType())

    percentified = F.concat(F.round(F.col(metric) * 100, 0).cast("int").cast("string"), F.lit('%'))
    riskvalue2 = F.when(risk_name_lit.isin("Phishing Failure", "Primary Email Protection - Spam"), percentified) \
                  .otherwise(F.col(metric).cast(StringType()))

    df = base_df.select(
        F.col("email").alias("HMCUserIdentifier"),
        F.col("DisplayName"),
        risk_name_lit.alias("RiskName"),
        F.col(metric).cast(StringType()).alias("RiskValue"),
        riskvalue2.alias("RiskValue2"),
        acceptable_col.alias("AcceptableLevel"),
        F.col(level).cast(DoubleType()).alias("RiskLevel"),
        F.col(multiplier).cast(DoubleType()).alias("RiskMultiplier"),
        (F.col(level) * F.col(multiplier)).cast(DoubleType()).alias("OverallRisk")
    )
    risk_rows.append(df)

risk_result_df = reduce(DataFrame.unionByName, risk_rows)


# =============================
# Summary
# =============================
results_df = (
    risk_result_df
      .groupBy("RiskName")
      .agg(
          F.avg("RiskLevel").alias("UserAverage"),
          F.avg("OverallRisk").alias("ExpandedRisk"),
          F.avg("AcceptableLevel").alias("AcceptedRiskLevel")
      )
      .withColumn("RiskGap", F.col("UserAverage") - F.col("AcceptedRiskLevel"))
      .withColumn("ARLDef", accepted_level_label(F.col("AcceptedRiskLevel")))
)

# Impacted Users (non-Darkweb via rule; Darkweb via breach-title counts)
impacted_counts_df = (
    risk_result_df
      .where(F.col("RiskLevel") > F.col("AcceptableLevel"))
      .groupBy("RiskName")
      .agg(F.countDistinct("HMCUserIdentifier").alias("ImpactedUsers"))
)

darkweb_impacted = (
    darkweb_counts
      .filter(F.col("darkweb_breach_count") >= F.lit(min_exposures))
      .select("email").distinct().count()
)

darkweb_impacted_df = spark.createDataFrame([("Darkweb Breach", darkweb_impacted)], ["RiskName", "ImpactedUsers"])

impacted_counts_df = (
    impacted_counts_df
      .filter(F.col("RiskName") != "Darkweb Breach")
      .unionByName(darkweb_impacted_df)
)

results_df = (
    results_df.drop("ImpactedUsers")
              .join(impacted_counts_df, on="RiskName", how="left")
              .fillna(0, subset=["ImpactedUsers"])
)

# Add numeric Importance and label
results_df = (
    results_df.join(
        dashboard_df.select(F.col("LimitName").alias("RiskName"), F.col("ImportanceNorm")),
        on="RiskName", how="left"
    )
    .withColumn("Importance", importance_label(F.col("ImportanceNorm")))
)


# =============================
# Detail table (pre-patch)
# =============================
risk_detail_df = (
    risk_result_df
      .withColumn(
          "NumericRiskValue",
          F.when(F.col("RiskValue").cast("double").isNotNull(), F.col("RiskValue").cast("double"))
           .otherwise(F.lit(None).cast("double"))
      )
      .withColumn("RLDef", risk_level_label(F.col("RiskLevel")))
      .join(dashboard_df.select(F.col("LimitName").alias("RiskName"), F.col("ImportanceNorm")), on="RiskName", how="left")
      .withColumn("Importance", importance_label(F.col("ImportanceNorm")))
      .withColumn("AcceptableLevelDef", accepted_level_label(F.col("AcceptableLevel")))
)


# =============================
# Patch: Recompute ONLY Phishing Failure levels using Bronze thresholds
# (apply to the in-memory detail DF before writing)
# =============================
lim_row = (
    dashboard_df
      .filter(F.col("LimitName") == F.lit("Phishing Failure"))
      .select(
          F.col("VeryLowLimit_Decimal").cast("double").alias("v1"),
          F.col("LowLimit_Decimal").cast("double").alias("v2"),
          F.col("MediumLimit_Decimal").cast("double").alias("v3"),
          F.col("HighLimit_Decimal").cast("double").alias("v4")
      )
      .first()
)

v1 = lim_row["v1"] if lim_row and lim_row["v1"] is not None else 0.01
v2 = lim_row["v2"] if lim_row and lim_row["v2"] is not None else 0.03
v3 = lim_row["v3"] if lim_row and lim_row["v3"] is not None else 0.04
v4 = lim_row["v4"] if lim_row and lim_row["v4"] is not None else 0.06

phish_name = F.col("RiskName").isin("Phishing Failure", "PhishingFailure")
x = F.col("NumericRiskValue")

new_level = (
    F.when(x.isNull() | (x <= F.lit(v1)), F.lit(1))
     .when(x <= F.lit(v2), F.lit(2))
     .when(x <= F.lit(v3), F.lit(3))
     .when(x <= F.lit(v4), F.lit(4))
     .otherwise(F.lit(5)).cast("double")
)
new_rldef = (
    F.when(new_level == 1, "Very Low Risk")
     .when(new_level == 2, "Low Risk")
     .when(new_level == 3, "Medium Risk")
     .when(new_level == 4, "High Risk")
     .otherwise("Very High Risk")
)

patched_detail_df = (
    risk_detail_df
      .withColumn("RiskLevel", F.when(phish_name, new_level).otherwise(F.col("RiskLevel")))
      .withColumn("RLDef", F.when(phish_name, new_rldef).otherwise(F.col("RLDef")))
      .withColumn(
          "OverallRisk",
          F.when(phish_name, F.col("RiskLevel") * F.col("RiskMultiplier")).otherwise(F.col("OverallRisk"))
      )
      .orderBy(F.col("RiskLevel").desc(), F.col("HMCUserIdentifier").asc())
)


# =============================
# Write outputs to Curated Lakehouse paths (Delta, overwrite)
# =============================
summary_rel  = "Silver/CyberSecurityUserRiskArea"
summary_path = tbl_path(curated_lh_id, summary_rel)

(results_df.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(summary_path)
)

detail_rel  = "Silver/CyberSecurityUserRiskAreaDetail"
detail_path = tbl_path(curated_lh_id, detail_rel)

(patched_detail_df.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(detail_path)
)

print(f"✅ Wrote summary to {summary_path}")
print(f"✅ Wrote detail to  {detail_path}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
