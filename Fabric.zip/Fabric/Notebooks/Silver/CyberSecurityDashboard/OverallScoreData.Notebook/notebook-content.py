# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, lit, when, concat_ws, count, sum as _sum,
    datediff, current_date, round as spark_round, to_date
    
)
from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

spark.conf.set("spark.sql.legacy.timeParserPolicy", "CORRECTED")

# ───────────────────────────────────────────────────────────────
# STEP 1: Load Tables (paths via Bronze/Curated base ids)
# ───────────────────────────────────────────────────────────────
risk_df   = read_delta(curated_lh_id, "Silver/CyberSecurityUserAndDefaultRisk")
limits_df = read_delta(bronze_lh_id,  "Bronze/CyberDashboardLimits")
manual_df = read_delta(bronze_lh_id,  "Bronze/CyberDashboardManualUpdates")


# ───────────────────────────────────────────────────────────────
# STEP 2: Manual Rule Violations
# ───────────────────────────────────────────────────────────────
reviewconverted_df = manual_df.withColumn(
    "DateValueConv", F.to_date(F.col("DateValue"), "MM/dd/yyyy")
)

review_df = (
    reviewconverted_df
      .filter(F.col("ManualFieldIdentifier") == F.lit("Last Group Membership Review"))
      .withColumn(
          "IsInFault",
          F.when(F.datediff(F.current_date(), F.col("DateValueConv")) > F.col("DateExceptionDays"), F.lit(1))
           .otherwise(F.lit(0))
      )
)

offboard_df = (
    manual_df
      .filter(F.col("ManualFieldIdentifier") == F.lit("Average Offboard Time"))
      .withColumn(
          "IsInFault",
          F.when(F.col("NumericValue") > F.col("NumericExceptionLimit"), F.lit(1))
           .otherwise(F.lit(0))
      )
)

manual_violations_df = review_df.select("IsInFault").unionByName(offboard_df.select("IsInFault"))

fault_count = manual_violations_df.filter(F.col("IsInFault") == 1).count()
adjustment = fault_count * 5


# ───────────────────────────────────────────────────────────────
# STEP 3: Get Risk Scores and Scale to 100
# ───────────────────────────────────────────────────────────────
risk_row = risk_df.select("HMCTotalUserRisk", "HMCDefaultUserRisk").first()
total_risk = (risk_row["HMCTotalUserRisk"] if risk_row else 0) + adjustment
acceptable_risk = (risk_row["HMCDefaultUserRisk"] if risk_row else 0) * 100


# ───────────────────────────────────────────────────────────────
# STEP 4: Dashboard Limits — Prepare Bands
# ───────────────────────────────────────────────────────────────
gauge_limits = (
    limits_df
      .filter(F.col("LimitName") == F.lit("DashboardUserGauge"))
      .select(
          F.col("VeryLowLimit_Decimal").alias("VeryLowLimitEnd"),
          F.col("LowLimit_Decimal").alias("LowLimitEnd"),
          F.col("MediumLimit_Decimal").alias("MediumLimitEnd"),
          F.col("HighLimit_Decimal").alias("HighLimitEnd"),
          F.col("VeryHighLimit_Decimal").alias("VeryHighLimitEnd")
      )
      .withColumn("VeryLowLimitStart", F.lit(0.0000))
      .withColumn("LowLimitStart",    F.col("VeryLowLimitEnd") + F.lit(0.0001))
      .withColumn("MediumLimitStart", F.col("LowLimitEnd")     + F.lit(0.0001))
      .withColumn("HighLimitStart",   F.col("MediumLimitEnd")  + F.lit(0.0001))
      .withColumn("VeryHighLimitStart", F.col("HighLimitEnd")  + F.lit(0.0001))
)


# ───────────────────────────────────────────────────────────────
# STEP 5: Build the "User" Score Row
# ───────────────────────────────────────────────────────────────
user_score_df = gauge_limits.select(
    F.lit("User").alias("OverallArea"),
    F.lit(total_risk).cast("decimal(20,4)").alias("HMCTotalScore"),
    F.lit(acceptable_risk).cast("decimal(20,4)").alias("TargetValue"),
    F.col("VeryLowLimitStart").cast("decimal(20,4)"),
    F.col("VeryLowLimitEnd").cast("decimal(20,4)"),
    F.col("LowLimitStart").cast("decimal(20,4)"),
    F.col("LowLimitEnd").cast("decimal(20,4)"),
    F.col("MediumLimitStart").cast("decimal(20,4)"),
    F.col("MediumLimitEnd").cast("decimal(20,4)"),
    F.col("HighLimitStart").cast("decimal(20,4)"),
    F.col("HighLimitEnd").cast("decimal(20,4)"),
    F.col("VeryHighLimitStart").cast("decimal(20,4)"),
    F.col("VeryHighLimitEnd").cast("decimal(20,4)")
)


# ───────────────────────────────────────────────────────────────
# STEP 6: "Overall" Score (Mode = 1)
# ───────────────────────────────────────────────────────────────
overall_raw = user_score_df.groupBy().agg(
    F.lit("Overall").alias("OverallArea"),
    (F.sum("HMCTotalScore") / F.count(F.lit(1))).alias("HMCTotalScore"),
    (F.sum("TargetValue")   / F.count(F.lit(1))).alias("TargetValue"),
    (F.sum("VeryLowLimitStart") / F.count(F.lit(1))).alias("VeryLowLimitStart"),
    (F.sum("VeryLowLimitEnd")   / F.count(F.lit(1))).alias("VeryLowLimitEnd"),
    (F.sum("LowLimitStart")     / F.count(F.lit(1))).alias("LowLimitStart"),
    (F.sum("LowLimitEnd")       / F.count(F.lit(1))).alias("LowLimitEnd"),
    (F.sum("MediumLimitStart")  / F.count(F.lit(1))).alias("MediumLimitStart"),
    (F.sum("MediumLimitEnd")    / F.count(F.lit(1))).alias("MediumLimitEnd"),
    (F.sum("HighLimitStart")    / F.count(F.lit(1))).alias("HighLimitStart"),
    (F.sum("HighLimitEnd")      / F.count(F.lit(1))).alias("HighLimitEnd"),
    (F.sum("VeryHighLimitStart")/ F.count(F.lit(1))).alias("VeryHighLimitStart"),
    (F.sum("VeryHighLimitEnd")  / F.count(F.lit(1))).alias("VeryHighLimitEnd")
)

overall_score_df = overall_raw.select(
    F.col("OverallArea"),
    F.round(F.col("HMCTotalScore"), 4).cast("decimal(20,4)").alias("HMCTotalScore"),
    F.round(F.col("TargetValue"), 4).cast("decimal(20,4)").alias("TargetValue"),
    F.round(F.col("VeryLowLimitStart"), 4).cast("decimal(20,4)").alias("VeryLowLimitStart"),
    F.round(F.col("VeryLowLimitEnd"), 4).cast("decimal(20,4)").alias("VeryLowLimitEnd"),
    F.round(F.col("LowLimitStart"), 4).cast("decimal(20,4)").alias("LowLimitStart"),
    F.round(F.col("LowLimitEnd"), 4).cast("decimal(20,4)").alias("LowLimitEnd"),
    F.round(F.col("MediumLimitStart"), 4).cast("decimal(20,4)").alias("MediumLimitStart"),
    F.round(F.col("MediumLimitEnd"), 4).cast("decimal(20,4)").alias("MediumLimitEnd"),
    F.round(F.col("HighLimitStart"), 4).cast("decimal(20,4)").alias("HighLimitStart"),
    F.round(F.col("HighLimitEnd"), 4).cast("decimal(20,4)").alias("HighLimitEnd"),
    F.round(F.col("VeryHighLimitStart"), 4).cast("decimal(20,4)").alias("VeryHighLimitStart"),
    F.round(F.col("VeryHighLimitEnd"), 4).cast("decimal(20,4)").alias("VeryHighLimitEnd")
)


# ───────────────────────────────────────────────────────────────
# STEP 7: Combine & Write Final Output
# ───────────────────────────────────────────────────────────────
final_df = user_score_df.unionByName(overall_score_df)

target_rel  = "Silver/CyberSecurityOverallScore"
target_path = tbl_path(curated_lh_id, target_rel)

(final_df.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(target_path)
)

print(f"✅ Wrote CyberSecurityOverallScore to {target_path}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
