# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from functools import reduce

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# ---- Load sources via Bronze/Curated base paths ----
user_risk_df = read_delta(curated_lh_id, "Silver/CyberSecurityUserRiskData")
entra_df     = read_delta(bronze_lh_id,  "Bronze/EntraUsers")
limits_df    = read_delta(bronze_lh_id,  "Bronze/CyberDashboardLimits").withColumnRenamed("LimitName", "RiskName")

# --- NEW: bring in normalized KB4 phishing (0–1) and overwrite PhishingRisk upstream
kb4_df = (
    read_delta(curated_lh_id, "Silver/CyberSecurityKnowBe4Data")
         .select(F.lower(F.col("email")).alias("email"), "phish_prone_percentage")
         .withColumn(
             "PhishingRisk_from_kb4",
             F.when(F.col("phish_prone_percentage").isNull(), F.lit(None).cast("double"))
              .when(F.col("phish_prone_percentage") > 1, F.col("phish_prone_percentage") / 100.0)
              .otherwise(F.col("phish_prone_percentage"))
         )
         .drop("phish_prone_percentage")
)

# ---- Build Displayname = "Surname, GivenName" and normalize email for join ----
entra_prepared_df = entra_df.select(
    F.lower(F.col("mail")).alias("email"),
    F.concat_ws(", ", F.col("surname"), F.col("givenName")).alias("FormattedDisplayName")
)

# Drop stale Displayname; normalize email
user_risk_df = user_risk_df.drop("Displayname").withColumn("email", F.lower(F.col("email")))

# --- Overwrite PhishingRisk with canonical normalized value
user_risk_df = (
    user_risk_df.alias("u")
      .join(kb4_df.alias("k"), on="email", how="left")
      .withColumn("PhishingRisk", F.coalesce(F.col("k.PhishingRisk_from_kb4"), F.col("u.PhishingRisk")))
      .drop("PhishingRisk_from_kb4")
)

# Join and SELECT explicitly to avoid duplicates
joined_df = (
    user_risk_df.alias("u")
      .join(entra_prepared_df.alias("e"), F.col("u.email") == F.col("e.email"), "inner")
      .select(
          F.col("u.*"),
          F.col("e.FormattedDisplayName").alias("Displayname")
      )
)

# ---- Discover ALL available base metrics from the wide table ----
all_cols = set(joined_df.columns)
def is_base_metric(c: str) -> bool:
    return (
        c.endswith("Risk")
        and f"{c}Level" in all_cols
        and f"{c}Multiplier" in all_cols
        and f"{c}AcceptableLevel" in all_cols
    )

discovered_metrics = [c for c in joined_df.columns if is_base_metric(c)]

pretty_map = {
    "EmploymentMonthsRisk": "Longevity",
    "PhishingRisk": "Phishing Failure",
    "RoleRisk": "Role",
    "DepartmentRisk": "Department",
    "PrimaryEmailProtectionMalwareRisk": "Primary Email Protection - Malware",
    "PrimaryEmailProtectionPhishingRisk": "Primary Email Protection - Phishing",
    "PrimaryEmailProtectionSpamRisk": "Primary Email Protection - Spam",
    "PrimaryEmailProtectionSuspiciousRisk": "Primary Email Protection - Suspicious",
    "SecondaryEmailProtectionMalwareRisk": "Secondary Email Protection - Malware",
    "SecondaryEmailProtectionPhishingRisk": "Secondary Email Protection - Phishing",
    "SecondaryEmailProtectionSocialEngineeringRisk": "Secondary Email Protection - Social Engineering",
    "SecondaryEmailProtectionSpamRisk": "Secondary Email Protection - Spam",
    "SecondaryEmailProtectionSuspiciousRisk": "Secondary Email Protection - Suspicious",
    "PrivilidgedAccountRisk": "Privilidged Account Access",
    "AdminstrativeAccessAccountRisk": "Administrative Account Access",
    "DarkwebBreachedCredentialRisk": "Darkweb Breach",
    "SecurityExceptionRisk": "Security Exceptions",
    "MultipleHMCEndpointRisk": "Multiple Endpoints",
    "MultipleBYODEndpointRisk": "Multiple BYOD Endpoints",
    "BOYDOutofComplianceRisk": "Endpoint Out of Compliance",
}

# Metrics that should display as %; assumes underlying value is 0–1
percentify_ratios = {"PrimaryEmailProtectionSpamRisk", "PhishingRisk"}
percent_already = set()  # keep empty since PhishingRisk is now 0–1

# ---- Build long-form risk rows for every discovered metric ----
risk_dfs = []
for base_col in discovered_metrics:
    base = F.col(base_col)
    risk_name_lit = F.lit(pretty_map.get(base_col, base_col))

    # RiskValue as string (raw numeric)
    risk_value_str = base.cast("string").alias("RiskValue")

    # RiskValue2: no decimals for percent metrics; keep others as strings
    risk_value2 = (
        F.when(
            F.lit(base_col).isin(list(percentify_ratios)),
            F.concat(
                F.round(base * F.lit(100.0), 0).cast("int").cast("string"),
                F.lit("%")
            )
        )
        .when(
            F.lit(base_col).isin(list(percent_already)),
            F.round(base, 0).cast("int").cast("string")
        )
        .otherwise(base.cast("string"))
        .alias("RiskValue2")
    )

    risk_df = joined_df.select(
        "HMCUserIdentifier",
        F.col("Displayname").alias("UserName"),
        risk_name_lit.alias("RiskName"),
        risk_value_str,
        risk_value2,
        F.col(f"{base_col}AcceptableLevel").alias("AcceptableLevel"),
        F.col(f"{base_col}Level").alias("RiskLevel"),
        F.col(f"{base_col}Multiplier").alias("RiskMultiplier"),
        (F.col(f"{base_col}Level") * F.col(f"{base_col}Multiplier")).alias("OverallRisk")
    )
    risk_dfs.append(risk_df)

# If there are no metrics (edge cases), create an empty DF with the right schema
if risk_dfs:
    risk_results_df = reduce(lambda a, b: a.unionByName(b), risk_dfs)
else:
    risk_results_df = joined_df.limit(0).select(
        F.col("HMCUserIdentifier"),
        F.col("Displayname").alias("UserName"),
        F.lit(None).cast("string").alias("RiskName"),
        F.lit(None).cast("string").alias("RiskValue"),
        F.lit(None).cast("double").alias("RiskValue2"),
        F.lit(None).cast("double").alias("AcceptableLevel"),
        F.lit(None).cast("int").alias("RiskLevel"),
        F.lit(None).cast("int").alias("RiskMultiplier"),
        F.lit(None).cast("int").alias("OverallRisk"),
    )

# ---- Join limits & add label columns ----
risk_results_df = (
    risk_results_df.join(limits_df, on="RiskName", how="left")
      .withColumn("NumericRiskValue", F.col("RiskValue").cast("double"))
      .withColumn(
          "RLDef",
          F.when(F.col("RiskLevel") == 1, "Very Low Risk")
           .when(F.col("RiskLevel") == 2, "Low Risk")
           .when(F.col("RiskLevel") == 3, "Medium Risk")
           .when(F.col("RiskLevel") == 4, "High Risk")
           .otherwise("Very High Risk")
      )
      .withColumn(
          "AcceptableLevelDef",
          F.when(F.col("AcceptableLevel") == 1, "Very Low Risk")
           .when(F.col("AcceptableLevel") == 2, "Low Risk")
           .when(F.col("AcceptableLevel") == 3, "Medium Risk")
           .when(F.col("AcceptableLevel") == 4, "High Risk")
           .otherwise("Very High Risk")
      )
)

# ---- Write out to Curated path (Delta overwrite) ----
levels_rel  = "Silver/CyberSecurityUserRiskLevels"
levels_path = tbl_path(curated_lh_id, levels_rel)

(risk_results_df
    .orderBy(F.desc("RiskLevel"), "HMCUserIdentifier")
    .write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(levels_path)
)

# ---- Post-write patch: correct Phishing Failure levels from Bronze limits ----
# Pull thresholds (decimals) for Phishing Failure
lim_row = (
    read_delta(bronze_lh_id, "Bronze/CyberDashboardLimits")
         .where(F.col("LimitName") == F.lit("Phishing Failure"))
         .select(
             F.col("VeryLowLimit_Decimal").cast("double").alias("v1"),
             F.col("LowLimit_Decimal").cast("double").alias("v2"),
             F.col("MediumLimit_Decimal").cast("double").alias("v3"),
             F.col("HighLimit_Decimal").cast("double").alias("v4")
         )
         .first()
)

# Safe defaults if any missing
v1 = lim_row["v1"] if lim_row and lim_row["v1"] is not None else 0.01
v2 = lim_row["v2"] if lim_row and lim_row["v2"] is not None else 0.03
v3 = lim_row["v3"] if lim_row and lim_row["v3"] is not None else 0.04
v4 = lim_row["v4"] if lim_row and lim_row["v4"] is not None else 0.06

# Read the just-written Delta by path
levels_df = spark.read.format("delta").load(levels_path)

is_phish = F.col("RiskName").isin("Phishing Failure", "PhishingFailure")
x = F.col("NumericRiskValue")  # already 0–1 decimal

new_lvl = (
    F.when(x.isNull() | (x <= F.lit(v1)), F.lit(1))
     .when(x <= F.lit(v2), F.lit(2))
     .when(x <= F.lit(v3), F.lit(3))
     .when(x <= F.lit(v4), F.lit(4))
     .otherwise(F.lit(5))
)

new_rldef = (
    F.when(new_lvl == 1, "Very Low Risk")
     .when(new_lvl == 2, "Low Risk")
     .when(new_lvl == 3, "Medium Risk")
     .when(new_lvl == 4, "High Risk")
     .otherwise("Very High Risk")
)

patched_levels = (
    levels_df
      .withColumn("RiskLevel", F.when(is_phish, new_lvl.cast("int")).otherwise(F.col("RiskLevel")))
      .withColumn("RLDef", F.when(is_phish, new_rldef).otherwise(F.col("RLDef")))
      .withColumn("OverallRisk",
                  F.when(is_phish, F.col("RiskLevel") * F.col("RiskMultiplier"))
                   .otherwise(F.col("OverallRisk")))
)

# Overwrite the table with corrected Phishing Failure rows
(patched_levels.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(levels_path)
)

print(f"✅ Wrote user risk levels to {levels_path} (with phishing patch applied)")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
