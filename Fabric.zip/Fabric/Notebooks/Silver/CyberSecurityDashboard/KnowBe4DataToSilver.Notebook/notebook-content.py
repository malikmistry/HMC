# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

spark.conf.set("spark.sql.session.timeZone", "UTC")

def parse_ts(col):
    # Try several common patterns; fall back to direct cast
    return F.coalesce(
        F.col(col).cast("timestamp"),
        F.to_timestamp(F.col(col), "yyyy-MM-dd'T'HH:mm:ss.SSSX"),  # handles Z/±hh:mm
        F.to_timestamp(F.col(col), "yyyy-MM-dd'T'HH:mm:ssX"),
        F.to_timestamp(F.regexp_replace(F.col(col), "Z$", ""), "yyyy-MM-dd'T'HH:mm:ss.SSS"),
        F.to_timestamp(F.col(col), "yyyy-MM-dd HH:mm:ss")
    )

# --- Sources (Bronze) ---
EXCLUDE_PST_IDS = [8269424]

pt_all = read_delta(bronze_lh_id, "Bronze/KnowBe4PhishingTest")
pt = pt_all.filter(~F.col("pst_id").isin(EXCLUDE_PST_IDS))

usr = read_delta(bronze_lh_id, "Bronze/KnowBe4Users")

# Active users only
usr_active = usr.filter(F.col("status") == F.lit("active"))

# Latest campaign pst_id (ORDER BY scheduled_at desc, pst_id desc LIMIT 1)
latest_row = (
    pt.select("pst_id", "scheduled_at")
      .orderBy(F.col("scheduled_at").desc(), F.col("pst_id").desc())
      .limit(1)
      .collect()
)
latest_pst_id = latest_row[0]["pst_id"] if latest_row else None
pt_latest = pt.filter(F.col("pst_id") == F.lit(latest_pst_id)) if latest_pst_id is not None else pt.limit(0)

# --- Clean + aggregate last OPEN ---
pt_clean = pt.withColumn("clicked_at_ts", parse_ts("clicked_at"))

pt_opened = (
    pt_clean.groupBy("user_id")
            .agg(F.max("clicked_at_ts").alias("last_failure_date"))   # true TIMESTAMP
)

# Left join so users with no events get NULL (not "Invalid Date")
last_failures = (
    usr_active.select(F.col("id").alias("user_id"), "email")
      .join(pt_opened, "user_id", "left")
      .select("email", F.col("last_failure_date").cast("timestamp").alias("last_failure_date"))
)

spark.conf.set("spark.sql.session.timeZone", "UTC")

out = (
    usr_active.alias("usr")
      .join(pt_latest.alias("pt"), F.col("usr.id") == F.col("pt.user_id"), "inner")
      .join(last_failures.alias("lf"), "email", "left")
      .filter(F.col("usr.department").isNotNull() & (F.trim(F.col("usr.department")) != ""))
      .filter(~F.col("usr.last_name").like("%Conf"))
      .select(
          F.col("usr.email").alias("email"),
          F.concat_ws(", ", F.col("usr.last_name"), F.col("usr.first_name")).alias("UserName"),
          (F.col("usr.phish_prone_percentage") / F.lit(100.0)).cast("double").alias("phish_prone_percentage"),
          F.col("usr.department").alias("department"),
          # employee_start_date -> DATE (robust: parse then truncate)
          F.to_date(
              F.coalesce(
                  F.col("usr.employee_start_date").cast("timestamp"),
                  F.to_timestamp("usr.employee_start_date", "yyyy-MM-dd'T'HH:mm:ss.SSSX"),
                  F.to_timestamp("usr.employee_start_date", "yyyy-MM-dd'T'HH:mm:ssX")
              )
          ).alias("employee_start_date"),
          # last_failure_date is already TIMESTAMP; truncate to DATE
          F.to_date(F.col("lf.last_failure_date")).alias("last_failure_date")
      )
      .dropDuplicates(["email"])
)


# --- Write to Curated Lakehouse path (Delta, overwrite) ---
target_rel  = "Silver/CyberSecurityKnowBe4Data"
target_path = tbl_path(curated_lh_id, target_rel)

(out.write
   .format("delta")
   .mode("overwrite")
   .option("overwriteSchema", "true")
   .save(target_path)
)

print(f"✅ Wrote CyberSecurityKnowBe4Data to {target_path}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
