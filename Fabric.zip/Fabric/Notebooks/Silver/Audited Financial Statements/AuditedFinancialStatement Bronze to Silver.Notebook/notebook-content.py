# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

from pyspark.sql import SparkSession
from delta.tables import DeltaTable
from datetime import date
import logger

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Gold Delta table path (uses Fabric helper 'get_basepath')
WorkspaceId   = None
BronzeLHId    = None
CuratedLHId   = None
TaskList      = None
NotebookName  = None
LakehouseName = None
RawLHId       = None

print(f"Params: WorkspaceId={WorkspaceId}, BronzeLHId={BronzeLHId}, CuratedLHId={CuratedLHId}")

if WorkspaceId is None:
    # Example defaults (replace with your IDs if needed)
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId  = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

# Resolve base lakehouse path; get_basepath is provided by notebook_utils in Fabric
curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

def tbl_path(base, rel): 
    return f"{base}/Tables/{rel}" 

def files_path(base, rel): 
    return f"{base}/Files/{rel}" 


# Bronze Path
date_folder = date.today().strftime("%Y-%m-%d")
bronze_rel  = f"AuditedFinancialStatements/{date_folder}"
bronze_path = files_path(bronze_lh_id, bronze_rel)
print("Bronze File path:", bronze_path)

# Silver table location (single output table)
silver_rel  = "Silver/AuditedFinancialStatement"
silver_path = tbl_path(curated_lh_id, silver_rel)
print("Silver Delta path:", silver_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Initialize Spark session
spark = SparkSession.builder \
    .appName("LoadBronzeToSilver") \
    .config("spark.jars.packages", "io.delta:delta-core_2.12:1.2.1") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

try:
    df = spark.read.parquet(bronze_path)
    input_files = df.inputFiles()
    print(f"Read parquet from: {bronze_path}")
    print(f"Number of files read: {len(input_files)}")
except Exception as e:
    mssparkutils.notebook.exit("No files found. Exiting notebook.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Write to Silver
if DeltaTable.isDeltaTable(spark, silver_path):
    print("Silver table exists. Performing MERGE on attachment_id.")

    delta_table = DeltaTable.forPath(spark, silver_path)

    # Build the merge expression
    merge_condition = "target.attachment_id = source.attachment_id"

    # Perform MERGE: update if matched, insert if not matched
    delta_table.alias("target").merge(
        df.alias("source"),
        merge_condition
    ).whenMatchedUpdateAll() \
     .whenNotMatchedInsertAll() \
     .execute()

else:
    print(f"Silver table does not exist. Creating {silver_rel}")
    df.write.format("delta").mode("overwrite").save(silver_path)

print(f"Merge completed for {df.count()} rows into Silver table: {silver_rel}")
mssparkutils.notebook.exit("Success: Bronze to Silver completed.")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
