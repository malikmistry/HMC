# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

from pyspark.sql import SparkSession
from delta.tables import DeltaTable
from datetime import date

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

WorkspaceId   = None
BronzeLHId    = None
CuratedLHId   = None
TaskList      = None
NotebookName  = None
LakehouseName = None
RawLHId       = None

print(f"Params: WorkspaceId={WorkspaceId}, BronzeLHId={BronzeLHId}, CuratedLHId={CuratedLHId}")

if WorkspaceId is None:
    # Example defaults (replace with your IDs if needed)
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId  = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

# Resolve base lakehouse path; get_basepath is provided by notebook_utils in Fabric
curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)


def tbl_path(base, rel): 
    return f"{base}/Tables/{rel}"
# ----------------------------
# Source (Bronze) and Target (Silver) table paths
# ----------------------------
bronze_rel  = "Bronze/AuditedFinancialStatement"   # read FROM this Delta table (source)
silver_rel  = "Silver/AuditedFinancialStatement"   # write TO this Delta table (target)

bronze_tbl_path = tbl_path(bronze_lh_id, bronze_rel)
silver_tbl_path = tbl_path(curated_lh_id, silver_rel)
silver_schema_path = tbl_path(curated_lh_id, "Silver")  # folder for the Silver schema

print("Bronze Delta path:", bronze_tbl_path)
print("Silver Delta path:", silver_tbl_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark = SparkSession.builder \
    .appName("BronzeToSilver_SnapshotCopy") \
    .getOrCreate()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# 1) Read CURRENT SNAPSHOT from Bronze
df = spark.read.format("delta").load(bronze_tbl_path)
src_cnt = df.count()
print(f"Read from Bronze: {src_cnt} rows")

# (Optional) ensure /Tables/Silver exists — harmless if it already does
sc   = spark.sparkContext
jvm  = sc._jvm
hcfg = sc._jsc.hadoopConfiguration()
fs   = jvm.org.apache.hadoop.fs.FileSystem.get(hcfg)
Path = jvm.org.apache.hadoop.fs.Path
def h_mkdirs(p: str): fs.mkdirs(Path(p))
h_mkdirs(silver_schema_path)

# 2) Overwrite Silver in-place
(df.write
   .format("delta")
   .mode("overwrite")   
   .option("overwriteSchema", "true")
   .save(silver_tbl_path))

# 3) Validate
df_silver = spark.read.format("delta").load(silver_tbl_path)
dst_cnt = df_silver.count()
print(f"Wrote to Silver: {dst_cnt} rows")
display(df_silver.limit(10))

print("Success: Audited Financial Statement Bronze To Silver")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
