# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

# =========================
# Copy entire folders between Fabric Lakehouses (all file types)
# =========================
# HOW TO USE:
# 1) Set SRC_BASE and DST_BASE below. You can use:
#    - Attached Lakehouses:  "lakehouse://<Name>/Files/<optional/subfolder>"
#    - ABFS URIs from UI:    "abfss://<workspaceId>@onelake.dfs.fabric.microsoft.com/<ItemId>.Lakehouse/Files/<subfolder>"
# 2) (Optional) Set DRY_RUN=True first to preview actions.
# 3) Run this single cell.

from typing import List, Tuple, Optional
import re

# ---- EDIT THESE ----
SRC_BASE = "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Files/AuditedFinancialStatements"
DST_BASE = "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/920a12cc-7104-4013-a2a3-d7baa57e9e3f/Files/AuditedFinancialStatements"

OVERWRITE = True     # If True, replace existing files at destination
DRY_RUN = False      # If True, only print intended actions (no changes)
INCLUDE = None       # e.g., r".*\.(parquet|csv|json)$"  (None = include all files)
EXCLUDE = None       # e.g., r"(^|/)_delta_log/|(^|/)\..+"  (None = exclude nothing)

# ---- UTILITIES ----
def _normalize_path(p: str) -> str:
    return p.rstrip("/")

def _join(a: str, b: str) -> str:
    a = _normalize_path(a)
    return f"{a}/{b}" if b else a

def _want_file(path: str) -> bool:
    if INCLUDE and not re.search(INCLUDE, path, flags=re.IGNORECASE):
        return False
    if EXCLUDE and re.search(EXCLUDE, path, flags=re.IGNORECASE):
        return False
    return True

def _ls(path: str):
    # robust ls that returns [] if path doesn't exist
    if not mssparkutils.fs.exists(path):
        return []
    return mssparkutils.fs.ls(path)

def _mkdirs(path: str):
    if not mssparkutils.fs.exists(path):
        if not DRY_RUN:
            mssparkutils.fs.mkdirs(path)

def copy_dir(src_dir: str, dst_dir: str, overwrite: bool = False):
    src_dir = _normalize_path(src_dir)
    dst_dir = _normalize_path(dst_dir)
    _mkdirs(dst_dir)

    stack: List[Tuple[str, str]] = [(src_dir, dst_dir)]
    files_copied = 0
    files_skipped = 0
    dirs_created = 0

    while stack:
        cur_src, cur_dst = stack.pop()

        for entry in _ls(cur_src):
            # entry.path is the full path; entry.name is the last segment in Fabric
            name = entry.name if hasattr(entry, "name") else entry.path.split("/")[-1]
            src_path = entry.path
            dst_path = _join(cur_dst, name)

            if entry.isDir:
                if not mssparkutils.fs.exists(dst_path):
                    dirs_created += 1
                    if not DRY_RUN:
                        mssparkutils.fs.mkdirs(dst_path)
                # Dive into subdirectory
                stack.append((src_path, dst_path))
            else:
                if not _want_file(src_path):
                    files_skipped += 1
                    continue

                if DRY_RUN:
                    print("[DRY-RUN] COPY", src_path, "->", dst_path)
                    files_copied += 1
                    continue

                # Handle overwrite manually (cp has no 'overwrite' kw)
                if mssparkutils.fs.exists(dst_path):
                    if overwrite:
                        # remove existing file before copying
                        mssparkutils.fs.rm(dst_path, recurse=False)
                    else:
                        files_skipped += 1
                        continue

                # Copy the file (not a directory; recurse=False)
                mssparkutils.fs.cp(src_path, dst_path, recurse=False)
                files_copied += 1

    print(f"Done. Copied files: {files_copied}, Skipped files: {files_skipped}, New folders: {dirs_created}")

# ---- RUN ----
print(f"Source:      {SRC_BASE}")
print(f"Destination: {DST_BASE}")
print(f"Overwrite:   {OVERWRITE} | Dry-run: {DRY_RUN}")
copy_dir(SRC_BASE, DST_BASE, overwrite=OVERWRITE)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Snapshot copy of a Delta table (no history), path → path
# No Lakehouse context or SQL needed

# Exact paths you gave
src_loc = "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465/Tables/Silver/AuditedFinancialStatement"
dst_loc = "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/AuditedFinancialStatement"

# Hadoop FS helpers (works without mssparkutils)
sc = spark.sparkContext
jvm = sc._jvm
fs = jvm.org.apache.hadoop.fs.FileSystem.get(sc._jsc.hadoopConfiguration())
Path = jvm.org.apache.hadoop.fs.Path

def h_exists(p): return fs.exists(Path(p))
def h_mkdirs(p): fs.mkdirs(Path(p))
def h_rm(p, recurse=True): fs.delete(Path(p), bool(recurse))

# 1) Read current snapshot from source
df = spark.read.format("delta").load(src_loc)

# 2) Prepare destination and clean overwrite
dst_schema_path = "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze"
h_mkdirs(dst_schema_path)
if h_exists(dst_loc):
    h_rm(dst_loc, recurse=True)

# 3) Write new Delta table at destination path
(df.write
   .format("delta")
   .mode("overwrite")
   .option("overwriteSchema", "true")
   .save(dst_loc))

# 4) Validate by reading the destination path directly
dst_df = spark.read.format("delta").load(dst_loc)
print("Row count at destination:", dst_df.count())
display(dst_df.limit(10))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
