# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

# Workspace A
src_root = "abfss://DEV@onelake.dfs.fabric.microsoft.com/LakehouseSilver.Lakehouse/Files/AuditedFinancialStatement"
dst_root = "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Files/"

# Make sure destination parent exists
mssparkutils.fs.mkdirs(dst_root)

# Recursively copy EVERYTHING (all files/subfolders)
mssparkutils.fs.cp(src_root, dst_root, recurse=True)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Source & destination OneLake (abfss) paths you provided
src_loc = "abfss://DEV@onelake.dfs.fabric.microsoft.com/LakehouseSilver.Lakehouse/Tables/AuditedFinancialStatements"
dst_loc = "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465/Tables/Silver/AuditedFinancialStatements"

# (Optional) make sure the parent folder exists
mssparkutils.fs.mkdirs("abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465/Tables/Silver")

# Copy the entire Delta directory (_delta_log + data)
mssparkutils.fs.cp(src_loc, dst_loc, recurse=True)
print("Copied to:", dst_loc)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
