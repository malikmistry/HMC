# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# assumes: from pyspark.sql import functions as F

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# --- Inputs ---
source_rel = "Bronze/AzureLogsData"
silver_rel = "Silver/UserNetworkAccessDataAzure"
entra_rel  = "Bronze/EntraUsers"
codes_rel  = "Bronze/CountryCodes"

# --- Read sources ---
src_df = read_delta(bronze_lh_id, source_rel)
entra_df = (
    read_delta(bronze_lh_id, entra_rel)
    .select(
        F.col("userPrincipalName").cast("string").alias("userPrincipalName"),
        F.col("department").cast("string").alias("department"),
        F.col("givenName").cast("string").alias("givenName"),
        F.col("surname").cast("string").alias("surname"),
    )
    .where(F.col("userPrincipalName").isNotNull())
)

codes_df = (
    read_delta(bronze_lh_id, codes_rel)
    .select(
        F.col("Azure").cast("string").alias("Azure"),
        F.col("Country").cast("string").alias("CountryFull"),
        F.col("BlackList").cast("boolean").alias("BlackList"),
        F.col("GreyList").cast("boolean").alias("GreyList"),
        F.col("WhiteList").cast("boolean").alias("WhiteList"),
    )
    .where(F.col("Azure").isNotNull())
    .dropDuplicates(["Azure"])
)

# --- Normalize & alias for safe joins ---
src_norm = (
    src_df
    .withColumn("who_norm",     F.lower(F.trim(F.col("who"))))
    .withColumn("country_norm", F.upper(F.trim(F.col("country"))))
).alias("l")

entra_norm = (
    entra_df
    .withColumn("upn_norm", F.lower(F.trim(F.col("userPrincipalName"))))
    .dropDuplicates(["upn_norm"])
).alias("e")

codes_norm = (
    codes_df
    .withColumn("azure_norm", F.upper(F.trim(F.col("Azure"))))
).alias("cc")

# --- LEFT JOIN: AzureLogsData (l) -> EntraUsers (e) on who == userPrincipalName ---
joined_le = (
    src_norm.join(
        entra_norm,
        on=F.col("l.who_norm") == F.col("e.upn_norm"),
        how="left"
    )
)

# --- Map country code -> full name using CountryCodes (cc) ---
joined_df = (
    joined_le.join(
        F.broadcast(codes_norm),
        on=F.col("l.country_norm") == F.col("cc.azure_norm"),
        how="left"
    )
)

# --- Derivations ---
user_name = F.trim(F.concat_ws(" ", F.col("e.givenName"), F.col("e.surname")))

# 'User' = part before '@' for any *.hmc.harvard.edu (incl. subdomains)
who_lc = F.lower(F.col("l.who"))
user_only = F.when(
    who_lc.rlike(r'@(?:[a-z0-9-]+\.)?hmc\.harvard\.edu$'),
    F.substring_index(F.col("l.who"), "@", 1)
).otherwise(F.lit(None).cast("string"))

country_final = F.coalesce(F.col("cc.CountryFull"), F.col("l.country").cast("string"))

location_col = F.concat_ws(
    ", ",
    F.trim(F.col("l.city")),
    F.trim(F.col("l.state")),
    F.trim(country_final)
)
from pyspark.sql import functions as F

# Build a normalized country-code column for the flag
country_code = F.upper(F.trim(F.coalesce(F.col("cc.Azure"), F.col("l.country"))))

login_outside_us = (
    F.when(country_code.isNull(), F.lit(False))   # treat unknown as not outside US
     .when(country_code == F.lit("US"), F.lit(False))
     .otherwise(F.lit(True))
)

# --- Select final columns (joined by UPN) ---
silver_df = (
    joined_df.select(
        F.col("l.timestamp").cast("timestamp").alias("timestamp"),
        F.col("l.success").cast("boolean").alias("success"),
        F.col("l.who").cast("string").alias("who"),
        user_only.alias("User"),
        F.col("l.ipAddress").cast("string").alias("ipAddress"),
        F.col("l.city").cast("string").alias("city"),
        F.col("l.state").cast("string").alias("state"),
        country_final.alias("country"),
        location_col.alias("location"),
        login_outside_us.alias("LoginOutsideUS"),
        F.col("l.deviceClass").cast("string").alias("deviceClass"),
        F.col("l.deviceOS").cast("string").alias("deviceOS"),
        F.col("l.deviceDisplayName").cast("string").alias("deviceDisplayName"),
        F.col("l.dirOSVersion").cast("string").alias("dirOSVersion"),
        F.col("e.department").cast("string").alias("department"),

        # Flags from CountryCodes (default False when no match)
        F.coalesce(F.col("cc.BlackList"), F.lit(False)).alias("BlackList"),
        F.coalesce(F.col("cc.GreyList"),  F.lit(False)).alias("GreyList"),
        F.coalesce(F.col("cc.WhiteList"), F.lit(False)).alias("WhiteList"),

        F.col("l.Source").cast("string").alias("Source"),
        user_name.alias("UserName"),
    )
)

# --- Write to Silver (Curated Lakehouse) ---
target_path = tbl_path(curated_lh_id, silver_rel)

(silver_df.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(target_path)
)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
