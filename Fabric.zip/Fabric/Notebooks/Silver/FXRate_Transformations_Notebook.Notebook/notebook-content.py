# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.functions import max as spark_max
from delta.tables import DeltaTable
from pyspark.sql.window import Window
from pyspark.sql.types import *

spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
print(etlloadtime)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell isfor testing
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "{\"JobAuditKey\":599,\"TaskKey\":76,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"FXRate\",\"SinkTableName\":\"FXRate\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"4\",\"NotebookName\":\"FXRateSilver\",\"SinkLakehouseName\":\"lh_curated\"}"
NotebookName = "FXRateSilver"
LakehouseName = "lh_curated"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""
NotebookName = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tasklist = json.loads(f"[{TaskList}]")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# spark.sql("""
#     UPDATE lh_curated.Silver.FXRate
#     SET FXDate = '2025-09-28'
#     WHERE IsLatest = 1;
# """)
# df = spark.sql("""
#     SELECT * FROM lh_bronze.Bronze.FXRate
#     WHERE to_date(Date_Time, 'dd/MM/yyyy HH:mm') = '09/07/2025'

# """)

# display(df)  # Fabric-friendly display

# from pyspark.sql.functions import to_date
 
# Read from source
# df = spark.table('lh_curated.Silver.FXRateCopy')
 
# # Ensure FXDate is a proper DateType column
# df = df.withColumn("FXDate", to_date("FXDate", "yyyy-MM-dd"))
#  
# Write to target
# df.write.format("delta").mode("append").saveAsTable('lh_curated.Silver.FXRate')

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Scenarios and Expected Behavior:
# __________________________________________________________________________________________________________________________________________________________________
# Scenario                              Source Today   Source Yesterday       Target Exists          Action
# __________________________________________________________________________________________________________________________________________________________________
# Normal case                               Yes              No                   Either          Filter today’s data, transform, and overwrite target
# Fallback to Yesterday                     No               Yes                   Yes            Use yesterday's data, transform, and overwrite target
# No Source, Target Empty                   No               No                    No             Raises error: Nothing to process and nothing to roll forward
# No Source Today, Target Exists            No               No                    Yes            Keeps existing target data, updates FXDate to today
# Unsupported ISO only                      Yes              -                     Yes            All data filtered out → runs UPDATE on existing target
# Partial Match                             Yes              -                     Yes            Writes only valid rows + USD row

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.FXRate (
# MAGIC     FXRateId INT NOT NULL,
# MAGIC     CurrencyId INT NOT NULL,
# MAGIC     FXDate DATE NOT NULL,
# MAGIC     FXRate DECIMAL(38,15) NOT NULL,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL,
# MAGIC     IsLatest INT NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

fx_schema = StructType([
    StructField("FXRateId", IntegerType(), nullable=False),
    StructField("CurrencyId", IntegerType(), nullable=False),
    StructField("FXDate", DateType(), nullable=False),
    StructField("FXRate", DecimalType(38, 15), nullable=False),
    StructField("ETLLoadDateTime", TimestampType(), nullable=False),
    StructField("IsLatest", IntegerType(), nullable=False)
])

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def safe_read_delta(path: str):
    try:
        return spark.read.format("delta").load(path)
    except Exception:
        return None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def write_with_islatest(today_date, dominant_date, df_new, target_path):
    # Ensure IsLatest exists
    if "IsLatest" not in df_new.columns:
        df_new = df_new.withColumn("IsLatest", F.lit(1))
    if dominant_date == 1:
        print('Dominant Date, setting all latest FXDate to today')
        df_new = df_new.withColumn("FXDate", F.lit(today_date).cast(DateType()))

    if DeltaTable.isDeltaTable(spark, target_path):
        delta_tbl = DeltaTable.forPath(spark, target_path)

        # Merge new records into existing (upsert by CurrencyId + FXDate)
        (
            delta_tbl.alias("t")
            .merge(
                df_new.alias("s"),
                "t.CurrencyId = s.CurrencyId AND t.FXDate = s.FXDate"
            )
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute()
        )
    else:
        # First-time write
        df_new.write.format("delta").mode("append").save(target_path)

    # Load after merge
    df_all = spark.read.format("delta").load(target_path)

    # Recompute IsLatest for each CurrencyId
    w = Window.partitionBy("CurrencyId").orderBy(F.col("FXDate").desc())
    df_latest = (
        df_all.withColumn("rownum", F.row_number().over(w))
              .withColumn("NewIsLatest", F.when(F.col("rownum") == 1, F.lit(1)).otherwise(F.lit(0)))
              .drop("rownum")
    )

    # Merge back only IsLatest updates
    delta_tbl = DeltaTable.forPath(spark, target_path)
    (
        delta_tbl.alias("t")
        .merge(
            df_latest.alias("s"),
            "t.CurrencyId = s.CurrencyId AND t.FXDate = s.FXDate"
        )
        .whenMatchedUpdate(set={"IsLatest": "s.NewIsLatest"})
        .execute()
    )


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def process_task(task, bronze_lh_id, curated_lh_id, real_today):
    try:
        source_path = f"{bronze_lh_id}/Tables/{task['SourceSchemaName']}/{task['SourceTableName']}"
        target_path = f"{curated_lh_id}/Tables/{task['SinkSchemaName']}/{task['SinkTableName']}"
        currency_table = f'{bronze_lh_id}/Tables/Bronze/HMCDataWarehouseCurrency'

        df_target = safe_read_delta(target_path)
        isTargetEmpty = 1 if df_target is None else 0

        today_date = real_today
        yesterday_date = real_today - timedelta(days=1)

        today_str = today_date.strftime("%Y-%m-%d")
        yesterday_str = yesterday_date.strftime("%Y-%m-%d")

        print(f"date today: {today_str}")

        # Final schema we expect
        final_cols = ["CurrencyId", "FXRateId", "FXDate", "FXRate", "ETLLoadDateTime", "IsLatest"]

        # Manual USD row aligned to final schema
        new_row = spark.createDataFrame([Row(CurrencyId=1, FXDate=today_str, FXRate=1.0000000)])


        # currency reference
        dfCurrencyXref = spark.read.format("delta").load(currency_table).select(
            F.col("ISOCode"), F.col("CurrencyId"), F.col("InverseQuoted")
        )

        # source data
        try:
            df_source = spark.read.format("delta").load(source_path)
        except Exception as e:
            raise RuntimeError(f"Source path does not exist or failed to load: {source_path}") from e

        # target info
        max_id = 0
        if df_target is not None:
            max_id = df_target.agg(F.max("FXRateId")).collect()[0]["max(FXRateId)"] or 0
        else:
            print("Target does not exist yet.")

        # filter today
        # df_today = df_source.filter(F.to_date("Date_Time", "dd/MM/yyyy HH:mm") == F.lit(today_date))
        df_today = df_source.filter(
            F.to_date("ETLLoadDateTime") == F.lit(today_date)
        )
        cnt_today = df_today.select("ISO").distinct().count()
        print(f"After today date filter: {df_today.count()} rows, {cnt_today} currencies")

        # Case 1: source empty and target empty → fail
        if is_df_empty(df_source) and isTargetEmpty == 1:
            raise RuntimeError("No data in both source and target tables. Nothing to process.")

        # Case 2: No today data → roll forward everything from yesterday
        if is_df_empty(df_today) and df_target is not None:
            print("No data for today. Rolling forward yesterday's data.")
            df_yesterday = df_target.filter(F.col("FXDate") == F.lit(yesterday_date))
            if is_df_empty(df_yesterday):
                print("No yesterday data either → skip")
                return
            df_today = df_yesterday.withColumn("FXDate", F.lit(today_date))

        else:
            # There is some data today → clean and compute rates
            df_today = df_today.withColumn(
                "FXDate", F.to_date(F.to_timestamp("Date_Time", "dd/MM/yyyy HH:mm"))
            )

            df_today = df_today.join(dfCurrencyXref, df_today["ISO"] == dfCurrencyXref["ISOCode"], "left") \
                               .filter(F.col("CurrencyId").isNotNull()) \
                               .filter(~F.col("ISO").isin("IRR", "SDG"))

            df_today = df_today.withColumn(
                "FXRate",
                F.when(F.col("InverseQuoted") == "N",
                       1.0 / F.col("USD_Mid").cast(DecimalType(38, 15)))
                .otherwise(F.col("USD_Mid").cast("double"))
            )

            df_today = df_today.select("CurrencyId", "FXDate", "FXRate")

            # add USD row
            df_today = df_today.unionByName(new_row.select("CurrencyId", "FXDate", "FXRate"), allowMissingColumns=True)

            # roll forward missing currencies from yesterday
            if df_target is not None:
                df_yesterday = df_target.filter(F.col("FXDate") == F.lit(yesterday_date))
                missing_ids = df_yesterday.select("CurrencyId").subtract(df_today.select("CurrencyId"))
                if missing_ids.count() > 0:
                    print(f"Rolling forward {missing_ids.count()} missing currencies from yesterday")
                    df_roll = df_yesterday.join(missing_ids, "CurrencyId").withColumn("FXDate", F.lit(today_date))
                    df_today = df_today.unionByName(df_roll.select("CurrencyId", "FXDate", "FXRate"), allowMissingColumns=True)

            df_today = df_today.dropDuplicates(["CurrencyId", "FXDate"])
        dominant_date = 1
        # Dominant date logic
        if cnt_today < 65:
            print("Today is not a dominant date (<65 currencies). Roll forward instead.")
            df_yesterday = df_target.filter(F.col("FXDate") == F.lit(yesterday_date))
            df_today = df_yesterday.withColumn("FXDate", F.lit(today_date))
            dominant_date = 0

        # add IDs and ETL timestamp
        window = Window.orderBy(F.monotonically_increasing_id())
        df_today = df_today.withColumn("FXRateId", F.row_number().over(window) + max_id) \
                           .withColumn("ETLLoadDateTime", F.lit(etlloadtime)) \
                           .withColumn("IsLatest", F.lit(1)) \
                           .withColumn("FXRate", F.col("FXRate").cast(DecimalType(38, 15))) \
                           .withColumn("CurrencyId", F.col("CurrencyId").cast(IntegerType())) \
                            .withColumn("FXDate", F.lit(today_date).cast(DateType())) \
                           .withColumn("FXRateId", F.col("FXRateId").cast(IntegerType()))
                            #    .withColumn("FXDate", F.col("FXDate").cast(DateType())) \

        # align final schema
        df_today = df_today.select(final_cols)

        # final write
        write_with_islatest(today_date,dominant_date, df_today, target_path)
        print("Completed.")

    except Exception as e:
        raise RuntimeError("Failed") from e


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)
        real_today = date.today()
        # real_today = date(2025, 10, 2) 
        yesterday_date = real_today - timedelta(days=1)
        # if real_today.weekday() == 0:
        #     print(f"Monday Date: {real_today}")
        #     # Process the task
        #     try:
        #         sunday_result = process_task(task_item,bronze_lh_basepath,curated_lh_basepath, yesterday_date)
        #     except Exception as e:
        #         print(f"Sunday task failed: {e}") 
        #     default_result = process_task(task_item,bronze_lh_basepath,curated_lh_basepath, real_today)
        # else:
        default_result = process_task(task_item,bronze_lh_basepath,curated_lh_basepath, real_today)
    except Exception as e:
        # mssparkutils.notebook.exit(f"FAILED: {e}")
        raise


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
