# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number, lit
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId =  ""
TaskList = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

# tasklist = json.loads(f"[{TaskList}]")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

lh_bronze_basepath = get_basepath(WorkspaceId, BronzeLHId)
lh_curated_basepath = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(lh_bronze_basepath )
display(lh_curated_basepath )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # SQL query
# def process_task(task):
#   df  = spark.sql("""
#   SELECT DISTINCT f.FundId, f.FundClassificationId as ClassificationId
#         , c.Description AS AssetClass
#         , c1.Description AS Strategy
#         , c2.Description AS SubStrategy
#   FROM (
#       SELECT f.FundId
#             , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN fcm.Level1ClassificationId ELSE ecm.Level1ClassificationId END AS Level1ClassificationId
#             , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN fcm.Level2ClassificationId ELSE ecm.Level2ClassificationId END AS Level2ClassificationId
#             , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN fcm.Level3ClassificationId ELSE ecm.Level3ClassificationId END AS Level3ClassificationId
#             , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN coalesce(fcm.Level3ClassificationId, coalesce(fcm.Level2ClassificationId, fcm.Level1ClassificationId))
#                     ELSE coalesce(ecm.Level3ClassificationId, coalesce(ecm.Level2ClassificationId, ecm.Level1ClassificationId)) END AS FundClassificationId
#       FROM Bronze.CrimsonXFund f
#           JOIN Bronze.CrimsonXClassificationMap AS ecm
#             ON f.EntityId = ecm.HMCObjectId AND ecm.EndDate IS NULL
#           LEFT JOIN Bronze.CrimsonXClassificationMap AS fcm
#             ON f.FundId = fcm.HMCObjectId AND fcm.EndDate IS NULL
#   ) f
#   JOIN lh_bronze.Bronze.CrimsonXClassification AS c
#     ON c.ClassificationId = f.Level1ClassificationId
#   LEFT JOIN lh_bronze.Bronze.CrimsonXClassification AS c1
#     ON c1.ClassificationId = f.Level2ClassificationId
#   LEFT JOIN lh_bronze.Bronze.CrimsonXClassification AS c2
#     ON c2.ClassificationId = f.Level3ClassificationId
#   """)

#   # lakehousePath = "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465"
#   # tableName = "Classification" 
#   target_table = task['SinkTableName']

#   deltaTablePath = f"{lh_curated_basepath}/Tables/Silver/{target_table}" 

#   df.write.format("delta").mode("overwrite").save(deltaTablePath)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

ETLLoadDateTime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC DROP TABLE IF EXISTS lh_curated.Silver.Classification;
# MAGIC 
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.Classification(
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	ClassificationId int NOT NULL,
# MAGIC 	AssetClass varchar(8000) NOT NULL,
# MAGIC 	Strategy varchar(8000) ,
# MAGIC 	SubStrategy varchar(8000) ,
# MAGIC 	BudgetStrategyId int ,
# MAGIC 	BudgetStrategy varchar(8000),
# MAGIC 	ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC ) 

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


spark.sql(f"""
create or replace temp view classification as 
select    CAST(f.FundId as VARCHAR(36)) as FundId
        , f.ClassificationId
		, ac.Description as AssetClass
		, sc.Description as Strategy
		, ssc.Description as SubStrategy
		, COALESCE(e.BudgetStrategyId, bscm.BudgetStrategyId) as BudgetStrategyId
		, bs.Description as BudgetStrategy
        
 from 
 (select f.FundId
        , f.EntityId
        , CASE WHEN fcm.HMCObjectId IS NULL THEN COALESCE(ecm.Level3ClassificationId, COALESCE(ecm.Level2ClassificationId, ecm.Level1ClassificationId))
		       ELSE COALESCE(fcm.Level3ClassificationId, COALESCE(fcm.Level2ClassificationId, fcm.Level1ClassificationId)) 
               END as ClassificationId
	    , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN fcm.Level1ClassificationId ELSE ecm.Level1ClassificationId 
            END AS Level1ClassificationId
        , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN fcm.Level2ClassificationId ELSE ecm.Level2ClassificationId 
            END AS Level2ClassificationId
        , CASE WHEN fcm.HMCObjectId IS NOT NULL THEN fcm.Level3ClassificationId ELSE ecm.Level3ClassificationId 
            END AS Level3ClassificationId
        , CASE WHEN fcm.HMCObjectId IS NOT NULL 
            THEN coalesce(fcm.Level3ClassificationId, coalesce(fcm.Level2ClassificationId, fcm.Level1ClassificationId))
            ELSE coalesce(ecm.Level3ClassificationId, coalesce(ecm.Level2ClassificationId, ecm.Level1ClassificationId)) 
            END AS FundClassificationId
 from delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXFund` f
		JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXClassificationMap` ecm 
        ON f.EntityId = ecm.HMCObjectId AND ecm.EndDate IS NULL
		LEFT JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXClassificationMap` fcm 
        ON f.FundId = fcm.HMCObjectId AND fcm.EndDate IS NULL) f
		JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXClassification` ac
        ON ac.ClassificationId = f.Level1ClassificationId
        JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXEntity` e ON e.EntityId = f.EntityId
        LEFT JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXClassification` sc 
        ON sc.ClassificationId = f.Level2ClassificationId
		LEFT JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXClassification` ssc 
        ON ssc.ClassificationId = f.Level3ClassificationId
		LEFT JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXBudgetStrategyClassificationMap` bscm 
        ON bscm.ClassificationId = f.ClassificationId
		LEFT JOIN delta.`{lh_bronze_basepath}/Tables/Bronze/CrimsonXBudgetStrategy` bs 
        On bs.BudgetStrategyId = COALESCE(e.BudgetStrategyId, bscm.BudgetStrategyId)
        """)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

target_table = f"{lh_curated_basepath}/Silver/Classification"

# display(target_table)

df = spark.table("classification")

dffinal = df.withColumn("ETLLoadDateTime",  to_timestamp(lit(ETLLoadDateTime)))

dffinal.write.format("delta").mode("append").save(f"{lh_curated_basepath}/Tables/Silver/Classification")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
