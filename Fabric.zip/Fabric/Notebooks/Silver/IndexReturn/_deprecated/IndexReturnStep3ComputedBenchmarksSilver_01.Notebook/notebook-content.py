# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Change History
# 01 TODO: create notebook that can handle computed benchmarks (e.g. 50% of one index and 50% of another)

WorkspaceId = ''
BronzeLhId = ''
CuratedLhId = ''

#TODO: change to use params
#todo: move to shared notebook??
#e.g bronze_lh_id = 'abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558'
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLhId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLhId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

def get_basepath(workspace_id, lakehouse_id) -> str: 
    lh_basepath = 	f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}" 
    return lh_basepath

bronze_lh_id = get_basepath(WorkspaceId, BronzeLhId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLhId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType, DateType
from datetime import date
from pyspark.sql.functions import last_day, col, min, max, col, max as spark_max, lit, min as spark_min, when, row_number, current_timestamp, month

# Mount the Lakehouse using its ID
# spark.sql(f"USE LAKEHOUSE {curated_lh_id}")

index_load_control = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index")

index_load_control = index_load_control.select(
    "IndexId",
    "IsActive",
    "isCustomIndex",
    "Frequency",
    "DisplayName"
)

index_load_control.filter(col("IndexId") == "18b7c764-774f-4a80-aad7-0edebc0207c3").show(5)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************





# Create Spark session
spark = SparkSession.builder.getOrCreate()

# Define schema
schema = StructType([
    StructField("IndexIdTarget", StringType(), False),
    StructField("IndexIdSource", StringType(), False),
    StructField("CurrencyId", IntegerType(), False),
    StructField("IndexContributionPct", DoubleType(), False),
    StructField("RecipeType", StringType(), False)
])

# Sample data
data = [
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "18b7c764-774f-4a80-aad7-0edebc0207c3", 1, 60.0, "CUSTOM"),
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "37028766-65c5-43e0-9fea-2088e246d8d8", 1, 40.0, "CUSTOM"),
]

# Create DataFrame
index_return_recipe = spark.createDataFrame(data, schema)

# Show it
index_return_recipe.show(truncate=False)

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# Step 1: Build universe of calculated indexes
calculated_indexes = (
    index_load_control
    .filter((F.col("IsActive") == "Y") & (F.col("IsCustomIndex") == "Y"))
    .join(
        index_return_recipe.filter(F.col("RecipeType") == "CUSTOM"),
        index_load_control["IndexId"] == index_return_recipe["IndexIdTarget"]
    )
    .select(index_load_control["IndexId"], index_load_control["IndexId"])
    .distinct()
)

calculated_indexes.show(10)
#xxx raise SystemExit("exiting")

# Step 2: Recursive dependencies - build recipe chain with levels
from pyspark.sql.types import StructType, StructField, IntegerType, DoubleType, StringType, DateType, BooleanType, TimestampType

index_return_recipe.show(5)
index_load_control.show(6)

recipe_df = (
    index_return_recipe
    .join(index_load_control.alias("target"), F.col("IndexIdTarget") == F.col("target.IndexId"))
    .join(index_load_control.alias("source"), F.col("IndexIdSource") == F.col("source.IndexId"))
    .filter(
        (F.col("target.isActive") == "Y") &
        (F.col("source.isActive") == "Y") &
        (F.col("RecipeType") == "CUSTOM")
    )
    .select(
        "IndexIdTarget", "IndexIdSource",
      #  F.col("target.IndexId").alias("IndexIdTarget"),
      #  F.col("source.IndexId").alias("IndexIdSource"),
        "IndexContributionPct"
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


df_stage = spark.read.parquet(f"{curated_lh_id}/Files/BloombergIndexReturnFrequencyPromoted")
df_stage = df_stage.orderBy(col("IndexId").asc(), col("CurrencyId").asc(), col("AsOfDate").asc())
df_stage.show(7)


df_wh = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/IndexReturn")
df_wh = df_wh.withColumn("Source", lit("Historical"))
df_wh.show(10)


recipe_df.show(9)

# Assign initial level 0 to real source indexes
level_df = recipe_df.withColumn("CreateLevel", F.lit(0))

level_df.show(8)

# Step 3: Compute Max Create Level per target index
index_max_level = (
    level_df
    .groupBy("IndexIdTarget")
    .agg(F.max("CreateLevel").alias("MaxCreateLevel"))
)

# Step 4: Load all source returns from both STAGE and Warehouse
#xxx stage_returns = index_return_stage.select("IndexId", "AsOfDate", "IndexReturn", "IndexLevel", "CurrencyId", "FrequencyId")
#xxx warehouse_returns = index_return_wh.select("IndexId", "AsOfDate", "IndexReturn", "IndexLevel", "CurrencyId", "FrequencyId")

input_returns = (
    recipe_df
    .join(df_stage, recipe_df["IndexIdSource"] == df_stage["IndexId"])
    .select(
        recipe_df["IndexIdTarget"],
        recipe_df["IndexIdSource"],
        "AsOfDate",
        "IndexContributionPct",
        "IndexReturn"
    )
    .unionByName(
        recipe_df
        .join(df_wh, recipe_df["IndexIdSource"] == df_wh["IndexId"])
        .select(
            recipe_df["IndexIdTarget"],
            recipe_df["IndexIdSource"],
            "AsOfDate",
            "IndexContributionPct",
            "IndexReturn"
        )
    )
)

input_returns.show(11)

# Step 5: Aggregate returns by target index
agg_returns = (
    input_returns
    .groupBy("IndexIdTarget", "AsOfDate")
    .agg(
        F.sum(F.col("IndexReturn") * (F.col("IndexContributionPct") / 100)).alias("IndexReturn")
    )
)


agg_returns.show(12)


# Step 6: Seed initial level values (assume starting IndexLevel = 100 for each IndexId)
initial_level = agg_returns.select("IndexIdTarget").distinct().withColumn("OrderNum", F.lit(0)).withColumn("IndexLevel", F.lit(100.0))

# Step 7: Calculate levels forward using returns
w = Window.partitionBy("IndexIdTarget").orderBy("AsOfDate")

ordered = (
    agg_returns
    .withColumn("OrderNum", F.row_number().over(w))
)

joined = (
    ordered
    .join(initial_level.select("IndexIdTarget", "IndexLevel"), on="IndexIdTarget")
    .withColumn(
        "IndexLevelCalc",
        F.expr("aggregate(collect_list(IndexReturn) over (partition by IndexIdTarget order by AsOfDate), IndexLevel, (acc, x) -> acc * (1 + x))")
    )
)

final_results = (
    joined
    .select(
        F.col("IndexIdTarget").alias("IndexId"),
        "AsOfDate",
        "IndexReturn",
        F.col("IndexLevelCalc").alias("IndexLevel")
    )
)
print("Almost Done.")

final_results.show(13)


#final_results.orderBy(col("AsOfDate").desc()).show(13)


    # ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "18b7c764-774f-4a80-aad7-0edebc0207c3", 1, 60.0, "CUSTOM"),
    # ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "37028766-65c5-43e0-9fea-2088e246d8d8", 1, 40.0, "CUSTOM"),

final_results.filter(col("IndexId") == "547c92eb-98c6-4167-94f7-48ced9f2f7f7").orderBy(col("AsOfDate").desc()).show(14)



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
