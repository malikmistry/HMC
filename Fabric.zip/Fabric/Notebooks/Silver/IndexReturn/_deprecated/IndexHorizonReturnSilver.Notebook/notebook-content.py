# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from decimal import Decimal
import requests
from datetime import date, datetime, timedelta
from requests.exceptions import HTTPError, ConnectionError, Timeout, RequestException
from pyspark.sql.types import StructType, StructField, DecimalType, DateType, StringType, IntegerType, LongType
from pyspark.sql.functions import to_date, lower
from delta.tables import DeltaTable
from pyspark.sql import functions as F, types as T

spark.conf.set('spark.sql.caseSensitive', True)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None
IndexHorizonReturnUrl = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_basepath)

curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_basepath)

if IndexHorizonReturnUrl == None:
    print("IndexHorizonReturnUrl Parameter is None.  Defaulting to dev URL")
    IndexHorizonReturnUrl = "https://winfunctionappdotnet-dev1.azurewebsites.net/api/CalculateIndexHorizonReturn?code=p5FkTa6fWird5I9Dz7gBvYPc3utum2xmwcCxmH6jyttrAzFu6juKfA=="


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

horizon_time_periods = [
    (1, "CYTD"),
    (2, "FYTD"),
    (5, "OneYear"),
    (6, "ThreeYear"),
    (7, "FiveYear"),
    (8, "SevenYear"),
    (9, "TenYear"),
    (11, "FifteenYear"),
    (12, "TwentyYear"),
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def getActiveIndices(lh_path):

    spark.read.format("delta").load(f"{lh_path}/Tables/Silver/Index").createOrReplaceTempView("vwIndices")

    df_active_indices = spark.sql("""
        SELECT DISTINCT IndexId, DisplayName, Frequency
        FROM vwIndices
        where IsActive = 1 AND NOT Frequency IS NULL  
    """)


    #xxx
    #df_active_indices = df_active_indices.filter(col("IndexId") == "18b7c764-774f-4a80-aad7-0edebc0207c3")

    #df_active_indices = df_active_indices.limit(10)

    df_active_indices.show(10)

    return df_active_indices

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def calcIndexReturns(request_data):

    start_time = datetime.now()

    data = http_post(IndexHorizonReturnUrl, request_data)

    # Convert only the value field; keep None as None
    for rec in data:
        v = rec.get("indexReturnValue")
        if isinstance(v, float):
            rec["indexReturnValue"] = Decimal(str(v))  # preserve precision

    schema = T.StructType([
        T.StructField("indexId", T.StringType(), True),
        T.StructField("indexReturnValue", T.DecimalType(38, 11), True),
        T.StructField("timePeriod", T.IntegerType(), True),
        T.StructField("error", T.StringType(), True),
        T.StructField("detailsKey", T.StringType(), True),
        T.StructField("useIndexCurrency", T.BooleanType(), True),
        T.StructField("currency", T.IntegerType(), True)
    ])

    #xxx
    df_results = spark.createDataFrame(data, schema=schema)
    #df_results.printSchema()
    #df_results.show(truncate=False)

    end_time = datetime.now()
    elapsed = end_time - start_time  # Returns a timedelta
    print("calcFundReturns elapsed time:", elapsed)    

    return df_results

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def getIndexRequest(indices, endDate):
    id_list = [str(r[0]) for r in indices] 
    index_request = { "Requests": [
    {
            "endDate": f"{endDate}",
            "isAnnualize": "false",
            "timePeriods": ["CYTD","FYTD","OneYear","ThreeYear","FiveYear","SevenYear","TenYear","FifteenYear","TwentyYear"],
            "indexes": id_list,
            "useIndexCurrency": "false",
            "currency": 1
     }
    ]
    }

    return index_request

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def end_of_prior_month(d: date) -> date:
    first_of_month = d.replace(day=1)
    return first_of_month - timedelta(days=1)

def end_of_prior_quarter(d: date) -> date:
    # Q1=Jan–Mar, Q2=Apr–Jun, Q3=Jul–Sep, Q4=Oct–Dec
    q = ((d.month - 1) // 3) + 1
    if q == 1:
        return date(d.year - 1, 12, 31)
    elif q == 2:
        return date(d.year, 3, 31)
    elif q == 3:
        return date(d.year, 6, 30)
    else:  # q == 4
        return date(d.year, 9, 30)

def getEndDateForFrequency(freq: int, today: date | None = None) -> date:
    if today is None:
        today = date.today()
    if freq == 8:   # for daily, use prior day
        return today - timedelta(days=1)
    if freq == 2:   # for monthly, use end of prior month
        return end_of_prior_month(today)
    if freq == 3:   # for quarterly, use end of prior quarter
        return end_of_prior_quarter(today)
    return today    # default/fallback

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#xxx
# this is newer logic including using outer loop over frequencies

start_time = datetime.now()
print(f"IndexHorizonReturnSilver: {start_time.strftime('%Y-%m-%d %H:%M:%S')}" )

indicesOfInterest = getActiveIndices(curated_lh_basepath)

print(f"Index Count = {indicesOfInterest.count()}")

indicesOfInterest.show(4)

batch_size = 100

indices = indicesOfInterest.collect()

periods = ["CYTD","FYTD","OneYear","ThreeYear","FiveYear","SevenYear","TenYear","FifteenYear","TwentyYear"]

tp_map = F.create_map(*[x for k, v in horizon_time_periods for x in (F.lit(k), F.lit(v))])

# AsOfDate is used to keep when the computations were run
AsOfDate = date.today()
print (AsOfDate)

allIndexHorizonData = None

# ---- OUTER LOOP: group by Frequency ----
freq_values = (
    indicesOfInterest
        .select("Frequency")
        .distinct()
        .collect()
)
freq_values = sorted([r["Frequency"] for r in freq_values])

print(freq_values)

for freq in freq_values:
    print(f"\n=== Processing Frequency = {freq} ===")
    grp_df = indicesOfInterest.filter(F.col("Frequency") == freq)
    grp_count = grp_df.count()
    print(f"Group count = {grp_count}")
    
    endDateForFrequency = getEndDateForFrequency(freq)
    print(f"Date = {endDateForFrequency}")

    grp_indices = grp_df.collect()

    for i in range(0, len(grp_indices), batch_size):
        print(f"Processing indices {i + 1} through {min(i + batch_size, len(grp_indices))} (Frequency={freq})...")
        batch_indices = grp_indices[i:i + batch_size]

        batch_request = getIndexRequest(batch_indices, endDateForFrequency)

        batch_start_time = datetime.now()
        batch_ids = [row["IndexId"] for row in batch_indices]

        print(batch_request)

        #xxx continue
        
        #xxx raise SystemExit("xxx")


        one_batch_horizon_returns = calcIndexReturns(batch_request)

        #print("on batch returns, A:")
        #one_batch_horizon_returns.show(10)

        one_batch_horizon_returns = one_batch_horizon_returns.withColumn(
            "timePeriod",
            F.coalesce(F.element_at(tp_map, F.col("timePeriod").cast("int")), F.lit("Unknown"))
        )

        #print("on batch returns, B:")
        #one_batch_horizon_returns.show(truncate=False)


        #xxxfrom pyspark.sql import functions as F, types as T

        # --- Returns (Decimal 38,11)
        vals = (one_batch_horizon_returns.groupBy("indexId")
                .pivot("timePeriod", periods)
                .agg(F.first("indexReturnValue", ignorenulls=True))
                .select("indexId", *periods))
        for p in periods:
            vals = vals.withColumn(p, F.col(p).cast(T.DecimalType(38, 11)))

        # --- Errors
        errs = (one_batch_horizon_returns.groupBy("indexId")
                .pivot("timePeriod", periods)
                .agg(F.first("error", ignorenulls=True)))
        for p in periods:
            errs = errs.withColumnRenamed(p, f"{p}Error")


        #print("errs:")
        #errs.show(10)
        #raise SystemExit("xxx")


        # --- detailsKey
        det = (one_batch_horizon_returns.groupBy("indexId")
                .pivot("timePeriod", periods)
                .agg(F.first("detailsKey", ignorenulls=True)))
        for p in periods:
            det = det.withColumnRenamed(p, f"{p}DetailsKey")

        # --- useIndexCurrency (bool per period)
        uic = (one_batch_horizon_returns.groupBy("indexId")
                .pivot("timePeriod", periods)
                .agg(F.first("useIndexCurrency", ignorenulls=True)))
        for p in periods:
            uic = (uic.withColumnRenamed(p, f"{p}UseIndexCurrency")
                    .withColumn(f"{p}UseIndexCurrency", F.col(f"{p}UseIndexCurrency").cast("boolean")))

        # --- currency (int per period)
        curr = (one_batch_horizon_returns.withColumn("currency", F.col("currency").cast("int"))
                .groupBy("indexId")
                .pivot("timePeriod", periods)
                .agg(F.first("currency", ignorenulls=True)))
        for p in periods:
            curr = (curr.withColumnRenamed(p, f"{p}Currency")
                    .withColumn(f"{p}Currency", F.col(f"{p}Currency").cast("int")))

        # --- Join all pivoted pieces
        wide = (vals
                .join(errs, "indexId", "left")
                .join(det,  "indexId", "left")
                .join(uic,  "indexId", "left")
                .join(curr, "indexId", "left"))

        #wide.show(truncate=False)

        df_oneBatch = wide

        #raise SystemExit("xxx")


        # df_oneBatch = (
        #     vals.join(errors, "indexId", "left")
        #         .select("indexId", *periods, *[f"{p}Error" for p in periods])
        # )

        #xxx todo: check that we see details key in the DB

        # Add typed NULL DetailsKey columns per period
        # for p in periods:
        #     df_oneBatch = df_oneBatch.withColumn(f"{p}DetailsKey", F.lit(None).cast("string"))

        # Add audit columns + Frequency (optional but useful)
        df_oneBatch = df_oneBatch.withColumn("EndDate", F.lit(endDateForFrequency))
        df_oneBatch = df_oneBatch.withColumn("AsOfDate", F.lit(AsOfDate))
        df_oneBatch = df_oneBatch.withColumn("ETLLoadDateTime", F.lit(datetime.now()))
        df_oneBatch = df_oneBatch.withColumn("Frequency", F.lit(freq))

        if allIndexHorizonData is None:
            allIndexHorizonData = df_oneBatch
        else:
            allIndexHorizonData = allIndexHorizonData.unionByName(df_oneBatch, allowMissingColumns=True)

        batch_end_time = datetime.now()
        print("Batch elapsed time:", batch_end_time - batch_start_time)

        # allIndexHorizonData now contains all frequencies, all batches
        #xxx
        # if i > 44:
        #     break;

if not allIndexHorizonData is None:
    allIndexHorizonData.show(11)
    print(f"final count =  {allIndexHorizonData.count()}")
    # DF schema
    allIndexHorizonData.printSchema()

# Delta table schema
print("showing schema for delta table Gold.IndexReturnHorizon")
path = f"{curated_lh_basepath}/Tables/Gold/IndexReturnHorizon"
spark.read.format("delta").load(path).printSchema()


print(f"Deleting old data for date {AsOfDate}")
delta_table = DeltaTable.forPath(spark, f"{curated_lh_basepath}/Tables/Gold/IndexReturnHorizon")
delta_table.delete(condition = F.col("AsOfDate").__eq__(AsOfDate))

allIndexHorizonData.write.format("delta").mode("append").save(f"{curated_lh_basepath}/Tables/Gold/IndexReturnHorizon")
spark.catalog.refreshTable("Gold.IndexReturnHorizon")

end_time = datetime.now()
elapsed = end_time - start_time  # Returns a timedelta
print("Total elapsed time:", elapsed)

raise SystemExit("xxx")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df = spark.sql("SELECT * FROM lh_curated.Gold.IndexReturnHorizon LIMIT 100")
display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# df = spark.sql("SELECT ReturnSourceId, count(*) FROM lh_curated.Silver.FundReturn group by ReturnSourceId order by ReturnSourceId")
# display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.conf.set('spark.sql.caseSensitive', True)

spark.sql(""" DROP TABLE Gold.IndexReturnHorizon """)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC DESCRIBE TABLE Gold.IndexReturnHorizon

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
CREATE TABLE Gold.IndexReturnHorizon (
    IndexId varchar(36) NOT NULL,
    EndDate date NOT NULL,
    AsOfDate date NOT NULL,
    CYTD decimal(38,11),
    CYTDError VARCHAR(200),
    CYTDDetailsKey VARCHAR(200),
    FYTD decimal(38,11),
    FYTDError VARCHAR(200),
    FYTDDetailsKey VARCHAR(200),
    OneYear decimal(38,11),
    OneYearError VARCHAR(200),
    OneYearDetailsKey VARCHAR(200),
    ThreeYear decimal(38,11),
    ThreeYearError VARCHAR(200),
    ThreeYearDetailsKey VARCHAR(200),
    FiveYear decimal(38,11),
    FiveYearError VARCHAR(200),
    FiveYearDetailsKey VARCHAR(200),
    SevenYear decimal(38,11),
    SevenYearError VARCHAR(200),
    SevenYearDetailsKey VARCHAR(200),
    TenYear decimal(38,11),
    TenYearError VARCHAR(200),
    TenYearDetailsKey VARCHAR(200),
    FifteenYear decimal(38,11),
    FifteenYearError VARCHAR(200),
    FifteenYearDetailsKey VARCHAR(200),
    TwentyYear decimal(38,11),
    TwentyYearError VARCHAR(200),
    TwentyYearDetailsKey VARCHAR(200),
    ETLLoadDateTime TIMESTAMP NOT NULL
)
USING DELTA
""")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
