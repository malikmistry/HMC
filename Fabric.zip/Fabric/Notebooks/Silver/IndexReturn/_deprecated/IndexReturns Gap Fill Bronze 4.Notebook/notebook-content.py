# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "920a12cc-7104-4013-a2a3-d7baa57e9e3f",
# META       "default_lakehouse_name": "lh_raw",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "920a12cc-7104-4013-a2a3-d7baa57e9e3f"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

#change history
# 04 working well in bronze
# 05 migrating to Silver where this belongs and making it read raw data from raw/bronze and write cleaned up data to Silver


#todo: paramaterize this... should be passed in via MDF
WorkspaceId = ''
BronzeLHId = ''
CuratedLHId = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_bronze")

#TODO: change to use params
#todo: move to shared notebook??
#e.g bronze_lh_id = 'abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558'
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLHId = ''

def get_basepath(workspace_id, lakehouse_id) -> str: 
    lh_basepath = 	f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}" 
    return lh_basepath

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


from pyspark.sql import SparkSession
from datetime import date
from pyspark.sql.functions import col, lit, to_date, trim, when, upper, lead, datediff, expr, when, pandas_udf, explode, struct, current_timestamp, concat
from pyspark.sql.window import Window
import pandas as pd
from pyspark.sql.types import ArrayType, StringType

#this notebook does several things:
# 1. validates data and logs issues
# 2. starts with index return data that is missing some dates (e.g. weekends) and produces a continous set of data points
# 3. enriches data by mapping from vendor conventions into HMC values

#real data has a mixture of index IDs, frequencies and currencies (and dates)
#also, some indices report as level and some as return

#todo: support rolling forward of both level and/or return

#todo: handle multiple frequencies (only roll forward Daily)
#todo: handle rolling forward returns if index reports as return
#todo: handle different data sources/reasons: Bloomberg nightly load, Bloomberg new index since inception, SOIL load, use generated manual benchmark files

# Version History
# 1 basic functionality demonstrates that logic works for canned data
# 2 migrated to "Dev - Crimson" and change to read parquet file
# 3 rename to IndexReturn Gap Fill Bronze 3 to denote this is Raw to Bronze processing
# 4 change to read initial data from lh_bronze delta table, stop using IndexReturn_STAGE, now use tmp parquet file in Files


# read delta table from bronze into a dataframe
df_stage = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/BloombergIndexReturn")

df_stage.show(13)

df_stage = df_stage.withColumn("Guid", upper(col("Guid")))
#df_stage.show(10)

df_with_errors = df_stage.withColumn(
    "ErrorMessage",
    when(col("Status") != "0", concat(lit("Bloomberg error: "), col("Status")))
    .when(col("Date").isNull(), lit("NULL Date"))
    .when(col("Date") == "", lit("Blank Date"))
    .when(col("Level").isNull(), lit("NULL Level"))
    .when(col("Level") == "", lit("Blank Level"))
    .when(col("Level") == "0", lit("Zero Level"))
    .otherwise(lit(None))
)

df_with_errors = df_with_errors.filter(col("ErrorMessage").isNotNull())
df_with_errors.show(22)

if df_with_errors.count() > 0:
    df_log = df_with_errors.select(
        lit("IndexReturn").alias("ApplicationName"), 
        df_with_errors["ErrorMessage"],
        df_with_errors["ETLLoadDateTime"]
    )
    df_log.show(7)
    #df_log.write.format("delta").mode("append").saveAsTable("Bronze.Log")
    path = f"{bronze_lh_id}/Tables/Bronze/Log"
    print(path)
    #df_log.write.format("delta").option("overwriteSchema", "true").mode("overwrite").save(path)
    df_log.write.format("delta").mode("append").save(path)

# filter out invalid data so that we only have good data to process
#xxx need to test this filter
df_stage = df_stage.filter(
    (col("Status") == 0) &    #this Status has been tested
    (col("Date").isNotNull()) &
    (trim(col("Date")) != "") &
    (col("Level").isNotNull()) &
    (trim(col("Level").cast("string")) != "")
)
df_stage.show(20)


#xxx and look up at HMC to get index Frequency (we only fill gaps for 8/Daily).  also get LEVEL/RETURN based and/or other metadata
df_stage = df_stage.select(
    col("SecurityIdentifier"),
    to_date(col("Date"), "yyyyMMdd").alias("AsOfDate"),
    col("Currency").alias("CurrencyId"),
    col("Level").alias("IndexLevel"),
    lit(0).alias("IndexReturn"),
    col("RunReason"),
    col("Guid"),
    col("AdditionalParam")
)

# Preview the result
df_stage.show(5)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "lh_bronze")

#xxx need to convert from ISO currency code to HMC INT ID
#xxx also BB ticker to HMC GUID

#todo: note: for BB sourced, use Ticker to get to HMC Index.  But, for manual, need the INT ID from HMCstaging to make to HMC
# get GUID and other metadata type values
dfIndexXref = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXIndex").select("IndexId", "Ticker", "Frequency", "IsLevelBased")
dfCurrencyXref = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXCurrency").select("CurrencyId", "ISOCode")
#xxx dfIndexXref = dfIndexXref.withColumn("IndexId", upper(col("IndexId")))

dfIndexXref.show(5)

dfWithHmcId = df_stage.join(dfIndexXref, df_stage["SecurityIdentifier"] == dfIndexXref["Ticker"], how="left")
dfUnmatched = dfWithHmcId.filter(col("Ticker").isNull())

dfWithHmcId.show(19)

#todo: how to handle this error... when raw vendor data does not resolve to an HMC index?
#todo: log this
if dfUnmatched.count() > 0:
    dfUnmatched.show(10)
    raise Exception("join failed, unmatched count = " + dfUnmatched.count())

dfWithHmcId = dfWithHmcId.select(
    col("IndexId"),
    col("Frequency").alias("FrequencyId"),
    col("AsOfDate"),
    col("CurrencyId").alias("CurrencyCode"),
    col("IndexLevel"),
    col("IndexReturn"),
    when(col("IsLevelBased") == True, "LEVEL").otherwise("RETURN").alias("VendorIndexReturnUnit"),
    col("RunReason"),
    col("Guid"),
    col("AdditionalParam")
)
dfWithHmcId = dfWithHmcId.join(dfCurrencyXref, dfWithHmcId["CurrencyCode"] == dfCurrencyXref["ISOCode"])
df_stage = dfWithHmcId.drop("CurrencyCode").drop("ISOCode")
df_stage.show(25)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Load base tables as DataFrames (assume these are registered or read from Lakehouse)
# df_stage = spark.table("dbo.IndexReturn_STAGE")
# df_frequency = spark.table("dbo.Frequency")
# df_version = spark.table("util.Version")
# df_index = spark.table("dbo.Index")

# hardcode Daily: we only fill gaps for 8/Daily
# todo: filter for 8/Daily and only fill gaps for 8.  But, need to carry along any other frequencies
frequency_id = 8

# this will cause grouping by the three columns and then ordered by the AsOfDate
window_spec = Window.partitionBy("IndexId", "FrequencyId", "CurrencyId").orderBy("AsOfDate")

# get value from "next" row knowing that we have sorted by AsOfDate 
df_date_list = (
    df_stage
    .filter(
        (col("FrequencyId") == frequency_id)
        #todo: keep or delete this:
        #(expr("ISNULL(x.RunPurpose, '--')") != "NIGHTLY_INDEX_LOAD_SOIL")
    )
    .withColumn("AsOfDateNext", lead("AsOfDate", 1).over(window_spec))
    .selectExpr(
        "IndexId", "CurrencyId", "FrequencyId", "AsOfDate", 
        "AsOfDateNext"
    )
)

df_date_list.show(10)

# Identify Gaps
df_gap = df_date_list.filter(
    datediff("AsOfDateNext", "AsOfDate") > 1
).withColumn("DaysDiff", datediff("AsOfDateNext", "AsOfDate")) \
 .withColumn("EventComment", lit(None).cast("string")) \
 .withColumn("ErrorType", lit("GAP"))

df_gap.show(10)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

should_fill_gap = 1
# ------------------------------------------------------------------
# 6. Stop here if ShouldFillGap = 0
# ------------------------------------------------------------------
if should_fill_gap != 1:
    print("Detected gaps but instructed not to fill. Returning result.")
    display(df_results)
    # Optionally return df_results or save it
else:
    # Explode gaps into missing dates (excluding endpoints)
    def date_range(start, end):
        return [str(d) for d in pd.date_range(start=start, end=end, freq='D')][1:-1]  # exclude start and end

    @pandas_udf(ArrayType(StringType()))
    def generate_dates(start_series: pd.Series, end_series: pd.Series) -> pd.Series:
        return start_series.combine(end_series, date_range)

    gaps_with_dates = df_gap \
        .withColumn("MissingDates", generate_dates(col("AsOfDate"), col("AsOfDateNext"))) \
        .withColumn("MissingDate", explode(col("MissingDates")))

    # Load original stage again for reference IndexLevel
    #stage_ref = df_stage.filter((col("IsValid") == 'Y') & (col("Ignore") == 'N'))
    stage_ref = df_stage


gaps = gaps_with_dates.alias("gaps")
stage = stage_ref.alias("stage")

plug_rows = gaps \
    .join(stage, 
        (gaps_with_dates.IndexId == stage_ref.IndexId) &
        (gaps_with_dates.CurrencyId == stage_ref.CurrencyId) &
        (gaps_with_dates.FrequencyId == stage_ref.FrequencyId) &
        (gaps_with_dates.AsOfDate == stage_ref.AsOfDate),
        how='left'
    ) \
    .select(
        col("gaps.IndexId"),
        col("gaps.FrequencyId"),
        col("MissingDate").cast("date").alias("AsOfDate"),
        col("IndexLevel"),
        lit(0).alias("IndexReturn"),
        col("VendorIndexReturnUnit"),
        col("RunReason"),
        col("Guid"),
        col("AdditionalParam"),
        col("gaps.CurrencyId")
    )
stage.show(10)
plug_rows.show(12)
df_union = stage.union(plug_rows).orderBy("IndexId", "CurrencyId", "FrequencyId", "AsOfDate")
df_union.show(14)


################################################################
#todo: remove this

index_ids = [
    "3499329f-8244-4458-82b0-fd59f38d5b9d",
    "9e407c13-4c92-437f-bf6b-06735b3b33fa",
    "d4b46287-be55-4e15-b46b-8fd005eecae7",
    "6cececd3-4f16-4ece-904a-92bbb1e758bd",
    "d488c25e-f9eb-4bd0-830b-8ba42ac72db9",
    "5531f7b2-21c3-4f11-87c0-01d72fe1499a",
    "a7e95c8a-9aa3-4ff6-981e-624e803e5ae7",
    "6dfedf9a-af76-4972-95b7-effdd9ab0c70",
    "afd52cb5-5591-4092-a74f-51a7a29330b7",
    "d341a6b3-1970-43da-bf90-d7426c5e4f27"
]

df_updated = df_union.withColumn(
    "VendorIndexReturnUnit",
    when(col("IndexId").isin(index_ids), "LEVEL")
    .otherwise(col("VendorIndexReturnUnit"))
)

df_filtered = df_updated.filter(col("VendorIndexReturnUnit") == "RETURN")
count_return = df_filtered.count()

print(f"Number of rows with 'RETURN': {count_return}")

df_filtered.show(50)
################################################################


#todo: ask if this pattern is ok.  we are saving this as staged data.  another notebook needs to do more work on it (compute levels/returns)
#xxx df_union.write.format("delta").mode("overwrite").save(f"{bronze_lh_id}/Tables/Bronze/IndexReturn_STAGE")

# write a temp file to bronze "Files"
df_updated.write.mode("overwrite").parquet( f"{bronze_lh_id}/Files/BloombergIndexReturnGapsFilled")

count_data = df_updated.count()
print(f"Number of rows = : {count_data}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
