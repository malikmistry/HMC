# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

# this notebook promotes data points to next highest frequency (Daily -> Monthly, Monthly -> Quarterly)

# Change History
# 01 got basics working, but, with too many assumptions
# 02 try to get it to work for both (Daily -> Monthly, Monthly -> Quarterly)... not completed
# 03 refactoring folder and lake house to use for tmp parquet files
# 04 more refactoring folder, etc
# 05 back to generalizing logic to work for (Daily -> Monthly, Monthly -> Quarterly)
# 06 got Daily -> Monthly working, now focus on Monthly -> Quarterly

# standard paramaters passed in via MDF
WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
from pyspark.sql import SparkSession
from pyspark.sql.functions import last_day, col, min, max, col, max as spark_max, lit, min as spark_min, when, row_number, current_timestamp, month, to_date
import pandas as pd
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType, DoubleType, DecimalType
from pyspark.sql.window import Window
from delta.tables import DeltaTable

dec_type = DecimalType(38, 11)

# Create Spark session
spark = SparkSession.builder.getOrCreate()
spark.conf.set("spark.sql.decimalOperations.allowPrecisionLoss", "false")


# get index metadata so we know Frequency, etc
dfIndexXref = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index").select("IndexId", "Ticker", "Frequency", "IsLevelBased")
dfIndexXref.show(5)

# read current state of staged data into a dataframe
# at this point, the data had gaps filled and returns computed
df_stage = spark.read.parquet(f"{curated_lh_id}/Files/BloombergIndexReturnCustom")
df_stage = df_stage.orderBy(col("IndexId").asc(), col("CurrencyId").asc(), col("AsOfDate").asc())
df_stage.show(7)

print(f"initial stage count = {df_stage.count()}")


print ("Showing xxxxxxxxxxxxxxxxxxx 0000")
df_stage.filter( 
    (col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd")
& (col("AsOfDate") >= "2025-04-22")
& (col("CurrencyId") == 1)
& (col("FrequencyId") == 8)
).orderBy(col("AsOfDate")).show(15)



# prepare a dataframe containing the Dailies, but for month end data points only
df_month_end = df_stage.filter((col("FrequencyId") == 8) & (col("AsOfDate") == last_day(col("AsOfDate"))))

# set these month end dated data points to 2/Monthly
df_month_end = df_month_end.withColumn("FrequencyId", lit(2)).withColumn("Source", lit("Fabric Frequency Promotion").cast("string"))

df_month_end.show(12)

# now work on quarterlies
df_quarter_end = df_stage.filter(
    (col("AsOfDate") == last_day(col("AsOfDate"))) &
    (month(col("AsOfDate")).isin([3, 6, 9, 12]))
)

# set these quarter end dated data points to 3/Quarterly
df_quarter_end = df_quarter_end.withColumn("FrequencyId", lit(3)).withColumn("Source", lit("Fabric Frequency Promotion").cast("string"))
df_quarter_end.show(13)

# now combine into one dataframe
df_freqs = df_month_end.union(df_quarter_end)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# In order to compute returns, we will need one data point prior to the staged data

#read historical data that will be needed for computations
df_wh = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/IndexReturn")

# get the historic monthlies and quarterlies
df_wh = df_wh.filter((col("FrequencyId") == 2) | (col("FrequencyId") == 3))
df_wh = df_wh.withColumn("Source", lit("Historical"))
df_wh.show(10)

# identify the earliest date for each grouping in our new/raw data set
min_dates = df_freqs\
    .groupBy("IndexId", "CurrencyId", "FrequencyId") \
    .agg(spark_min("AsOfDate").alias("AsOfDate"))

display(min_dates)

# now query the historic data for the max date that is prior to the above min dates
start_rows = df_wh.alias("ir").join(
    min_dates.alias("mindate"),
    (col("ir.IndexId") == col("mindate.IndexId")) &
    (col("ir.CurrencyId") == col("mindate.CurrencyId")) &
    (col("ir.FrequencyId") == col("mindate.FrequencyId")) &
    (col("ir.AsOfDate") < col("mindate.AsOfDate"))
).groupBy("ir.IndexId", "ir.CurrencyId", "ir.FrequencyId") \
 .agg(spark_max("ir.AsOfDate").alias("AsOfDate"))

#leverage the staged data to create an index "metadata" dataframe
df_index_metadata = df_freqs.dropDuplicates(["IndexId", "CurrencyId", "FrequencyId"]).alias("stg")

# Join in order to get the historic data with desired columns
wh = df_wh.alias("wh")
sr = start_rows.alias("sr")
metadata = df_index_metadata.alias("md")

wh.show(6)
sr.show(7)
metadata.show(8)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

historical_data = wh.join(
    sr,
    on=["IndexId", "CurrencyId", "FrequencyId", "AsOfDate"],
    how="inner"
).join(
    metadata,
    on=["IndexId", "CurrencyId", "FrequencyId"],
    how="inner"
).select(
    col("wh.IndexId"),
    col("wh.FrequencyId"),
    col("wh.AsOfDate"),
    col("wh.IndexLevel"),
    col("wh.IndexReturn"),
    col("md.VendorIndexReturnUnit"),  # need to get this from stage
    col("md.RunReason"),
    col("md.Guid"),
    col("md.AdditionalParam"),
    col("wh.CurrencyId"),
    col("wh.Source")
)

# flag this data as "Historical" so that we can filter it out later
# filter it out later in the notebook
historical_data = historical_data.withColumn("Source", lit("Historical"))
historical_data.show(3)

df_freqs.show(20)

# Union the stage data with the historic data
df_freqs = df_freqs.unionByName(historical_data)

# separate out return based data into a separate dataframe
df_freqs_returns = df_freqs.filter(col("VendorIndexReturnUnit") == "RETURN")

# keep level based data in df_freqs
df_freqs = df_freqs.filter(col("VendorIndexReturnUnit") == "LEVEL")
df_freqs.show(22)

df_xxx = df_stage.filter((col("IndexId") == "04aa2a49-255e-439e-adff-3935e49e4c8c") & (col("AsOfDate") == "2025-07-31") & (col("CurrencyId") == 26)).orderBy(col("AsOfDate"))
df_xxx.show(6)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# need to know earliest data in staged data in order to find one data point prior
df_summary = df_freqs.agg(
    min("AsOfDate").alias("MinDate"),
    max("AsOfDate").alias("MaxDate")
)
df_summary.show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


df_xxx = df_stage.filter((col("IndexId") == "547c92eb-98c6-4167-94f7-48ced9f2f7f7") & (col("AsOfDate") == "2025-07-29") & (col("CurrencyId") == 1)).orderBy(col("AsOfDate"))
df_xxx.show(6)

df_xxx = df_freqs.filter((col("IndexId") == "547c92eb-98c6-4167-94f7-48ced9f2f7f7") & (col("AsOfDate") == "2025-07-29") & (col("CurrencyId") == 1)).orderBy(col("AsOfDate"))
df_xxx.show(6)

# Add Row Numbers and Calculate LEVEL-Based Returns (month over month)
window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("AsOfDate")
df_freqs = df_freqs.withColumn("RowNum", row_number().over(window_spec))

# Join with previous row to compute LEVEL-based returns
df_prev = df_freqs.withColumnRenamed("RowNum", "RowNumPrev") \
                  .withColumnRenamed("IndexLevel", "IndexLevelPrev")

df_computed = df_freqs.alias("curr").join(
    df_prev.alias("prev"),
    (col("curr.IndexId") == col("prev.IndexId")) &
    (col("curr.CurrencyId") == col("prev.CurrencyId")) &
    (col("curr.FrequencyId") == col("prev.FrequencyId")) &
    (col("curr.RowNum") == col("prev.RowNumPrev") + 1)
).withColumn(
    "CalcIndexReturn",
    when(col("prev.IndexLevelPrev") == 0, lit(0.0).cast(dec_type))
    .otherwise(
     ( 
      (col("curr.IndexLevel").cast(dec_type) - col("prev.IndexLevelPrev").cast(dec_type))
      
      / col("prev.IndexLevelPrev").cast(dec_type)
     ).cast(dec_type)))


df_xxx = df_computed.filter((col("curr.IndexId") == "f23798b7-6c88-4547-b90c-ae6e5c2654e4") & (col("curr.AsOfDate") == "2025-06-30") & (col("curr.CurrencyId") == 1)).orderBy(col("curr.AsOfDate"))
df_xxx.show(6)

df_computed.show(10)

# filter out the "Historic" data points that were only needed to do the returns computations
df_computed = df_computed.filter(col("curr.Source") != "Historical")
df_computed.show(10)

# get back to desired set of columns
df_freqs = df_computed.select("curr.IndexId", "curr.FrequencyId", "curr.AsOfDate", "curr.IndexLevel", col("CalcIndexReturn").alias("IndexReturn"), 
  "curr.VendorIndexReturnUnit","curr.RunReason","curr.Guid","curr.AdditionalParam","curr.CurrencyId","curr.Source")

df_freqs.show(9)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# df_xxx = df_freqs.filter((col("IndexId") == "04aa2a49-255e-439e-adff-3935e49e4c8c") & (col("AsOfDate") == "2025-07-31") & (col("CurrencyId") == 26)).orderBy(col("AsOfDate"))
# df_xxx.show(6)
# df_stage.show(7)

# union the initial set of stage data with newly computed frequency promotions
df_stage = df_stage.union(df_freqs)


print(f"count before = {df_stage.count()}")

# the union does not drop dups, so do it here 
df_stage = df_stage.dropDuplicates()

#xxx todo: figure out why than count can be over 2000 different
#count before = 404703
#count after =  402520
print(f"count after = {df_stage.count()}")

#todo: fire Crimson Event to alert others that the data load has completed
df_summary = df_stage.agg(
    min("AsOfDate").alias("MinAsOfDate"),
    max("AsOfDate").alias("MaxAsOfDate"),
    max("RunReason").alias("MaxRunReason"),
    max("Guid").alias("MaxGuid"),
    max("AdditionalParam").alias("MaxAdditionalParam")
)

df_summary.show()

# make the dataframe look like IndexReturn

currentTs = current_timestamp()

#xxx check on this... only flag as updated by "Fabric" if the notebook truly updated the data
#get more columns added to match IndexReturn with which we will need to merge
df_stage = df_stage.withColumn("ReturnComment", lit(None).cast("string")) \
.withColumn("ReturnSource", lit(None).cast("string")) \
.withColumn("VersionNum", lit(-999).cast("BigInt")) \
.withColumn("UpdateTimeStamp", currentTs) \
.withColumn("ETLLoadDateTime", currentTs)
# .withColumn("IndexLevel", col("IndexLevel").cast("Decimal(26,11)")) \
# .withColumn("IndexReturn", col("IndexReturn").cast("Decimal(26,11)"))



# now get columns in same order as current CrimsonX prod IndexReturns
df_stage = df_stage.select("IndexId", "FrequencyId", "AsOfDate", 
  "CurrencyId", "IndexLevel", "IndexReturn", "ReturnComment",
"ReturnSource","VersionNum", "UpdateTimeStamp", "Source",
"ETLLoadDateTime")

#todo: keep these? these three are new/extra need to identify why we are loading this data
#"curr.RunReason","curr.Guid","curr.AdditionalParam")



#xxx todo: figure out why we have dups here
df_check_for_dups = df_stage.groupBy("IndexId", "FrequencyId", "AsOfDate", "CurrencyId") \
    .count() \
    .filter("count > 1")
if df_check_for_dups.count() > 0:
  display(df_check_for_dups)
  raise Exception("Problem: found duplicate rows in frequency promotion.  Need to investigate.")


# note: for IndexReturn processing, this is the first place where we modify the IndexReturn table
# xxx TODO: figure out the best practice for having NON NULL columns (and other integrity constraints)

#spark.sql(f"ALTER TABLE {curated_lh_id}/Tables/Silver/IndexReturn ALTER COLUMN IndexReturn SET NOT NULL")


df_stage = df_stage.withColumnRenamed("Source", "UpdateByHMCUserId")
# df_stage.show(17)


print ("Showing xxxxxxxxxxxxxxxxxxx 1111")
df_stage.filter( 
    (col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd")
& (col("AsOfDate") >= "2025-04-22")
& (col("CurrencyId") == 1)
& (col("FrequencyId") == 8)
).orderBy(col("AsOfDate")).show(15)

#merge dataframe to the delta table
# delta_table = DeltaTable.forPath(spark, f"{curated_lh_id}/Tables/Silver/IndexReturn")
# mergeReturn = delta_table.alias("target").merge(
#     df_stage.alias("source"),
#     "target.IndexId = source.IndexId AND target.FrequencyId = source.FrequencyId AND target.AsOfDate = source.AsOfDate AND target.CurrencyId = source.CurrencyId"
# ).whenMatchedUpdateAll() \
#  .whenNotMatchedInsertAll() \
#  .execute()

# print(mergeReturn)

# # query delta table to look for results of above merge
# hist = delta_table.history(1).select("operation", "operationMetrics")
# op, metrics = hist.collect()[0]
# print(op)
# for k, v in metrics.items():
#     print(f"{k}: {v}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#delta_table = DeltaTable.forPath(spark, f"{curated_lh_id}/Tables/Silver/IndexReturn")

# make df_stage visible to SQL
df_stage.createOrReplaceTempView("source_stage")

spark.sql(f"""
MERGE INTO delta.`{curated_lh_id}/Tables/Silver/IndexReturn` AS target
USING source_stage AS source
ON  target.IndexId     = source.IndexId
AND target.FrequencyId = source.FrequencyId
AND target.AsOfDate    = source.AsOfDate
AND target.CurrencyId  = source.CurrencyId
WHEN MATCHED THEN
  UPDATE SET *
WHEN NOT MATCHED THEN
  INSERT *
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC --select  * from lh_curated.Silver.IndexReturn where IndexId = '176ce410-3838-4292-8c24-d7694e8705fd' and AsOfDate >= '2025-04-22' order by AsOfDate  LIMIT 100
# MAGIC 
# MAGIC select distinct UpdateByHMCUserId from  lh_curated.Silver.IndexReturn where  AsOfDate >= '2025-01-01'
# MAGIC 
# MAGIC 
# MAGIC -- select * from [lh_curated].[Silver].[IndexReturn] ret 
# MAGIC -- WHERE  ret.IndexId = '176ce410-3838-4292-8c24-d7694e8705fd'
# MAGIC -- and ret.AsOfDate >= '2025-04-24'
# MAGIC -- ORDER BY ret.AsOfDate 

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql 
# MAGIC 
# MAGIC -- xxx for debugging
# MAGIC select  * from source_stage where IndexId = '176ce410-3838-4292-8c24-d7694e8705fd'   LIMIT 100

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#########################################################################################
# more debugging... I do not see the 0.0 getting into the Delta Table from Azure Data Explorer
# zero = lit(0).cast(delta_tbl.toDF().schema["IndexLevel"].dataType)
# delta_tbl = DeltaTable.forPath(spark, f"{curated_lh_id}/Tables/Silver/IndexReturn")
# delta_tbl.update(
#     condition="IndexId = '547c92eb-98c6-4167-94f7-48ced9f2f7f7' and AsOfDate >= DATE '2025-04-30'",
#     set={"IndexLevel": zero}
# )

df_stage.write.mode("overwrite").parquet( f"{curated_lh_id}/Files/BloombergIndexReturnFrequencyPromoted")

#xxx add flush???
# from delta.tables import DeltaTable
# delta_tbl = DeltaTable.forPath(spark, f"{curated_lh_id}/Tables/Silver/IndexReturn")
# delta_tbl.checkpoint()


spark.sql("REFRESH TABLE lh_curated.Silver.IndexReturn")
spark.sql("SELECT COUNT(*) FROM lh_curated.Silver.IndexReturn").show()


print("Done.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC -- SELECT COUNT(*) FROM lh_curated.Silver.IndexReturn
# MAGIC SELECT * FROM lh_curated.Silver.IndexReturn ORDER BY UpdateTimeStamp DESC limit 10

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
