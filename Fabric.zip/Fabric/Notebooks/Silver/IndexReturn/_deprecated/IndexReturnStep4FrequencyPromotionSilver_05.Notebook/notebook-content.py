# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# this notebook promotes data points to next highest frequency (Daily -> Monthly, Monthly -> Quarterly)

# Change History
# 01 got basics working, but, with too many assumptions
# 02 try to get it to work for both (Daily -> Monthly, Monthly -> Quarterly)... not completed
# 03 refactoring folder and lake house to use for tmp parquet files
# 04 more refactoring folder, etc
# 05 back to generalizing logic to work for (Daily -> Monthly, Monthly -> Quarterly)

WorkspaceId = ''
BronzeLhId = ''
CuratedLhId = ''

#TODO: change to use params
#todo: move to shared notebook??
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
CuratedLhId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

def get_basepath(workspace_id, lakehouse_id) -> str: 
    lh_basepath = 	f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}" 
    return lh_basepath

curated_lh_id = get_basepath(WorkspaceId, CuratedLhId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
from pyspark.sql import SparkSession
from pyspark.sql.functions import last_day, col, min, max, col, max as spark_max, lit, min as spark_min, when, row_number, current_timestamp, month
import pandas as pd
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType, DoubleType
from pyspark.sql.window import Window
from delta.tables import DeltaTable

# Create Spark session
spark = SparkSession.builder.getOrCreate()

# get index metadata so we know Frequency, etc
dfIndexXref = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index").select("IndexId", "Ticker", "Frequency", "IsLevelBased")
dfIndexXref.show(5)

# read current state of staged data into a dataframe
# at this point, the data had gaps filled and returns computed
df_stage = spark.read.parquet(f"{curated_lh_id}/Files/BloombergIndexReturnCalculated")
df_stage = df_stage.orderBy(col("IndexId").asc(), col("CurrencyId").asc(), col("AsOfDate").asc())
df_stage.show(7)

#xxx df_stage.filter((col("IndexId") == "178b38b1-5d51-4e0d-90bd-e65dbf7e8d73") & (col("CurrencyId") == 29) & (col("AsOfDate") == "2025-05-31")).show(20)

print(f"initial stage count = {df_stage.count()}")

# prepare a dataframe containing the Dailies, but for month end data points only
df_month_end = df_stage.filter((col("FrequencyId") == 8) & (col("AsOfDate") == last_day(col("AsOfDate"))))

# set these month end dated data points to 2/Monthly
df_month_end = df_month_end.withColumn("FrequencyId", lit(2))
df_month_end.show(12)


# xxx handle quarterlies later

# # now work on quarterlies
# df_quarter_end = df_stage.filter(
#     (col("AsOfDate") == last_day(col("AsOfDate"))) &
#     (month(col("AsOfDate")).isin([3, 6, 9, 12]))
# )

# # set these quarter end dated data points to 3/Quarterly
# df_quarter_end = df_quarter_end.withColumn("FrequencyId", lit(3))
# df_quarter_end.show(13)

# # now combine into one dataframe
# df_freqs = df_month_end.union(df_quarter_end)

df_freqs = df_month_end


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# In order to compute returns, we will need one data point prior to the staged data

#read historical data that will be needed for computations
df_wh = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/IndexReturn")

# get the historic monthlies and quarterlies
df_wh = df_wh.filter((col("FrequencyId") == 2) | (col("FrequencyId") == 3))
df_wh = df_wh.withColumn("Source", lit("Historical"))
df_wh.show(10)

# identify the earliest date for each grouping in our new/raw data set
min_dates = df_freqs\
    .groupBy("IndexId", "CurrencyId", "FrequencyId") \
    .agg(spark_min("AsOfDate").alias("AsOfDate"))

display(min_dates)

# now query the historic data for the max date that is prior to the above min dates
start_rows = df_wh.alias("ir").join(
    min_dates.alias("mindate"),
    (col("ir.IndexId") == col("mindate.IndexId")) &
    (col("ir.CurrencyId") == col("mindate.CurrencyId")) &
    (col("ir.FrequencyId") == col("mindate.FrequencyId")) &
    (col("ir.AsOfDate") < col("mindate.AsOfDate"))
).groupBy("ir.IndexId", "ir.CurrencyId", "ir.FrequencyId") \
 .agg(spark_max("ir.AsOfDate").alias("AsOfDate"))

#leverage the staged data to create an index "metadata" dataframe
df_index_metadata = df_freqs.dropDuplicates(["IndexId", "CurrencyId", "FrequencyId"]).alias("stg")

# Join in order to get the historic data with desired columns
wh = df_wh.alias("wh")
sr = start_rows.alias("sr")
metadata = df_index_metadata.alias("md")

wh.show(6)
sr.show(7)
metadata.show(8)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

start_data = wh.join(
    sr,
    on=["IndexId", "CurrencyId", "FrequencyId", "AsOfDate"],
    how="inner"
).join(
    metadata,
    on=["IndexId", "CurrencyId", "FrequencyId"],
    how="inner"
).select(
    col("wh.IndexId"),
    col("wh.FrequencyId"),
    col("wh.AsOfDate"),
    col("wh.IndexLevel"),
    col("wh.IndexReturn"),
    col("md.VendorIndexReturnUnit"),  # need to get this from stage
    col("md.RunReason"),
    col("md.Guid"),
    col("md.AdditionalParam"),
    col("wh.CurrencyId"),
    col("wh.Source")
)

# flag this data as not valid because we do not want to move it to move to next medallion
#xxx
start_data = start_data.withColumn("Source", lit("Historical"))
start_data.show(3)

df_freqs.show(20)

# Union the stage data with the historic data
df_freqs = df_freqs.unionByName(start_data)

##############################################################
# xxx todo: remove this once data is fixed in CrimsonX 
# df_freqs = df_freqs.withColumn(
#     "VendorIndexReturnUnit",
#     when(col("IndexId") == "604271f0-de76-45f0-b9cf-220c51e42149", "LEVEL")
#     .otherwise(col("VendorIndexReturnUnit"))
# )
##############################################################

# separate out return based data into a separate dataframe
df_freqs_returns = df_freqs.filter(col("VendorIndexReturnUnit") == "RETURN")

# keep level based data in df_freqs
df_freqs = df_freqs.filter(col("VendorIndexReturnUnit") == "LEVEL")
df_freqs.show(22)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# need to know earliest data in staged data in order to find one data point prior
df_summary = df_freqs.agg(
    min("AsOfDate").alias("MinDate"),
    max("AsOfDate").alias("MaxDate")
)
df_summary.show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Add Row Numbers and Calculate LEVEL-Based Returns (month over month)
window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("AsOfDate")
df_freqs = df_freqs.withColumn("RowNum", row_number().over(window_spec))

# Join with previous row to compute LEVEL-based returns
df_prev = df_freqs.withColumnRenamed("RowNum", "RowNumPrev") \
                  .withColumnRenamed("IndexLevel", "IndexLevelPrev")

df_computed = df_freqs.alias("curr").join(
    df_prev.alias("prev"),
    (col("curr.IndexId") == col("prev.IndexId")) &
    (col("curr.CurrencyId") == col("prev.CurrencyId")) &
    (col("curr.FrequencyId") == col("prev.FrequencyId")) &
    (col("curr.RowNum") == col("prev.RowNumPrev") + 1)
).withColumn(
    "CalcIndexReturn",
    when(col("prev.IndexLevelPrev") == 0, lit(0.0))
    .otherwise((col("curr.IndexLevel") - col("prev.IndexLevelPrev")) / col("prev.IndexLevelPrev"))
)

#display(df_computed)
df_computed.show(10)


# filter out the "Historic" data points that were only needed to do the return computation

df_computed = df_computed.filter(col("prev.Source") != "Historical")
df_computed.show(10)



# df_xxx_debug = df_computed.groupBy("curr.IndexId", "curr.FrequencyId", "curr.AsOfDate", "curr.CurrencyId") \
#     .count() \
#     .filter("count > 1")
# display(df_xxx_debug)
# exit(0)

df_xxx = df_computed.filter((col("curr.IndexId") == "d3b06c27-a8d0-4e5f-ba82-fb7f063c836e") & (col("curr.CurrencyId") == 10))
df_xxx.show(100)


# get back to desired set of columns
df_freqs = df_computed.select("curr.IndexId", "curr.FrequencyId", "curr.AsOfDate", "curr.IndexLevel", col("CalcIndexReturn").alias("IndexReturn"), 
  "curr.VendorIndexReturnUnit","curr.RunReason","curr.Guid","curr.AdditionalParam","curr.CurrencyId","curr.Source",)

df_freqs.show(13)

#xxx write out file for development... remove this later
df_freqs.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(f"{curated_lh_id}/Tables/Silver/IndexReturn_STAGE_for_compare")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# union the initial set of stage data with newly computed frequency promotions
df_stage = df_stage.union(df_freqs)

print(f"count before = {df_stage.count()}")

# the union does not drop dups, so do it here 
df_stage = df_stage.dropDuplicates()

print(f"count after = {df_stage.count()}")


#todo: fire Crimson Event to alert others that the data load has completed
df_summary = df_stage.agg(
    min("AsOfDate").alias("MinAsOfDate"),
    max("AsOfDate").alias("MaxAsOfDate"),
    max("RunReason").alias("MaxRunReason"),
    max("Guid").alias("MaxGuid"),
    max("AdditionalParam").alias("MaxAdditionalParam")
)

df_summary.show()

# make the dataframe look like IndexReturn

#todo: use this or ETLLoadDateTime??
currentTs = current_timestamp()

#get more columns added to match IndexReturn with which we will need to merge
df_stage = df_stage.withColumn("ReturnComment", lit(None).cast("string")) \
.withColumn("ReturnSource", lit(None).cast("string")) \
.withColumn("VersionNum", lit(-999).cast("string")) \
.withColumn("UpdateTimeStamp", currentTs) \
.withColumn("UpdateByHmcUserId", lit(None).cast("string")) \
.withColumn("ETLLoadDateTime", currentTs)

#df_stage.printSchema()
#df_stage.show(10)

# now get columns in same order as current CrimsonX prod IndexReturns
df_stage = df_stage.select("IndexId", "FrequencyId", "AsOfDate", 
  "CurrencyId", "IndexLevel", "IndexReturn", "ReturnComment",
"ReturnSource","VersionNum", "UpdateTimeStamp", "UpdateByHmcUserId",
"ETLLoadDateTime")

#todo: keep these? these three are new/extra need to identify why we are loading this data
#"curr.RunReason","curr.Guid","curr.AdditionalParam")


#xxx todo: figure out why we have dups here
df_check_for_dups = df_stage.groupBy("IndexId", "FrequencyId", "AsOfDate", "CurrencyId") \
    .count() \
    .filter("count > 1")
if df_check_for_dups.count() > 0:
  display(df_check_for_dups)
  #xxx log issue
  df_xxx = df_stage.filter((col("IndexId") == "d3b06c27-a8d0-4e5f-ba82-fb7f063c836e") & (col("AsOfDate") == "2025-06-30") & (col("CurrencyId") == 10))
  df_xxx.show(100)


#merge dataframe to the delta table
delta_table = DeltaTable.forPath(spark, f"{curated_lh_id}/Tables/Silver/IndexReturn")
delta_table.alias("target").merge(
    df_stage.alias("source"),
    "target.IndexId = source.IndexId AND target.FrequencyId = source.FrequencyId AND target.AsOfDate = source.AsOfDate AND target.CurrencyId = source.CurrencyId"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

print("Done.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
