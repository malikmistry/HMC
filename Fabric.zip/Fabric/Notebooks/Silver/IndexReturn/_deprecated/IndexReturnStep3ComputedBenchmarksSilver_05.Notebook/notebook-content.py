# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

# Change History
# 01 initial version intended to support custom/computed benchmarks (e.g. 50% of one index and 50% of another)
# 02 first version that is starting to take shape

WorkspaceId = ''
BronzeLhId = ''
CuratedLhId = ''

#TODO: change to use params
#todo: move to shared notebook??
#e.g bronze_lh_id = 'abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558'
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLhId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLhId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

def get_basepath(workspace_id, lakehouse_id) -> str: 
    lh_basepath = 	f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}" 
    return lh_basepath

bronze_lh_id = get_basepath(WorkspaceId, BronzeLhId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLhId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import SparkSession, Window, DataFrame
from functools import reduce
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType, DateType, DecimalType
from datetime import date
from pyspark.sql.functions import last_day, col, min, max, lit, when, row_number, current_timestamp, month, rank, sum
from decimal import Decimal

spark = SparkSession.builder.getOrCreate()
spark.conf.set("spark.sql.decimalOperations.allowPrecisionLoss", "false")

dec_type = DecimalType(38, 11)

# computed benchmarks only supported for USD and Daily
currency_id = 1 # xxx USD... prod does USD only

frequency_id = 8 #xxx Daily

index_load_control = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index")
index_load_control = index_load_control.select("IndexId", "isCustomIndex", "Frequency", "DisplayName", "IsActive")

#xxx look at anything in df
print("showing index_load_control")
index_load_control.filter((col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd") | (col("IndexId") == "18b7c764-774f-4a80-aad7-0edebc0207c3")
| (col("IndexId") == "37028766-65c5-43e0-9fea-2088e246d8d8") ).show(5)

#xxx irr = spark.table("etl.IndexReturnRecipe")
schema = StructType([
    StructField("IndexIdTarget", StringType(), False),
    StructField("IndexIdSource", StringType(), False),
    StructField("CurrencyId", IntegerType(), False),
    StructField("IndexContributionPct", dec_type, False),
    StructField("CreateLevel", IntegerType(), False),
    StructField("RecipeType", StringType(), False),
])
#xxx todo: replace with call to a new recipe delta table
data = [
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "18b7c764-774f-4a80-aad7-0edebc0207c3", 1, Decimal("50.0"), 0, "CUSTOM" ),
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "37028766-65c5-43e0-9fea-2088e246d8d8", 1, Decimal("50.0"), 0, "CUSTOM" ),

    # Natural Resources Benchmark	e9d419ba-9a21-ea11-8133-0050569a56ba	Cambridge Associates Natural Resources	55d419ba-9a21-ea11-8133-0050569a56ba
    # CrimsonX   84bd39b3-9e52-4eba-86be-4979bddeb9df   1f1a7e47-847d-471f-9af6-76221462304d
    #todo: support quarterly
    ("1f1a7e47-847d-471f-9af6-76221462304d", "84bd39b3-9e52-4eba-86be-4979bddeb9df", 1, Decimal("100.0"), 0, "CUSTOM" ),

    # 250% MSCI ACWI TR	63701978-C464-43BB-AD50-3433BED49010	Y	MSCI AC World TR Net USD	8ED419BA-9A21-EA11-8133-0050569A56BA	Y	CUSTOM	554	306	1950-01-01	9999-12-31	250.0000000000
    # this one is 8/Daily
    ("176ce410-3838-4292-8c24-d7694e8705fd", "e4a151b5-511d-4de9-9b87-d22bd05753f6", 1, Decimal("250.0"), 0, "CUSTOM" ),

    # Russell 2000 Inverse	0DB08336-DB66-47DF-A695-89AE79F3ECD6	Y	Russell 2000	01D519BA-9A21-EA11-8133-0050569A56BA	Y	INVERSE	544	393	1950-01-01	9999-12-31	-100.0000000000	2022-05-17 08:41:57.893	reidd	NULL
    ("22854b09-25a7-4dcf-82f3-98a89504709b", "cc53584e-edd5-49bd-961e-19ff2eee4cfc", 1, Decimal("-100.0"), 0, "INVERSE" ),

    #todo: 80% SPX Long, this takes 80% SPX and 20% of "Zero Percent Benchmark" which has 0 rows in IndexReturn... does that mean the "sum()" is only summing the .80 of SPX and getting nothing for the other "zero" benchmark?
    ("d6677877-4001-4269-94a4-17e2904e02f6", "91bd2f6c-6b28-4460-b8ea-11aae5546d71", 1, Decimal("80.0"), 0, "CUSTOM" ),
    ("d6677877-4001-4269-94a4-17e2904e02f6", "faf2e7ab-6593-461b-a8ef-4435bab5ffaf", 1, Decimal("20.0"), 0, "CUSTOM" ),

    # "250% EuroStoxx & S&P 500 Blend Inverse" odd name, but, the recipe is -250 of another computed benchmark, "EuroStoxx & S&P 500 Blend"
    ("22adae54-10d5-4f59-a6a1-7f9b07aaa6dc", "547c92eb-98c6-4167-94f7-48ced9f2f7f7", 1, Decimal("-250.0"), 0, "INVERSE" ),

]
index_return_recipe = spark.createDataFrame(data, schema)
index_return_recipe.show(11)


xxx_recipe_2 = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/IndexCustomBlendRecipe")
xxx_recipe_2.show(22)

raise SystemExit("xxx")

schema = StructType([
    StructField("IndexId", StringType(), False),
    StructField("IndexName", StringType(), False),
    StructField("CurrencyId", IntegerType(), False),
    StructField("FrequencyId", IntegerType(), False),
    StructField("LoadStartDate", DateType(), False),  # earliest date for data from BB
    StructField("LoadEndDate", DateType(), False),  # latest date from BB
    StructField("ReturnStartDate", DateType(), False), # date needed to get data from "wh" (one day prior to new data)
    StructField("CreateLevel", IntegerType(), False)
])
LoadStartDate = date(2025, 4, 28)
LoadEndDate = date(2025, 8, 13)
ReturnStartDate = date(2025, 4, 27)
#xxx todo: replace with call to a new recipe delta table, and compute ReturnStartDate
data = [
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "EuroStoxx & S&P 500 Blend", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("18b7c764-774f-4a80-aad7-0edebc0207c3",                    "iiii_1", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("37028766-65c5-43e0-9fea-2088e246d8d8",                    "iiii_2", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("1f1a7e47-847d-471f-9af6-76221462304d","Natural Resources Benchmark", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("84bd39b3-9e52-4eba-86be-4979bddeb9df","Cambridge Associates Natural Resources", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("176ce410-3838-4292-8c24-d7694e8705fd",         "250% MSCI ACWI TR", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("e4a151b5-511d-4de9-9b87-d22bd05753f6",  "MSCI AC World TR Net USD", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("22854b09-25a7-4dcf-82f3-98a89504709b",      "Russell 2000 Inverse", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("cc53584e-edd5-49bd-961e-19ff2eee4cfc",              "Russell 2000", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("d6677877-4001-4269-94a4-17e2904e02f6",              "80% SPX Long", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("91bd2f6c-6b28-4460-b8ea-11aae5546d71","S&P 500 INDEX AT UNITED STATES", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("faf2e7ab-6593-461b-a8ef-4435bab5ffaf",      "Zero Percent Benchmark", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("22adae54-10d5-4f59-a6a1-7f9b07aaa6dc",      "250% EuroStoxx & S&P 500 Blend Inverse", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 )
]
index_universe = spark.createDataFrame(data, schema)
#index_universe.show(22)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, when, sum, broadcast

def build_index_recipe_dependency_levels(
    index_return_recipe: DataFrame,
    index_load_control: DataFrame
) -> list[DataFrame]:
    # Join to determine whether each IndexIdSource is a custom index
    recipe_with_is_custom = index_return_recipe \
        .join(
            broadcast(index_load_control.selectExpr("IndexId as IndexIdSource", "IsCustomIndex")),
            on="IndexIdSource",
            how="left"
        )

    recipe_levels = []
    processed_targets = set()

    # Level 0: Targets whose sources are ALL non-custom
    level_df = recipe_with_is_custom.groupBy("IndexIdTarget") \
        .agg(sum(when(col("IsCustomIndex") == True, 1).otherwise(0)).alias("num_custom_sources")) \
        .filter(col("num_custom_sources") == 0) \
        .select("IndexIdTarget")

    level_0_targets = [row["IndexIdTarget"] for row in level_df.collect()]
    processed_targets.update(level_0_targets)

    level_0_df = recipe_with_is_custom.filter(col("IndexIdTarget").isin(level_0_targets))
    recipe_levels.append(level_0_df)

    # Iteratively build higher dependency levels
    while True:
        remaining = recipe_with_is_custom.filter(~col("IndexIdTarget").isin(list(processed_targets)))
        if remaining.isEmpty():
            break

        candidate_targets = remaining.select("IndexIdTarget").distinct()
        next_targets = []

        for row in candidate_targets.collect():
            target = row["IndexIdTarget"]
            source_rows = remaining.filter(col("IndexIdTarget") == target).select("IndexIdSource").collect()
            source_ids = [r["IndexIdSource"] for r in source_rows]

            # A target is eligible if all its sources are either non-custom or already processed
            all_sources_valid = all(
                index_load_control.filter(col("IndexId") == src).select("IsCustomIndex").first()["IsCustomIndex"] == False or
                src in processed_targets
                for src in source_ids
            )

            if all_sources_valid:
                next_targets.append(target)

        if not next_targets:
            break  # Prevent infinite loop if there's a circular dependency

        processed_targets.update(next_targets)
        level_df = recipe_with_is_custom.filter(col("IndexIdTarget").isin(next_targets))
        recipe_levels.append(level_df)

    return recipe_levels

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

ilc = index_load_control
irr = index_return_recipe

# get original state of "staged" data we are working with
df_stage_orig = spark.read.parquet(f"{curated_lh_id}/Files/BloombergIndexReturnCalculated")

# filter down to just the currency of interest for this notebook invocation
df_stage = df_stage_orig.filter(col("Currencyid") == currency_id)

df_stage = df_stage.orderBy(col("IndexId").asc(), col("CurrencyId").asc(), col("AsOfDate").asc())
#df_stage.show(7)

# get values from the stage data
agg_result = df_stage.agg(
    max("VendorIndexReturnUnit").alias("max_VendorIndexReturnUnit"),
    max("RunReason").alias("max_RunReason"),
    max("Guid").alias("max_Guid"),
    max("AdditionalParam").alias("max_AdditionalParam")
).collect()[0]

# Extract each value into its own variable
max_VendorIndexReturnUnit   = agg_result["max_VendorIndexReturnUnit"]
max_RunReason = agg_result["max_RunReason"]
max_Guid  = agg_result["max_Guid"]
max_AdditionalParam  = agg_result["max_AdditionalParam"]

ingredient_dates = index_universe.alias("iu") \
    .join(irr.alias("irr"), col("iu.IndexId") == col("irr.IndexIdTarget")) \
    .join(df_stage.alias("stage"), col("irr.IndexIdSource") == col("stage.IndexId")) \
    .groupBy("iu.IndexId") \
    .agg(
        min("stage.AsOfDate").alias("LoadStartDate"),
        max("stage.AsOfDate").alias("LoadEndDate")
    )

#ingredient_dates.show(22)

dated_universe = index_universe.join(ingredient_dates, on="IndexId", how="left")

print("Full Universe joined")
#dated_universe.show(99)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def computeBenchmarks(
    df_stage: DataFrame,
    df_recipe: DataFrame
) -> list[DataFrame]:

    print("IN computeBenchmarks, showing df_stage")
    df_stage.show(5)

    # get historic data
    df_wh = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/IndexReturn")

    # filter down to just the currency we are working with
    df_wh = df_wh.filter(col("Currencyid") == currency_id)

    df_wh = df_wh.withColumn("Source", lit("Historical"))
    # df_wh.show(5)

    # df_wh.filter( 
    #     (col("IndexId") == "e4a151b5-511d-4de9-9b87-d22bd05753f6")
    # & (col("AsOfDate") >= "2025-04-17")
    # & (col("CurrencyId") == 1)
    # ).orderBy(col("AsOfDate")).show(15)


    print ("Showing recipe...")
    df_recipe.show(100)

    # now get one data point earlier than our staged data
    start_rows = df_wh.alias("ir").join(
        index_universe.alias("mindate"),
        (col("ir.IndexId") == col("mindate.IndexId")) &
        (col("ir.CurrencyId") == col("mindate.CurrencyId")) &
        (col("ir.FrequencyId") == col("mindate.FrequencyId")) &
        (col("ir.AsOfDate") == col("mindate.ReturnStartDate"))) \
        .select("ir.IndexId", "ir.AsOfDate", "ir.FrequencyId", "ir.CurrencyId", "ir.IndexLevel", "ir.IndexReturn")

    start_rows = start_rows.withColumn("RecordSource", lit("Historical"))
    start_rows.show(10)
    df_wh.show(11)

    print ("Showing xxxxxxxxxxxxxxxxxxx 0000")
    df_wh.filter( 
        (col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd")
    & (col("AsOfDate") >= "2025-04-22")
    & (col("CurrencyId") == 1)
    ).orderBy(col("AsOfDate")).show(15)

    df_recipe.show(9)
    df_stage.show(4)

    # input_returns = df_recipe.alias("r") \
    #     .join(df_stage.alias("s"), col("r.IndexIdSource") == col("s.IndexId")) \
    #     .select(
    #         "r.IndexIdTarget", "s.FrequencyId", "s.AsOfDate", "s.IndexReturn", "r.IndexContributionPct",
    #     "s.CurrencyId", "s.VendorIndexReturnUnit", "s.RunReason", "s.Guid", "s.AdditionalParam"         )

    input_returns = df_recipe.alias("r") \
        .join(df_stage.alias("s"), col("r.IndexIdSource") == col("s.IndexId")) \
        .select(
            "r.IndexIdTarget", "s.FrequencyId", "s.AsOfDate", "s.IndexReturn", "r.IndexContributionPct",
        "s.CurrencyId"  )

    #input_returns.orderBy(col("AsOfDate").asc()).show(8)

    #xxx debug this to see if we are setting this to None
    input_returns = input_returns.withColumnRenamed("IndexIdTarget", "IndexId")


    input_returns.show(11)

    # input_returns.filter((col("AsOfDate") == "2025-04-17") & (col("CurrencyId") == 1)).show(17)

    # Step 1: Add WeightedReturn with true Decimal precision
    input_returns = input_returns.withColumn(
        "WeightedReturn",
        (
            col("IndexReturn").cast(dec_type) *
            col("IndexContributionPct").cast(dec_type) /
            lit(Decimal("100.0")).cast(dec_type)
        ).cast(dec_type)
    )

    print("showing input_returns")
    input_returns.filter( 
        (col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd")
    & (col("AsOfDate") >= "2025-04-17")
    & (col("CurrencyId") == 1)
    ).orderBy(col("AsOfDate").desc()).show(13)


    # Step 2: Now sum the precomputed Decimal column
    blended_returns = input_returns.groupBy("IndexId", "AsOfDate", "FrequencyId", "CurrencyId") \
        .agg(
            sum("WeightedReturn").cast(dec_type).alias("IndexReturn")
        ) \
        .withColumn("IndexLevel", lit(0).cast(dec_type)) \
        .withColumn("RecordSource", lit("Computation(1)"))

    # print("start rows")
    # start_rows.show(7)

    # add in start_rows which gives us a row containing a level from which we can compute a level for the next date
    df_stage = blended_returns.unionByName(start_rows).sort("AsOfDate")
    #df_stage.show(19)


    print("showing blended_returns")
    blended_returns.filter(  
        (col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd")
    & (col("AsOfDate") >= "2025-04-17")
    & (col("CurrencyId") == 1)   
    ).orderBy(col("AsOfDate").desc()).show(13)


    # for row in df_xxx.select("IndexReturn").collect():
    #     print(f"{row['IndexReturn']:.11f}")

    #xxx
    print(f"blended_returns count = {blended_returns.count()}")
    #display(blended_returns.filter(col("CurrencyId") == 1))


    # the computed data gives us returns, now calculate levels

    # df_stage = blended_returns.unionByName(start_rows).sort("AsOfDate")
    #df_stage.show(5)

    # Assign RowNum per Index group
    window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("AsOfDate")
    df_stage = df_stage.withColumn("RowNum", row_number().over(window_spec))




    print("showing xxxxxxxxxxxxxxxxxxxxxxx  df_stage about to use Pandas")
    df_stage.filter(  
        (col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd")
    & (col("AsOfDate") >= "2025-04-17")
    & (col("CurrencyId") == 1)   
    ).orderBy(col("AsOfDate")).show(13)


    # Convert to Pandas for group-based recursion
    pdf = df_stage.toPandas()

    # Apply recursion per group
    for keys, group in pdf.groupby(["IndexId", "CurrencyId", "FrequencyId"]):
        group = group.sort_values("RowNum")
        levels = []
        for i, row in group.iterrows():
            index_return = Decimal(str(row["IndexReturn"]))
            if row["RowNum"] == 1:
                level = Decimal(str(row["IndexLevel"]))
            else:
                level = levels[-1] * (Decimal("1") + index_return)
            levels.append(level)
        pdf.loc[group.index, "IndexLevel"] = levels

    # Convert back to Spark DataFrame
    df_stage = spark.createDataFrame(pdf)

    print("showing xxxxxxxxxxxxxxxxxxxxxxx  df_stage after using Pandas 111")
    df_stage.filter(  
        (col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd")
    & (col("AsOfDate") >= "2025-04-17")
    & (col("CurrencyId") == 1)   
    ).orderBy(col("AsOfDate")).show(13)

    df_stage = df_stage.withColumn("IndexLevel", col("IndexLevel").cast(dec_type))
    df_stage = df_stage.withColumn("IndexReturn", col("IndexReturn").cast(dec_type))

    print("showing xxxxxxxxxxxxxxxxxxxxxxx  df_stage after using Pandas 222")
    df_stage.filter(  
        (col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd")
    & (col("AsOfDate") >= "2025-04-17")
    & (col("CurrencyId") == 1)   
    ).orderBy(col("AsOfDate")).show(13)


    #df_stage.orderBy(col("AsOfDate").asc()).show(7)

    print(f"count 1 = {df_stage.count()}")
    # get rid of Historical rows that were needed for computation.  Also get rid of any monthlies and quarterlies
    df_stage = df_stage.filter((col("RecordSource") != "Historical") & (col("FrequencyId") != 2) & (col("FrequencyId") != 3))
    print(f"count 2 = {df_stage.count()}")

    #xxx todo: figure out if we only do computations for USD
    #xxx looks like prod only does USD, also it calls proc twice: once for Daily and once for Monthly
    #df_stage.filter(col("AsOfDate") == "2025-04-17").show(7)

    # df_stage_orig.show(5)
    # df_stage.show(6)
    return df_stage

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dependency_levels = build_index_recipe_dependency_levels(index_return_recipe, index_load_control)

# just show all levels first
# for i, df in enumerate(dependency_levels):
#     print(f"\n=== Level {i} ===")
#     df.select("IndexIdTarget", "IndexIdSource", "RecipeType", "IndexContributionPct").show()


# Now call computations level by level.  Each call will leave its computations in df_stage to be used by next level.
for i, df in enumerate(dependency_levels):
    print(f"\n================================================================================== Level {i} ===")
    #df.select("IndexIdTarget", "IndexIdSource", "RecipeType", "IndexContributionPct").show()




    df_check_for_dups = df_stage.groupBy("IndexId", "FrequencyId", "AsOfDate", "CurrencyId") \
        .count() \
        .filter("count > 1")
    if df_check_for_dups.count() > 0:
        display(df_check_for_dups)
        raise Exception("Problem: found duplicate rows.  Need to investigate. 11111")


    print("showing xxxxxxxxxxxxxxxxxxxxxxx  df_stage 4444")
    df_stage.filter(  
        (col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd")
    & (col("AsOfDate") >= "2025-04-17")
    & (col("CurrencyId") == 1)   
    ).orderBy(col("AsOfDate")).show(13)

    df_tmp_computed = computeBenchmarks(df_stage, df)



    df_check_for_dups = df_tmp_computed.groupBy("IndexId", "FrequencyId", "AsOfDate", "CurrencyId") \
        .count() \
        .filter("count > 1")
    if df_check_for_dups.count() > 0:
        display(df_check_for_dups)
        raise Exception("Problem: found duplicate rows.  Need to investigate. 33333")


    # xxx clean up columns
    df_tmp_computed = df_tmp_computed.select("IndexId", "FrequencyId", "AsOfDate", "IndexLevel", "IndexReturn",
    lit(max_VendorIndexReturnUnit).alias("VendorIndexReturnUnit") ,
    lit(max_RunReason).alias("RunReason") ,
    lit(max_Guid).alias("Guid") ,
    lit(max_AdditionalParam).alias("AdditionalParam") ,
    "CurrencyId",
    lit("Fabric Computed").alias("Source") )

    df_stage = df_stage.union(df_tmp_computed)


    df_check_for_dups = df_stage.groupBy("IndexId", "FrequencyId", "AsOfDate", "CurrencyId") \
        .count() \
        .filter("count > 1")
    if df_check_for_dups.count() > 0:
        display(df_check_for_dups)
        raise Exception("Problem: found duplicate rows.  Need to investigate. 222222")


    print("showing xxxxxxxxxxxxxxxxxxxxxxx  df_stage 5555")
    df_stage.filter(  
        (col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd")
    & (col("AsOfDate") >= "2025-04-17")
    & (col("CurrencyId") == 1)   
    ).orderBy(col("AsOfDate")).show(13)

currentTs = current_timestamp()

# xxx clean up columns
df_stage = df_stage.select("IndexId", "FrequencyId", "AsOfDate", "IndexLevel", "IndexReturn",
lit(max_VendorIndexReturnUnit).alias("VendorIndexReturnUnit") ,
lit(max_RunReason).alias("RunReason") ,
lit(max_Guid).alias("Guid") ,
lit(max_AdditionalParam).alias("AdditionalParam") ,
"CurrencyId",
lit("Fabric Computed").alias("Source") 
)

#xxx remove this later.  for now, its good to see this timestamp
# df_stage = df_stage.withColumn("UpdateTimeStamp", currentTs) \
#     .withColumn("UpdateByHmcUserId", lit("Fabric").cast("string")) 


#get more columns added to match IndexReturn with which we will need to merge
#df_stage = df_stage.withColumn("ReturnComment", lit(None).cast("string")) \

df_stage.orderBy(col("AsOfDate").desc()).show(5)
df_stage_orig.orderBy(col("AsOfDate").desc()).show(6)


df_check_for_dups = df_stage.groupBy("IndexId", "FrequencyId", "AsOfDate", "CurrencyId") \
    .count() \
    .filter("count > 1")
if df_check_for_dups.count() > 0:
  display(df_check_for_dups)
  raise Exception("Problem: found duplicate rows.  Need to investigate. 55555")


# ggggg clean up columns: force Source to be the same so that union will work below
# set to same value alredy in the staged data
df_stage = df_stage.withColumn("Source", lit("Fabric Computed"))



print(f"df_stage count before = {df_stage.count()}")
print(f"df_stage_orig count before = {df_stage_orig.count()}")

df_stage = df_stage.union(df_stage_orig)
print(f"df_stage count after = {df_stage.count()}")

df_stage = df_stage.dropDuplicates()
print(f"df_stage count after drop dups = {df_stage.count()}")




print("showing xxxxxxxxxxxxxxxxxxxxxxx  df_stage 33333")
df_stage.filter(  
    (col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd")
& (col("AsOfDate") >= "2025-04-17")
& (col("CurrencyId") == 1)   
).orderBy(col("AsOfDate")).show(13)



print("showing xxxxxxxxxxxxxxxxxxxxxxx  df_stage investigating dup ")
df_stage.filter(  
    (col("IndexId") == "44d94be0-4892-4a42-96cc-258f917ceda1")
    & (col("AsOfDate") == "2024-10-21")
    & (col("CurrencyId") == 1)   
    ).orderBy(col("AsOfDate")).show(13)

#44d94be0-4892-4a42-96cc-258f917ceda1,8,2024-10-21



#xxx
df_stage = df_stage.dropDuplicates()
print(f"df_stage count after drop dups = {df_stage.count()}")



#xxx todo: figure out why we have dups here
df_check_for_dups = df_stage.groupBy("IndexId", "FrequencyId", "AsOfDate", "CurrencyId") \
    .count() \
    .filter("count > 1")
if df_check_for_dups.count() > 0:
  display(df_check_for_dups)
  raise Exception("Problem: found duplicate rows.  Need to investigate. 66666")


#todo: merge df_stage and df_stage_orig

#save out the calcualted data
df_stage.write.mode("overwrite").parquet( f"{curated_lh_id}/Files/BloombergIndexReturnCustom")

print("Done.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
