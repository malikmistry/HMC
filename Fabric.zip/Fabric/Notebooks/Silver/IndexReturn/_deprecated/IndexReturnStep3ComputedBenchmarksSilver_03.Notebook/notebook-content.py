# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

# Change History
# 01 initial version intended to support custom/computed benchmarks (e.g. 50% of one index and 50% of another)
# 02 first version that is starting to take shape

WorkspaceId = ''
BronzeLhId = ''
CuratedLhId = ''

#TODO: change to use params
#todo: move to shared notebook??
#e.g bronze_lh_id = 'abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558'
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLhId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLhId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

def get_basepath(workspace_id, lakehouse_id) -> str: 
    lh_basepath = 	f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}" 
    return lh_basepath

bronze_lh_id = get_basepath(WorkspaceId, BronzeLhId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLhId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import SparkSession, Window, DataFrame
from functools import reduce
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType, DateType, DecimalType
from datetime import date
from pyspark.sql.functions import last_day, col, min, max, lit, when, row_number, current_timestamp, month, rank, sum
from decimal import Decimal

spark = SparkSession.builder.getOrCreate()
spark.conf.set("spark.sql.decimalOperations.allowPrecisionLoss", "false")

dec_type = DecimalType(38, 11)

# Constants
FREQUENCY = 'Daily'
CURRENCY_ISO = 'USD'
RECIPE_TYPE = 'CUSTOM'
LOAD_NAME = 'CustomIdxRtn'
OBJECT_NAME = 'IndexReturn_CalculatedIdx'
VERSION_NUM = 9999  # Replace with actual version if needed

# Load FrequencyId and CurrencyId
# frequency_id = spark.table("HMCDataWarehouse.dbo.Frequency") \
#     .filter(col("description") == FREQUENCY).select("FrequencyId").first()["FrequencyId"]
frequency_id = 8 #xxx Daily
#xxx todo: test for monthly

#xxx prod currently only computes USD
# currency_id = spark.table("HMCDataWarehouse.dbo.Currency") \
#     .filter(col("ISOCode") == CURRENCY_ISO).select("CurrencyId").first()["CurrencyId"]
currency_id = 1 # xxx USD... prod does USD only

index_load_control = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index")
index_load_control = index_load_control.select("IndexId", "isCustomIndex", "Frequency", "DisplayName", "IsActive")

#xxx look at anything in df
index_load_control.filter((col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd") | (col("IndexId") == "18b7c764-774f-4a80-aad7-0edebc0207c3")
| (col("IndexId") == "37028766-65c5-43e0-9fea-2088e246d8d8") ).show(5)

#xxx irr = spark.table("etl.IndexReturnRecipe")
schema = StructType([
    StructField("IndexIdTarget", StringType(), False),
    StructField("IndexIdSource", StringType(), False),
    StructField("CurrencyId", IntegerType(), False),
    StructField("IndexContributionPct", dec_type, False),
    StructField("CreateLevel", IntegerType(), False),
    StructField("RecipeType", StringType(), False),
])
#xxx todo: replace with call to a new recipe delta table
data = [
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "18b7c764-774f-4a80-aad7-0edebc0207c3", 1, Decimal("50.0"), 0, "CUSTOM" ),
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "37028766-65c5-43e0-9fea-2088e246d8d8", 1, Decimal("50.0"), 0, "CUSTOM" ),

    # Natural Resources Benchmark	e9d419ba-9a21-ea11-8133-0050569a56ba	Cambridge Associates Natural Resources	55d419ba-9a21-ea11-8133-0050569a56ba
    # CrimsonX   84bd39b3-9e52-4eba-86be-4979bddeb9df   1f1a7e47-847d-471f-9af6-76221462304d
    #todo: support quarterly
    ("1f1a7e47-847d-471f-9af6-76221462304d", "84bd39b3-9e52-4eba-86be-4979bddeb9df", 1, Decimal("100.0"), 0, "CUSTOM" ),

    # 250% MSCI ACWI TR	63701978-C464-43BB-AD50-3433BED49010	Y	MSCI AC World TR Net USD	8ED419BA-9A21-EA11-8133-0050569A56BA	Y	CUSTOM	554	306	1950-01-01	9999-12-31	250.0000000000
    # this one is 8/Daily
    ("176ce410-3838-4292-8c24-d7694e8705fd", "e4a151b5-511d-4de9-9b87-d22bd05753f6", 1, Decimal("250.0"), 0, "CUSTOM" ),

    # Russell 2000 Inverse	0DB08336-DB66-47DF-A695-89AE79F3ECD6	Y	Russell 2000	01D519BA-9A21-EA11-8133-0050569A56BA	Y	INVERSE	544	393	1950-01-01	9999-12-31	-100.0000000000	2022-05-17 08:41:57.893	reidd	NULL
    ("22854b09-25a7-4dcf-82f3-98a89504709b", "cc53584e-edd5-49bd-961e-19ff2eee4cfc", 1, Decimal("-100.0"), 0, "INVERSE" ),

    #todo: 80% SPX Long, this takes 80% SPX and 20% of "Zero Percent Benchmark" which has 0 rows in IndexReturn... does that mean the "sum()" is only summing the .80 of SPX and getting nothing for the other "zero" benchmark?
    ("d6677877-4001-4269-94a4-17e2904e02f6", "91bd2f6c-6b28-4460-b8ea-11aae5546d71", 1, Decimal("80.0"), 0, "CUSTOM" ),
    ("d6677877-4001-4269-94a4-17e2904e02f6", "faf2e7ab-6593-461b-a8ef-4435bab5ffaf", 1, Decimal("20.0"), 0, "CUSTOM" ),

    # "250% EuroStoxx & S&P 500 Blend Inverse" odd name, but, the recipe is -250 of another computed benchmark, "EuroStoxx & S&P 500 Blend"
    ("22adae54-10d5-4f59-a6a1-7f9b07aaa6dc", "547c92eb-98c6-4167-94f7-48ced9f2f7f7", 1, Decimal("-250.0"), 0, "INVERSE" ),

]
index_return_recipe = spark.createDataFrame(data, schema)
index_return_recipe.show(11)
schema = StructType([
    StructField("IndexId", StringType(), False),
    StructField("IndexName", StringType(), False),
    StructField("CurrencyId", IntegerType(), False),
    StructField("FrequencyId", IntegerType(), False),
    StructField("LoadStartDate", DateType(), False),  # earliest date for data from BB
    StructField("LoadEndDate", DateType(), False),  # latest date from BB
    StructField("ReturnStartDate", DateType(), False), # date needed to get data from "wh" (one day prior to new data)
    StructField("CreateLevel", IntegerType(), False)
])
LoadStartDate = date(2025, 4, 22)
LoadEndDate = date(2025, 8, 8)
ReturnStartDate = date(2025, 4, 21)
#xxx todo: replace with call to a new recipe delta table, and compute ReturnStartDate
data = [
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "EuroStoxx & S&P 500 Blend", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("18b7c764-774f-4a80-aad7-0edebc0207c3",                    "iiii_1", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("37028766-65c5-43e0-9fea-2088e246d8d8",                    "iiii_2", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("1f1a7e47-847d-471f-9af6-76221462304d","Natural Resources Benchmark", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("84bd39b3-9e52-4eba-86be-4979bddeb9df","Cambridge Associates Natural Resources", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("176ce410-3838-4292-8c24-d7694e8705fd",         "250% MSCI ACWI TR", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("e4a151b5-511d-4de9-9b87-d22bd05753f6",  "MSCI AC World TR Net USD", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("22854b09-25a7-4dcf-82f3-98a89504709b",      "Russell 2000 Inverse", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("cc53584e-edd5-49bd-961e-19ff2eee4cfc",              "Russell 2000", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("d6677877-4001-4269-94a4-17e2904e02f6",              "80% SPX Long", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("91bd2f6c-6b28-4460-b8ea-11aae5546d71","S&P 500 INDEX AT UNITED STATES", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("faf2e7ab-6593-461b-a8ef-4435bab5ffaf",      "Zero Percent Benchmark", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("22adae54-10d5-4f59-a6a1-7f9b07aaa6dc",      "250% EuroStoxx & S&P 500 Blend Inverse", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 )
]
index_universe = spark.createDataFrame(data, schema)
index_universe.show(22)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# get historic data
df_wh = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/IndexReturn")

# filter down to just the currency we are working with
df_wh = df_wh.filter(col("Currencyid") == currency_id)

df_wh = df_wh.withColumn("Source", lit("Historical"))
df_wh.show(5)

df_wh.filter( 
     (col("IndexId") == "e4a151b5-511d-4de9-9b87-d22bd05753f6")
& (col("AsOfDate") >= "2025-04-17")
& (col("CurrencyId") == 1)
).orderBy(col("AsOfDate")).show(15)


df_wh.printSchema()

# now get one data point earlier than our staged data
start_rows = df_wh.alias("ir").join(
    index_universe.alias("mindate"),
    (col("ir.IndexId") == col("mindate.IndexId")) &
    (col("ir.CurrencyId") == col("mindate.CurrencyId")) &
    (col("ir.FrequencyId") == col("mindate.FrequencyId")) &
    (col("ir.AsOfDate") == col("mindate.ReturnStartDate"))) \
    .select("ir.IndexId", "ir.AsOfDate", "ir.FrequencyId", "ir.CurrencyId", "ir.IndexLevel", "ir.IndexReturn")

start_rows = start_rows.withColumn("RecordSource", lit("Historical"))

start_rows.show(10)

df_wh.printSchema()

df_wh.show(11)

df_wh.filter( 
     (col("IndexId") == "e4a151b5-511d-4de9-9b87-d22bd05753f6")
& (col("AsOfDate") >= "2025-04-17")
& (col("CurrencyId") == 1)
).orderBy(col("AsOfDate")).show(15)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


ilc = index_load_control
irr = index_return_recipe

# Recursively resolve dependencies
all_levels = []
current_level = index_universe

while True:
    print("Looping...")
    current_level.show(13)
    all_levels.append(current_level)
    next_level = irr.alias("irr") \
        .join(current_level.alias("prev"), col("irr.IndexIdSource") == col("prev.IndexId")) \
        .join(ilc.alias("ilcT"), col("irr.IndexIdTarget") == col("ilcT.IndexId")) \
        .join(ilc.alias("ilcS"), col("irr.IndexIdSource") == col("ilcS.IndexId")) \
        .filter(
            #xxx (col("irr.RecipeType") == RECIPE_TYPE) &
            (col("ilcT.IsActive") == 'Y') &
            (col("ilcS.IsActive") == 'Y') &
            (col("ilcS.isCustomIndex") == 'Y') &
            (col("ilcS.Frequency") == frequency_id)
        ) \
        .selectExpr(
            "ilcT.IndexId as IndexId",
            "ilcT.DisplayName as IndexName",
            "irr.CurrencyId",
            "ilcT.Frequency as FrequencyId",
            "LoadStartDate",
            "LoadEndDate",
            "ReturnStartDate",
            "(prev.CreateLevel + 1) as CreateLevel"
        ).distinct()
    if next_level.count() == 0:
        print("Next Level count 0")
        break
    current_level = next_level


print(all_levels)

if len(all_levels) > 1:
    full_universe = all_levels[0].unionByName(*all_levels[1:])
else:
    full_universe = all_levels[0]



# After union
full_universe_deduped = full_universe.groupBy("IndexId").agg(
    max("CreateLevel").alias("CreateLevel")
)



print("Full Universe")
full_universe_deduped.show(100)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# get original state of "staged" data we are working with
df_stage_orig = spark.read.parquet(f"{curated_lh_id}/Files/BloombergIndexReturnCalculated")

# filter down to just the currency of interest
df_stage = df_stage_orig.filter(col("Currencyid") == currency_id)

df_stage = df_stage.orderBy(col("IndexId").asc(), col("CurrencyId").asc(), col("AsOfDate").asc())
df_stage.show(7)

# get values from the stage data
agg_result = df_stage.agg(
    max("VendorIndexReturnUnit").alias("max_VendorIndexReturnUnit"),
    max("RunReason").alias("max_RunReason"),
    max("Guid").alias("max_Guid"),
    max("AdditionalParam").alias("max_AdditionalParam")
).collect()[0]

# Extract each value into its own variable
max_VendorIndexReturnUnit   = agg_result["max_VendorIndexReturnUnit"]
max_RunReason = agg_result["max_RunReason"]
max_Guid  = agg_result["max_Guid"]
max_AdditionalParam  = agg_result["max_AdditionalParam"]

ingredient_dates = full_universe.alias("iu") \
    .join(irr.alias("irr"), col("iu.IndexId") == col("irr.IndexIdTarget")) \
    .join(df_stage.alias("stage"), col("irr.IndexIdSource") == col("stage.IndexId")) \
    .groupBy("iu.IndexId") \
    .agg(
        min("stage.AsOfDate").alias("LoadStartDate"),
        max("stage.AsOfDate").alias("LoadEndDate")
    )

ingredient_dates.show(22)

dated_universe = full_universe.join(ingredient_dates, on="IndexId", how="left")

print("Full Universe joined")
dated_universe.show(99)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Stage input returns
recipe_df = irr

recipe_df.show(9)
df_stage.show(4)

input_returns = recipe_df.alias("r") \
    .join(df_stage.alias("s"), col("r.IndexIdSource") == col("s.IndexId")) \
    .select(
        "r.IndexIdTarget", "s.FrequencyId", "s.AsOfDate", "s.IndexReturn", "r.IndexContributionPct",
       "s.CurrencyId", "s.VendorIndexReturnUnit", "s.RunReason", "s.Guid", "s.AdditionalParam"         )

input_returns.orderBy(col("AsOfDate").asc()).show(8)

input_returns = input_returns.withColumnRenamed("IndexIdTarget", "IndexId")

input_returns.filter((col("AsOfDate") == "2025-04-17") & (col("CurrencyId") == 1)).show(17)


input_returns.printSchema()

# this is the actual calculation of the custom return value
# this is loosing persion due to the sum()
# blended_returns = input_returns.groupBy("IndexId", "AsOfDate", "FrequencyId", "CurrencyId") \
#     .agg(
#         sum(
#             (col("IndexReturn").cast(dec_type) *
#              col("IndexContributionPct").cast(dec_type) /
#              lit(Decimal("100.0")).cast(dec_type))  # Use Decimal literal!
#         ).cast(dec_type).alias("IndexReturn")
#     ) \
#     .withColumn("IndexLevel", lit(0).cast(dec_type)) \
#     .withColumn("RecordSource", lit("Computation(1)"))

# blended_returns.orderBy(col("AsOfDate").desc()).show(12)



# from decimal import Decimal
# from pyspark.sql.functions import col, lit, sum as _sum
# from pyspark.sql.types import DecimalType

# Step 1: Add WeightedReturn with true Decimal precision
input_returns = input_returns.withColumn(
    "WeightedReturn",
    (
        col("IndexReturn").cast(dec_type) *
        col("IndexContributionPct").cast(dec_type) /
        lit(Decimal("100.0")).cast(dec_type)
    ).cast(dec_type)
)

input_returns.printSchema()

input_returns.filter( 
     (col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd")
& (col("AsOfDate") >= "2025-04-17")
& (col("CurrencyId") == 1)
).orderBy(col("AsOfDate")).show(13)


# Step 2: Now sum the precomputed Decimal column
blended_returns = input_returns.groupBy("IndexId", "AsOfDate", "FrequencyId", "CurrencyId") \
    .agg(
        sum("WeightedReturn").cast(dec_type).alias("IndexReturn")
    ) \
    .withColumn("IndexLevel", lit(0).cast(dec_type)) \
    .withColumn("RecordSource", lit("Computation(1)"))

blended_returns.printSchema()


print("start rows")
start_rows.show(7)

# add in start_rows which gives us a row containing a level from which we can compute a level for the next date
df_stage = blended_returns.unionByName(start_rows).sort("AsOfDate")
df_stage.show(19)

df_xxx = blended_returns.filter(  
     (col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd")

& (col("AsOfDate") >= "2025-04-17")
& (col("CurrencyId") == 1)   )


df_xxx.show(12)

# for row in df_xxx.select("IndexReturn").collect():
#     print(f"{row['IndexReturn']:.11f}")


#xxx
print(f"blended_returns count = {blended_returns.count()}")
#display(blended_returns.filter(col("CurrencyId") == 1))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# the computed data gives us returns, now calculate levels

# df_stage = blended_returns.unionByName(start_rows).sort("AsOfDate")
df_stage.show(5)

# Assign RowNum per Index group
window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("AsOfDate")
df_stage = df_stage.withColumn("RowNum", row_number().over(window_spec))

# Convert to Pandas for group-based recursion
pdf = df_stage.toPandas()

# Apply recursion per group
for keys, group in pdf.groupby(["IndexId", "CurrencyId", "FrequencyId"]):
    group = group.sort_values("RowNum")
    levels = []
    for i, row in group.iterrows():
        index_return = Decimal(str(row["IndexReturn"]))
        if row["RowNum"] == 1:
            level = Decimal(str(row["IndexLevel"]))
        else:
            level = levels[-1] * (Decimal("1") + index_return)
        levels.append(level)
    pdf.loc[group.index, "IndexLevel"] = levels


#print(levels)

# Convert back to Spark DataFrame
df_stage = spark.createDataFrame(pdf)
df_stage = df_stage.withColumn("IndexLevel", col("IndexLevel").cast(dec_type))
df_stage = df_stage.withColumn("IndexReturn", col("IndexReturn").cast(dec_type))


df_stage.orderBy(col("AsOfDate").asc()).show(7)

print(f"count 1 = {df_stage.count()}")
# get rid of Historical rows that were needed for computation.  Also get rid of any monthlies and quarterlies
df_stage = df_stage.filter((col("RecordSource") != "Historical") & (col("FrequencyId") != 2) & (col("FrequencyId") != 3))
print(f"count 2 = {df_stage.count()}")

#xxx todo: figure out if we only do computations for USD
#xxx looks like prod only does USD, also it calls proc twice: once for Daily and once for Monthly
df_stage.filter(col("AsOfDate") == "2025-04-17").show(7)


df_stage_orig.show(5)
df_stage.show(6)

currentTs = current_timestamp()

# clean up columns
df_stage = df_stage.select("IndexId", "FrequencyId", "AsOfDate", "IndexLevel", "IndexReturn",
lit(max_VendorIndexReturnUnit).alias("VendorIndexReturnUnit") ,
lit(max_RunReason).alias("RunReason") ,
lit(max_Guid).alias("Guid") ,
lit(max_AdditionalParam).alias("AdditionalParam") ,
"CurrencyId",
lit("Fabriccc Computed").alias("Source") 
)


#xxx remove this later.  for now, its good to see this timestamp
# df_stage = df_stage.withColumn("UpdateTimeStamp", currentTs) \
# .withColumn("UpdateByHmcUserId", lit("Fabric").cast("string")) 


#get more columns added to match IndexReturn with which we will need to merge
#df_stage = df_stage.withColumn("ReturnComment", lit(None).cast("string")) \

df_stage.orderBy(col("AsOfDate").desc()).show(5)
df_stage_orig.orderBy(col("AsOfDate").desc()).show(6)

df_stage = df_stage.union(df_stage_orig)

# fix data types before saving this dataframe
df_stage.printSchema()

#todo: merge df_stage and df_stage_orig

#save out the calcualted data
df_stage.write.mode("overwrite").parquet( f"{curated_lh_id}/Files/BloombergIndexReturnCustom")

print("Done.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
