# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

# Change History
# 01 initial version intended to support custom/computed benchmarks (e.g. 50% of one index and 50% of another)
# 02 first version that is starting to take shape

WorkspaceId = ''
BronzeLhId = ''
CuratedLhId = ''

#TODO: change to use params
#todo: move to shared notebook??
#e.g bronze_lh_id = 'abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558'
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLhId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLhId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

def get_basepath(workspace_id, lakehouse_id) -> str: 
    lh_basepath = 	f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}" 
    return lh_basepath

curated_lh_id = get_basepath(WorkspaceId, CuratedLhId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import SparkSession, Window, DataFrame
from functools import reduce
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType, DateType, DecimalType
from datetime import date
from pyspark.sql.functions import last_day, col, min, max, lit, when, row_number, current_timestamp, month, rank, sum
from decimal import Decimal

spark = SparkSession.builder.getOrCreate()
spark.conf.set("spark.sql.decimalOperations.allowPrecisionLoss", "false")

dec_type = DecimalType(38, 11)

# Constants
FREQUENCY = 'Daily'
CURRENCY_ISO = 'USD'

# Load FrequencyId and CurrencyId
# frequency_id = spark.table("HMCDataWarehouse.dbo.Frequency") \
#     .filter(col("description") == FREQUENCY).select("FrequencyId").first()["FrequencyId"]
frequency_id = 8 #xxx Daily
#xxx todo: test for monthly

#xxx prod currently only computes USD
# currency_id = spark.table("HMCDataWarehouse.dbo.Currency") \
#     .filter(col("ISOCode") == CURRENCY_ISO).select("CurrencyId").first()["CurrencyId"]
currency_id = 1 # xxx USD... prod does USD only

index_load_control = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index")
index_load_control = index_load_control.select("IndexId", "IsCustomIndex", "Frequency", "DisplayName", "IsActive")

#xxx look at anything in df
index_load_control.filter((col("IndexId") == "176ce410-3838-4292-8c24-d7694e8705fd") | (col("IndexId") == "18b7c764-774f-4a80-aad7-0edebc0207c3")
| (col("IndexId") == "37028766-65c5-43e0-9fea-2088e246d8d8") ).show(5)

#xxx irr = spark.table("etl.IndexReturnRecipe")
schema = StructType([
    StructField("IndexIdTarget", StringType(), False),
    StructField("IndexIdSource", StringType(), False),
    StructField("CurrencyId", IntegerType(), False),
    StructField("IndexContributionPct", dec_type, False),
    StructField("CreateLevel", IntegerType(), False),
    StructField("RecipeType", StringType(), False),
])
#xxx todo: replace with call to a new recipe delta table
data = [
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "18b7c764-774f-4a80-aad7-0edebc0207c3", 1, Decimal("50.0"), 0, "CUSTOM" ),
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "37028766-65c5-43e0-9fea-2088e246d8d8", 1, Decimal("50.0"), 0, "CUSTOM" ),

    # Natural Resources Benchmark	e9d419ba-9a21-ea11-8133-0050569a56ba	Cambridge Associates Natural Resources	55d419ba-9a21-ea11-8133-0050569a56ba
    # CrimsonX   84bd39b3-9e52-4eba-86be-4979bddeb9df   1f1a7e47-847d-471f-9af6-76221462304d
    #todo: support quarterly
    ("1f1a7e47-847d-471f-9af6-76221462304d", "84bd39b3-9e52-4eba-86be-4979bddeb9df", 1, Decimal("100.0"), 0, "CUSTOM" ),

    # 250% MSCI ACWI TR	63701978-C464-43BB-AD50-3433BED49010	Y	MSCI AC World TR Net USD	8ED419BA-9A21-EA11-8133-0050569A56BA	Y	CUSTOM	554	306	1950-01-01	9999-12-31	250.0000000000
    # this one is 8/Daily
    ("176ce410-3838-4292-8c24-d7694e8705fd", "e4a151b5-511d-4de9-9b87-d22bd05753f6", 1, Decimal("250.0"), 0, "CUSTOM" ),

    # Russell 2000 Inverse	0DB08336-DB66-47DF-A695-89AE79F3ECD6	Y	Russell 2000	01D519BA-9A21-EA11-8133-0050569A56BA	Y	INVERSE	544	393	1950-01-01	9999-12-31	-100.0000000000	2022-05-17 08:41:57.893	reidd	NULL
    ("22854b09-25a7-4dcf-82f3-98a89504709b", "cc53584e-edd5-49bd-961e-19ff2eee4cfc", 1, Decimal("-100.0"), 0, "INVERSE" ),

    #todo: 80% SPX Long, this takes 80% SPX and 20% of "Zero Percent Benchmark" which has 0 rows in IndexReturn... does that mean the "sum()" is only summing the .80 of SPX and getting nothing for the other "zero" benchmark?
    ("d6677877-4001-4269-94a4-17e2904e02f6", "91bd2f6c-6b28-4460-b8ea-11aae5546d71", 1, Decimal("80.0"), 0, "CUSTOM" ),
    ("d6677877-4001-4269-94a4-17e2904e02f6", "faf2e7ab-6593-461b-a8ef-4435bab5ffaf", 1, Decimal("20.0"), 0, "CUSTOM" ),

    # "250% EuroStoxx & S&P 500 Blend Inverse" odd name, but, the recipe is -250 of another computed benchmark, "EuroStoxx & S&P 500 Blend"
    ("22adae54-10d5-4f59-a6a1-7f9b07aaa6dc", "547c92eb-98c6-4167-94f7-48ced9f2f7f7", 1, Decimal("-250.0"), 0, "INVERSE" ),

]
index_return_recipe = spark.createDataFrame(data, schema)
index_return_recipe.show(11)

schema = StructType([
    StructField("IndexId", StringType(), False),
    StructField("IndexName", StringType(), False),
    StructField("CurrencyId", IntegerType(), False),
    StructField("Frequency", IntegerType(), False),
    StructField("LoadStartDate", DateType(), False),  # earliest date for data from BB
    StructField("LoadEndDate", DateType(), False),  # latest date from BB
    StructField("ReturnStartDate", DateType(), False), # date needed to get data from "wh" (one day prior to new data)
    StructField("CreateLevel", IntegerType(), False)
])
LoadStartDate = date(2025, 4, 22)
LoadEndDate = date(2025, 8, 8)
ReturnStartDate = date(2025, 4, 21)
#xxx todo: replace with call to a new recipe delta table, and compute ReturnStartDate
data = [
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "EuroStoxx & S&P 500 Blend", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("18b7c764-774f-4a80-aad7-0edebc0207c3",                    "iiii_1", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("37028766-65c5-43e0-9fea-2088e246d8d8",                    "iiii_2", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("1f1a7e47-847d-471f-9af6-76221462304d","Natural Resources Benchmark", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("84bd39b3-9e52-4eba-86be-4979bddeb9df","Cambridge Associates Natural Resources", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("176ce410-3838-4292-8c24-d7694e8705fd",         "250% MSCI ACWI TR", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("e4a151b5-511d-4de9-9b87-d22bd05753f6",  "MSCI AC World TR Net USD", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("22854b09-25a7-4dcf-82f3-98a89504709b",      "Russell 2000 Inverse", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("cc53584e-edd5-49bd-961e-19ff2eee4cfc",              "Russell 2000", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("d6677877-4001-4269-94a4-17e2904e02f6",              "80% SPX Long", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("91bd2f6c-6b28-4460-b8ea-11aae5546d71","S&P 500 INDEX AT UNITED STATES", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),
    ("faf2e7ab-6593-461b-a8ef-4435bab5ffaf",      "Zero Percent Benchmark", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 ),

    ("22adae54-10d5-4f59-a6a1-7f9b07aaa6dc",      "250% EuroStoxx & S&P 500 Blend Inverse", 1, 8, LoadStartDate, LoadEndDate, ReturnStartDate, 0 )
]
index_universe = spark.createDataFrame(data, schema)
index_universe.show(22)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, when, sum, broadcast

def build_index_recipe_dependency_levels(
    index_return_recipe: DataFrame,
    index_load_control: DataFrame
) -> list[DataFrame]:
    # Join to determine whether each IndexIdSource is a custom index
    recipe_with_is_custom = index_return_recipe \
        .join(
            broadcast(index_load_control.selectExpr("IndexId as IndexIdSource", "IsCustomIndex")),
            on="IndexIdSource",
            how="left"
        )

    recipe_levels = []
    processed_targets = set()

    # Level 0: Targets whose sources are ALL non-custom
    level_df = recipe_with_is_custom.groupBy("IndexIdTarget") \
        .agg(sum(when(col("IsCustomIndex") == True, 1).otherwise(0)).alias("num_custom_sources")) \
        .filter(col("num_custom_sources") == 0) \
        .select("IndexIdTarget")

    level_0_targets = [row["IndexIdTarget"] for row in level_df.collect()]
    processed_targets.update(level_0_targets)

    level_0_df = recipe_with_is_custom.filter(col("IndexIdTarget").isin(level_0_targets))
    recipe_levels.append(level_0_df)

    # Iteratively build higher dependency levels
    while True:
        remaining = recipe_with_is_custom.filter(~col("IndexIdTarget").isin(list(processed_targets)))
        if remaining.isEmpty():
            break

        candidate_targets = remaining.select("IndexIdTarget").distinct()
        next_targets = []

        for row in candidate_targets.collect():
            target = row["IndexIdTarget"]
            source_rows = remaining.filter(col("IndexIdTarget") == target).select("IndexIdSource").collect()
            source_ids = [r["IndexIdSource"] for r in source_rows]

            # A target is eligible if all its sources are either non-custom or already processed
            all_sources_valid = all(
                index_load_control.filter(col("IndexId") == src).select("IsCustomIndex").first()["IsCustomIndex"] == False or
                src in processed_targets
                for src in source_ids
            )

            if all_sources_valid:
                next_targets.append(target)

        if not next_targets:
            break  # Prevent infinite loop if there's a circular dependency

        processed_targets.update(next_targets)
        level_df = recipe_with_is_custom.filter(col("IndexIdTarget").isin(next_targets))
        recipe_levels.append(level_df)

    return recipe_levels


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print("here a")

dependency_levels = build_index_recipe_dependency_levels(index_return_recipe, index_load_control)

for i, df in enumerate(dependency_levels):
    print(f"\n=== Level {i} ===")
    df.select("IndexIdTarget", "IndexIdSource", "RecipeType", "IndexContributionPct").show()


raise SystemExit("xxx")


# Recursive logic replaced by iterative accumulation
all_deps = index_universe.select("IndexId").distinct()

all_deps.show(100)

levels = []
for lvl in range(3):  # max depth
    print(f"level = {lvl}")
    #xxx deps = expand_dependencies(all_deps, level=lvl)
    deps = expand_dependencies(all_deps)
    
    print("here b")
    if deps.count() == 0:
        break
    levels.append(deps)
    #all_deps = all_deps.union(deps.select("IndexIdTargetWH").withColumnRenamed("IndexIdTargetWH", "IndexIdWarehouse")).distinct()
    all_deps = all_deps.union(deps.select("IndexIdTarget")).distinct()

# === Recipe Construction ===
recipe_df = index_return_recipe \
    .join(index_load_control.alias("tgt"), F.col("IndexIdTarget") == F.col("tgt.IndexId")) \
    .join(index_load_control.alias("src"), F.col("IndexIdSource") == F.col("src.IndexId")) \
    .filter((F.col("tgt.IsActive") == 'Y') & (F.col("src.IsActive") == 'Y')) \
    .select("IndexIdTarget", "IndexIdSource", "tgt.IndexId",
            "src.IndexId", "IndexContributionPct")

recipe_df.show(100)
raise SystemExit("xxx")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# === Input Return Assembly ===
input_returns_stage = recipe_df \
    .join(index_return_stage_df, (F.col("IndexIdSourceWH") == index_return_stage_df.IndexId) &
          (index_return_stage_df.IsValid == 'Y') & (index_return_stage_df.Ignore == 'N')) \
    .select("IndexIdTargetWH", "IndexIdSourceWH", "IndexContributionPct",
            "IndexLevel", "IndexReturn", "AsOfDate")

input_returns_wh = recipe_df \
    .join(index_return_wh_df, (F.col("IndexIdSourceWH") == index_return_wh_df.IndexId)) \
    .select("IndexIdTargetWH", "IndexIdSourceWH", "IndexContributionPct",
            "IndexLevel", "IndexReturn", "AsOfDate")

input_returns_df = input_returns_stage.unionByName(input_returns_wh).dropDuplicates(["IndexIdTargetWH", "IndexIdSourceWH", "AsOfDate"])

# === Return Calculation ===
weighted_returns_df = input_returns_df \
    .withColumn("WeightedReturn", F.col("IndexReturn") * (F.col("IndexContributionPct") / 100)) \
    .groupBy("IndexIdTargetWH", "AsOfDate") \
    .agg(F.sum("WeightedReturn").alias("IndexReturn"))

# === Seeding Initial Level ===
first_date_window = Window.partitionBy("IndexIdTargetWH").orderBy("AsOfDate")
weighted_returns_df = weighted_returns_df \
    .withColumn("OrderNum", F.row_number().over(first_date_window))

# Initial seed: set IndexLevel = 100 for first record
weighted_returns_df = weighted_returns_df \
    .withColumn("IndexLevel", F.when(F.col("OrderNum") == 1, F.lit(100.0)))

# === Recursive Index Level Calculation ===
level_window = Window.partitionBy("IndexIdTargetWH").orderBy("AsOfDate")

# Use iterative filling since Spark doesn’t support recursive UDFs directly
from pyspark.sql.types import StructType, StructField, DoubleType
from pyspark.sql import Row

def propagate_levels(pdf):
    pdf = pdf.sort_values("AsOfDate")
    for i in range(1, len(pdf)):
        prev = pdf.iloc[i - 1]
        pdf.at[i, "IndexLevel"] = prev["IndexLevel"] * (1 + pdf.at[i, "IndexReturn"])
    return pdf

result_df = weighted_returns_df.groupBy("IndexIdTargetWH").applyInPandas(propagate_levels, schema=weighted_returns_df.schema)

# === Final Output: Cleaned Returns ===
final_result_df = result_df.select(
    F.col("IndexIdTargetWH").alias("IndexId"),
    F.lit(currency_id).alias("CurrencyId"),
    F.lit(frequency_id).alias("Frequency"),
    "AsOfDate", "IndexLevel", "IndexReturn",
    F.lit('Y').alias("IsValid"),
    F.lit('N').alias("Ignore")
)

# Now `final_result_df` can be written to IndexReturn_STAGE or further processed
# Example: final_result_df.write.format("delta").mode("append").saveAsTable("dbo.IndexReturn_STAGE")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
