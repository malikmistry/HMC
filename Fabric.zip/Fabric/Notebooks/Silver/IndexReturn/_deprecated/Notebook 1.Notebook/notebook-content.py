# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# CELL ********************

# Change History
# 01 initial version intended to support custom/computed benchmarks (e.g. 50% of one index and 50% of another)
# 02 first version that is starting to take shape

# xxx todo: move this to be after basic roll forward, but, before copying the current daily to be month end

WorkspaceId = ''
BronzeLhId = ''
CuratedLhId = ''

#TODO: change to use params
#todo: move to shared notebook??
#e.g bronze_lh_id = 'abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558'
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLhId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLhId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

def get_basepath(workspace_id, lakehouse_id) -> str: 
    lh_basepath = 	f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}" 
    return lh_basepath

bronze_lh_id = get_basepath(WorkspaceId, BronzeLhId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLhId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import SparkSession, Window, DataFrame
from functools import reduce
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType, DateType, DecimalType
from datetime import date
from pyspark.sql.functions import last_day, col, min, max, lit, when, row_number, current_timestamp, month, rank, sum

spark = SparkSession.builder.getOrCreate()

# Constants
FREQUENCY = 'Daily'
CURRENCY_ISO = 'USD'
RECIPE_TYPE = 'CUSTOM'
LOAD_NAME = 'CustomIdxRtn'
OBJECT_NAME = 'IndexReturn_CalculatedIdx'
VERSION_NUM = 9999  # Replace with actual version if needed

# Load FrequencyId and CurrencyId
# frequency_id = spark.table("HMCDataWarehouse.dbo.Frequency") \
#     .filter(col("description") == FREQUENCY).select("FrequencyId").first()["FrequencyId"]
frequency_id = 8 #xxx Daily

# currency_id = spark.table("HMCDataWarehouse.dbo.Currency") \
#     .filter(col("ISOCode") == CURRENCY_ISO).select("CurrencyId").first()["CurrencyId"]
currency_id = 1 # xxx USD

# Get initial universe of calculated indexes
#xxx ilc = spark.table("etl.IndexLoadControl")
index_load_control = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index")
#xxx index_load_control = index_load_control.select("IndexId", "isCustomIndex", "Frequency", "DisplayName", "IsActive").filter(col("IsCustomIndex") == 1)
index_load_control = index_load_control.select("IndexId", "isCustomIndex", "Frequency", "DisplayName", "IsActive")

#xxx look at anything in df
index_load_control.filter((col("IndexId") == "547c92eb-98c6-4167-94f7-48ced9f2f7f7") | (col("IndexId") == "18b7c764-774f-4a80-aad7-0edebc0207c3")
| (col("IndexId") == "37028766-65c5-43e0-9fea-2088e246d8d8") ).show(5)

#xxx irr = spark.table("etl.IndexReturnRecipe")
schema = StructType([
    StructField("IndexIdTarget", StringType(), False),
    StructField("IndexIdSource", StringType(), False),
    StructField("CurrencyId", IntegerType(), False),
    StructField("IndexContributionPct", DoubleType(), False),
    StructField("CreateLevel", IntegerType(), False),
    StructField("RecipeType", StringType(), False),
])
#xxx todo: replace with call to a new recipe delta table
data = [
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "18b7c764-774f-4a80-aad7-0edebc0207c3", 1, 50.0, 0, "CUSTOM" ),
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "37028766-65c5-43e0-9fea-2088e246d8d8", 1, 50.0, 0, "CUSTOM" ),
]
index_return_recipe = spark.createDataFrame(data, schema)
index_return_recipe.show(truncate=False)


# index_universe = ilc.alias("ilc") \
#     .join(irr.alias("irr"), col("ilc.IndexId") == col("irr.IndexIdTarget")) \
#     .filter(
#         (col("ilc.IsActive") == 'Y') &
#         (col("ilc.isCustomIndex") == 'Y') &
#         (col("ilc.Frequency") == frequency_id) &
#         (col("irr.RecipeType") == RECIPE_TYPE)
#     ) \
#     .selectExpr("ilc.IndexId as IndexId", "ilc.DisplayName", "0 as Level") \
#     .distinct()

schema = StructType([
    StructField("IndexId", StringType(), False),
    StructField("IndexName", StringType(), False),
    StructField("CurrencyId", IntegerType(), False),
    StructField("FrequencyId", IntegerType(), False),
    StructField("LoadStartDate", DateType(), False),
    StructField("LoadEndDate", DateType(), False),
    StructField("ReturnStartDate", DateType(), False),
    StructField("CreateLevel", IntegerType(), False)
])
#xxx todo: replace with call to a new recipe delta table, and compute ReturnStartDate
data = [
    ("547c92eb-98c6-4167-94f7-48ced9f2f7f7", "EuroStoxx & S&P 500 Blend", 1, 8, date(2025, 4, 11), date(2025, 7, 29), date(2025, 4, 10), 0 )
]
index_universe = spark.createDataFrame(data, schema)
index_universe.show(truncate=False)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# get historic data
df_wh = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/IndexReturn")
df_wh = df_wh.withColumn("Source", lit("Historical"))
df_wh.show(5)
df_wh.printSchema()

# now get one data point earlier than our staged data
start_rows = df_wh.alias("ir").join(
    index_universe.alias("mindate"),
    (col("ir.IndexId") == col("mindate.IndexId")) &
    (col("ir.CurrencyId") == col("mindate.CurrencyId")) &
    (col("ir.FrequencyId") == col("mindate.FrequencyId")) &
    (col("ir.AsOfDate") == col("mindate.ReturnStartDate"))) \
    .select("ir.IndexId", "ir.AsOfDate", "ir.FrequencyId", "ir.CurrencyId", "ir.IndexLevel", "ir.IndexReturn")

start_rows = start_rows.withColumn("RecordSource", lit("Historical"))

# ).groupBy("ir.IndexId", "ir.CurrencyId", "ir.FrequencyId") \
#  .agg(spark_max("ir.AsOfDate").alias("AsOfDate"))

start_rows.show(100)

start_rows.printSchema()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

ilc = index_load_control
irr = index_return_recipe

# Recursively resolve dependencies
all_levels = []
current_level = index_universe

while True:
    current_level.show(13)
    all_levels.append(current_level)
    next_level = irr.alias("irr") \
        .join(current_level.alias("prev"), col("irr.IndexIdSource") == col("prev.IndexId")) \
        .join(ilc.alias("ilcT"), col("irr.IndexIdTarget") == col("ilcT.IndexId")) \
        .join(ilc.alias("ilcS"), col("irr.IndexIdSource") == col("ilcS.IndexId")) \
        .filter(
            (col("irr.RecipeType") == RECIPE_TYPE) &
            (col("ilcT.IsActive") == 'Y') &
            (col("ilcS.IsActive") == 'Y') &
            (col("ilcS.isCustomIndex") == 'Y') &
            (col("ilcS.Frequency") == frequency_id)
        ) \
        .selectExpr(
            "irr.IndexIdTarget as IndexId",
           # "ilcT.IndexId as IndexId",
            "ilcT.DisplayName as DisplayName",
            "(prev.CreateLevel + 1) as CreateLevel"
        ).distinct()
    if next_level.count() == 0:
        break
    current_level = next_level

#getting error: TypeError: DataFrame.unionByName() missing 1 required positional argument: 'other'
#xxx full_universe = all_levels[0].unionByName(*all_levels[1:])

if len(all_levels) > 1:
    full_universe = all_levels[0].unionByName(*all_levels[1:])
else:
    full_universe = all_levels[0]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

df_stage = spark.read.parquet(f"{curated_lh_id}/Files/BloombergIndexReturnFrequencyPromoted")
df_stage = df_stage.orderBy(col("IndexId").asc(), col("CurrencyId").asc(), col("AsOfDate").asc())
df_stage.show(7)

# Infer load date ranges
# stage = spark.table("dbo.IndexReturn_STAGE").filter(
#     (col("CurrencyId") == currency_id) &
#     (col("FrequencyId") == frequency_id) &
#     (col("IsValid") == 'Y') &
#     (col("Ignore") == 'N') &
#     (col("RunPurpose") != 'NIGHTLY_INDEX_LOAD_SOIL')
# )

ingredient_dates = full_universe.alias("iu") \
    .join(irr.alias("irr"), col("iu.IndexId") == col("irr.IndexIdTarget")) \
    .join(df_stage.alias("stage"), col("irr.IndexIdSource") == col("stage.IndexId")) \
    .groupBy("iu.IndexId") \
    .agg(
        min("stage.AsOfDate").alias("LoadStartDate"),
        max("stage.AsOfDate").alias("LoadEndDate")
    )

ingredient_dates.show(22)

dated_universe = full_universe.join(ingredient_dates, on="IndexId", how="left")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Stage input returns
recipe_df = irr
#xxx warehouse_df = spark.table("HMCDataWarehouse.dbo.IndexReturn")

# input_returns = recipe_df.alias("r") \
#     .join(df_stage.alias("s"), col("r.IndexIdSource") == col("s.IndexId")) \
#     .filter((col("s.IsValid") == 'Y') & (col("s.Ignore") == 'N')) \
#     .select(
#         "r.IndexIdTarget as IndexId", "s.AsOfDate", "s.IndexReturn", "r.IndexContributionPct",
#         "s.FrequencyId", "s.CurrencyId"
#     )

recipe_df.show(9)
df_stage.show(4)

input_returns = recipe_df.alias("r") \
    .join(df_stage.alias("s"), col("r.IndexIdSource") == col("s.IndexId")) \
    .select(
        "r.IndexIdTarget", "s.AsOfDate", "s.IndexReturn", "r.IndexContributionPct",
        "s.FrequencyId", "s.CurrencyId"
    )

input_returns = input_returns.withColumnRenamed("IndexIdTarget", "IndexId")

# # Compute blended returns
# blended_returns = input_returns.groupBy("IndexId", "AsOfDate", "FrequencyId", "CurrencyId") \
#     .agg(sum(col("IndexReturn") * (col("IndexContributionPct") / 100.0)).alias("IndexReturn")) \
#     .withColumn("IndexLevel", lit(0)).withColumn("RecordSource", lit("Computation(1)"))


# # Compute blended returns
# blended_returns = input_returns.groupBy("IndexId", "AsOfDate", "FrequencyId", "CurrencyId") \
#     .agg(sum(col("IndexReturn") * (col("IndexContributionPct").cast(DecimalType(26,11)) / lit(100.0).cast(DecimalType(26,11))).alias("IndexReturn")) \
#     .withColumn("IndexLevel", lit(0)).withColumn("RecordSource", lit("Computation(1)"))

dec_type = DecimalType(26, 11)
blended_returns = input_returns.groupBy("IndexId", "AsOfDate", "FrequencyId", "CurrencyId") \
    .agg(
        sum(
            (col("IndexReturn").cast(dec_type) *
             col("IndexContributionPct").cast(dec_type) /
             lit(100).cast(dec_type))
        ).alias("IndexReturn")
    ) \
    .withColumn("IndexLevel", lit(0).cast(dec_type)) \
    .withColumn("RecordSource", lit("Computation(1)"))


#xxx
print(f"blended_returns count = {blended_returns.count()}")
#display(blended_returns.filter(col("CurrencyId") == 1))

blended_returns.show(11)

blended_returns.printSchema()

start_rows.show(12)

start_rows.printSchema()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# the computed data gives us returns, now calculate levels

df_stage = blended_returns.unionByName(start_rows).sort("AsOfDate")
df_stage.show(22)

df_stage.printSchema()

# Assign RowNum per Index group
window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("AsOfDate")
df_stage = df_stage.withColumn("RowNum", row_number().over(window_spec))

# Convert to Pandas for group-based recursion
pdf = df_stage.toPandas()

# Apply recursion per group
for keys, group in pdf.groupby(["IndexId", "CurrencyId", "FrequencyId"]):
    group = group.sort_values("RowNum")
    levels = []
    for i, row in group.iterrows():
        #print(row)
        if row["RowNum"] == 1:
            # Default starting value if not provided
            # TODO: how to handle this case?
            #level = 100000.0 if pd.isna(row["IndexLevel"]) else row["IndexLevel"]
            #xxx level = row["IndexLevelNEW"]
            level = row["IndexLevel"]  
        else:
            level = levels[-1] * (1 + row["IndexReturn"] )
        levels.append(level)
    #print(levels)
    #xxx pdf.loc[group.index, "IndexLevelNEW"] = levels
    pdf.loc[group.index, "IndexLevel"] = levels
    



#print(levels)

if df_stage.isEmpty():
    print("no returns data")
else:
    # Convert back to Spark DataFrame
    df_stage = spark.createDataFrame(pdf)

    df_stage.show(99)

    raise SystemExit("xxx")

    # keep just Raw data (gets rid of "Historical")
    df_stage = df_stage.filter(col("Source") == "Raw")

    df_stage_return_based.show(22)

    # clean up columns
    df_stage_return_based = df_stage_return_based.select("IndexId", "FrequencyId", "AsOfDate", "CurrencyId", 
    col("IndexLevelNEW").alias("IndexLevel"), "IndexReturn", "IsValid", "VendorIndexReturnUnit")

    df_stage_return_based.show(23)

#xxx
raise SystemExit("exiting")


# Rank and calculate levels, xxx old
window_spec = Window.partitionBy("IndexId").orderBy("AsOfDate")
blended_returns = blended_returns.withColumn("OrderNum", rank().over(window_spec))

blended_returns.printSchema()

results = []
for idx in blended_returns.select("IndexId").distinct().collect():
    index_id = idx["IndexId"]
    df = blended_returns.filter(col("IndexId") == index_id).orderBy("OrderNum")
    #prev_level = 100.0  # seed level
    prev_level = 10000.0  # seed level
    computed = []
    for row in df.collect():
        rtn = row.IndexReturn
        level = prev_level * (1 + rtn) if rtn is not None else None
        computed.append((row.IndexId, row.AsOfDate, row.FrequencyId, row.CurrencyId, level, rtn, row.RecordSource))
        prev_level = level
        #print(computed)
    results.append(spark.createDataFrame(computed, df.columns))


results[0].show(7)

leveled_df = reduce(DataFrame.unionByName, results)

#xxx
leveled_df.filter(col("CurrencyId") == 1).orderBy("AsOfDate").show(10)

#xxx
raise SystemExit("stopping script")

# Insert to stage
leveled_df.selectExpr(
    f"'{LOAD_NAME}' as LoadType",
    "'Index Recipe.' as LoadComment",
    f"'{OBJECT_NAME}' as LoadProcess",
    "current_timestamp() as LoadTimestamp",
    "min(AsOfDate) over() as LoadStartDate",
    "IndexId", "CurrencyId", "FrequencyId", "AsOfDate",
    "IndexLevel", "IndexReturn",
    f"{VERSION_NUM} as VersionNum",
    "'Y' as IsNew", "'N' as IsDup", "Ignore", f"'{LOAD_NAME}' as RunPurpose"
).write.insertInto("dbo.IndexReturn_STAGE")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
