# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# Change History
# 01 got basics working, but, with too many assumptions
# 02 try to get it to work for both (Daily -> Monthly, Monthly -> Quarterly)
#todo: consider parameterizing this and then call for (Daily -> Monthly and Monthly -> Quarterly)

WorkspaceId = ''
BronzeLhId = ''
CuratedLhId = ''

#TODO: change to use params
#todo: move to shared notebook??
#e.g bronze_lh_id = 'abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558'
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLhId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLhId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

def get_basepath(workspace_id, lakehouse_id) -> str: 
    lh_basepath = 	f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}" 
    return lh_basepath

bronze_lh_id = get_basepath(WorkspaceId, BronzeLhId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLhId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from pyspark.sql import SparkSession
from pyspark.sql.functions import last_day, col, min, max, col, max as spark_max, lit, min as spark_min, when, row_number, current_timestamp
from pyspark.sql import Window
from datetime import datetime, date
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType, DoubleType
from pyspark.sql.window import Window

# Create Spark session
spark = SparkSession.builder.getOrCreate()

# this notebook promotes data points to next highest frequency (Daily -> Monthly, Monthly -> Quarterly)

# get index metadata so we know Frequency, etc
dfIndexXref = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index").select("IndexId", "Ticker", "Frequency", "IsLevelBased")
dfIndexXref.show(5)

# read current state of staged data into a dataframe
# at this point, the data had gaps filled and returns computed
# now we need to compute monthly and quarterly returns

df_stage = spark.read.parquet(f"{curated_lh_id}/Files/BloombergIndexReturnCalculated")
df_stage = df_stage.orderBy(col("IndexId").asc(), col("CurrencyId").asc(), col("AsOfDate").asc())
df_stage.show(5)

print(f"initial stage count = {df_stage.count()}")

# put non-dailies in new DF
df_stage_non_dailies = df_stage.filter(col("FrequencyId") != 8)

# keep dailies in df_stage
df_stage = df_stage.filter(col("FrequencyId") == 8)

print(f"non-dailies count = {df_stage_non_dailies.count()}")
print(f"dailies count = {df_stage.count()}")


# work with just the dailies
# we need an EOM value for current month, so roll current/max day to EOM
group_keys = ["IndexId", "CurrencyId"]

# Define a window partitioned by the group keys, ordered by AsOfDate descending
w = Window.partitionBy(*group_keys).orderBy(col("AsOfDate").desc())

# Add a row_number per group to find the max AsOfDate row
df_with_rank = df_stage.withColumn("row_num", row_number().over(w))

# Filter only the latest row per group
df_max = df_with_rank.filter(col("row_num") == 1).drop("row_num")

# Create the new row(s) with AsOfDate = end of month
df_eom = df_max.withColumn("AsOfDate", last_day(col("AsOfDate")))
df_eom.show(10)

# Union the new row(s) with the original data
df_stage = df_stage.unionByName(df_eom)
df_stage.show(11)

# filter for just EOM values
df_stage = df_stage.filter(col("AsOfDate") == last_day(col("AsOfDate")))
df_stage.show(12)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# In order to compute monthly returns, we will need one monthly data point prior to our staged data

#read historical data that will be needed for computations
df_wh = spark.read.format("delta").load("Tables/Bronze/IndexReturn")

# just 2/Monthly
df_wh = df_wh.filter(col("FrequencyId") == 2)
df_wh = df_wh.withColumn("Source", lit("Historical"))
df_wh.show(10)

# identify the earliest date for each grouping in our new/raw data
min_dates = df_stage\
    .groupBy("IndexId", "CurrencyId", "FrequencyId") \
    .agg(spark_min("AsOfDate").alias("AsOfDate"))

# we started with Frequencyid 8/Daily, but, the data is now only EOM, so set to 2/Monthly
min_dates = min_dates.withColumn("FrequencyId", lit(2))
display(min_dates)

# now query the historic data for the max date that is prior to the above min dates
start_rows = df_wh.alias("ir").join(
    min_dates.alias("mindate"),
    (col("ir.IndexId") == col("mindate.IndexId")) &
    (col("ir.CurrencyId") == col("mindate.CurrencyId")) &
    (col("ir.FrequencyId") == col("mindate.FrequencyId")) &
    (col("ir.AsOfDate") < col("mindate.AsOfDate"))
).groupBy("ir.IndexId", "ir.CurrencyId", "ir.FrequencyId") \
 .agg(spark_max("ir.AsOfDate").alias("AsOfDate"))

#leverage the staged data to create an index "metadata" dataframe
df_index_metadata = df_stage.dropDuplicates(["IndexId", "CurrencyId", "FrequencyId"]).alias("stg")
#xxx
df_index_metadata = df_index_metadata.withColumn("FrequencyId", lit(2))


# Join in order to get the historic data with desired columns
wh = df_wh.alias("wh")
sr = start_rows.alias("sr")
metadata = df_index_metadata.alias("md")

wh.show(6)
sr.show(7)
metadata.show(8)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

start_data = wh.join(
    sr,
    on=["IndexId", "CurrencyId", "FrequencyId", "AsOfDate"],
    how="inner"
).join(
    metadata,
    on=["IndexId", "CurrencyId", "FrequencyId"],
    how="inner"
).select(
    col("wh.IndexId"),
    col("wh.FrequencyId"),
    col("wh.AsOfDate"),
    col("wh.IndexLevel"),
    col("wh.IndexReturn"),
    col("md.VendorIndexReturnUnit"),  # need to get this from stage
    col("md.RunReason"),
    col("md.Guid"),
    col("md.AdditionalParam"),
    col("wh.CurrencyId"),
    col("wh.Source")
)

# flag this data as not valid because we do not want to move it to move to next medallion
#xxx
start_data = start_data.withColumn("Source", lit("Historical"))
start_data.show(3)

df_stage.show(20)

# Union the stage data with the historic data
df_stage = df_stage.unionByName(start_data)


##############################################################
# xxx todo: remove this once data is fixed in CrimsonX 
df_stage = df_stage.withColumn(
    "VendorIndexReturnUnit",
    when(col("IndexId") == "604271f0-de76-45f0-b9cf-220c51e42149", "LEVEL")
    .otherwise(col("VendorIndexReturnUnit"))
)
##############################################################


# separate out return based data into a separate dataframe
df_stage_return_based = df_stage.filter(col("VendorIndexReturnUnit") == "RETURN")

# keep level based data in df_stage
df_stage = df_stage.filter(col("VendorIndexReturnUnit") == "LEVEL")
df_stage.show(22)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# need to know earliest data in staged data in order to find one data point prior
df_summary = df_stage.agg(
    min("AsOfDate").alias("MinDate"),
    max("AsOfDate").alias("MaxDate")
)

df_summary.show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Add Row Numbers and Calculate LEVEL-Based Returns (month over month)
window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("AsOfDate")
df_stage = df_stage.withColumn("RowNum", row_number().over(window_spec))

# Join with previous row to compute LEVEL-based returns
df_prev = df_stage.withColumnRenamed("RowNum", "RowNumPrev") \
                  .withColumnRenamed("IndexLevel", "IndexLevelPrev")

df_joined = df_stage.alias("curr").join(
    df_prev.alias("prev"),
    (col("curr.IndexId") == col("prev.IndexId")) &
    (col("curr.CurrencyId") == col("prev.CurrencyId")) &
    (col("curr.FrequencyId") == col("prev.FrequencyId")) &
    (col("curr.RowNum") == col("prev.RowNumPrev") + 1)
).withColumn(
    "CalcIndexReturn",
    when(col("prev.IndexLevelPrev") == 0, lit(0.0))
    .otherwise((col("curr.IndexLevel") - col("prev.IndexLevelPrev")) / col("prev.IndexLevelPrev"))
)

#display(df_joined)
df_joined.show(10)

# get back to desired set of columns
df_stage = df_joined.select("curr.IndexId", "curr.FrequencyId", "curr.AsOfDate", "curr.IndexLevel", col("CalcIndexReturn").alias("IndexReturn"), 
  "curr.VendorIndexReturnUnit","curr.RunReason","curr.Guid","curr.AdditionalParam","curr.CurrencyId","curr.Source",)

df_stage.show(13)

#df_stage.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(f"{curated_lh_id}/Tables/Silver/BloombergIndexFequencyPromoted")
df_stage.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(f"{curated_lh_id}/Tables/Silver/IndexReturn_STAGE_for_compare")



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
