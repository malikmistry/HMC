# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

WorkspaceId = ''
BronzeLhId = ''
CuratedLhId = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************


# CELL ********************

#TODO: change to use params
#todo: move to shared notebook??
#e.g bronze_lh_id = 'abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558'
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLhId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLhId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

def get_basepath(workspace_id, lakehouse_id) -> str: 
    lh_basepath = 	f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}" 
    return lh_basepath

bronze_lh_id = get_basepath(WorkspaceId, BronzeLhId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLhId)
print(curated_lh_id)

from datetime import datetime, date
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, when, row_number, current_timestamp, max as spark_max, min as spark_min
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType, DoubleType
from pyspark.sql.window import Window

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#read historical data that will be needed for computations
df_wh = spark.read.format("delta").load("Tables/Bronze/IndexReturn")
#df_wh = df_wh.withColumn("IndexId", upper(col("IndexId")))
df_wh.show(10)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# build a dataframe for staging the data from the raw data and flag data appropriately
# read tmp file created by the gap fill notebook

df_stage = spark.read.parquet(f"{curated_lh_id}/Files/BloombergIndexReturnGapsFilled")

df_stage = df_stage.orderBy(col("IndexId").asc(), col("CurrencyId").asc(), col("AsOfDate").asc())
df_stage.show(13)

df_stage = df_stage.withColumn("Source", lit("Stage"))

# need to know which rows were brought in as the "prior date" data point needed for computation. designate as Historical
# note that these Historical rows will not get to our index returns table (they are already there)
df_wh = df_wh.withColumn("Source", lit("Historical"))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# The HMC index SLA states that we need to have both a level and a return for each date
# Consider a level based index. In order to compute a "return" for a new level data point, we need the value for the prior level

# start by identifing the earliest date for each grouping in our new/raw data
min_dates = df_stage\
    .groupBy("IndexId", "CurrencyId", "FrequencyId") \
    .agg(spark_min("AsOfDate").alias("AsOfDate"))

display(min_dates)

# now query the historic data for the max date that is prior to the above min dates
start_rows = df_wh.alias("ir").join(
    min_dates.alias("mindate"),
    (col("ir.IndexId") == col("mindate.IndexId")) &
    (col("ir.CurrencyId") == col("mindate.CurrencyId")) &
    (col("ir.FrequencyId") == col("mindate.FrequencyId")) &
    (col("ir.AsOfDate") < col("mindate.AsOfDate"))
).groupBy("ir.IndexId", "ir.CurrencyId", "ir.FrequencyId") \
 .agg(spark_max("ir.AsOfDate").alias("AsOfDate"))

#leverage the staged data to create an index "metadata" dataframe
df_index_metadata = df_stage.dropDuplicates(["IndexId", "CurrencyId", "FrequencyId"]).alias("stg")

# Join in order to get the historic data with desired columns
wh = df_wh.alias("wh")
sr = start_rows.alias("sr")
metadata = df_index_metadata.alias("md")

wh.show(6)
sr.show(7)
metadata.show(8)

start_data = wh.join(
    sr,
    on=["IndexId", "CurrencyId", "FrequencyId", "AsOfDate"],
    how="inner"
).join(
    metadata,
    on=["IndexId", "CurrencyId", "FrequencyId"],
    how="inner"
).select(
    col("wh.IndexId"),
    col("wh.FrequencyId"),
    col("wh.AsOfDate"),
    col("wh.IndexLevel"),
    col("wh.IndexReturn"),
    col("md.VendorIndexReturnUnit"),  # need to get this from stage
    col("md.RunReason"),
    col("md.Guid"),
    col("md.AdditionalParam"),
    col("wh.CurrencyId"),
    col("wh.Source")
)

# flag this data as not valid because we do not want to move it to move to next medallion
#xxx
start_data = start_data.withColumn("Source", lit("Historical"))
start_data.show(3)

df_stage.show(20)

# Union the stage data with the historic data
df_stage = df_stage.unionByName(start_data)


##############################################################
# xxx todo: remove this once data is fixed in CrimsonX 
df_stage = df_stage.withColumn(
    "VendorIndexReturnUnit",
    when(col("IndexId") == "604271f0-de76-45f0-b9cf-220c51e42149", "LEVEL")
    .otherwise(col("VendorIndexReturnUnit"))
)
##############################################################


# separate out return based data into a separate dataframe
df_stage_return_based = df_stage.filter(col("VendorIndexReturnUnit") == "RETURN")

# keep level based data in df_stage
df_stage = df_stage.filter(col("VendorIndexReturnUnit") == "LEVEL")
df_stage.show(22)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Add Row Numbers and Calculate LEVEL-Based Returns
window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("AsOfDate")
df_stage = df_stage.withColumn("RowNum", row_number().over(window_spec))

# Join with previous row to compute LEVEL-based returns
df_prev = df_stage.withColumnRenamed("RowNum", "RowNumPrev") \
                  .withColumnRenamed("IndexLevel", "IndexLevelPrev")

df_joined = df_stage.alias("curr").join(
    df_prev.alias("prev"),
    (col("curr.IndexId") == col("prev.IndexId")) &
    (col("curr.CurrencyId") == col("prev.CurrencyId")) &
    (col("curr.FrequencyId") == col("prev.FrequencyId")) &
    (col("curr.RowNum") == col("prev.RowNumPrev") + 1)
).withColumn(
    "CalcIndexReturn",
    when(col("prev.IndexLevelPrev") == 0, lit(0.0))
    .otherwise((col("curr.IndexLevel") - col("prev.IndexLevelPrev")) / col("prev.IndexLevelPrev"))
)

#display(df_joined)
df_joined.show(10)

# get back to desired set of columns
df_stage = df_joined.select("curr.IndexId", "curr.FrequencyId", "curr.AsOfDate", "curr.IndexLevel", col("CalcIndexReturn").alias("IndexReturn"), 
  "curr.VendorIndexReturnUnit","curr.RunReason","curr.Guid","curr.AdditionalParam","curr.CurrencyId","curr.Source",)

df_stage.show(13)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# for RETURN based index returns, calculate levels

if df_stage_return_based.count() > 0:
    print( f"return based count = {df_stage_return_based.count()}")

display(df_stage_return_based)

#for raw BB sourced data, all numeric values are in column IndexLevel
#but, for a return based index, we need to put that data in the IndexReturn column and then compute the level
#TODO: this code will need to change for a manually sources .xlsx index return file

# for Historical data point, need to presere the level
df_stage_return_based  = df_stage_return_based.withColumn(
    "IndexLevelNEW",
    when(
        (col("Source") == "Historical"), col("IndexLevel")
    ).otherwise(None))

df_stage_return_based = df_stage_return_based.withColumn(
    "IndexReturn",
    when(
        (col("Source") == "Historical"), None
    ).otherwise(col("IndexLevel")))

# Assign RowNum per Index group
window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("AsOfDate")
df_stage_return_based = df_stage_return_based.withColumn("RowNum", row_number().over(window_spec))

# Convert to Pandas for group-based recursion
pdf = df_stage_return_based.toPandas()

# Apply recursion per group
for keys, group in pdf.groupby(["IndexId", "CurrencyId", "FrequencyId"]):
    group = group.sort_values("RowNum")
    levels = []
    for i, row in group.iterrows():
        #print(row)
        if row["RowNum"] == 1:
            # Default starting value if not provided
            # TODO: how to handle this case?
            #level = 100000.0 if pd.isna(row["IndexLevel"]) else row["IndexLevel"]
            level = row["IndexLevelNEW"]
        else:
            level = levels[-1] * (1 + row["IndexReturn"] )
        levels.append(level)
    #print(levels)
    pdf.loc[group.index, "IndexLevelNEW"] = levels
#print(levels)


if df_stage_return_based.isEmpty():
    print("no returns data")
else:
    # Convert back to Spark DataFrame
    df_stage_return_based = spark.createDataFrame(pdf)

    # keep just Raw data (gets rid of "Historical")
    df_stage_return_based = df_stage_return_based.filter(col("Source") == "Raw")

    df_stage_return_based.show(100)

    # clean up columns
    df_stage_return_based = df_stage_return_based.select("IndexId", "FrequencyId", "AsOfDate", "CurrencyId", 
    col("IndexLevelNEW").alias("IndexLevel"), "IndexReturn", "IsValid", "VendorIndexReturnUnit")

    df_stage_return_based.show(100)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

#todo: account for if either level based and returns based dataframes are empty

if df_stage_return_based.isEmpty():
    print("no return based returns")
else:
    # combine the return based data with the level based data (already in df_stage)
    df_stage = df_stage.union(df_stage_return_based)

df_stage.show(9)

#save out the calcualted data
df_stage.write.mode("overwrite").parquet( f"{curated_lh_id}/Files/BloombergIndexReturnCalculated")

#df_stage.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(f"{curated_lh_id}/Tables/Bronze/BloombergIndexReturnCalculated")

# code below here makes df_stage look like IndexReturn
# todo: delete this or migrate to final step

#todo: use this or ETLLoadDateTime??
currentTs = current_timestamp()

#get more columns added to match IndexReturn with which we will need to merge
df_stage = df_stage.withColumn("ReturnComment", lit(None).cast("string")) \
.withColumn("ReturnSource", lit(None).cast("string")) \
.withColumn("VersionNum", lit(-999).cast("string")) \
.withColumn("UpdateTimeStamp", currentTs) \
.withColumn("UpdateByHmcUserId", lit(None).cast("string"))

# now get columns in same order as current CrimsonX prod IndexReturns
df_stage = df_stage.select("curr.IndexId", "curr.FrequencyId", "curr.AsOfDate", 
  "curr.CurrencyId", "curr.IndexLevel", "IndexReturn", "ReturnComment",
"ReturnSource","VersionNum", "UpdateTimeStamp", "UpdateByHmcUserId",

#todo: keep these? these three are new/extra need to identify why we are loading this data
"curr.RunReason","curr.Guid","curr.AdditionalParam")

df_stage.show(22)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#merge dataframe to the delta table

from delta.tables import DeltaTable
from pyspark.sql.functions import col

# add in this column to match DB columns
df_stage = df_stage.withColumn("ETLLoadDateTime", currentTs)

#xxx this will fail until we get the IndexReturn table loaded to Silver
#xxx: also, this needs to be done after all work is done on the staged data
#xxx: it was here to test merging the staged data to the delta table
delta_table = DeltaTable.forPath(spark, f"{curated_lh_id}/Tables/Silver/IndexReturn")
delta_table.alias("target").merge(
    df_stage.alias("source"),
    "target.IndexId = source.IndexId AND target.FrequencyId = source.FrequencyId AND target.AsOfDate = source.AsOfDate AND target.CurrencyId = source.CurrencyId"
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()

print("Done.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
