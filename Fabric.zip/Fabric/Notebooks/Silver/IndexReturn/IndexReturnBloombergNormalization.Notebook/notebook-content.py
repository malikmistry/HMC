# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "920a12cc-7104-4013-a2a3-d7baa57e9e3f",
# META       "default_lakehouse_name": "lh_raw",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "920a12cc-7104-4013-a2a3-d7baa57e9e3f"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

# standard parameters passed in via MDF, default values are for development
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col, lit, when, upper, concat, trim

#xxx this cell handles data from Bloomberg.  A FileTask got BB data into a delta table and this cell reads it

#xxx need to read different file for a new index load

# The MDF got the *.txt files all the way to bronze, so this notebook picks up by reading the Bronze delta table
df_stage = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/BloombergIndexReturn")
df_stage = df_stage.withColumn("SecurityIdentifier", upper(col("SecurityIdentifier").cast("string")))
df_stage.show(13)

# xxx todo: cleanup dup tickers
# for this notebook, first purge erroneous indices that need to be cleaned up
# e.g. the below shows two indices with the same ticker.  That is not supported 
# SELECT IndexId, DisplayName, Ticker, IsActive, CurrencyId FROM dbo.[Index] WHERE Ticker = 'SMLLBV Index'
# IndexId	DisplayName	Ticker	IsActive	CurrencyId
#04aa2a49-255e-439e-adff-3935e49e4c8c	BM&F Bovespa Small Cap BRL	SMLLBV Index	1	26
#ba9bac3b-7e86-4eff-97ac-fe339c2871fa	BM&F Bovespa Small Cap USD	SMLLBV Index	1	1

df_stage = df_stage.filter(col("SecurityIdentifier") != "SMLLBV INDEX")

df_stage.printSchema()

df_check_for_dups = df_stage.filter(col("Status") == "0").groupBy("SecurityIdentifier", "Date", "Currency") \
    .count() \
    .filter("count > 1")
if df_check_for_dups.count() > 0:
    display(df_check_for_dups)
    raise Exception("Problem: found duplicate rows.  Need to investigate. Were there more than one days worth of files in the Bloomberg/Nightly folder?")


# xxx =============================================================================================
# =============================================================================================
# =============================================================================================
df_with_errors = df_stage.withColumn(
    "ErrorMessage",
    when(col("Status") != "0", concat(lit("Bloomberg error: "), col("Status")))
    .when(col("Date").isNull(), lit("NULL Date"))
    .when(col("Date") == "", lit("Blank Date"))
    .when(col("Level").isNull(), lit("NULL Level"))
    .when(col("Level") == "", lit("Blank Level"))
    .when(col("Level") == "0", lit("Zero Level"))
    .otherwise(lit(None))
)

df_with_errors = df_with_errors.filter(col("ErrorMessage").isNotNull())
df_with_errors.show(22)

if df_with_errors.count() > 0:
    df_log = df_with_errors.select(
        lit("IndexReturn").alias("ApplicationName"), 
        df_with_errors["ErrorMessage"],
        df_with_errors["ETLLoadDateTime"]
    )
    df_log.show(7)
    #df_log.write.format("delta").mode("append").saveAsTable("Bronze.Log")
    path = f"{bronze_lh_id}/Tables/Bronze/Log"
    print(path)
    #df_log.write.format("delta").option("overwriteSchema", "true").mode("overwrite").save(path)
    df_log.write.format("delta").mode("append").save(path)

# filter out invalid data so that we only have good data to process
#xxx need to test this filter (non-zero status code is working, but, test other error criteria)
#xxx todo: record these errors via Purvue or other means
df_stage = df_stage.filter(
    (col("Status") == 0) &    #this Status has been tested
    (col("Date").isNotNull()) &
    (trim(col("Date")) != "") &
    (col("Level").isNotNull()) &
    (trim(col("Level").cast("string")) != "")
)
df_stage.show(20)

# and look up at HMC to get index Frequency (we only fill gaps for 8/Daily).  also get LEVEL/RETURN based and/or other metadata
df_stage = df_stage.select(
    col("SecurityIdentifier"),
    to_date(col("Date"), "yyyyMMdd").alias("AsOfDate"),
    col("Currency").alias("CurrencyId"),
    col("Level").alias("IndexLevel"),
    lit(0).alias("IndexReturn"),
    col("RunReason"),
    col("Guid"),
    col("AdditionalParam")
)

# Preview the result
df_stage.show(5)

df_debug = df_stage.filter((col("SecurityIdentifier") == "HFRIRVA INDEX") & (col("AsOfDate") == "2025-08-31") & (col("CurrencyId") == "USD")).orderBy(col("AsOfDate").desc())
df_debug.show(7)
df_debug.printSchema()



# xxx =============================================================================================
# =============================================================================================
# =============================================================================================

#todo: note: for BB sourced, use Ticker to get to HMC Index.  But, for manual, need the INT ID from HMCstaging to make to HMC
# get GUID and other metadata type values
#dfIndexXref = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index").select("IndexId", "Ticker", "Frequency", "IsLevelBased").filter(col("IsActive") == 1)

# do not filter out inactive because we need their tickers because we are retrieving them from Bloomberg
#Note that sometimes we query Bloomberg for ticker "RU30GRTR Index" and the time series data comes back with ticker "RU30GRTR INDEX"
#So, we need to handle the tickers case-insensitive. Convert to upper.
dfIndexXref = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index").select("IndexId", upper(col("Ticker")).alias("Ticker"), "Frequency", "IsLevelBased")
dfCurrencyXref = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Currency").select("CurrencyId", "ISOCode")

dfIndexXref.show(5)
dfIndexXref.filter(col("Ticker") == "XET CURNCY").show(5)

dfWithHmcId = df_stage.join(dfIndexXref, df_stage["SecurityIdentifier"] == dfIndexXref["Ticker"], how="left")
dfUnmatched = dfWithHmcId.filter(col("Ticker").isNull())

display(dfWithHmcId)

#todo: how to handle this error... when raw vendor data does not resolve to an HMC index?
#todo: maybe log isue, purge from the staged data and then continue
#note: this will happen when the BB files includes the C2R securities
if dfUnmatched.count() > 0:
    dfUnmatched.show(10)
    dfUniqueTickers = dfUnmatched.select(col("SecurityIdentifier")).distinct()
    dfUniqueTickers.show(100)
    raise Exception(f"join failed, unmatched count = {dfUnmatched.count()}")

dfWithHmcId = dfWithHmcId.select(
    col("IndexId"),
    col("Frequency").alias("FrequencyId"),
    col("AsOfDate").alias("ReturnDate"),
    col("CurrencyId").alias("CurrencyCode"),
    col("IndexLevel").alias("LevelValue"),
    col("IndexReturn").alias("ReturnValue"),
    when(col("IsLevelBased") == True, "LEVEL").otherwise("RETURN").alias("VendorIndexReturnUnit"),
    col("RunReason"),
    col("Guid"),
    col("AdditionalParam")
)
dfWithHmcId = dfWithHmcId.join(dfCurrencyXref, dfWithHmcId["CurrencyCode"] == dfCurrencyXref["ISOCode"])
df_stage = dfWithHmcId.drop("CurrencyCode").drop("ISOCode")
df_stage.show(25)

df_debug = df_stage.filter(col("FrequencyId").isNull())
if df_debug.count() > 0:
    df_debug.show(19)
    raise Exception("Problem: missing Frequency")

df_stage.write.mode("overwrite").parquet( f"{curated_lh_id}/Files/IndexReturnNormalized")

print(f"Done")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
