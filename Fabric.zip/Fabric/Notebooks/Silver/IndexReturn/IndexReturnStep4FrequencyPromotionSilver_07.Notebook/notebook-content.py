# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

# The fourth and final step in processing is to promote frequencies.  The HMC Index Return SLA says that for a daily quoted 
# benchmark, there should be monthly and quarterly data points.  For monthly benchmarks, there should also be quarterly data points.
# The “promoted” data points are created by taking the level from one month end and computing a return for the next month end.
# Likewise for computing quarterlies… use the levels from two data points to compute a new quarterly data point.
#
# Like the other notebooks, this one starts by reading the data from step 3: {curated_lh_id}/Files/BloombergIndexReturnCustom.
#
# However, rather than writing out a parquet files of its dataframe, this last notebook merges its dataframe with the 
# IndexReturn delta table: {curated_lh_id}/Tables/Silver/IndexReturn


# standard paramaters passed in via MDF
WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
from pyspark.sql import SparkSession
from pyspark.sql import types as T
from pyspark.sql.functions import last_day, col, min, max, col, max as spark_max, lit, min as spark_min, when, row_number, current_timestamp, month, to_date
import pandas as pd
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType, DoubleType, DecimalType
from pyspark.sql.window import Window
from delta.tables import DeltaTable

dec_type = DecimalType(38, 11)

# Create Spark session
spark = SparkSession.builder.getOrCreate()
spark.conf.set("spark.sql.decimalOperations.allowPrecisionLoss", "false")

# get index metadata so we know Frequency, etc
dfIndexXref = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index").select("IndexId", "Ticker", "Frequency", "IsLevelBased")
dfIndexXref.show(5)

# read current state of staged data into a dataframe
# at this point, the data had gaps filled and returns computed
df_stage = spark.read.parquet(f"{curated_lh_id}/Files/BloombergIndexReturnCustom")
df_stage = df_stage.orderBy(col("IndexId").asc(), col("CurrencyId").asc(), col("ReturnDate").asc())
df_stage.show(7)

print(f"initial stage count = {df_stage.count()}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# for Dailies, need to copy most recent AsOfData row to be an End of Month
# xxx todo: move this to be after we compute custom indices

from pyspark.sql.functions import col, last_day, lit, row_number
from pyspark.sql.window import Window

# Step 1: Filter original df_stage for FrequencyId == 8
df_freq8 = df_stage.filter(col("FrequencyId") == 8)

# Step 2: Define window to find max ReturnDate per (IndexId, CurrencyId)
w = Window.partitionBy("IndexId", "CurrencyId").orderBy(col("ReturnDate").desc())

# Step 3: Get the latest row per group
df_max_eom_rows = df_freq8.withColumn("row_num", row_number().over(w)) \
                    .filter(col("row_num") == 1) \
                    .drop("row_num")

df_max_eom_rows.show(13)

# Step 4: Create EOM rows with FrequencyId set to 2
#xxx this may make dups during the step 4 notebook
df_max_eom_rows = df_max_eom_rows.withColumn("ReturnDate", last_day(col("ReturnDate"))) \
                        .withColumn("FrequencyId", lit(2))

df_debug = df_max_eom_rows.filter((col("IndexId") == "f23798b7-6c88-4547-b90c-ae6e5c2654e4") & (col("CurrencyId") == 3) & (col("FrequencyId") == 2)).orderBy(col("ReturnDate").desc())
df_debug.show(6)

df_max_eom_rows.show(8)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# prepare a dataframe containing the Dailies, but for month end data points only
df_month_end = df_stage.filter((col("FrequencyId") == 8) & (col("ReturnDate") == last_day(col("ReturnDate"))))

# set these month end dated data points to 2/Monthly
df_month_end = df_month_end.withColumn("FrequencyId", lit(2)).withColumn("Source", lit("Fabric Frequency Promotion").cast("string"))

df_month_end.show(12)

# now work on quarterlies (only promote monthlies, not dailies, to quarterly)
df_quarter_end = df_month_end.filter(
    (col("ReturnDate") == last_day(col("ReturnDate"))) &
    (month(col("ReturnDate")).isin([3, 6, 9, 12]))
)

# set these quarter end dated data points to 3/Quarterly
df_quarter_end = df_quarter_end.withColumn("FrequencyId", lit(3)).withColumn("Source", lit("Fabric Frequency Promotion").cast("string"))
df_quarter_end.show(13)

# now combine into one dataframe
df_freqs = df_month_end.union(df_quarter_end)

df_freqs = df_freqs.union(df_max_eom_rows)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# In order to compute returns, we will need one data point prior to the staged data

#read historical data that will be needed for computations
df_wh = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/IndexReturn")

# get the historic monthlies and quarterlies
df_wh = df_wh.filter((col("FrequencyId") == 2) | (col("FrequencyId") == 3))
df_wh = df_wh.withColumn("Source", lit("Historical")) \
            .withColumnRenamed("AsOfDate","ReturnDate") \
            .withColumnRenamed("IndexLevel","LevelValue") \
            .withColumnRenamed("IndexReturn","ReturnValue")

# TODO: Mike can you please look at the renaming columns above? Commented them out for now

df_wh.show(10)

# identify the earliest date for each grouping in our new/raw data set
min_dates = df_freqs\
    .groupBy("IndexId", "CurrencyId", "FrequencyId") \
    .agg(spark_min("ReturnDate").alias("ReturnDate"))

#display(min_dates)

# now query the historic data for the max date that is prior to the above min dates
start_rows = df_wh.alias("ir").join(
    min_dates.alias("mindate"),
    (col("ir.IndexId") == col("mindate.IndexId")) &
    (col("ir.CurrencyId") == col("mindate.CurrencyId")) &
    (col("ir.FrequencyId") == col("mindate.FrequencyId")) &
    (col("ir.ReturnDate") < col("mindate.ReturnDate"))
).groupBy("ir.IndexId", "ir.CurrencyId", "ir.FrequencyId") \
 .agg(spark_max("ir.ReturnDate").alias("ReturnDate"))

#leverage the staged data to create an index "metadata" dataframe
df_index_metadata = df_freqs.dropDuplicates(["IndexId", "CurrencyId", "FrequencyId"]).alias("stg")

# Join in order to get the historic data with desired columns
wh = df_wh.alias("wh")
sr = start_rows.alias("sr")
metadata = df_index_metadata.alias("md")

# wh.show(6)
# sr.show(7)
# metadata.show(8)

historical_data = wh.join(
    sr,
    on=["IndexId", "CurrencyId", "FrequencyId", "ReturnDate"],
    how="inner"
).join(
    metadata,
    on=["IndexId", "CurrencyId", "FrequencyId"],
    how="inner"
).select(
    col("wh.IndexId"),
    col("wh.FrequencyId"),
    col("wh.ReturnDate"),
    col("wh.LevelValue"),
    col("wh.ReturnValue"),
    col("md.VendorIndexReturnUnit"),  # need to get this from stage
    col("md.RunReason"),
    col("md.Guid"),
    col("md.AdditionalParam"),
    col("wh.CurrencyId"),
    col("wh.Source")
)

# flag this data as "Historical" so that we can filter it out later
# filter it out later in the notebook
historical_data = historical_data.withColumn("Source", lit("Historical"))

# Union the stage data with the historic data
df_freqs = df_freqs.unionByName(historical_data)

# separate out return based data into a separate dataframe
df_freqs_returns = df_freqs.filter(col("VendorIndexReturnUnit") == "RETURN")

# keep level based data in df_freqs
df_freqs = df_freqs.filter(col("VendorIndexReturnUnit") == "LEVEL")
df_freqs.show(22)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"rowcount before: {df_stage.count()}")
#xxx the above union causes dulicates
key = df_stage.columns[:4] # IndexId|FrequencyId|ReturnDate|LevelValue
key = ["IndexId","FrequencyId","ReturnDate","LevelValue","CurrencyId"]
df_stage = df_stage.dropDuplicates(key)
print(f"rowcount after: {df_stage.count()}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# need to know earliest data in staged data in order to find one data point prior
df_summary = df_freqs.agg(
    min("ReturnDate").alias("MinDate"),
    max("ReturnDate").alias("MaxDate")
)
df_summary.show()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# Add Row Numbers and Calculate LEVEL-Based Returns (month over month or quarter over quarter)
window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("ReturnDate")
df_freqs = df_freqs.withColumn("RowNum", row_number().over(window_spec))

# Join with previous row to compute LEVEL-based returns
df_prev = df_freqs.withColumnRenamed("RowNum", "RowNumPrev") \
                  .withColumnRenamed("LevelValue", "LevelValuePrev")

df_computed = df_freqs.alias("curr").join(
    df_prev.alias("prev"),
    (col("curr.IndexId") == col("prev.IndexId")) &
    (col("curr.CurrencyId") == col("prev.CurrencyId")) &
    (col("curr.FrequencyId") == col("prev.FrequencyId")) &
    (col("curr.RowNum") == col("prev.RowNumPrev") + 1)
).withColumn(
    "CalcIndexReturn",
    when(col("prev.LevelValuePrev") == 0, lit(0.0).cast(dec_type))
    .otherwise(
     ( 
      (col("curr.LevelValue").cast(dec_type) - col("prev.LevelValuePrev").cast(dec_type))
      
      / col("prev.LevelValuePrev").cast(dec_type)
     ).cast(dec_type)))

df_computed.show(10)

# filter out the "Historic" data points that were only needed to do the returns computations
df_computed = df_computed.filter(col("curr.Source") != "Historical")
df_computed.show(10)

# get back to desired set of columns
df_freqs = df_computed.select("curr.IndexId", "curr.FrequencyId", "curr.ReturnDate", "curr.LevelValue", col("CalcIndexReturn").alias("ReturnValue"), 
  "curr.VendorIndexReturnUnit","curr.RunReason","curr.Guid","curr.AdditionalParam","curr.CurrencyId","curr.Source")

print(f"rowcount before: {df_freqs.count()}")
key = ["IndexId","FrequencyId","ReturnDate","LevelValue","CurrencyId"]
df_freqs = df_freqs.dropDuplicates(key)
print(f"rowcount after: {df_freqs.count()}")

df_check_for_dups = df_freqs.groupBy("IndexId", "FrequencyId", "ReturnDate", "CurrencyId") \
    .count() \
    .filter("count > 1")
if df_check_for_dups.count() > 0:
  display(df_check_for_dups)
  print(f"Duplicate row count = {df_check_for_dups.count()}")
  raise Exception("xxx111 Problem: found duplicate rows in frequency promotion.  Need to investigate.")

df_freqs.show(9)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# at this point, we have the original df_stage and we have the df_freqs containing the frequency promoted values

# grab just the 8/Daily values
# this is filtering out the regular monthlies
#xxx df_stage = df_stage.filter(col("FrequencyId") == 8)

# xxx figure out if df_stage contains old 2's and 3's... should we delete them and then do the union ? 

# add in the newly computed frequency promotions
df_stage = df_stage.union(df_freqs)

# raise SystemExit("xxx")

print(f"rowcount before: {df_stage.count()}")
#xxx the above union causes dulicates
key = df_stage.columns[:4] # IndexId|FrequencyId|ReturnDate|LevelValue
key = ["IndexId","FrequencyId","ReturnDate","LevelValue","CurrencyId"]

df_stage = df_stage.dropDuplicates(key)
print(f"rowcount after: {df_stage.count()}")

df_check_for_dups = df_stage.groupBy("IndexId", "FrequencyId", "ReturnDate", "CurrencyId") \
    .count() \
    .filter("count > 1")
if df_check_for_dups.count() > 0:
  display(df_check_for_dups)
  print(f"Duplicate row count = {df_check_for_dups.count()}")
  raise Exception("xxx222 Problem: found duplicate rows in frequency promotion.  Need to investigate.")

#todo: fire Crimson Event to alert others that the data load has completed
df_summary = df_stage.agg(
    min("ReturnDate").alias("MinReturnDate"),
    max("ReturnDate").alias("MaxReturnDate"),
    max("RunReason").alias("MaxRunReason"),
    max("Guid").alias("MaxGuid"),
    max("AdditionalParam").alias("MaxAdditionalParam")
)

df_summary.show()

# make the dataframe look like IndexReturn

currentTs = current_timestamp()

#xxx check on this... only flag as updated by "Fabric" if the notebook truly updated the data
#get more columns added to match IndexReturn with which we will need to merge
df_stage = df_stage.withColumn("ReturnComment", lit(None).cast("string")) \
.withColumn("ReturnSource", lit(None).cast("string")) \
.withColumn("VersionNum", lit(-999).cast("BigInt")) \
.withColumn("UpdateTimeStamp", currentTs) \
.withColumn("ETLLoadDateTime", currentTs)


# now get columns in same order as current CrimsonX prod IndexReturns
df_stage = df_stage.select("IndexId", "FrequencyId", "ReturnDate", "CurrencyId", "LevelValue", "ReturnValue", 
"ReturnComment", "ReturnSource","VersionNum", "UpdateTimeStamp", "Source", "ETLLoadDateTime")

#todo: keep these? these three are new/extra need to identify why we are loading this data
#"curr.RunReason","curr.Guid","curr.AdditionalParam")


#xxx todo: figure out why we have dups here
df_check_for_dups = df_stage.groupBy("IndexId", "FrequencyId", "ReturnDate", "CurrencyId") \
    .count() \
    .filter("count > 1")
if df_check_for_dups.count() > 0:
  display(df_check_for_dups)
  print(f"Duplicate row count = {df_check_for_dups.count()}")
  raise Exception("Problem: found duplicate rows in frequency promotion.  Need to investigate.")

df_stage = df_stage.drop("ReturnComment")
df_stage = df_stage.withColumnRenamed("Source", "ReturnComment")
df_stage.show(17)

df_stage.printSchema()

df_stage = (
    df_stage
    .withColumn("IndexId",  F.col("IndexId").cast(T.VarcharType(36)))
    .withColumn("FrequencyId",  F.col("FrequencyId").cast(T.IntegerType()))
    .withColumn("ReturnDate",  F.col("ReturnDate").cast(T.DateType()))
    .withColumn("CurrencyId",  F.col("CurrencyId").cast(T.IntegerType()))
    .withColumn("LevelValue",  F.col("LevelValue").cast(T.DecimalType(38, 11)))
    .withColumn("ReturnValue", F.col("ReturnValue").cast(T.DecimalType(38, 11)))
    #.withColumn("ReturnComment", F.substring(F.col("ReturnComment").cast("string"), 1, 200))
    .withColumn("ReturnSource",  F.substring(F.col("ReturnSource").cast("string"), 1, 50))
    .withColumn("ETLLoadDateTime", F.to_timestamp("ETLLoadDateTime"))
)


df_stage.printSchema()


df_stage = df_stage.drop("VersionNum").drop("UpdateTimeStamp").drop("UpdateByHMCUserId")

df_stage.printSchema()


ordered = [ "IndexId","FrequencyId","ReturnDate","CurrencyId","LevelValue","ReturnValue","ReturnComment","ReturnSource","ETLLoadDateTime" ]
df_stage = df_stage.select(*ordered)

df_stage.printSchema()

#raise SystemExit("xxx")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#delta_table = DeltaTable.forPath(spark, f"{curated_lh_id}/Tables/Silver/IndexReturn")

# make df_stage visible to SQL
df_stage.createOrReplaceTempView("source_stage")

spark.sql(f"""
MERGE INTO delta.`{curated_lh_id}/Tables/Silver/IndexReturn` AS target
USING source_stage AS source
ON  target.IndexId     = source.IndexId
AND target.FrequencyId = source.FrequencyId
AND target.ReturnDate  = source.ReturnDate
AND target.CurrencyId  = source.CurrencyId
WHEN MATCHED THEN
  UPDATE SET *
WHEN NOT MATCHED THEN
  INSERT *
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC --select  * from lh_curated.Silver.IndexReturn where IndexId = '176ce410-3838-4292-8c24-d7694e8705fd' and ReturnDate >= '2025-04-22' order by ReturnDate  LIMIT 100
# MAGIC 
# MAGIC -- select distinct ReturnComment from  lh_curated.Silver.IndexReturn where  ReturnDate >= '2025-01-01'
# MAGIC 
# MAGIC select  * from  lh_curated.Silver.IndexReturn order by ReturnDate desc limit 10
# MAGIC 
# MAGIC 
# MAGIC -- select * from [lh_curated].[Silver].[IndexReturn] ret 
# MAGIC -- WHERE  ret.IndexId = '176ce410-3838-4292-8c24-d7694e8705fd'
# MAGIC -- and ret.ReturnDate >= '2025-04-24'
# MAGIC -- ORDER BY ret.ReturnDate 

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#%%sql 

#-- xxx for debugging
#select  * from source_stage where IndexId = '176ce410-3838-4292-8c24-d7694e8705fd'   LIMIT 100

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# #########################################################################################
# # more debugging... I do not see the 0.0 getting into the Delta Table from Azure Data Explorer
# # zero = lit(0).cast(delta_tbl.toDF().schema["IndexLevel"].dataType)
# # delta_tbl = DeltaTable.forPath(spark, f"{curated_lh_id}/Tables/Silver/IndexReturn")
# # delta_tbl.update(
# #     condition="IndexId = '547c92eb-98c6-4167-94f7-48ced9f2f7f7' and ReturnDate >= DATE '2025-04-30'",
# #     set={"IndexLevel": zero}
# # )

# df_stage.write.mode("overwrite").parquet( f"{curated_lh_id}/Files/BloombergIndexReturnFrequencyPromoted")

# #xxx add flush???
# # from delta.tables import DeltaTable
# # delta_tbl = DeltaTable.forPath(spark, f"{curated_lh_id}/Tables/Silver/IndexReturn")
# # delta_tbl.checkpoint()

# spark.sql("REFRESH TABLE lh_curated.Silver.IndexReturn")
# spark.sql("SELECT COUNT(*) FROM lh_curated.Silver.IndexReturn").show()

print("Done.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC 
# MAGIC -- SELECT COUNT(*) FROM lh_curated.Silver.IndexReturn
# MAGIC -- SELECT * FROM lh_curated.Silver.IndexReturn ORDER BY ETLLoadDateTime DESC limit 10
# MAGIC 
# MAGIC -- SELECT * FROM lh_curated.Silver.IndexReturn where ReturnComment like 'Fabr%' limit 10
# MAGIC 
# MAGIC SELECT * FROM lh_curated.Silver.IndexReturn where not ReturnComment like 'Fabr%' limit 10


# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }
