# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

# This is the second step in processing index returns: compute returns from levels and levels from returns.  Some indices are quoted as a 
# level for a given day (e.g. 5,232) while others are quoted as a return (e.g. 0.3%).  HMC normalizes this by computing a return for indices 
# that are quoted as level and vice versa.  Note that as of 10/28/2025, all indices retrieved from Bloomberg are quoted as a level.  HMC’s 
# benchmarks that are quoted as returns are the “manual” benchmarks such as “CA Emerging Market”.
#
# This notebook picks up with the processing by reading the parquet file written by step 1: {curated_lh_id}/Files/BloombergIndexReturnGapsFilled
# This notebook then writes out its dataframe as another file: {curated_lh_id}/Files/BloombergIndexReturnCalculated

# standard parameters passed in via MDF
WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from datetime import datetime, date
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, when, row_number, current_timestamp, max as spark_max, min as spark_min
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType, DoubleType, DecimalType
from pyspark.sql.window import Window

dec_type = DecimalType(38, 11)

spark = SparkSession.builder.getOrCreate()
spark.conf.set("spark.sql.decimalOperations.allowPrecisionLoss", "false")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# build a dataframe for staging the data from the raw data and flag data appropriately
# read tmp file created by the gap fill notebook

df_stage = spark.read.parquet(f"{curated_lh_id}/Files/BloombergIndexReturnGapsFilled")

df_stage.orderBy(col("AsOfDate")).show(11)

df_stage = df_stage.withColumn("Source", lit("Fabric Computed"))

df_stage = df_stage.withColumn("IndexLevel", col("IndexLevel").cast(dec_type))

# read historical data that will be needed for computations
# need to know which rows were brought in as the "prior date" data point needed for computation. designate as "Historical"
# note that these Historical rows will not get to our index returns table (they are already there)
df_wh = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/IndexReturn")
df_wh = df_wh.withColumn("Source", lit("Historical"))
df_wh.show(10)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def seedStartRows(df_stage):

    # The HMC index SLA states that we need to have both a level and a return for each date
    # Consider a level based index. In order to compute a "return" for a new level data point, we need the value for the prior level

    # start by identifing the earliest date for each grouping in our new/raw data
    min_dates = df_stage\
        .groupBy("IndexId", "CurrencyId", "FrequencyId") \
        .agg(spark_min("AsOfDate").alias("AsOfDate"))

    display(min_dates)

    # now query the historic data for the max date that is prior to the above min dates
    start_rows = df_wh.alias("ir").join(
        min_dates.alias("mindate"),
        (col("ir.IndexId") == col("mindate.IndexId")) &
        (col("ir.CurrencyId") == col("mindate.CurrencyId")) &
        (col("ir.FrequencyId") == col("mindate.FrequencyId")) &
        (col("ir.ReturnDate") < col("mindate.AsOfDate"))
    ).groupBy("ir.IndexId", "ir.CurrencyId", "ir.FrequencyId") \
    .agg(spark_max("ir.ReturnDate").alias("ReturnDate"))

    #leverage the staged data to create an index "metadata" dataframe
    df_index_metadata = df_stage.dropDuplicates(["IndexId", "CurrencyId", "FrequencyId"]).alias("stg")

    # Join in order to get the historic data with desired columns
    wh = df_wh.alias("wh")
    sr = start_rows.alias("sr")
    metadata = df_index_metadata.alias("md")

    wh.show(6)
    sr.show(7)
    metadata.show(8)

    start_data = wh.join(
        sr,
        on=["IndexId", "CurrencyId", "FrequencyId", "ReturnDate"],
        how="inner"
    ).join(
        metadata,
        on=["IndexId", "CurrencyId", "FrequencyId"],
        how="inner"
    ).select(
        col("wh.IndexId"),
        col("wh.FrequencyId"),
        col("wh.ReturnDate"),
        col("wh.LevelValue"),
        col("wh.ReturnValue"),
        col("md.VendorIndexReturnUnit"),  # need to get this from stage
        col("md.RunReason"),
        col("md.Guid"),
        col("md.AdditionalParam"),
        col("wh.CurrencyId"),
        col("wh.Source")
    )

    # flag this data as not valid because we do not want to move it to move to next medallion
    #xxx
    start_data = start_data.withColumn("Source", lit("Historical"))
    start_data.show(3)

    df_stage = df_stage.withColumnRenamed("AsOfDate", "ReturnDate")\
    .withColumnRenamed("IndexLevel", "LevelValue")\
    .withColumnRenamed("IndexReturn", "ReturnValue")

    df_stage.show(20)

    # Union the stage data with the historic data
    df_stage = df_stage.unionByName(start_data)

    return df_stage

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def seedNewIndexLoad(df_stage, minReturnDate):

    df_stage.show(5)

    df_stage = df_stage.withColumnRenamed("AsOfDate", "ReturnDate")\
    .withColumnRenamed("IndexLevel", "LevelValue")\
    .withColumnRenamed("IndexReturn", "ReturnValue")


    #xxx probably need to duplicate the first row and set its data back one day

    # rows to duplicate
    subset = df_stage.filter(F.col("ReturnDate") == minReturnDate)

    # duplicated rows with ReturnDate - 1 day
    subset = subset.withColumn("ReturnDate", F.date_sub(F.col("ReturnDate"), 1))

    df_stage = df_stage.unionByName(subset)

    df_stage.show(6)

    return df_stage

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# determine why we are running: get values from the stage data
agg_result = df_stage.agg(
    spark_max("VendorIndexReturnUnit").alias("max_VendorIndexReturnUnit"),
    spark_max("RunReason").alias("max_RunReason"),
    spark_max("Guid").alias("max_Guid"),
    spark_max("AdditionalParam").alias("max_AdditionalParam"),
    spark_min("AsOfDate").alias("min_ReturnDate"),
    
).collect()[0]

# Extract each value into its own variable
max_VendorIndexReturnUnit   = agg_result["max_VendorIndexReturnUnit"]
max_RunReason = agg_result["max_RunReason"]
max_Guid  = agg_result["max_Guid"]
max_AdditionalParam  = agg_result["max_AdditionalParam"]
min_ReturnDate  = agg_result["min_ReturnDate"]

print(f"max_VendorIndexReturnUnit = {max_VendorIndexReturnUnit}")
print(f"max_RunReason = {max_RunReason}")
print(f"max_Guid = {max_Guid}")
print(f"max_AdditionalParam = {max_AdditionalParam}")
print(f"min_ReturnDate = {min_ReturnDate}")


#xxx
# max_VendorIndexReturnUnit = LEVEL
# max_RunReason = NEW_INDEX_LOAD
# max_Guid = 65c2359b-a371-4d10-8715-08ddfc66a532

if (max_RunReason == "NIGHTLY_INDEX_LOAD_ALL"):
    df_stage = seedStartRows(df_stage)
elif (max_RunReason == "NEW_INDEX_LOAD"):
    df_stage = seedNewIndexLoad(df_stage, min_ReturnDate)
else:
    print ("xxx error")
    raise SystemExit(f"unsupported run reason: {max_RunReason}")

# separate out return based data into a separate dataframe
df_stage_return_based = df_stage.filter(col("VendorIndexReturnUnit") == "RETURN")

# keep level based data in df_stage
df_stage = df_stage.filter(col("VendorIndexReturnUnit") == "LEVEL")
df_stage.show(22)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Add Row Numbers and Calculate LEVEL-Based Returns
window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("ReturnDate")
df_stage = df_stage.withColumn("RowNum", row_number().over(window_spec))

# Join with previous row to compute LEVEL-based returns
df_prev = df_stage.withColumnRenamed("RowNum", "RowNumPrev") \
                  .withColumnRenamed("IndexLevel", "IndexLevelPrev")

# was getting 7 decimals of precision... we need 11
# solution included setting allowPrecisionLoss
curr_level = col("curr.LevelValue").cast(dec_type)
prev_level = col("prev.LevelValue").cast(dec_type)

print("================================================")
df_stage.orderBy(col("ReturnDate")).show(9)
df_prev.orderBy(col("ReturnDate")).show(11)


df_joined = df_stage.alias("curr").join(
    df_prev.alias("prev"),
    (col("curr.IndexId") == col("prev.IndexId")) &
    (col("curr.CurrencyId") == col("prev.CurrencyId")) &
    (col("curr.FrequencyId") == col("prev.FrequencyId")) &
    (col("curr.RowNum") == col("prev.RowNumPrev") + 1)
).withColumn(
    "CalcIndexReturn",
    when(prev_level == 0, lit(0.0).cast(dec_type))
    .otherwise(
        ((curr_level - prev_level) / prev_level).cast(dec_type)
    )
)

df_joined.select("CalcIndexReturn").show(truncate=False)

# for row in df_joined.select("CalcIndexReturn").collect():
#     print(f"{row['CalcIndexReturn']:.11f}")


#display(df_joined)
df_joined.show(10)

# get back to desired set of columns
df_stage = df_joined.select("curr.IndexId", "curr.FrequencyId", "curr.ReturnDate", "curr.LevelValue", col("CalcIndexReturn").alias("ReturnValue"), 
  "curr.VendorIndexReturnUnit","curr.RunReason","curr.Guid","curr.AdditionalParam","curr.CurrencyId","curr.Source",)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# for RETURN based index returns, calculate levels

if df_stage_return_based.count() > 0:
    print( f"return based count = {df_stage_return_based.count()}")

display(df_stage_return_based)

#for raw BB sourced data, all numeric values are in column IndexLevel
#but, for a return based index, we need to put that data in the IndexReturn column and then compute the level
#TODO: this code will need to change for a manually sources .xlsx index return file

# for Historical data point, need to presere the level
df_stage_return_based  = df_stage_return_based.withColumn(
    "IndexLevelNEW",
    when(
        (col("Source") == "Historical"), col("LevelValue")
    ).otherwise(None))

df_stage_return_based = df_stage_return_based.withColumn(
    "ReturnValue",
    when(
        (col("Source") == "Historical"), None
    ).otherwise(col("LevelValue")))

# Assign RowNum per Index group
window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("ReturnDate")
df_stage_return_based = df_stage_return_based.withColumn("RowNum", row_number().over(window_spec))

# Convert to Pandas for group-based recursion
pdf = df_stage_return_based.toPandas()

# Apply recursion per group
for keys, group in pdf.groupby(["IndexId", "CurrencyId", "FrequencyId"]):
    group = group.sort_values("RowNum")
    levels = []
    for i, row in group.iterrows():
        #print(row)
        if row["RowNum"] == 1:
            # Default starting value if not provided
            # TODO: how to handle this case?
            #level = 100000.0 if pd.isna(row["IndexLevel"]) else row["IndexLevel"]
            level = row["IndexLevelNEW"]
        else:
            level = levels[-1] * (1 + row["IndexReturn"] )
        levels.append(level)
    #print(levels)
    pdf.loc[group.index, "IndexLevelNEW"] = levels
#print(levels)

if df_stage_return_based.isEmpty():
    print("no returns data")
else:
    # Convert back to Spark DataFrame
    df_stage_return_based = spark.createDataFrame(pdf)

    # keep just Raw data (gets rid of "Historical")
    df_stage_return_based = df_stage_return_based.filter(col("Source") == "Raw")

    df_stage_return_based.show(100)

    # clean up columns
    df_stage_return_based = df_stage_return_based.select("IndexId", "FrequencyId", "AsOfDate", "CurrencyId", 
    col("IndexLevelNEW").alias("IndexLevel"), "IndexReturn", "IsValid", "VendorIndexReturnUnit")

    df_stage_return_based.show(100)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

#todo: account for if either level based and returns based dataframes are empty

if df_stage_return_based.isEmpty():
    print("no return based returns")
else:
    # combine the return based data with the level based data (already in df_stage)
    df_stage = df_stage.union(df_stage_return_based)

df_stage.show(9)

#save out the calcualted data
df_stage.write.mode("overwrite").parquet( f"{curated_lh_id}/Files/BloombergIndexReturnCalculated")

print("Done")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
