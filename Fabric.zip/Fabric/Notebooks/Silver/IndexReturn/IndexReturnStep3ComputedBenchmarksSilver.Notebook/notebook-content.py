# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# PARAMETERS CELL ********************

# This third step in processing index returns computes HMC custom blends.  For example we can define a new benchmark to be a blend of 
# 50% of benchmark A and 50% of benchmark B.  The "recipe" is stored in the table IndexCustomBlendRecipe.  
#
# As with the other steps, this notebook reads the parquet file from step 2: {curated_lh_id}/Files/BloombergIndexReturnCalculated.
# It then writes out its dataframe as parquet file {curated_lh_id}/Files/BloombergIndexReturnCustom.
#
# The computation logic is based on return values.  After all return values are computed/blended, additional  the logic computes 
# levels from the returns.

# standard parameters passed in via MDF, default values are for development
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import SparkSession, Window, DataFrame
from functools import reduce
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType, DateType, DecimalType
from datetime import date, timedelta
from decimal import Decimal
from pyspark.sql.functions import col, to_date, min as fmin, max as fmax, count as fcount, date_sub, lit, greatest, least, date_sub
from pyspark.sql.functions import min, max, when, row_number, current_timestamp, month, rank, sum, broadcast
from pyspark.sql import functions as F, types as T
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

dec_type = DecimalType(38, 11)

# # get original state of "staged" data we are working with
df_stage_orig = spark.read.parquet(f"{curated_lh_id}/Files/BloombergIndexReturnCalculated")

df_stage_orig.show(11)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark = SparkSession.builder.getOrCreate()
spark.conf.set("spark.sql.decimalOperations.allowPrecisionLoss", "false")

# computed benchmarks only supported for USD and Daily
currency_id = 1 # 1/USD... prod does USD only

frequency_id = 8 # Daily

index_load_control = (
    spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index")
    .filter((col("CurrencyId") == currency_id) & (col("Frequency") == frequency_id))
    .select("IndexId", "IsCustomIndex", "Frequency", col("DisplayName").alias("IndexName"), "IsActive", "CurrencyId" )
)

index_load_control = index_load_control.withColumnRenamed("Frequency", "FrequencyId")

index_return_recipe = (
    spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/IndexCustomBlendRecipe")
    .withColumnRenamed("TargetIndexId", "IndexIdTarget")
    .withColumnRenamed("SourceIndexId", "IndexIdSource")
    .withColumnRenamed("CurrencyIdBase", "CurrencyId")
)

# Collect unique IndexIds (targets + sources)
ids = (
    index_return_recipe.select(col("IndexIdTarget").alias("IndexId"))
    .union(index_return_recipe.select(col("IndexIdSource").alias("IndexId")))
    .where(col("IndexId").isNotNull())
    .distinct()
)

# Build baseline lookup from the Index table
ix = index_load_control.select("IndexId", "IndexName", "CurrencyId", "FrequencyId")

# Universe (one row per IndexId)
universe = (
    ids.join(ix, on="IndexId", how="left")
       .withColumn("CreateLevel", lit(0).cast("int"))
       .select("IndexId", "IndexName", "CurrencyId", "FrequencyId", "CreateLevel")
       .distinct()
)

universe.createOrReplaceTempView("universe")

# ------------------------------------------------------------------------------------
# A) Coverage from df_stage_orig for any *existing* IndexId (usually sources)
#df_stage_orig_d = df_stage_orig.withColumn("ReturnDate", to_date(col("ReturnDate")))

bounds = (
    df_stage_orig.filter(col("CurrencyId") == 1)
    .groupBy("IndexId", "CurrencyId", "FrequencyId")
    .agg(
        fmin("ReturnDate").alias("LoadStartDate"),
        fmax("ReturnDate").alias("LoadEndDate")
    )
    .withColumn("ReturnStartDate", date_sub(col("LoadStartDate"), 1))
)

# print("----------------------------- now showing bounds")
# bounds.show(13)

# --- Your existing 'bounds' from df_stage_orig (base coverage) ---
# bounds: IndexId, CurrencyId, FrequencyId, LoadStartDate, LoadEndDate, ReturnStartDate

# Build dependency edges: Source -> Target (distinct, no nulls)
edges = (
    index_return_recipe
        .select("IndexIdSource", "IndexIdTarget")
        .where(col("IndexIdSource").isNotNull() & col("IndexIdTarget").isNotNull())
        .distinct()
)

# Precompute total source count per target
target_src_counts = (
    edges.groupBy("IndexIdTarget")
         .agg(F.countDistinct("IndexIdSource").alias("total_srcs"))
)

# Start with base bounds (only indexes that already have data)
current = bounds.select("IndexId", "CurrencyId", "FrequencyId", "LoadStartDate", "LoadEndDate", "ReturnStartDate").distinct()

# We'll iterate up to the number of distinct targets (upper bound on depth)
max_depth = index_return_recipe.select("IndexIdTarget").distinct().count()

for _ in range(max_depth):
    # Join each Source with its current bounds
    src_with_bounds = (
        edges.join(current.withColumnRenamed("IndexId", "IndexIdSource"), on="IndexIdSource", how="left")
             .select(
                 "IndexIdTarget",
                 col("CurrencyId"),
                 col("FrequencyId"),
                 col("LoadStartDate").alias("SrcLoadStartDate"),
                 col("LoadEndDate").alias("SrcLoadEndDate")
             )
    )

    # Aggregate per Target: only when all sources are resolved (no NULL start)
    agg_per_target = (
        src_with_bounds.groupBy("IndexIdTarget", "CurrencyId", "FrequencyId")
            .agg(
                F.sum(F.when(col("SrcLoadStartDate").isNotNull(), F.lit(1)).otherwise(F.lit(0))).alias("resolved_srcs"),
                F.max("SrcLoadStartDate").alias("AggLoadStartDate"),
                F.min("SrcLoadEndDate").alias("AggLoadEndDate")
            )
            .join(target_src_counts, on="IndexIdTarget", how="left")
            .where(col("resolved_srcs") == col("total_srcs"))  # only targets whose ALL sources are resolved
            .select(
                col("IndexIdTarget").alias("IndexId"),
                "CurrencyId",
                "FrequencyId",
                col("AggLoadStartDate").alias("LoadStartDate"),
                col("AggLoadEndDate").alias("LoadEndDate")
            )
            .withColumn("ReturnStartDate", date_sub(col("LoadStartDate"), 1))
    )

    # Merge: fill missing targets or fill missing dates for partially-known rows
    merged = (
        universe.select("IndexId", "CurrencyId", "FrequencyId")  # keep the universe you already built
            .join(current, on=["IndexId", "CurrencyId", "FrequencyId"], how="left")
            .join(agg_per_target.withColumnRenamed("LoadStartDate", "NewLoadStartDate")
                                .withColumnRenamed("LoadEndDate", "NewLoadEndDate")
                                .withColumnRenamed("ReturnStartDate", "NewReturnStartDate"),
                  on=["IndexId", "CurrencyId", "FrequencyId"], how="left")
            .select(
                "IndexId", "CurrencyId", "FrequencyId",
                F.coalesce(col("LoadStartDate"), col("NewLoadStartDate")).alias("LoadStartDate"),
                F.coalesce(col("LoadEndDate"), col("NewLoadEndDate")).alias("LoadEndDate"),
                F.coalesce(col("ReturnStartDate"), col("NewReturnStartDate")).alias("ReturnStartDate"),
            )
            .distinct()
    )

    # If nothing new was added, we can stop early
    if merged.exceptAll(current).rdd.isEmpty() and current.exceptAll(merged).rdd.isEmpty():
        break

    current = merged

# Final bounds with propagated dates across dependency levels
bounds = current


# print("----------------------------- bounds with propagated coverage")
# bounds.orderBy("IndexId").show(14, truncate=False)

# ------------------------------------------------------------------------------------
# B) Derive *target* coverage from its sources.
#    Default rule: INTERSECTION of source ranges so all sources are present.
#    (start = max of starts; end = min of ends)
edges = (
    index_return_recipe
    .select("IndexIdTarget", "IndexIdSource", "CurrencyId")
    .distinct()
    .filter(col("CurrencyId") == currency_id)
)

# print("----------------------------- now showing edges")
# edges.show(15)

# Join source coverage
src_bounds = edges.join(
    bounds.withColumnRenamed("IndexId", "IndexIdSource"),
    on=["IndexIdSource", "CurrencyId"],
    how="left"
)

# Count how many sources exist vs how many have bounds
target_bounds_intersection = (
    src_bounds
    .groupBy("IndexIdTarget", "CurrencyId")
    .agg(
        F.max("LoadStartDate").alias("LoadStartDate"),
        F.min("LoadEndDate").alias("LoadEndDate"),
        fcount("*").alias("num_sources"),
        fcount("LoadStartDate").alias("num_with_bounds"),
    )
    # Keep only targets where all sources had data; otherwise intersection is incomplete
    .filter(col("num_sources") == col("num_with_bounds"))
    .withColumn("ReturnStartDate", date_sub(col("LoadStartDate"), 1))
    .withColumnRenamed("IndexIdTarget", "IndexId")
    .withColumn("FrequencyId", lit(frequency_id))
)

target_bounds_intersection = (
    src_bounds
    .groupBy("IndexIdTarget", "CurrencyId")
    .agg(
        F.max("LoadStartDate").alias("LoadStartDate"),
        F.min("LoadEndDate").alias("LoadEndDate"),
        fcount("*").alias("num_sources"),
        fcount("LoadStartDate").alias("num_with_bounds"),
    )
    # Keep only targets where all sources had data; otherwise intersection is incomplete
    .filter(col("num_sources") == col("num_with_bounds"))
    .withColumn("ReturnStartDate", date_sub(col("LoadStartDate"), 1))
    .withColumnRenamed("IndexIdTarget", "IndexId")
    .withColumn("FrequencyId", lit(frequency_id))
)

target_bounds_intersection = target_bounds_intersection.drop("num_sources", "num_with_bounds")

# ------------------------------------------------------------------------------------
# C) Combine source bounds + derived target bounds, then update universe
# ------------------------------------------------------------------------------------
bounds_all = bounds.unionByName(target_bounds_intersection)

bounds_all = bounds_all.dropDuplicates()

df_cfg_updated = (
    universe
    .drop("LoadStartDate", "LoadEndDate", "ReturnStartDate")
    .join(F.broadcast(bounds_all), on=["IndexId", "CurrencyId", "FrequencyId"], how="left")
)

# ------------------------------------------------------------------------------------
# D) Diagnostics (recommended)
# ------------------------------------------------------------------------------------
# Targets with missing coverage (e.g., at least one source lacks data)
targets_missing = (
    universe.select("IndexId").join(
        target_bounds_intersection.select("IndexId").withColumn("has_bounds", lit(True)),
        on="IndexId", how="left"
    )
    .filter(col("has_bounds").isNull())
)

# Which sources are missing stage data?
missing_src = src_bounds.filter(col("LoadStartDate").isNull()).select("IndexIdSource").distinct()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def build_index_recipe_dependency_levels(
    index_return_recipe: DataFrame,
    index_load_control: DataFrame
) -> list[DataFrame]:
    # Join to determine whether each IndexIdSource is a custom index
    recipe_with_is_custom = index_return_recipe \
        .join(
            broadcast(index_load_control.selectExpr("IndexId as IndexIdSource", "IsCustomIndex")),
            on="IndexIdSource",
            how="left"
        )

    recipe_levels = []
    processed_targets = set()

    # Level 0: Targets whose sources are ALL non-custom
    level_df = recipe_with_is_custom.groupBy("IndexIdTarget") \
        .agg(sum(when(col("IsCustomIndex") == True, 1).otherwise(0)).alias("num_custom_sources")) \
        .filter(col("num_custom_sources") == 0) \
        .select("IndexIdTarget")

    level_0_targets = [row["IndexIdTarget"] for row in level_df.collect()]
    processed_targets.update(level_0_targets)

    level_0_df = recipe_with_is_custom.filter(col("IndexIdTarget").isin(level_0_targets))
    recipe_levels.append(level_0_df)

    # Iteratively build higher dependency levels
    while True:
        remaining = recipe_with_is_custom.filter(~col("IndexIdTarget").isin(list(processed_targets)))
        if remaining.isEmpty():
            break

        candidate_targets = remaining.select("IndexIdTarget").distinct()
        next_targets = []

        for row in candidate_targets.collect():
            target = row["IndexIdTarget"]
            source_rows = remaining.filter(col("IndexIdTarget") == target).select("IndexIdSource").collect()
            source_ids = [r["IndexIdSource"] for r in source_rows]

            # A target is eligible if all its sources are either non-custom or already processed
            all_sources_valid = all(
                index_load_control.filter(col("IndexId") == src).select("IsCustomIndex").first()["IsCustomIndex"] == False or
                src in processed_targets
                for src in source_ids
            )

            if all_sources_valid:
                next_targets.append(target)

        if not next_targets:
            break  # Prevent infinite loop if there's a circular dependency

        processed_targets.update(next_targets)
        level_df = recipe_with_is_custom.filter(col("IndexIdTarget").isin(next_targets))
        recipe_levels.append(level_df)

    return recipe_levels

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

ilc = index_load_control
irr = index_return_recipe

# filter down to just the currency of interest for this notebook invocation
# note that we leave df_stage_orig untouched and make a copy to be used for computations 
df_stage_computed = df_stage_orig.filter(col("CurrencyId") == currency_id)

df_stage_computed = df_stage_computed.orderBy(col("IndexId").asc(), col("CurrencyId").asc(), col("ReturnDate").asc())


# get values from the stage data
agg_result = df_stage_computed.agg(
    max("VendorIndexReturnUnit").alias("max_VendorIndexReturnUnit"),
    max("RunReason").alias("max_RunReason"),
    max("Guid").alias("max_Guid"),
    max("AdditionalParam").alias("max_AdditionalParam")
).collect()[0]

# Extract each value into its own variable
# we need these later to fill in our dataframe of "stage" data
max_VendorIndexReturnUnit   = agg_result["max_VendorIndexReturnUnit"]
max_RunReason = agg_result["max_RunReason"]
max_Guid  = agg_result["max_Guid"]
max_AdditionalParam  = agg_result["max_AdditionalParam"]


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def computeBenchmarks(
    df_stage: DataFrame,
    df_recipe: DataFrame
) -> list[DataFrame]:

    # get historic data
    df_wh = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/IndexReturn")

    # filter down to just the currency we are working with
    df_wh = df_wh.filter(col("CurrencyId") == currency_id)
    df_wh = df_wh.withColumn("Source", lit("Historical"))

    # ============================================================================================================
    # merge data from last iteration into df_wh... data from last iteration is needed for this iteration
    # note that this data is all the same Frequency (Daily) and Currency (USD), so key is just index id and date

    # make df_stage look like df_wh
    df_stage = df_stage.drop("VendorIndexReturnUnit", "RunReason", "Guid", "AdditionalParam")
    df_stage = df_stage.withColumn("ReturnComment", F.lit(None).cast(T.StringType()))\
        .withColumn("ReturnSource", F.lit(None).cast(T.StringType()))\
        .withColumn("ETLLoadDateTime", F.lit(None).cast(T.StringType()))

    key_cols = ["IndexId", "ReturnDate"]

    # remove any target rows whose keys exist in source
    keys_only = df_stage.select(*key_cols).dropDuplicates()
    df_wh = df_wh.join(keys_only, on=key_cols, how="left_anti")

    # append source rows (replaces any removed ones and add new ones)
    df_wh = df_wh.unionByName(df_stage)

    # now get one data point earlier than our staged data
    start_rows = df_wh.alias("ir").join(
        df_cfg_updated.alias("mindate"),
        (col("ir.IndexId") == col("mindate.IndexId")) &
        (col("ir.CurrencyId") == col("mindate.CurrencyId")) &
        (col("ir.FrequencyId") == col("mindate.FrequencyId")) &
        (col("ir.ReturnDate") == col("mindate.ReturnStartDate"))) \
        .select("ir.IndexId", "ir.ReturnDate", "ir.FrequencyId", "ir.CurrencyId", "ir.LevelValue", "ir.ReturnValue")

    start_rows = start_rows.withColumn("RecordSource", lit("Historical"))

    input_returns = df_recipe.alias("r") \
        .join(df_stage.alias("s"), col("r.IndexIdSource") == col("s.IndexId")) \
        .select(
            "r.IndexIdTarget", "s.FrequencyId", "s.ReturnDate", "s.ReturnValue", "r.IndexContributionPct",
        "s.CurrencyId"  )

    input_returns = input_returns.withColumnRenamed("IndexIdTarget", "IndexId")

    # Add WeightedReturn with true Decimal precision
    input_returns = input_returns.withColumn(
        "WeightedReturn",
        (
            col("ReturnValue").cast(dec_type) *
            col("IndexContributionPct").cast(dec_type) /
            lit(Decimal("100.0")).cast(dec_type)
        ).cast(dec_type)
    )

    # Now sum the precomputed Decimal column
    blended_returns = input_returns.groupBy("IndexId", "ReturnDate", "FrequencyId", "CurrencyId") \
        .agg(
            sum("WeightedReturn").cast(dec_type).alias("ReturnValue")
        ) \
        .withColumn("LevelValue", lit(0).cast(dec_type)) \
        .withColumn("RecordSource", lit("Computation(1)"))

    # add in start_rows which gives us a row containing a level from which we can compute a level for the next date
    df_stage = blended_returns.unionByName(start_rows).sort("ReturnDate")

    # for row in df_debug.select("ReturnValue").collect():
    #     print(f"{row['ReturnValue']:.11f}")


    # the computed data gives us returns, now calculate levels

    # Assign RowNum per Index group
    window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("ReturnDate")
    df_stage = df_stage.withColumn("RowNum", row_number().over(window_spec))

    if df_stage.isEmpty():
        # e.g. this can happen during a manual benchmark .xlsx load if it does not impact custom benchmarks
        print("IN computeBenchmarks: df_stage is empty")
        return df_stage;

    # Convert to Pandas for group-based recursion
    pdf = df_stage.toPandas()

    # Apply recursion per group
    for keys, group in pdf.groupby(["IndexId", "CurrencyId", "FrequencyId"]):
        group = group.sort_values("RowNum")
        levels = []
        for i, row in group.iterrows():
            index_return = Decimal(str(row["ReturnValue"]))
            if row["RowNum"] == 1:
                level = Decimal(str(row["LevelValue"]))
            else:
                level = levels[-1] * (Decimal("1") + index_return)
            levels.append(level)
        pdf.loc[group.index, "LevelValue"] = levels

    # Convert back to Spark DataFrame
    df_stage = spark.createDataFrame(pdf)
    
    # print("IN computeBenchmarks, showing MSCI EAFE Inverse 999")
    # #xxx
    # df_debug = (
    #     df_stage
    #     .filter(
    #         (col("IndexId").isin(     "6f731e60-c22e-407b-928b-5880da74e5f8"            )) &
    #         (col("ReturnDate").between(lit("2025-07-05"), lit("2025-07-12"))) 
    #     )
    #     .orderBy(col("ReturnDate").asc())
    # )
    # df_debug.show(15)


    df_stage = df_stage.withColumn("LevelValue", col("LevelValue").cast(dec_type))
    df_stage = df_stage.withColumn("ReturnValue", col("ReturnValue").cast(dec_type))

    print(f"count 1 = {df_stage.count()}")

    # get rid of Historical rows that were needed for computation.  Also get rid of any monthlies and quarterlies
    df_stage = df_stage.filter((col("RecordSource") != "Historical") & (col("FrequencyId") != 2) & (col("FrequencyId") != 3))

    return df_stage

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#xxx consider cleaning up the recipe table
# Remove "Cambridge Associates Real Estate" and "Real Estate Benchmark" from recipe because they are both custom and they 
# both come from the "manual" .xlsx mechanism.  Also, in the current recipe table, one is 100% of the other... redundant.
index_return_recipe = index_return_recipe.filter(~col("SourceIndexId").isin(
                "8fba8740-6e81-49a4-9e0b-11561ae81bc2",
                "7ecd094c-3450-471f-b5eb-c1ea6c4b55b2"))

# look to see if our stage data has anything that relates to blended/computed benchmarks
df_stage_orig.show(10, truncate=False)
df_joined = index_return_recipe.join(
    df_stage_orig,
    (index_return_recipe["IndexIdSource"] == df_stage_orig["IndexId"]),
    how="inner"
)
row_count = df_joined.count()

if row_count > 0:
    dependency_levels = build_index_recipe_dependency_levels(index_return_recipe, index_load_control)

    # Now call computations level by level.  Each call will leave its computations in df_stage to be used by next level.
    for i, df_recipe_level in enumerate(dependency_levels):
        print(f"\n================================================================================== Level {i} ===")

        df_check_for_dups = df_stage_computed.groupBy("IndexId", "FrequencyId", "ReturnDate", "CurrencyId") \
            .count() \
            .filter("count > 1")
        if df_check_for_dups.count() > 0:
            display(df_check_for_dups)
            raise Exception("Problem: found duplicate rows.  Need to investigate: 1")

        df_tmp_computed = computeBenchmarks(df_stage_computed, df_recipe_level)

        df_check_for_dups = df_tmp_computed.groupBy("IndexId", "FrequencyId", "ReturnDate", "CurrencyId") \
            .count() \
            .filter("count > 1")
        if df_check_for_dups.count() > 0:
            display(df_check_for_dups)
            raise Exception("Problem: found duplicate rows.  Need to investigate: 2")

        # clean up columns
        df_tmp_computed = df_tmp_computed.select("IndexId", "FrequencyId", "ReturnDate", "LevelValue", "ReturnValue",
        lit(max_VendorIndexReturnUnit).alias("VendorIndexReturnUnit") ,
        lit(max_RunReason).alias("RunReason") ,
        lit(max_Guid).alias("Guid") ,
        lit(max_AdditionalParam).alias("AdditionalParam") ,
        "CurrencyId",
        lit("Fabric Computed").alias("Source") )

        df_stage_computed = df_stage_computed.union(df_tmp_computed)

        df_check_for_dups = df_stage_computed.groupBy("IndexId", "FrequencyId", "ReturnDate", "CurrencyId") \
            .count() \
            .filter("count > 1")
        if df_check_for_dups.count() > 0:
            display(df_check_for_dups)
            raise Exception("Problem: found duplicate rows.  Need to investigate: 3")

        # print("showing ===========================  df_stage 5555")
        # #xxx
        # df_debug = (
        #     df_tmp_computed
        #     .filter(
        #         (col("IndexId").isin(
        #             #"d6677877-4001-4269-94a4-17e2904e02f6",
        #             #"91bd2f6c-6b28-4460-b8ea-11aae5546d71",
        #             "f1a5484c-87f3-4ab9-8127-04b7a772c51c"
        #         )) &
        #         (col("CurrencyId") == currency_id) &
        #         (col("ReturnDate").between(lit("2025-07-04"), lit("2025-07-12")))  # inclusive
        #     )
        #     .orderBy(col("ReturnDate").asc())
        # )
        # df_debug.show(25)
        # df_debug = (
        #     df_stage_computed
        #     .filter(
        #         (col("IndexId").isin(
        #             #"d6677877-4001-4269-94a4-17e2904e02f6",
        #             #"91bd2f6c-6b28-4460-b8ea-11aae5546d71",
        #             "f1a5484c-87f3-4ab9-8127-04b7a772c51c"
        #         )) &
        #         (col("CurrencyId") == currency_id) &
        #         (col("ReturnDate").between(lit("2025-07-04"), lit("2025-07-12")))  # inclusive
        #     )
        #     .orderBy(col("ReturnDate").asc())
        # )
        # df_debug.show(11)

    currentTs = current_timestamp()

    # clean up columns
    df_stage_computed = df_stage_computed.select("IndexId", "FrequencyId", "ReturnDate", "LevelValue", "ReturnValue",
    lit(max_VendorIndexReturnUnit).alias("VendorIndexReturnUnit") ,
    lit(max_RunReason).alias("RunReason") ,
    lit(max_Guid).alias("Guid") ,
    lit(max_AdditionalParam).alias("AdditionalParam") ,
    "CurrencyId",
    lit("Fabric Computed").alias("Source") 
    )

    #get more columns added to match ReturnValue with which we will need to merge
    #df_stage = df_stage.withColumn("ReturnComment", lit(None).cast("string")) \

    # df_stage_computed.orderBy(col("ReturnDate").desc()).show(5)
    # df_stage_orig.orderBy(col("ReturnDate").desc()).show(6)

    df_check_for_dups = df_stage_computed.groupBy("IndexId", "FrequencyId", "ReturnDate", "CurrencyId") \
        .count() \
        .filter("count > 1")
    if df_check_for_dups.count() > 0:
        display(df_check_for_dups)
        raise Exception("Problem: found duplicate rows.  Need to investigate: 4")

    # print(f"9999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999")
    # #xxx
    # df_debug = (
    #     df_stage_computed
    #     .filter(
    #         (col("IndexId").isin( 
    #             #  "d6677877-4001-4269-94a4-17e2904e02f6",
    #                "f1a5484c-87f3-4ab9-8127-04b7a772c51c" )) &
    #         (col("CurrencyId") == currency_id)

    #     )
    #     .orderBy(col("ReturnDate").asc())
    # )
    # df_debug.show(23)


    print(f"df_stage count before = {df_stage_computed.count()}")
    print(f"df_stage_orig count before = {df_stage_orig.count()}")

    df_stage_orig = df_stage_orig.union(df_stage_computed)
    print(f"df_stage count after = {df_stage_orig.count()}")

    df_stage_orig = df_stage_orig.dropDuplicates()
    print(f"df_stage count after drop dups = {df_stage_orig.count()}")


    print(f"df_stage count before drop dups = {df_stage_orig.count()}")
    df_stage_orig = df_stage_orig.dropDuplicates()
    print(f"df_stage count after drop dups = {df_stage_orig.count()}")

    df_check_for_dups = df_stage_orig.groupBy("IndexId", "FrequencyId", "ReturnDate", "CurrencyId") \
        .count() \
        .filter("count > 1")
    if df_check_for_dups.count() > 0:
        display(df_check_for_dups)
        raise Exception("Problem: found duplicate rows.  Need to investigate: 5")

#save out the calcualted data
df_stage_orig.write.mode("overwrite").parquet( f"{curated_lh_id}/Files/BloombergIndexReturnCustom")

print("Done.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
