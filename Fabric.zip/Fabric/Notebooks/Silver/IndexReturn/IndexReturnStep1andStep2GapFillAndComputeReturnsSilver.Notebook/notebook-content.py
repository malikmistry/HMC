# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "920a12cc-7104-4013-a2a3-d7baa57e9e3f",
# META       "default_lakehouse_name": "lh_raw",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "920a12cc-7104-4013-a2a3-d7baa57e9e3f"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************


# There are 4 notebooks for index return processing.  A prerequisite is that the raw index return data is normalized and
# saved to f"{curated_lh_id}/Files/IndexReturnNormalized".  Sources of raw data are Bloomberg and the HMC Manual .xlsx file.
# MDF Orchestration pipelines handle getting the data to the IndexReturnNormalized file.  Then, a job is called that calls
# this Notebook.

# This notebook reads the normalized data and processes it to fill gaps. E.g. the BB data does not have values for weekends 
# or holidays, but, the HMC Index Return SLA states that we will have continuous data points.  So, we roll forward a Friday 
# value into Saturday.  This first notebook does that work.
#
# The second through fourth notebooks contain a more detailed description of their work, but, a quick description is: 
# second: compute returns from levels and levels from returns, third: compute HMC custom blends and fourth: promote 
# frequencies such as Dailies to Monthlies
#
# Note that the last step in this notebook is to write out a dataframe as a parquet file:
# {curated_lh_id}/Files/BloombergIndexReturnGapsFilled.  The next notebook read that file.

# standard parameters passed in via MDF, default values are for development
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import SparkSession
from pyspark.sql.window import Window
import pandas as pd
from datetime import datetime, date
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType, DoubleType, DecimalType, ArrayType

from pyspark.sql.functions import col, lit, to_date, trim, when, upper, lead, datediff, expr, when, pandas_udf, explode, struct, current_timestamp, concat, last_day, row_number, current_date
from pyspark.sql.functions import max as spark_max, min as spark_min

dec_type = DecimalType(38, 11)

spark = SparkSession.builder.getOrCreate()
spark.conf.set("spark.sql.decimalOperations.allowPrecisionLoss", "false")


df_stage = spark.read.parquet(f"{curated_lh_id}/Files/IndexReturnNormalized")
df_stage.show(8)

# hardcode Daily: we only fill gaps for 8/Daily
# filter for 8/Daily and only fill gaps for 8.  But, need to carry along any other frequencies

# this will cause grouping by the three columns and then ordered by the ReturnDate
window_spec = Window.partitionBy("IndexId", "FrequencyId", "CurrencyId").orderBy("ReturnDate")

# get value from "next" row knowing that we have sorted by ReturnDate 
df_date_list = (
    df_stage
    .filter(
        (col("FrequencyId") == 8)
    )
    .withColumn("ReturnDateNext", lead("ReturnDate", 1).over(window_spec))
    .selectExpr(
        "IndexId", "CurrencyId", "FrequencyId", "ReturnDate", 
        "ReturnDateNext"
    )
)

print("showing date_list")
df_date_list.orderBy(col("ReturnDate").desc()).show(10)

#xxx
# Identify Gaps
# df_gap = df_date_list.filter(
#     datediff("ReturnDateNext", "ReturnDate") > 1
# ).withColumn("DaysDiff", datediff("ReturnDateNext", "ReturnDate")) \
#  .withColumn("EventComment", lit(None).cast("string")) \
#  .withColumn("ErrorType", lit("GAP"))


# print("showing df_gap")
# df_gap.show(13)


# Step 1: Define the window
window_spec = Window.partitionBy("IndexId", "FrequencyId", "CurrencyId").orderBy("ReturnDate")

# Step 2: Filter and prepare df_stage, we only fill gaps for 8/Daily
df_filtered = df_stage.filter(col("FrequencyId") == 8)

# Step 3: Add ReturnDateNext (lead) and a flag for the last row in each group
df_date_list = df_filtered.withColumn("ReturnDateNext", lead("ReturnDate", 1).over(window_spec))

# Step 4: Fill in current date as ReturnDateNext where it's the last row (null lead)
df_date_list = df_date_list.withColumn(
    "ReturnDateNext",
    when(col("ReturnDateNext").isNull(), current_date()).otherwise(col("ReturnDateNext"))
)

# Step 5: Select only what you need
df_date_list = df_date_list.select(
    "IndexId", "CurrencyId", "FrequencyId", "ReturnDate", "ReturnDateNext"
)

# Step 6: Identify Gaps
df_gap = df_date_list.filter(
    datediff("ReturnDateNext", "ReturnDate") > 1
).withColumn("DaysDiff", datediff("ReturnDateNext", "ReturnDate")) \
 .withColumn("EventComment", lit(None).cast("string")) \
 .withColumn("ErrorType", lit("GAP"))

# Optional: Show the result
df_gap.orderBy("IndexId", "CurrencyId", "ReturnDate")


# Explode gaps into missing dates (excluding endpoints)
def date_range(start, end):
    return [str(d) for d in pd.date_range(start=start, end=end, freq='D')][1:-1]  # exclude start and end

@pandas_udf(ArrayType(StringType()))
def generate_dates(start_series: pd.Series, end_series: pd.Series) -> pd.Series:
    return start_series.combine(end_series, date_range)

gaps_with_dates = df_gap \
    .withColumn("MissingDates", generate_dates(col("ReturnDate"), col("ReturnDateNext"))) \
    .withColumn("MissingDate", explode(col("MissingDates")))

gaps = gaps_with_dates.alias("gaps")
stage = df_stage.alias("stage")

plug_rows = gaps \
    .join(stage, 
        (gaps_with_dates.IndexId == stage.IndexId) &
        (gaps_with_dates.CurrencyId == stage.CurrencyId) &
        (gaps_with_dates.FrequencyId == stage.FrequencyId) &
        (gaps_with_dates.ReturnDate == stage.ReturnDate),
        how='left'
    ) \
    .select(
        col("gaps.IndexId"),
        col("gaps.FrequencyId"),
        col("MissingDate").cast("date").alias("ReturnDate"),
        col("LevelValue"),
        lit(0).alias("ReturnValue"),
        col("VendorIndexReturnUnit"),
        col("RunReason"),
        col("Guid"),
        col("AdditionalParam"),
        col("gaps.CurrencyId")
    )
#stage.show(10)
#plug_rows.show(12)
df_union = stage.union(plug_rows).orderBy("IndexId", "CurrencyId", "FrequencyId", "ReturnDate")
#df_union.show(14)

count_data = df_union.count()
print(f"Number of rows = : {count_data}")

df_stage = df_union

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": false,
# META   "editable": true
# META }

# CELL ********************

# For 2/Monthlies, some values can have dates that are not month end.  For example, HEDGNAV Index has a 5/30/2025 value, but, month end was 5/31/2025
# HMC specification is to move these to month end dates

df_stage = df_stage.withColumn(
    "ReturnDate",
    when(col("FrequencyId") == 2, last_day(col("ReturnDate")))
    .otherwise(col("ReturnDate"))  # keep original value otherwise
)

count_data = df_stage.count()
print(f"Number of rows = : {count_data}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#df_debug = df_stage.filter((col("IndexId") == "65c2359b-a371-4d10-8715-08ddfc66a532") & (col("CurrencyId") == 3) & (col("FrequencyId") == 8)).orderBy(col("ReturnDate").asc())
#df_debug.show(7)

#raise SystemExit("xxx")


df_stage.show(100)

#xxx
# final step: write out to file that next notebook will read
# df_stage.write.mode("overwrite").parquet( f"{curated_lh_id}/Files/BloombergIndexReturnGapsFilled")
# print(f"Done")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This is the second step in processing index returns: compute returns from levels and levels from returns.  Some indices are quoted as a 
# level for a given day (e.g. 5,232) while others are quoted as a return (e.g. 0.3%).  HMC normalizes this by computing a return for indices 
# that are quoted as level and vice versa.  Note that as of 10/28/2025, all indices retrieved from Bloomberg are quoted as a level.  HMC’s 
# benchmarks that are quoted as returns are the “manual” benchmarks such as “CA Emerging Market”.
#
# This notebook picks up with the processing by reading the parquet file written by step 1: {curated_lh_id}/Files/BloombergIndexReturnGapsFilled
# This notebook then writes out its dataframe as another file: {curated_lh_id}/Files/BloombergIndexReturnCalculated




# build a dataframe for staging the data from the raw data and flag data appropriately
# read tmp file created by the gap fill notebook

#xxx df_stage = spark.read.parquet(f"{curated_lh_id}/Files/BloombergIndexReturnGapsFilled")

df_stage.orderBy(col("ReturnDate")).show(11)

df_stage = df_stage.withColumn("Source", lit("Fabric Computed"))

df_stage = df_stage.withColumn("LevelValue", col("LevelValue").cast(dec_type))
df_stage = df_stage.withColumn("ReturnValue", col("ReturnValue").cast(dec_type))

# read historical data that will be needed for computations
# need to know which rows were brought in as the "prior date" data point needed for computation. designate as "Historical"
# note that these Historical rows will not get to our index returns table (they are already there)
df_wh = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/IndexReturn")
df_wh = df_wh.withColumn("Source", lit("Historical"))
#df_wh.show(10)

print("in first cell")
df_stage.orderBy(col("ReturnDate")).show(11)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def seedStartRows(df_stage):

    # The HMC index SLA states that we need to have both a level and a return for each date
    # Consider a level based index. In order to compute a "return" for a new level data point, we need the value for the prior level

    # start by identifing the earliest date for each grouping in our new/raw data
    min_dates = df_stage\
        .groupBy("IndexId", "CurrencyId", "FrequencyId") \
        .agg(spark_min("ReturnDate").alias("ReturnDate"))

    # now query the historic data for the max date that is prior to the above min dates
    start_rows = df_wh.alias("ir").join(
        min_dates.alias("mindate"),
        (col("ir.IndexId") == col("mindate.IndexId")) &
        (col("ir.CurrencyId") == col("mindate.CurrencyId")) &
        (col("ir.FrequencyId") == col("mindate.FrequencyId")) &
        (col("ir.ReturnDate") < col("mindate.ReturnDate"))
    ).groupBy("ir.IndexId", "ir.CurrencyId", "ir.FrequencyId") \
    .agg(spark_max("ir.ReturnDate").alias("ReturnDate"))

    #leverage the staged data to create an index "metadata" dataframe
    df_index_metadata = df_stage.dropDuplicates(["IndexId", "CurrencyId", "FrequencyId"]).alias("stg")

    # Join in order to get the historic data with desired columns
    wh = df_wh.alias("wh")
    sr = start_rows.alias("sr")
    metadata = df_index_metadata.alias("md")

    # wh.show(6)
    # sr.show(7)
    # metadata.show(8)

    start_data = wh.join(
        sr,
        on=["IndexId", "CurrencyId", "FrequencyId", "ReturnDate"],
        how="inner"
    ).join(
        metadata,
        on=["IndexId", "CurrencyId", "FrequencyId"],
        how="inner"
    ).select(
        col("wh.IndexId"),
        col("wh.FrequencyId"),
        col("wh.ReturnDate"),
        col("wh.LevelValue"),
        col("wh.ReturnValue"),
        col("md.VendorIndexReturnUnit"),  # need to get this from stage
        col("md.RunReason"),
        col("md.Guid"),
        col("md.AdditionalParam"),
        col("wh.CurrencyId"),
        col("wh.Source")
    )

    # flag this data as Historical/not valid because we do not want to move it to move to next medallion
    start_data = start_data.withColumn("Source", lit("Historical"))
    start_data.show(30)

    # Union the stage data with the historic data
    df_stage = df_stage.unionByName(start_data)

    return df_stage

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def seedNewIndexLoad(df_stage, minReturnDate):

    #df_stage.show(5)

    #xxx
    # df_stage = df_stage.withColumnRenamed("ReturnDate", "ReturnDate")\
    # .withColumnRenamed("LevelValue", "LevelValue")\
    # .withColumnRenamed("IndexReturn", "ReturnValue")

    #xxx probably need to duplicate the first row and set its date back one day

    # rows to duplicate
    subset = df_stage.filter(F.col("ReturnDate") == minReturnDate)

    # duplicated rows with ReturnDate - 1 day
    subset = subset.withColumn("ReturnDate", F.date_sub(F.col("ReturnDate"), 1))

    df_stage = df_stage.unionByName(subset)

    #df_stage.show(6)

    return df_stage

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# determine why we are running: get values from the stage data
agg_result = df_stage.agg(
    spark_max("VendorIndexReturnUnit").alias("max_VendorIndexReturnUnit"),
    spark_max("RunReason").alias("max_RunReason"),
    spark_max("Guid").alias("max_Guid"),
    spark_max("AdditionalParam").alias("max_AdditionalParam"),
    spark_min("ReturnDate").alias("min_ReturnDate"),
    
).collect()[0]

# Extract each value into its own variable
max_VendorIndexReturnUnit   = agg_result["max_VendorIndexReturnUnit"]
max_RunReason = agg_result["max_RunReason"]
max_Guid  = agg_result["max_Guid"]
max_AdditionalParam  = agg_result["max_AdditionalParam"]
min_ReturnDate  = agg_result["min_ReturnDate"]

print(f"max_VendorIndexReturnUnit = {max_VendorIndexReturnUnit}")
print(f"max_RunReason = {max_RunReason}")
print(f"max_Guid = {max_Guid}")
print(f"max_AdditionalParam = {max_AdditionalParam}")
print(f"min_ReturnDate = {min_ReturnDate}")

if (max_RunReason == "NIGHTLY_INDEX_LOAD_ALL" or max_RunReason == "Manual"):
    print("hello =================== 9")
    df_stage.show(12)
    df_stage = seedStartRows(df_stage)
elif (max_RunReason == "NEW_INDEX_LOAD"):
    df_stage = seedNewIndexLoad(df_stage, min_ReturnDate)
else:
    raise SystemExit(f"unsupported run Reason: {max_RunReason}")

# separate out return based data into a separate dataframe
df_stage_return_based = df_stage.filter(col("VendorIndexReturnUnit") == "RETURN")

# keep level based data in df_stage
df_stage = df_stage.filter(col("VendorIndexReturnUnit") == "LEVEL")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Add Row Numbers and Calculate LEVEL-Based Returns
window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("ReturnDate")
df_stage = df_stage.withColumn("RowNum", row_number().over(window_spec))

# Join with previous row to compute LEVEL-based returns
df_prev = df_stage.withColumnRenamed("RowNum", "RowNumPrev") \
                  .withColumnRenamed("LevelValue", "LevelValuePrev")

# was getting 7 decimals of precision... we need 11
# solution included setting allowPrecisionLoss
curr_level = col("curr.LevelValue").cast(dec_type)
prev_level = col("prev.LevelValuePrev").cast(dec_type)

# print("================================================")
df_stage.orderBy(col("ReturnDate")).show(9)
df_prev.orderBy(col("ReturnDate")).show(11)


df_joined = df_stage.alias("curr").join(
    df_prev.alias("prev"),
    (col("curr.IndexId") == col("prev.IndexId")) &
    (col("curr.CurrencyId") == col("prev.CurrencyId")) &
    (col("curr.FrequencyId") == col("prev.FrequencyId")) &
    (col("curr.RowNum") == col("prev.RowNumPrev") + 1)
).withColumn(
    "CalcReturnValue",
    when(prev_level == 0, lit(0.0).cast(dec_type))
    .otherwise(
        ((curr_level - prev_level) / prev_level).cast(dec_type)
    )
)

#df_joined.select("CalcReturnValue").show(truncate=False)

# for row in df_joined.select("CalcReturnValue").collect():
#     print(f"{row['CalcReturnValue']:.11f}")

# get back to desired set of columns
df_stage = df_joined.select("curr.IndexId", "curr.FrequencyId", "curr.ReturnDate", "curr.LevelValue", col("CalcReturnValue").alias("ReturnValue"), 
  "curr.VendorIndexReturnUnit","curr.RunReason","curr.Guid","curr.AdditionalParam","curr.CurrencyId","curr.Source")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# for RETURN based index returns, calculate levels

if df_stage_return_based.count() > 0:
    print( f"return based count = {df_stage_return_based.count()}")

#for raw BB sourced data, all numeric values are in column LevelValue
#but, for a return based index, we need to put that data in the ReturnValue column and then compute the level

# for Historical data point, need to presere the level
df_stage_return_based  = df_stage_return_based.withColumn(
    "LevelValueNEW",
    when(
        (col("Source") == "Historical"), col("LevelValue")
    ).otherwise(None))

# Assign RowNum per Index group
window_spec = Window.partitionBy("IndexId", "CurrencyId", "FrequencyId").orderBy("ReturnDate")
df_stage_return_based = df_stage_return_based.withColumn("RowNum", row_number().over(window_spec))

df_stage_return_based = df_stage_return_based .withColumn("ReturnValue", (F.col("ReturnValue") / F.lit(100.0).cast(dec_type)).cast(dec_type))

# Ensure precise types
df = (df_stage_return_based
      .withColumn("IndexReturn", F.col("ReturnValue").cast(dec_type))
      .withColumn("LevelValue", F.col("LevelValue").cast(dec_type)))

# Order window per index/currency/frequency
w = Window.partitionBy("IndexId","CurrencyId","FrequencyId").orderBy("ReturnDate").rowsBetween(Window.unboundedPreceding, Window.currentRow)

# Mark resets where Source == 'Historical'
df = df.withColumn("is_hist", F.when(F.col("Source")=="Historical", F.lit(1)).otherwise(F.lit(0)))

# Build segment ids that reset at each Historical row
seg = Window.partitionBy("IndexId","CurrencyId","FrequencyId").orderBy("ReturnDate")
df = df.withColumn("segment_id", F.sum("is_hist").over(seg))

# For each segment, get the starting level (first LevelValue in that segment)
seg_w = Window.partitionBy("IndexId","CurrencyId","FrequencyId","segment_id").orderBy("ReturnDate") \
              .rowsBetween(Window.unboundedPreceding, Window.currentRow)

start_level = F.first(F.when(F.col("Source")=="Historical", F.col("LevelValue")), ignorenulls=True).over(seg_w)

# Cumulative product of (1 + return) within the segment using log-sum-exp trick
# Use Decimal -> cast to double for log/exp, then back to Decimal
log_incr = F.when(F.col("Source")!="Historical", F.log1p(F.col("IndexReturn").cast("double"))).otherwise(F.lit(0.0))
cumulative_log = F.sum(log_incr).over(seg_w)
cumulative_factor = F.exp(cumulative_log)  # double

df = df.withColumn("IndexLevelNEW", (start_level.cast("double") * cumulative_factor).cast(dec_type))

# keep just Raw data (gets rid of "Historical")
df_stage_return_based = df.filter(col("Source") != "Historical")

# clean up columns
df_stage_return_based = df_stage_return_based.select("IndexId", "FrequencyId", "ReturnDate", 
col("IndexLevelNEW").alias("LevelValue"), "ReturnValue", "VendorIndexReturnUnit", "RunReason","Guid","AdditionalParam","CurrencyId","Source")


if df_stage_return_based.isEmpty():
    print("no return based returns")
else:
    # combine the return based data with the level based data (already in df_stage)
    df_stage = df_stage.union(df_stage_return_based)

df_stage.show(9)

#raise SystemExit("xxx")

#save out the calcualted data
df_stage.write.mode("overwrite").parquet( f"{curated_lh_id}/Files/BloombergIndexReturnCalculated")

print("Done")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
