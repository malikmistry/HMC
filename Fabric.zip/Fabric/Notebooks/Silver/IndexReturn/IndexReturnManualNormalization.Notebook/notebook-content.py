# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "920a12cc-7104-4013-a2a3-d7baa57e9e3f",
# META       "default_lakehouse_name": "lh_raw",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "920a12cc-7104-4013-a2a3-d7baa57e9e3f"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

# standard parameters passed in via MDF, default values are for development
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
print(bronze_lh_id)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)
print(curated_lh_id)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col, lit, when, upper

# The MDF got the *.txt files all the way to bronze, so this notebook picks up by reading the Bronze delta table
df_stage = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/ManualBenchmarkLoad")
df_stage.show(13, truncate=False)

# filter out NULl rows that come from the MDF FileTask
df_stage = df_stage.filter(F.col("SecurityName").isNotNull())

dfIndexXref = spark.read.format("delta").load(f"{curated_lh_id}/Tables/Silver/Index").select("IndexId", "DisplayName", upper(col("Ticker")).alias("Ticker"), "Frequency", "IsLevelBased", "CurrencyId")
dfIndexXref.show(9)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dfWithHmcId = df_stage.join(dfIndexXref, df_stage["SecurityId"] == dfIndexXref["IndexId"], how="left")
dfUnmatched = dfWithHmcId.filter(col("IndexId").isNull())

display(dfWithHmcId)

#todo: how to handle this error... when raw vendor data does not resolve to an HMC index?
#todo: use purvue to capture this error
#todo: maybe log issue, purge from the staged data and then continue
#note: this will happen when the BB files includes the C2R securities
if dfUnmatched.count() > 0:
    dfUnmatched.show(10)
    dfUniqueTickers = dfUnmatched.select(col("SecurityId")).distinct()
    dfUniqueTickers.show(100)
    raise Exception(f"join failed, unmatched count = {dfUnmatched.count()}")

dfWithHmcId = dfWithHmcId.select(
    col("IndexId"),
    col("Frequency").alias("FrequencyId"),
    col("DataDate").alias("ReturnDate"),
    col("IndexLevel").alias("LevelValue"),
    col("IndexReturn").alias("ReturnValue"),
    when(col("IsLevelBased") == True, "LEVEL").otherwise("RETURN").alias("VendorIndexReturnUnit"),
    lit("Manual").alias("RunReason"),
    lit(None).alias("Guid").cast("string"),
    lit(None).alias("AdditionalParam").cast("string"),
    col("CurrencyId"),
)

df_stage = dfWithHmcId
df_stage.show(25)

df_debug = df_stage.filter(col("FrequencyId").isNull())
if df_debug.count() > 0:
    df_debug.show(19)
    raise Exception("Problem: missing Frequency")

df_stage.write.mode("overwrite").parquet( f"{curated_lh_id}/Files/IndexReturnNormalized")

print(f"Done")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
