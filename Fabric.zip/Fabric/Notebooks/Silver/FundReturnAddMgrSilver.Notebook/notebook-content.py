# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""
NotebookName = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
# WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
# BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
# CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
# TaskList = "{\"JobAuditKey\":537,\"TaskKey\":116,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"CrimsonXFundReturn\",\"SinkTableName\":\"FundReturn\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"14\",\"NotebookName\":\"FundReturnAddMgrSilver\",\"SinkLakehouseName\":\"lh_curated\"}"
# NotebookName = "FundSilver"
# LakehouseName = "lh_curated"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#we will attach the sinklakehouse to the notebook
if LakehouseName == 'lh_bronze':
    LakehouseId = BronzeLHId
elif LakehouseName == 'lh_curated':
    LakehouseId = CuratedLHId

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tasklist = json.loads(f"{TaskList}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def is_df_empty(df, column_name=None, excluded_value=None):
    if column_name is not None and excluded_value is not None:
        df = df.filter(col(column_name) != excluded_value)
    return df.limit(1).count() == 0

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# 
# **Process Fund Trade Silver Table**

# CELL ********************

def process_task(task,bronze_lh_id,curated_lh_id):
    try:
        source_path = f"{bronze_lh_id}/Tables/{task['SourceSchemaName']}/{task['SourceTableName']}"
        target_path = f"{curated_lh_id}/Tables/{task['SinkSchemaName']}/{task['SinkTableName']}"
        datetime_col = 'Date_Time'
        print(source_path)
        print(target_path)
        #abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXFund

        #Read table path
        # bronzeclassificationmap_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXClassificationMap"
        # bronzetagmaster_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXTagMaster"
        # bronzetag_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXTag"
        # silvercashflowtrandetail_path = f"{curated_lh_id}/Tables/Silver/CashflowTransactionDetail"
        # bronzefundreturn_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXFundReturn"
        # bronzefundvaluation_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXFundValuation"





        today_date = date.today()
        today_str = date.today().strftime('%Y-%m-%d')
        #yesterday_str = (today_str - timedelta(days=1)).strftime('%Y-%m-%d')
        # Set watermark
        etlloadtime = datetime.now(timezone.utc)

        # TRY Read source
        try:
            df_source = spark.read.format("delta").load(source_path)
            df_source.createOrReplaceTempView("src")

            # df_bronzeclassificationmap = spark.read.format("delta").load(bronzeclassificationmap_path)
            # df_bronzeclassificationmap.createOrReplaceTempView("CrimsonXClassificationMap")
            # df_bronzetagmaster = spark.read.format("delta").load(bronzetagmaster_path)
            # df_bronzetagmaster.createOrReplaceTempView("CrimsonXTagMaster")
            # df_bronzetag = spark.read.format("delta").load(bronzetag_path)
            # df_bronzetag.createOrReplaceTempView("CrimsonXTag")

            # df_silvercashflowtrandetail = spark.read.format("delta").load(silvercashflowtrandetail_path)
            # df_silvercashflowtrandetail.createOrReplaceTempView("CashflowTransactionDetail")
            # df_bronzefundreturn = spark.read.format("delta").load(bronzefundreturn_path)
            # df_bronzefundreturn.createOrReplaceTempView("CrimsonXFundReturn")
            # df_bronzefundvaluation = spark.read.format("delta").load(bronzefundvaluation_path)
            # df_bronzefundvaluation.createOrReplaceTempView("CrimsonXFundValuation")
            # Spark SQL
            query = f"""

                MERGE INTO lh_curated.Silver.FundReturn AS tgt
                USING (
                    SELECT 
                        FundId
                        ,ReturnTypeId
                        ,ReturnSourceId
                        ,FrequencyId
                        ,NULL as CalculationMethodologyId
                        ,ReturnDate as EndDate
                        ,ReturnValue
                        ,NULL as ReturnError
                        ,NULL as ReturnDetailsKey
                        ,UpdateTimestamp as AsOfDate
                    FROM src
                    WHERE ReturnSourceId IN (2,4)
                ) AS src
                ON tgt.FundId = src.FundId AND tgt.ReturnTypeId = src.ReturnTypeId AND tgt.ReturnSourceId = src.ReturnSourceId AND tgt.FrequencyId = src.FrequencyId AND tgt.EndDate = src.EndDate
                WHEN MATCHED THEN
                UPDATE SET
                    tgt.ReturnTypeId = src.ReturnTypeId
                    ,tgt.ReturnSourceId = src.ReturnSourceId
                    ,tgt.FrequencyId = src.FrequencyId
                    ,tgt.CalculationMethodologyId = src.CalculationMethodologyId
                    ,tgt.EndDate = src.EndDate
                    ,tgt.ReturnValue = src.ReturnValue
                    ,tgt.ReturnError = src.ReturnError
                    ,tgt.ReturnDetailsKey = src.ReturnDetailsKey
                    ,tgt.AsOfDate = src.AsOfDate
                    ,tgt.ETLLoadDateTime = '{etlloadtime}'

                WHEN NOT MATCHED THEN
                INSERT (FundId, ReturnTypeId, ReturnSourceId, FrequencyId, CalculationMethodologyId, EndDate, ReturnValue, ReturnError, ReturnDetailsKey, AsOfDate, ETLLoadDateTime)
                VALUES (src.FundId, src.ReturnTypeId, src.ReturnSourceId, src.FrequencyId, src.CalculationMethodologyId, src.EndDate, src.ReturnValue, src.ReturnError, src.ReturnDetailsKey, src.AsOfDate, '{etlloadtime}')

            """
            result_df = spark.sql(query)
            #result_df.show(5)
        except Exception as e:
            raise RuntimeError(f"Source path does not exist or failed to load: {source_path}") from e
        # Write the result as a Delta table
        #result_df.write.format("delta").mode("overwrite").save(target_path)
        #df_today.write.format("delta").mode("overwrite").save(target_path)
        print('Completed')
    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise RuntimeError(f"Failed") from e

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)


        # Process the task
        result = process_task(task_item,bronze_lh_basepath,curated_lh_basepath)

    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise
#abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXFundTrade

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

source_path = "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXFundReturn"

df_source = spark.read.format("delta").load(source_path)
df_source.createOrReplaceTempView("src")

target_path = "abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/e9fc4e80-ff69-4d45-bbdd-892592889465/Tables/Silver/FundReturn"

# df_bronzeclassificationmap = spark.read.format("delta").load(bronzeclassificationmap_path)
# df_bronzeclassificationmap.createOrReplaceTempView("CrimsonXClassificationMap")
# df_bronzetagmaster = spark.read.format("delta").load(bronzetagmaster_path)
# df_bronzetagmaster.createOrReplaceTempView("CrimsonXTagMaster")
# df_bronzetag = spark.read.format("delta").load(bronzetag_path)
# df_bronzetag.createOrReplaceTempView("CrimsonXTag")

# df_silvercashflowtrandetail = spark.read.format("delta").load(silvercashflowtrandetail_path)
# df_silvercashflowtrandetail.createOrReplaceTempView("CashflowTransactionDetail")
# df_bronzefundreturn = spark.read.format("delta").load(bronzefundreturn_path)
# df_bronzefundreturn.createOrReplaceTempView("CrimsonXFundReturn")
# df_bronzefundvaluation = spark.read.format("delta").load(bronzefundvaluation_path)
# df_bronzefundvaluation.createOrReplaceTempView("CrimsonXFundValuation")
# Spark SQL
query = f"""

               MERGE INTO lh_curated.Silver.FundReturn AS tgt
                USING (
                    SELECT 
                        FundId
                        ,ReturnTypeId
                        ,ReturnSourceId
                        ,FrequencyId
                        ,NULL as CalculationMethodologyId
                        ,ReturnDate as EndDate
                        ,ReturnValue
                        ,NULL as ReturnError
                        ,NULL as ReturnDetailsKey
                        ,CAST(UpdateTimestamp AS DATE) as AsOfDate
                    FROM src
                    WHERE ReturnSourceId IN (2,4)
                ) AS src
                ON tgt.FundId = src.FundId
                WHEN MATCHED THEN
                UPDATE SET
                    tgt.ReturnTypeId = src.ReturnTypeId
                    ,tgt.ReturnSourceId = src.ReturnSourceId
                    ,tgt.FrequencyId = src.FrequencyId
                    ,tgt.CalculationMethodologyId = src.CalculationMethodologyId
                    ,tgt.EndDate = src.EndDate
                    ,tgt.ReturnValue = src.ReturnValue
                    ,tgt.ReturnError = src.ReturnError
                    ,tgt.ReturnDetailsKey = src.ReturnDetailsKey
                    ,tgt.AsOfDate = src.AsOfDate

                WHEN NOT MATCHED THEN
                INSERT (FundId, ReturnTypeId, ReturnSourceId, FrequencyId, CalculationMethodologyId, EndDate, ReturnValue, ReturnError, ReturnDetailsKey, AsOfDate)
                VALUES (src.FundId, src.ReturnTypeId, src.ReturnSourceId, src.FrequencyId, src.CalculationMethodologyId, src.EndDate, src.ReturnValue, src.ReturnError, src.ReturnDetailsKey, src.AsOfDate)

"""
spark.sql(query)
#result_df.show(5)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC SELECT count(*) FROM lh_curated.Silver.FundReturn

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
