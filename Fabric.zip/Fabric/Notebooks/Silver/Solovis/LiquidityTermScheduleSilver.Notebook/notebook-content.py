# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
from delta.tables import DeltaTable
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
# WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
# BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
# CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
# TaskList = "{\"JobAuditKey\":2360,\"TaskKey\":88,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"LiquidityTerms\",\"SinkTableName\":\"FundLiquidityTermSchedule\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"7\",\"NotebookName\":\"LiquidityTermScheduleSilver\",\"SinkLakehouseName\":\"lh_curated\",\"RawStoragePath\":null,\"RawStorageFileName\":null,\"RelativeUrl\":null}"
# NotebookName = "LiquidityTermScheduleSilver"
# LakehouseName = "lh_curated"
# RawLHId = "920a12cc-7104-4013-a2a3-d7baa57e9e3f"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ''
BronzeLHId = ''
CuratedLHId = ''
TaskList = ''

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "{\"JobAuditKey\":2360,\"TaskKey\":88,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"LiquidityTerms\",\"SinkTableName\":\"FundLiquidityTermSchedule\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"7\",\"NotebookName\":\"LiquidityTermScheduleSilver\",\"SinkLakehouseName\":\"lh_curated\",\"RawStoragePath\":null,\"RawStorageFileName\":null,\"RelativeUrl\":null}"
NotebookName = "LiquidityTermScheduleSilver"
LakehouseName = "lh_curated"
RawLHId = "920a12cc-7104-4013-a2a3-d7baa57e9e3f"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.FundLiquidityTermSchedule (
# MAGIC     FundId VARCHAR(36) NOT NULL,
# MAGIC     RedemptionDate DATE NOT NULL,
# MAGIC     NoticeDate DATE NOT NULL,
# MAGIC     ContractualRedemptionFrequencyTypeId INT,
# MAGIC     RedemptionAmountLocal DECIMAL(38,2),
# MAGIC     RedemptionAmountUSD DECIMAL(38, 2),
# MAGIC     CurrencyId INT NOT NULL,
# MAGIC     LiquidityOptionId INT NOT NULL,
# MAGIC     ReceiptDate DATE NOT NULL,
# MAGIC     Comment VARCHAR(8000),
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Review.FundLiquidityTermSchedule (
# MAGIC     FundId VARCHAR(36) NOT NULL,
# MAGIC     RedemptionDate DATE NOT NULL,
# MAGIC     NoticeDate DATE NOT NULL,
# MAGIC     ContractualRedemptionFrequencyTypeId INT,
# MAGIC     RedemptionAmountLocal DECIMAL(38,2),
# MAGIC     RedemptionAmountUSD DECIMAL(38, 2),
# MAGIC     CurrencyId INT NOT NULL,
# MAGIC     LiquidityOptionId INT NOT NULL,
# MAGIC     ReceiptDate DATE NOT NULL,
# MAGIC     Comment VARCHAR(8000),
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Build paths
bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Copy data to the review table
#dfReview = spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Silver/FundLiquidityTermSchedule")
# Save this off to be reviewed
spark.sql("""TRUNCATE TABLE lh_curated.Review.FundLiquidityTermSchedule""")

# dfReview.write.format("delta") \
#     .mode("append") \
#     .save(f"{curated_lh_basepath}/Tables/Review/FundLiquidityTermSchedule")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisLiquidityTerms").createOrReplaceTempView("slt")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisLiquidityReceipts").createOrReplaceTempView("slr")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisActiveBookFundMapping").createOrReplaceTempView("abfm")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisInvestments").createOrReplaceTempView("si")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisCurrency").createOrReplaceTempView("scur")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/CrimsonXCurrency").createOrReplaceTempView("c")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisEntities").createOrReplaceTempView("se")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/HMCDataWarehouseLiquidityRedemptionFrequencyType").createOrReplaceTempView("rft")
spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Silver/FXRate").createOrReplaceTempView("fx")
spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Silver/ShareClass").createOrReplaceTempView("sc")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

spark.sql("""
INSERT INTO lh_curated.Review.FundLiquidityTermSchedule
(FundId, CurrencyId, LiquidityOptionId, ContractualRedemptionFrequencyTypeId, NoticeDate,
    RedemptionDate, ReceiptDate, RedemptionAmountLocal, RedemptionAmountUSD, Comment, ETLLoadDateTime)
SELECT abfm.FundId
	   , c.CurrencyId
	   , slt.LiquidityOptionId
	   , rft.LiquidityRedemptionFrequencyTypeId AS ContractualRedemptionFrequencyTypeId
	   , to_date(slt.NextNoticeDate, "M/dd/yyyy") as NoticeDate
	   , to_date(slt.NextRedemptionDate, "M/dd/yyyy") as RedemptionDate
	   , to_date(slr.ReceiptDate, "M/dd/yyyy") as ReceiptDate
	   , SUM(CAST(slr.ReceiptAmount as DECIMAL(38,2))) as RedemptionAmount
       , SUM(CAST(slr.ReceiptAmount as DECIMAL(38,2)) * fx.FXRate) as RedemptionAmountUSD
	   , MAX(slt.Comment) as Comment
       , current_timestamp
FROM slt
	    JOIN si ON slt.InvestmentResourceId = si.ResourceId
		JOIN se ON se.Id = si.HoldingId
		JOIN abfm ON abfm.InvestmentResourceId = slt.InvestmentResourceId
		JOIN sc ON sc.ShareClassId = abfm.ShareClassId
		JOIN slr ON slt.InvestmentResourceId = slr.InvestmentResourceId
																AND slr.NextRedemptionDate = slt.NextRedemptionDate
																AND slr.LiquidityOptionId = slt.LiquidityOptionId
																AND slr.LiquidityTermsId = slt.Id
		JOIN scur ON scur.Id = slt.CurrencyId
		JOIN c ON c.ISOCode = scur.Code
        JOIN lh_curated.Silver.FXRate fx ON fx.CurrencyId = c.CurrencyId
                                        AND fx.IsLatest = 1
		JOIN rft ON CASE WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = '2Y' THEN 'Biennial'
	          WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = 'Rolling 2Y' THEN 'Biennial'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = 'Semi-Annual' THEN 'Semi-Annually'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = 'Semi-Annual' THEN 'Semi-Annually'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = '2 Year Lock' THEN 'Hard Lock'
		      WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = '1 Year Hard Lock' THEN 'Hard Lock'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = 'Redemption' THEN 'Red 1'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = 'Redemption 1' THEN 'Red 1'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = 'Redemption 2' THEN 'Red 1'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = 'Redemption 3' THEN 'Red 1'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = 'Redemption 4' THEN 'Red 1'
		      WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = 'Soft Lock Year 1' THEN 'Soft Lock 1'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = '1 Year Soft Lock' THEN 'Soft Lock 1'
		      WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = 'Final Redemption' THEN 'Red 1'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) LIKE 'Hard Lock%' THEN 'Hard Lock'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = '2 Year Soft Lock' THEN 'Soft Lock'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) LIKE 'Annual %' THEN 'Annually'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = 'Fixed Term' THEN 'Illiquid'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = 'Bi-ennial' THEN 'Biennial'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency)= 'Semi Annual' THEN 'Semi-Annually'
			  WHEN COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) = 'Annual' THEN 'Annually'
			  ELSE COALESCE(se.RedemptionFrequency,slt.RedemptionFrequency) END = rft.Description
where to_date(slr.NextRedemptionDate, "M/dd/yyyy") >= current_date
group by abfm.FundId
	   , c.CurrencyId
	   , slt.LiquidityOptionId
	   , rft.LiquidityRedemptionFrequencyTypeId
	   , slt.NextNoticeDate
	   , slt.NextRedemptionDate
	   , slr.ReceiptDate
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# display(dfReviewLiquidity.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Write out to Silver
spark.sql("""
    TRUNCATE TABLE lh_curated.Silver.FundLiquidityTermSchedule
""")

dfReviewLiquidity = spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Review/FundLiquidityTermSchedule")
dfReviewLiquidity.write.format("delta") \
    .mode("append") \
    .saveAsTable("lh_curated.Silver.FundLiquidityTermSchedule")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# display(dfReviewLiquidity.count())
# dfReviewLiquidity.printSchema()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
