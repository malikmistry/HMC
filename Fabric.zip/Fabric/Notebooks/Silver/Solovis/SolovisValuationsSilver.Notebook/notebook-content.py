# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql.functions import col, lit, coalesce
from pyspark.sql import functions as F
from delta.tables import DeltaTable

spark.conf.set('spark.sql.caseSensitive', True)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# WorkspaceId = ""
# BronzeLHId = ""
# CuratedLHId = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Build paths
bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Setup review table before any writes occur
hasReviewTable = DeltaTable.isDeltaTable(spark, f"{curated_lh_basepath}/Tables/Silver/FundValuation")
hasReviewTable = False #Used to reseed the valuations table in silver
if hasReviewTable:
    dfValuations = spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Silver/FundValuation")
    # Save this off to be reviewed
    spark.sql("""TRUNCATE TABLE lh_curated.Review.FundValuation""")

    dfValuations.write.format("delta") \
        .mode("append") \
        .save(f"{curated_lh_basepath}/Tables/Review/FundValuation")

display(hasReviewTable)

dfsmvh = spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisMarketValueHistory")

# Save this off to be SolovisMarketValueHistory
dfsmvh.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(f"{bronze_lh_basepath}/Tables/Bronze/SolovisMarketValueHistoryBackup")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Load and register required Bronze tables
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisMarketValues").createOrReplaceTempView("smv")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisMarketValueHistory").createOrReplaceTempView("smvh")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisActiveBookFundMapping").createOrReplaceTempView("abfm")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisInvestments").createOrReplaceTempView("si")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/SolovisCurrency").createOrReplaceTempView("scur")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/CrimsonXCurrency").createOrReplaceTempView("c")
spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Silver/FXRate").createOrReplaceTempView("fx")
if hasReviewTable:
    spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Review/FundValuation").createOrReplaceTempView("rfv")
spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/CrimsonXFundValuation").createOrReplaceTempView("fv")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Build out Solovis Fund Valuation history which includes new changes
# Get all of history
dfSolovisVHistory = spark.sql("""
SELECT smvh.ResourceId
		, CASE WHEN smvh.ValueTypeId not in (127, 64, 16) THEN smvh.ValueTypeId * -1
						      ELSE smvh.ValueTypeId END as ValueTypeId
		, smvh.CurrencyId
		, to_date(smvh.MvDate, "M/d/yyyy") as MvDate
		, CAST(smvh.TotalValue AS DECIMAL(38, 2)) as TotalValue
        , smvh.UnitPrice
        , smvh.Units
        , smvh.UpdatedBy
	    , smvh.UpdatedAtTimestamp
		, 0 as IsNew
FROM smvh
WHERE -- ValueTypeId IN (127, 64) AND 
		to_date(smvh.MvDate, "M/d/yyyy") > '2020-6-30' --Take everything that happened in solovis, exclude ems timeframe, which is causing issues with dataload
		AND smvh.TotalValue IS NOT NULL
""")

display(dfSolovisVHistory.count())

# Get the current values
dfSolovisCurrentValuations = spark.sql("""
SELECT smv.ResourceId
		, CAST(CASE WHEN smv.ValueTypeId not in (127, 64, 16) THEN smv.ValueTypeId * -1
						      ELSE smv.ValueTypeId END as int) as ValueTypeId
		, smv.CurrencyId
		, to_date(smv.MvDate, "M/d/yyyy") AS MvDate
		, CAST(smv.TotalValue AS DECIMAL(38, 2))
		, smv.UnitPrice
        , smv.Units
        , smv.UpdatedBy
		, smv.UpdatedAtTimestamp
		, 1 as IsNew
FROM smv
        LEFT JOIN smvh ON  smv.ResourceId = smvh.ResourceId
						    AND to_date(smv.MvDate, "M/d/yyyy") = to_date(smvh.MvDate, "M/d/yyyy")
							AND smv.ValueTypeId = smvh.ValueTypeId
							AND smv.CurrencyId = smvh.CurrencyId
--							AND to_date(smv.MvDate, "M/d/yyyy") < DATEADD(DAY, -500, CURRENT_DATE)
WHERE --smv.ValueTypeId IN (127, 64) AND
		smvh.ResourceId IS NULL
		AND to_date(smv.MvDate, "M/d/yyyy") < CURRENT_DATE --DATEADD(DAY, -50, CURRENT_DATE) --CURRENT_DATE  -- Exclude valuations dated for today or future.  Valuations could go out as far as next month end and sometimes requires corrections after the fact.
""")
display(dfSolovisCurrentValuations.count())

# Merge together
dfAllSolvisValuations = dfSolovisVHistory.union(dfSolovisCurrentValuations)
display(dfAllSolvisValuations.count())
dfAllSolvisValuations.printSchema()

dfAllSolvisValuations.createOrReplaceTempView("AllSolovisValuations")

dfAllValuations = spark.sql("""
	SELECT abfm.FundId
	       , abfm.ShareClassId
		   , abfm.InvestmentResourceId
		   , c.CurrencyId
		   , asv.MvDate
		   , last_day(asv.MvDate) as NAVDate
		   , asv.TotalValue
		   , asv.ValueTypeId
	FROM AllSolovisValuations asv
			JOIN abfm ON asv.ResourceId = abfm.InvestmentResourceId
			JOIN si ON si.ResourceId = asv.ResourceId
 			JOIN scur ON scur.Id = asv.CurrencyId
 			JOIN c ON c.ISOCode = scur.Code
	WHERE si.OwnerId = 1
""")

dfAllValuations.createOrReplaceTempView("AllValuations")
display(dfAllValuations.count())
dfAllValuations.printSchema()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Get only the estimate and actual valuations (64, 127)
dfEstimateActualsValuations = spark.sql("""
SELECT *
FROM AllValuations av
WHERE ValueTypeId in (64, 127)
""")

display(dfEstimateActualsValuations.count())
dfEstimateActualsValuations.printSchema()

dfEstimateActualsValuations.createOrReplaceTempView("EstimateActualsValuations")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Function to get the valuations for the targeted Valuation Type
def getValuations(valueTypeId, ValuationTypeId):

    display(spark.sql(f"""SELECT FundId
        , av.ShareClassId
        , av.CurrencyId
        , av.InvestmentResourceId
        , av.MvDate
        , MAX(av.ValueTypeId) as ValueTypeId
    FROM AllValuations av
    WHERE EXISTS(SELECT 1 FROM EstimateActualsValuations eav WHERE eav.ValueTypeId = {valueTypeId} AND eav.FundId = av.FundId AND eav.CurrencyId = av.CurrencyId AND eav.MvDate = av.MvDate)
    GROUP BY av.FundId
        , av.ShareClassId
        , av.CurrencyId
        , av.MvDate
        , av.InvestmentResourceId""").count())

    dfTargetValuations = spark.sql(f"""
    WITH targets as
    (SELECT FundId
        , av.ShareClassId
        , av.CurrencyId
        , av.InvestmentResourceId
        , av.MvDate
        , MAX(av.ValueTypeId) as ValueTypeId
    FROM AllValuations av
    WHERE EXISTS(SELECT 1 FROM EstimateActualsValuations eav WHERE eav.ValueTypeId = {valueTypeId} AND eav.FundId = av.FundId AND eav.CurrencyId = av.CurrencyId AND eav.MvDate = av.MvDate)
    GROUP BY av.FundId
        , av.ShareClassId
        , av.CurrencyId
        , av.MvDate
        , av.InvestmentResourceId)
    SELECT av.FundId
        , av.MvDate as ValuationDate
        , av.NAVDate
        , av.CurrencyId
        , {ValuationTypeId} as ValuationTypeId
        , SUM(av.TotalValue) as ValuationAmount
    FROM AllValuations av 
            JOIN targets t ON av.FundId = t.FundId
                                AND av.ShareClassId = t.ShareClassId
                                AND av.CurrencyId = t.CurrencyId
                                AND av.InvestmentResourceId = t.InvestmentResourceId
                                AND av.MvDate = t.MvDate
                                AND av.ValueTypeId = t.ValueTypeId
    WHERE av.ValueTypeId <= {valueTypeId}
    GROUP BY av.FundId
        , av.MvDate
        , av.NAVDate
        , av.CurrencyId
    """)

    display(dfTargetValuations.count())
    return dfTargetValuations

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Get the estimate and actuals
dfValuations = getValuations(64, 1)
display(dfValuations.count())
dfValuations = dfValuations.union(getValuations(127, 2))
display(dfValuations.count())
dfValuations.createOrReplaceTempView("FundValuations")
dfValuations.printSchema()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Compare current valuations with existing ones and remove the ones where there isn't a match
# If we have a Review table the use that as the source, otherwise CrimsonX in bronze
if hasReviewTable:
    dfReviewValuations = spark.sql("""
    SELECT rfv.FundId
        , rfv.NAVDate
        , rfv.ValuationDate
        , SUM(CAST(rfv.ValuationAmount AS DECIMAL(38, 2))) as ValuationAmount
        , rfv.ValuationTypeId
        , rfv.CurrencyId
        , 0 as IsNew
    FROM rfv
    GROUP BY rfv.FundId
        , rfv.NAVDate
        , rfv.ValuationDate
        , rfv.CurrencyId
        , rfv.ValuationTypeId    
    """)
else:
    dfReviewValuations = spark.sql("""
    SELECT fv.FundId
        , fv.NavDate as NAVDate
        , fv.ValuationDate
        , SUM(CAST(fv.ValuationAmt AS DECIMAL(38, 2))) as ValuationAmount
        , fv.ValuationTypeId
        , fv.CurrencyId
        , 0 as IsNew
    FROM fv
    WHERE fv.PortfolioTypeId = 0
            AND to_date(fv.EndDate) = '9999-12-31'
            AND to_date(fv.ValuationDate, "M/d/yyyy") <= '2020-6-30'
    GROUP BY fv.FundId
        , fv.NavDate
        , fv.ValuationDate
        , fv.CurrencyId
        , fv.ValuationTypeId    
    """)    

dfReviewValuations.createOrReplaceTempView("ReviewValuations")

# Now take the new valuations and merge them with the old ones
dfAllValuations = spark.sql("""
    SELECT cv.FundId
        , cv.NAVDate
        , cv.ValuationDate
        , cv.ValuationAmount
        , cv.ValuationTypeId
        , cv.CurrencyId
        , 1 as IsNew
    FROM FundValuations cv
            LEFT JOIN ReviewValuations fv ON cv.FundId = fv.FundId
                        AND cv.NAVDate = fv.NAVDate
                        AND cv.ValuationDate = fv.ValuationDate
                        AND cv.CurrencyId = fv.CurrencyId
                        AND cv.ValuationTypeId = fv.ValuationTypeId
    WHERE fv.FundId IS NULL
    union
    SELECT fv.FundId
        , fv.NAVDate
        , fv.ValuationDate
        , fv.ValuationAmount
        , fv.ValuationTypeId
        , fv.CurrencyId
        , fv.IsNew
    FROM ReviewValuations fv
""")    

display(dfAllValuations.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Set the frequency of the valuation
# Build out the USD columns
dfAllValuations.createOrReplaceTempView("AllValuation")

dfValuationsFinal = spark.sql("""
SELECT av.FundId
       , av.NAVDate
        , av.ValuationDate
        , av.ValuationTypeId
        , av.CurrencyId
        , av.ValuationAmount
        , CAST(av.ValuationAmount * CASE WHEN fx.FXRate IS NULL THEN 1 ELSE fx.FXRate END AS DECIMAL(38, 2)) as ValuationAmountUSD
        , current_timestamp as ETLLoadDateTime
  FROM AllValuation av
       LEFT JOIN fx fx ON av.CurrencyId = fx.CurrencyId
                            AND av.ValuationDate = fx.FXDate
""")

display(dfValuationsFinal.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Write out data to Solovis History and curated Review table
spark.sql("""TRUNCATE TABLE lh_curated.Review.FundValuation""")

dfValuationsFinal.write.format("delta") \
    .mode("append") \
    .saveAsTable("lh_curated.Review.FundValuation")
    #    .option("overwriteSchema", "true") \

spark.sql("""
INSERT INTO lh_bronze.Bronze.SolovisMarketValueHistory
(ResourceId, UnitPrice, Units, CurrencyId, TotalValue, ValueTypeId, MvDate, UpdatedBy, UpdatedAtTimestamp)
SELECT ResourceId
       , UnitPrice
       , Units
       , CurrencyId
       , TotalValue
       , ValueTypeId
       , MvDate
       , UpdatedBy
       , UpdatedAtTimestamp
FROM AllSolovisValuations
WHERE IsNew = 1
""")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Write out to Silver
spark.sql("""
    TRUNCATE TABLE lh_curated.Silver.FundValuation
""")

dfReviewFundValuations = spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Review/FundValuation")
dfReviewFundValuations.write.format("delta") \
    .mode("append") \
    .saveAsTable("lh_curated.Silver.FundValuation")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dfSilverFundValuations = spark.read.format("delta").load(f"{curated_lh_basepath}/Tables/Silver/FundValuation")
dfSilverFundValuations.printSchema()

display(dfSilverFundValuations.count())

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# %%sql
# DROP TABLE IF EXISTS lh_curated.Review.FundValuation

# CREATE TABLE lh_curated.Review.FundValuation(
# 	FundId VARCHAR(36) NOT NULL,
# 	NAVDate DATE NOT NULL,
# 	ValuationDate DATE NOT NULL,
# 	ValuationTypeId  INT NOT NULL,
# 	CurrencyId INT NOT NULL,
# 	ValuationAmount DECIMAL(38, 2) NOT NULL,
# 	ValuationAmountUSD DECIMAL(38, 2) NOT NULL,
# 	ETLLoadDateTime TIMESTAMP NOT NULL
# )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#%%sql
# DROP TABLE IF EXISTS lh_curated.Silver.FundValuation

# CREATE TABLE lh_curated.Silver.FundValuation(
# 	FundId VARCHAR(36) NOT NULL,
# 	NAVDate DATE NOT NULL,
# 	ValuationDate DATE NOT NULL,
# 	ValuationTypeId  INT NOT NULL,
# 	CurrencyId INT NOT NULL,
# 	ValuationAmount DECIMAL(38, 2) NOT NULL,
# 	ValuationAmountUSD DECIMAL(38, 2) NOT NULL,
# 	ETLLoadDateTime TIMESTAMP NOT NULL
# )

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
