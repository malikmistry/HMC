# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     },
# META     "environment": {}
# META   }
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""
NotebookName = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
# TaskList = "{\"JobAuditKey\":537,\"TaskKey\":116,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"CrimsonXFund\",\"SinkTableName\":\"Fund\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"14\",\"NotebookName\":\"FundSilver\",\"SinkLakehouseName\":\"lh_curated\"}"
# NotebookName = "FundSilver"
# LakehouseName = "lh_curated"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#we will attach the sinklakehouse to the notebook
if LakehouseName == 'lh_bronze':
    LakehouseId = BronzeLHId
elif LakehouseName == 'lh_curated':
    LakehouseId = CuratedLHId

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number,upper, coalesce, lit
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

In_DateToProcessString = None
if In_DateToProcessString is not None:  
    In_DateToProcess = datetime.strptime(In_DateToProcessString, "%Y-%m-%d").date()  
else:
    In_DateToProcess = date.today()

# In_DateToProcess = date.today()
# In_DateToProcess = date(2025,1,7)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.Transaction(
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	ExposureDate date NOT NULL,
# MAGIC 	TransactionTypeId int NOT NULL,
# MAGIC 	TransactionType varchar(200) NOT NULL,
# MAGIC 	TransactionSubTypeId int NOT NULL,
# MAGIC 	TransactionSubType varchar(200) NOT NULL,
# MAGIC 	TransactionAmountInLocal decimal(38, 2),
# MAGIC 	TransactionAmountInUSD decimal(38, 2),
# MAGIC 	TransactionAmountOutLocal decimal(38, 2),
# MAGIC 	TransactionAmountOutUSD decimal(38, 2),
# MAGIC 	TransactionAmountLocal decimal(38, 2),
# MAGIC 	TransactionAmountUSD decimal(38, 2),
# MAGIC 	TransactionCount bigint,
# MAGIC 	ETLLoadDateTime timestamp NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# -------------------------------------------------
# Fund Paid load
# Step 1: read transactions
# -------------------------------------------------

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)
curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

cashflowtransactiondetail_path = f"{curated_lh_id}/Tables/Silver/CashflowTransactionDetail"
df_cashflowtransactiondetail = spark.read.format("delta").load(cashflowtransactiondetail_path)
df_cashflowtransactiondetail.createOrReplaceTempView("CrimsonXCashflowTransactionDetail")
cashflowtransactiontype_path = f"{curated_lh_id}/Tables/Silver/CashflowTransactionType"
df_cashflowtransactiontype = spark.read.format("delta").load(cashflowtransactiontype_path)
df_cashflowtransactiontype.createOrReplaceTempView("CashflowTransactionType")
cashflowtransactionsubtype_path = f"{curated_lh_id}/Tables/Silver/CashflowTransactionSubtype"
df_cashflowtransactionsubtype = spark.read.format("delta").load(cashflowtransactionsubtype_path)
df_cashflowtransactionsubtype.createOrReplaceTempView("CashflowTransactionSubType")

# -----------
#spark.conf.set("spark.sql.catalog.spark_catalog.defaultNamespace", "LakehouseSilver")
# -----------
if isinstance(In_DateToProcess, (datetime, date)):
    DateToProcess = In_DateToProcess
else:
    try:
        DateToProcess = datetime.strptime(In_DateToProcess, '%Y-%m-%d')
    except (ValueError, TypeError):
        print(f"'{In_DateToProcess}' is not a valid date or string in the expected format.")
        # return None

print(f"'{In_DateToProcess}'.  In_DateToProcess")

# Read in Transactions
#dfTransactions = spark.table("CashflowTransactionDetail") \
#.select(
#    "FundId",
#    "CashflowTransactionTypeId",
#    "CommitmentEffectLocal",
#    "FundedAmountLocal",
#    "UnfundedAdjustmentLocal",
#    "RecallableAmountLocal",
#    "FundedAmountUSD",
#    "TransactionAmountInLocal",
#    "TransactionAmountInUSD",
#    "TransactionAmountOutLocal",
#    "TransactionAmountOutUSD"
#)

dfTransactions = spark.sql("""select vw.FundId,vw.CashflowTransactionTypeId as TransactionTypeId, ctt.Description as TransactionType, vw.CashflowTransactionSubtypeId as TransactionSubTypeId, cst.Description as TransactionSubType, vw.ExposureDate,vw.CashflowTransactionTypeId,vw.CommitmentEffectLocal,vw.FundedAmountLocal,vw.UnfundedAdjustmentLocal,vw.RecallableAmountLocal,vw.FundedAmountUSD,vw.TransactionAmountInLocal,vw.TransactionAmountInUSD,vw.TransactionAmountOutLocal,vw.TransactionAmountOutUSD, (vw.TransactionAmountInLocal-vw.TransactionAmountOutLocal) as TransactionAmountLocal,  (vw.TransactionAmountInUSD-vw.TransactionAmountOutUSD) as TransactionAmountUSD,vw.TransactionTag 
                              FROM CrimsonXCashflowTransactionDetail vw 
                                    JOIN CashflowTransactionType ctt ON vw.CashflowTransactionTypeId = ctt.CashflowTransactionTypeId
                                    JOIN CashflowTransactionSubType cst ON vw.CashflowTransactionSubtypeId = cst.CashflowTransactionSubtypeId
                              where vw.PortfolioTypeId = 0 and IFNULL(vw.TransactionTag,'--') not like 'ZZ-#%' """) # 22,23 = Transfer*
dfTransactions = dfTransactions.withColumn("FundId", dfTransactions["FundId"])
# dfTransactions = dfTransactions.withColumn("ShareClassId", upper(dfTransactions["ShareClassId"]))
dfTransactions = dfTransactions.withColumn("TransactionTag", coalesce(col("TransactionTag"), lit("--")) )

dfTransactionsNET = spark.sql("""select vw.FundId,vw.CashflowTransactionTypeId as TransactionTypeId, ctt.Description as TransactionType,vw.CashflowTransactionSubtypeId as TransactionSubTypeId, cst.Description as TransactionSubType,vw.ExposureDate,vw.CashflowTransactionTypeId,vw.CommitmentEffectLocal,vw.FundedAmountLocal,vw.UnfundedAdjustmentLocal,vw.RecallableAmountLocal,vw.FundedAmountUSD,vw.TransactionAmountInLocal,vw.TransactionAmountInUSD,vw.TransactionAmountOutLocal,vw.TransactionAmountOutUSD, (vw.TransactionAmountInLocal-vw.TransactionAmountOutLocal) as TransactionAmountLocal,  (vw.TransactionAmountInUSD-vw.TransactionAmountOutUSD) as TransactionAmountUSD,vw.TransactionTag 
                                  FROM CrimsonXCashflowTransactionDetail vw 
                                    JOIN CashflowTransactionType ctt ON vw.CashflowTransactionTypeId = ctt.CashflowTransactionTypeId
                                    JOIN CashflowTransactionSubType cst ON vw.CashflowTransactionSubtypeId = cst.CashflowTransactionSubtypeId                                  
                                  where vw.PortfolioTypeId = 0 and IFNULL(vw.TransactionTag,'--') = 'ZZ-#NET#' """) # 22,23 = Transfer*
dfTransactionsNET = dfTransactionsNET.withColumn("FundId", dfTransactionsNET["FundId"])
# dfTransactionsNET = dfTransactions.withColumn("ShareClassId", upper(dfTransactionsNET["ShareClassId"]))


#display(dfTransactions)
display(dfTransactionsNET)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# -------------------------------------------------
# Fund Paid load
# Step 2: get transacctions to exclude 
# -------------------------------------------------

dfXferNetToZero = spark.sql("""select vw.FundId as FundId,vw.ExposureDate as ExposureDate,SUM(IFNULL(vw.TransactionAmountInLocal,0) - IFNULL(vw.TransactionAmountOutLocal,0)) AS TransactionAmount 
                               FROM CrimsonXCashflowTransactionDetail vw 
                               where vw.CashflowTransactionTypeId in (22,23) and IFNULL(vw.TransactionTag,'--') not like 'ZZ-#%' GROUP BY vw.FundId,vw.ExposureDate 
                               having SUM(IFNULL(vw.TransactionAmountInLocal,0) - IFNULL(vw.TransactionAmountOutLocal,0)) = 0  """) # 22,23 = Transfer*
dfXferNetToZero = dfXferNetToZero.withColumn("FundId", dfXferNetToZero["FundId"])
# dfXferNetToZero.show()
# display(dfXferNetToZero)

dfExcludeNetToZero = spark.sql("select vw.FundId as FundId,vw.ExposureDate as ExposureDate,SUM(IFNULL(vw.TransactionAmountInLocal,0) - IFNULL(vw.TransactionAmountOutLocal,0)) AS TransactionAmount FROM CrimsonXCashflowTransactionDetail vw where IFNULL(vw.TransactionTag,'--') not like 'ZZ-#%' GROUP BY vw.FundId,vw.ExposureDate having SUM(IFNULL(vw.TransactionAmountInLocal,0) - IFNULL(vw.TransactionAmountOutLocal,0)) = 0  ")  
dfExcludeNetToZero = dfExcludeNetToZero.withColumn("FundId", dfExcludeNetToZero["FundId"])
# dfExcludeNetToZero.show()

dfExcludeNetToAlmostZero = spark.sql("select vw.FundId as FundId,vw.ExposureDate as ExposureDate,SUM(IFNULL(vw.TransactionAmountInLocal,0) - IFNULL(vw.TransactionAmountOutLocal,0)) AS TransactionAmount FROM CrimsonXCashflowTransactionDetail vw where IFNULL(vw.TransactionTag,'--') not like 'ZZ-#%' GROUP BY vw.FundId,vw.ExposureDate having abs(SUM(IFNULL(vw.TransactionAmountInLocal,0) - IFNULL(vw.TransactionAmountOutLocal,0))) between 0.01 and 0.99  ") 
dfExcludeNetToAlmostZero = dfExcludeNetToAlmostZero.withColumn("FundId", dfExcludeNetToAlmostZero["FundId"])
# dfExcludeNetToAlmostZero.show()

dfExcludeNetToZeroZZ = spark.sql("select vw.FundId as FundId,vw.ExposureDate as ExposureDate,SUM(IFNULL(vw.TransactionAmountInLocal,0) - IFNULL(vw.TransactionAmountOutLocal,0)) AS TransactionAmount FROM CrimsonXCashflowTransactionDetail vw where IFNULL(vw.TransactionTag,'--') like 'ZZ%' and IFNULL(vw.TransactionTag,'--') not like 'ZZ-#%' GROUP BY vw.FundId,vw.ExposureDate having SUM(IFNULL(vw.TransactionAmountInLocal,0) - IFNULL(vw.TransactionAmountOutLocal,0)) = 0  ") 
dfExcludeNetToZeroZZ = dfExcludeNetToZeroZZ.withColumn("FundId", dfExcludeNetToZeroZZ["FundId"])
# dfExcludeNetToZeroZZ.show()



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# -------------------------------------------------
# Fund Paid load
# Step 3: exclude the transactions from the main transaction set
# -------------------------------------------------

from pyspark.sql.functions import col,lit, max as sql_max

# dfTransactionFlows = dfTransactions.join(dfXferNetToZero, on=(col("dfTransactions.FundId") == col("dfXferNetToZero.FundId")) & (col("dfTransactions.ExposureDate") == col("dfXferNetToZero.ExposureDate")), how="left_anti")
dfTransactionFlows = dfTransactions.join(dfExcludeNetToZero, (dfTransactions.FundId == dfExcludeNetToZero.FundId) & (dfTransactions.ExposureDate == dfExcludeNetToZero.ExposureDate) , how="left_anti") # & (~col("TransactionTag").like("ZZ-#%"))
dfTransactionFlows = dfTransactionFlows.join(dfExcludeNetToAlmostZero, (dfTransactionFlows.FundId == dfExcludeNetToAlmostZero.FundId) & (dfTransactionFlows.ExposureDate == dfExcludeNetToAlmostZero.ExposureDate), how="left_anti") # & (~col("TransactionTag").like("ZZ-#%"))
dfTransactionFlows = dfTransactionFlows.join(dfXferNetToZero, (dfTransactionFlows.FundId == dfXferNetToZero.FundId) & (dfTransactionFlows.ExposureDate == dfXferNetToZero.ExposureDate) & (dfTransactionFlows.CashflowTransactionTypeId.isin(22,23) & (~col("TransactionTag").like("ZZ-#%"))), how="left_anti")
dfTransactionFlows = dfTransactionFlows.join(dfExcludeNetToZeroZZ, (dfTransactionFlows.FundId == dfExcludeNetToZeroZZ.FundId) & (dfTransactionFlows.ExposureDate == dfExcludeNetToZeroZZ.ExposureDate) & (col("TransactionTag").like("ZZ%") ), how="left_anti") # & (~col("TransactionTag").like("ZZ-#%"))

# tricky part.  with this exclusion, want to exclude ZZ tagged rows for fundId, exposureDate BUT keep non-ZZ rows for that same fundId, exposureDate
# dfTransactionAddBack = dfTransactionFlows.join(dfExcludeNetToZeroZZ, (dfTransactionFlows.FundId == dfExcludeNetToZeroZZ.FundId) & (dfTransactionFlows.ExposureDate == dfExcludeNetToZeroZZ.ExposureDate), how="inner").select(
#    dfTransactionFlows["*"]             # All columns from DataFrame dfTransactionFlows
# )
# dfTransactionAddBack = dfTransactionAddBack.filter(~col("TransactionTag").like("ZZ%"))  #not like ZZ* transaction tag
# dfTransactionsClean = dfTransactionFlows2.unionByName(dfTransactionAddBack)

dfTransactionsClean = dfTransactionFlows.withColumn("LoadType",lit('normal') )

display(dfTransactionsClean)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# -------------------------------------------------
# Fund Paid load
# Step 4a: aggregate ZZ rows -- for a fund and exposure date -- into 1 transaction line item
# -------------------------------------------------

from pyspark.sql.window import Window
#from pyspark.sql.functions import sum
#from pyspark.sql.functions import lead
#from pyspark.sql.functions import coalesce, lit, sum, lead,count,col,when
from pyspark.sql.types import DateType
from pyspark.sql.types import DecimalType
from pyspark.sql.functions import (
    col, lit, sum, count,
    min as min_, max as max_, first, when
)

# separate the xactions into 2 buckets, one to work with and one that won't be worked with (but needs to be merge back in)
dfTransactionsCleanZZ = dfTransactionsClean.filter(col("TransactionTag").like("ZZ%"))   # like ZZ* transaction tag


#Commented by Jason - Update: not enforcing manual adjustment to all filtered records
# dfXactionFlowAggZZ_TEMP = dfTransactionsCleanZZ.groupBy(["FundId","ExposureDate"]).agg(
#     sum("TransactionAmountInLocal").alias("TransactionAmountInLocal"),
#     sum("TransactionAmountOutLocal").alias("TransactionAmountOutLocal"),
#     sum("TransactionAmountInUSD").alias("TransactionAmountInUSD"),
#     sum("TransactionAmountOutUSD").alias("TransactionAmountOutUSD"),
#     #sum("TransactionAmountLocal").alias("TransactionAmountLocal"),
#     #sum("TransactionAmountUSD").alias("TransactionAmountUSD"),
#     count("FundId").alias("TransactionCount")
# )

# dfXactionFlowAggZZ_TEMP = dfXactionFlowAggZZ_TEMP.withColumn("TransactionTypeId",lit(28) )
# dfXactionFlowAggZZ_TEMP = dfXactionFlowAggZZ_TEMP.withColumn("TransactionSubTypeId",lit(91) ) \
#      .withColumn("TransactionType", lit("Manual Adjustment")) \
#      .withColumn("TransactionSubType", lit("Manual Adjustment"))



# 1) Aggregate by FundId + ExposureDate, and carry type/subtype info
dfXactionFlowAggZZ_TEMP = (
    dfTransactionsCleanZZ
        .groupBy("FundId", "ExposureDate")
        .agg(
            sum("TransactionAmountInLocal").alias("TransactionAmountInLocal"),
            sum("TransactionAmountOutLocal").alias("TransactionAmountOutLocal"),
            sum("TransactionAmountInUSD").alias("TransactionAmountInUSD"),
            sum("TransactionAmountOutUSD").alias("TransactionAmountOutUSD"),
            count("FundId").alias("TransactionCount"),

            # For TransactionTypeId
            min_("TransactionTypeId").alias("MinTypeId"),
            max_("TransactionTypeId").alias("MaxTypeId"),
            first("TransactionType", ignorenulls=True).alias("AnyType"),

            # For TransactionSubTypeId
            min_("TransactionSubTypeId").alias("MinSubTypeId"),
            max_("TransactionSubTypeId").alias("MaxSubTypeId"),
            first("TransactionSubType", ignorenulls=True).alias("AnySubType")
        )
)

# 2) Decide whether to use existing type/subtype or force Manual Adjustment
dfXactionFlowAggZZ_TEMP = (
    dfXactionFlowAggZZ_TEMP
        # If all TransactionTypeId in the group are the same (and not null),
        # use that; otherwise use 28 ("Manual Adjustment")
        .withColumn(
            "TransactionTypeId",
            when(
                (col("MinTypeId").eqNullSafe(col("MaxTypeId"))) & col("MinTypeId").isNotNull(),
                col("MinTypeId")
            ).otherwise(lit(28))
        )
        .withColumn(
            "TransactionType",
            when(
                (col("MinTypeId").eqNullSafe(col("MaxTypeId"))) & col("MinTypeId").isNotNull(),
                col("AnyType")
            ).otherwise(lit("Manual Adjustment"))
        )

        # Same logic for subtypes: if all the same, keep; else force 91 / "Manual Adjustment"
        .withColumn(
            "TransactionSubTypeId",
            when(
                (col("MinSubTypeId").eqNullSafe(col("MaxSubTypeId"))) & col("MinSubTypeId").isNotNull(),
                col("MinSubTypeId")
            ).otherwise(lit(91))
        )
        .withColumn(
            "TransactionSubType",
            when(
                (col("MinSubTypeId").eqNullSafe(col("MaxSubTypeId"))) & col("MinSubTypeId").isNotNull(),
                col("AnySubType")
            ).otherwise(lit("Manual Adjustment"))
        )

        # Clean up helper columns
        .drop(
            "MinTypeId", "MaxTypeId", "AnyType",
            "MinSubTypeId", "MaxSubTypeId", "AnySubType"
        )
)


dfXactionFlowAggZZ_TEMP = dfXactionFlowAggZZ_TEMP.withColumn("TransactionAmountLocal",(col("TransactionAmountInLocal") - col("TransactionAmountOutLocal")) ) 
dfXactionFlowAggZZ_TEMP = dfXactionFlowAggZZ_TEMP.withColumn("TransactionAmountUSD",(col("TransactionAmountInUSD") - col("TransactionAmountOutUSD")) ) 

dfXactionFlowAggZZ = (dfXactionFlowAggZZ_TEMP
        .withColumn("TransactionAmountInLocalNEW", when(col("TransactionAmountLocal") > 0 ,col("TransactionAmountLocal") )
             .otherwise(0.00).cast(DecimalType(38, 2)) )
        .withColumn("TransactionAmountOutLocalNEW",when(col("TransactionAmountLocal") < 0 ,col("TransactionAmountLocal") * -1 )
             .otherwise(0.00).cast(DecimalType(38, 2)) )
        .withColumn("TransactionAmountInUSDNEW", when(col("TransactionAmountUSD") > 0 ,col("TransactionAmountUSD") )
             .otherwise(0.00).cast(DecimalType(38, 2)) )
        .withColumn("TransactionAmountOutUSDNEW",when(col("TransactionAmountUSD") < 0 ,col("TransactionAmountUSD") * -1 )
             .otherwise(0.00).cast(DecimalType(38, 2)) )
)

dfXactionFlowAggZZ = dfXactionFlowAggZZ.select("FundId","ExposureDate","TransactionTypeId","TransactionType","TransactionSubTypeId","TransactionSubType"
                                              ,"TransactionAmountInLocalNEW","TransactionAmountOutLocalNEW","TransactionAmountInUSDNEW","TransactionAmountOutUSDNEW"
                                              ,"TransactionAmountLocal","TransactionAmountUSD","TransactionCount")

dfXactionFlowAggZZ = dfXactionFlowAggZZ.withColumnRenamed("TransactionAmountInLocalNEW", "TransactionAmountInLocal").withColumnRenamed("TransactionAmountOutLocalNEW", "TransactionAmountOutLocal").withColumnRenamed("TransactionAmountInUSDNEW", "TransactionAmountInUSD").withColumnRenamed("TransactionAmountOutUSDNEW", "TransactionAmountOutUSD")

# display(dfTransactionsCleanZZ)
# display(dfXactionFlowAggZZ_TEMP)
display(dfXactionFlowAggZZ)
# dfXactionFlowAggZZ.printSchema()


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# -------------------------------------------------
# Fund Paid load
# Step 4b: accumulate transactions with fund id, exposure date, transaction type
# -------------------------------------------------

from pyspark.sql.functions import sum,count
from pyspark.sql.types import DecimalType

# separate the xactions into 2 buckets, one to work with and one that won't be worked with (but needs to be merge back in)
dfTransactionsCleanNotZZ = dfTransactionsClean.filter(~col("TransactionTag").like("ZZ%"))  # not like ZZ* transaction tag

# dfTransactionFlows = dfTransactionFlows.withColumn("TransactionAmountOutLocal", dfTransactionFlows["TransactionAmountOutLocal"].cast(DecimalType(25, 2)))
dfXactionFlowAgg = dfTransactionsCleanNotZZ.groupBy(["FundId","ExposureDate","TransactionTypeId","TransactionType","TransactionSubTypeId","TransactionSubType"]).agg(
    sum("TransactionAmountInLocal").alias("TransactionAmountInLocal"),
    sum("TransactionAmountOutLocal").alias("TransactionAmountOutLocal"),
    sum("TransactionAmountInUSD").alias("TransactionAmountInUSD"),
    sum("TransactionAmountOutUSD").alias("TransactionAmountOutUSD"),
    sum("TransactionAmountLocal").alias("TransactionAmountLocal"),
    sum("TransactionAmountUSD").alias("TransactionAmountUSD"),
    count("FundId").alias("TransactionCount")
) # .filter("total > 100")

display(dfXactionFlowAgg)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# -------------------------------------------------
# Fund Paid load
# Step 4c: calculate a running total
# -------------------------------------------------

dfXactionFlowNetZZ_TEMP = dfTransactionsNET.groupBy(["FundId","ExposureDate"]).agg(
    sum("TransactionAmountInLocal").alias("TransactionAmountInLocal"),
    sum("TransactionAmountOutLocal").alias("TransactionAmountOutLocal"),
    sum("TransactionAmountInUSD").alias("TransactionAmountInUSD"),
    sum("TransactionAmountOutUSD").alias("TransactionAmountOutUSD"),
    #sum("TransactionAmountLocal").alias("TransactionAmountLocal"),
    #sum("TransactionAmountUSD").alias("TransactionAmountUSD"),
    count("FundId").alias("TransactionCount")
)

dfXactionFlowNetZZ_TEMP = dfXactionFlowNetZZ_TEMP.withColumn("TransactionTypeId",lit(28) )
dfXactionFlowNetZZ_TEMP = dfXactionFlowNetZZ_TEMP.withColumn("TransactionSubTypeId",lit(91) ) \
     .withColumn("TransactionType", lit("Manual Adjustment")) \
     .withColumn("TransactionSubType", lit("Manual Adjustment"))

dfXactionFlowNetZZ_TEMP = dfXactionFlowNetZZ_TEMP.withColumn("TransactionAmountLocal",(col("TransactionAmountInLocal") - col("TransactionAmountOutLocal")) ) 
dfXactionFlowNetZZ_TEMP = dfXactionFlowNetZZ_TEMP.withColumn("TransactionAmountUSD",(col("TransactionAmountInUSD") - col("TransactionAmountOutUSD")) ) 

dfXactionFlowNetZZ = (dfXactionFlowNetZZ_TEMP
        .withColumn("TransactionAmountInLocalNEW", when(col("TransactionAmountLocal") > 0 ,col("TransactionAmountLocal") )
             .otherwise(0.00).cast(DecimalType(38, 2)) )
        .withColumn("TransactionAmountOutLocalNEW",when(col("TransactionAmountLocal") < 0 ,col("TransactionAmountLocal") *-1 )
             .otherwise(0.00).cast(DecimalType(38, 2)) )
        .withColumn("TransactionAmountInUSDNEW", when(col("TransactionAmountUSD") > 0 ,col("TransactionAmountUSD") )
             .otherwise(0.00).cast(DecimalType(38, 2)) )
        .withColumn("TransactionAmountOutUSDNEW",when(col("TransactionAmountUSD") < 0 ,col("TransactionAmountUSD") * -1 )
             .otherwise(0.00).cast(DecimalType(38, 2)) )
)

dfXactionFlowNetZZ = dfXactionFlowNetZZ.select("FundId","ExposureDate","TransactionTypeId","TransactionType","TransactionSubTypeId","TransactionSubType"
                                              ,"TransactionAmountInLocalNEW","TransactionAmountOutLocalNEW","TransactionAmountInUSDNEW","TransactionAmountOutUSDNEW"
                                              ,"TransactionAmountLocal","TransactionAmountUSD","TransactionCount")

dfXactionFlowNetZZ = dfXactionFlowNetZZ.withColumnRenamed("TransactionAmountInLocalNEW", "TransactionAmountInLocal").withColumnRenamed("TransactionAmountOutLocalNEW", "TransactionAmountOutLocal").withColumnRenamed("TransactionAmountInUSDNEW", "TransactionAmountInUSD").withColumnRenamed("TransactionAmountOutUSDNEW", "TransactionAmountOutUSD")

# display(dfTransactionsCleanZZ)
# display(dfXactionFlowAggZZ_TEMP)
display(dfXactionFlowNetZZ)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# -------------------------------------------------
# Fund Paid load
# Step 5: calculate a running total
# -------------------------------------------------

from pyspark.sql.window import Window
#from pyspark.sql.functions import sum
#from pyspark.sql.functions import lead
from pyspark.sql.functions import coalesce, lit, sum, lead
from pyspark.sql.types import DateType

# re-combine the 2 flavors of data being processed
dfXactionFlowAggAllZZ = dfXactionFlowAggZZ.unionByName(dfXactionFlowNetZZ)
dfXactionFlowAggAll = dfXactionFlowAgg.unionByName(dfXactionFlowAggAllZZ)

#COMMENTED OUT: this does not work, after changing FundId,ExposureDate aggregation to FundId,ExposureDate,TransactionTypeId,TransactionSubTypeId
#windowClause = Window.partitionBy("fundid").orderBy("exposuredate","TransactionTypeId","TransactionSubTypeId").rowsBetween(Window.unboundedPreceding, Window.currentRow)
#
#dfFundPaid = (
#    dfXactionFlowAggAll.withColumn("CumTransactionAmountInLocal", sum("TransactionAmountInLocal").over(windowClause))
#      .withColumn("CumTransactionAmountOutLocal", sum("TransactionAmountOutLocal").over(windowClause))
#      .withColumn("CumTransactionAmountInUSD", sum("TransactionAmountInUSD").over(windowClause))
#      .withColumn("CumTransactionAmountOutUSD", sum("TransactionAmountOutUSD").over(windowClause))
#      .withColumn("CumTransactionAmountLocal", sum("TransactionAmountLocal").over(windowClause))
#      .withColumn("CumTransactionAmountUSD", sum("TransactionAmountUSD").over(windowClause))
#)

dfFundPaid = dfXactionFlowAggAll

# display(dfFundPaid)

# COMMENTED OUT: derive "EndDate".  This does not work since we added TransactionTypeId, SubtypeId.
# windowClauseEndDate = Window.partitionBy("FundId").orderBy("ExposureDate")
# Compute Next Exposure Date as End Date
# dfFundPaidPlusEndDate = dfFundPaid.withColumn("EndDate", lead("ExposureDate").over(windowClauseEndDate))
#dfFundPaid = dfFundPaid.withColumnRenamed("ExposureDate", "AsOfDate")

dfFundPaidClean=dfFundPaid.select("FundId","ExposureDate"
                                 ,"TransactionTypeId","TransactionType","TransactionSubTypeId","TransactionSubType"
                                 ,"TransactionAmountInLocal","TransactionAmountInUSD"
                                 ,"TransactionAmountOutLocal","TransactionAmountOutUSD"
                                 ,"TransactionAmountLocal","TransactionAmountUSD"
                                 #,"CumTransactionAmountInLocal","CumTransactionAmountInUSD"
                                 #,"CumTransactionAmountOutLocal","CumTransactionAmountOutUSD"
                                 #,"CumTransactionAmountLocal","CumTransactionAmountUSD"
                                 ,"TransactionCount")

#dfFundPaidFINAL = dfFundPaidFINAL.withColumn(
#    "EndDate",
#    coalesce(dfFundPaidFINAL["EndDate"], lit("9999-12-31").cast(DateType()))
#)          

# cosmetics.  exclude any xactions that are 0's across the board, i.e. add no value to the fund INs and OUTs.
dfFundPaidFINAL = dfFundPaidClean.filter(
   ~(
    (col("TransactionAmountInLocal") == 0) & 
    (col("TransactionAmountOutLocal") == 0) & 
    (col("TransactionAmountLocal") == 0) 
))

# dfFundPaidFINAL = dfFundPaidClean
display(dfFundPaidFINAL)
dfFundPaidFINAL.createOrReplaceTempView("dfFundPaidFINAL")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

dfTest = dfFundPaidFINAL.filter((col("FundId") == "3b4dc7c9-0cc8-4d7f-878a-d25dceb69cb3") & (col("ExposureDate") == to_date(lit("2025-03-19"))))

# dfTransactionFlows = dfTransactions.join(dfExcludeNetToZero, (dfTransactions.FundId == dfExcludeNetToZero.FundId) & (dfTransactions.ExposureDate == dfExcludeNetToZero.ExposureDate) , how="left_anti") # & (~col("TransactionTag").like("ZZ-#%"))
# dfTransactionFlows = dfTransactionFlows.join(dfExcludeNetToAlmostZero, (dfTransactionFlows.FundId == dfExcludeNetToAlmostZero.FundId) & (dfTransactionFlows.ExposureDate == dfExcludeNetToAlmostZero.ExposureDate), how="left_anti") # & (~col("TransactionTag").like("ZZ-#%"))
# dfTransactionFlows = dfTransactionFlows.join(dfXferNetToZero, (dfTransactionFlows.FundId == dfXferNetToZero.FundId) & (dfTransactionFlows.ExposureDate == dfXferNetToZero.ExposureDate) & (dfTransactionFlows.CashflowTransactionTypeId.isin(22,23) & (~col("TransactionTag").like("ZZ-#%"))), how="left_anti")
# dfTransactionFlows = dfTransactionFlows.join(dfExcludeNetToZeroZZ, (dfTransactionFlows.FundId == dfExcludeNetToZeroZZ.FundId) & (dfTransactionFlows.ExposureDate == dfExcludeNetToZeroZZ.ExposureDate) & (col("TransactionTag").like("ZZ%") ), how="left_anti") # & (~col("TransactionTag").like("ZZ-#%"))



display(dfTest)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# -------------------------------------------------
# Fund Paid load
# Step 6: Write Silver transaction to DeltaLake
# -------------------------------------------------
from pyspark.sql.types import StringType, StructType, StructField
from delta.tables import DeltaTable

#lakehousePath = "abfss://DEV@onelake.dfs.fabric.microsoft.com/LakehouseSilver.Lakehouse"
#tableName = "TransactionIBOR" # In_TableToProcess # "Entity"
# tableKey =  "FundId" 
# tableKey2 = "StartDate"
# tableKey3 = In_TableKey3  # None

etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
query = f"""
SELECT 
    CAST(FundId AS VARCHAR(36)) AS FundId
    ,ExposureDate
    ,TransactionTypeId
    ,TransactionType
    ,TransactionSubTypeId
    ,TransactionSubType
    ,TransactionAmountInLocal
    ,TransactionAmountInUSD
    ,TransactionAmountOutLocal
    ,TransactionAmountOutUSD
    ,TransactionAmountLocal
    ,TransactionAmountUSD
    ,TransactionCount
    ,CAST('{etlloadtime}' AS TIMESTAMP) AS ETLLoadDateTime
FROM dfFundPaidFINAL

"""
result_df = spark.sql(query)

target_path = f"{curated_lh_id}/Tables/Silver/Transaction"
#deltaTablePath = f"{lakehousePath}/Tables/{tableName}" 
print(": deltaTablePath=" + target_path)

result_df.write.format("delta").mode("overwrite").save(target_path) 


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# -------------------------------------------------
# DEBUG DEBUG DEBUG
# -------------------------------------------------

# dfDEBUG3 = dfTransactions.filter( (col("FundId") == '6C4E2620-4ADC-4DCB-9DC1-E61E534DD083') & (col("ExposureDate") == "2020-07-24") ) 
##dfDEBUG3 = dfTransactionsClean.filter( (col("FundId") == '6C4E2620-4ADC-4DCB-9DC1-E61E534DD083') & (col("ExposureDate") == "2020-07-24") ) 
# dfDEBUG3 = dfFundPaidFINAL.filter( (col("FundId") == '6C4E2620-4ADC-4DCB-9DC1-E61E534DD083') & (col("ExposureDate") == "2020-07-24") ) 
##display(dfDEBUG3)
# dfDEBUG3 = dfTransactions.filter( (col("FundId") == '6C4E2620-4ADC-4DCB-9DC1-E61E534DD083') )
# dfDEBUG3 = dfXferNetToZero.filter( (col("FundId") == '6C4E2620-4ADC-4DCB-9DC1-E61E534DD083') & (col("ExposureDate") == "2020-07-24") ) 
# display(dfDEBUG3)
# dfDEBUG3 = dfExcludeNetToZero.filter( (col("FundId") == '6C4E2620-4ADC-4DCB-9DC1-E61E534DD083') & (col("ExposureDate") == "2020-07-24") ) 
# display(dfDEBUG3)
# dfDEBUG3 = dfExcludeNetToAlmostZero.filter( (col("FundId") == '6C4E2620-4ADC-4DCB-9DC1-E61E534DD083') & (col("ExposureDate") == "2020-07-24") ) 
# display(dfDEBUG3)
# dfDEBUG3 = dfExcludeNetToZeroZZ.filter( (col("FundId") == '6C4E2620-4ADC-4DCB-9DC1-E61E534DD083') & (col("ExposureDate") == "2020-07-24") ) 
# display(dfDEBUG3)

# -- testing excluding all 0 rows.
# --C682E4BD-FEBE-4B98-8FA8-132946C9B7FC
# --6D8679E4-40E8-4462-9855-CC5E2C6EF084 | 2018-01-31
#  dfFundPaidDEBUG = dfFundPaidFINAL.filter(col("FundId") == '6D8679E4-40E8-4462-9855-CC5E2C6EF084') # & col("AsOfDate") == '2018-01-31' ) 
# dfFundPaidDEBUG = dfFundPaidFINAL.filter(col("FundId") == 'C682E4BD-FEBE-4B98-8FA8-132946C9B7FC' ) 
#display(dfFundPaidDEBUG)

# -- testing combining ZZ rows.
# --4BA9FD86-C843-4B04-A300-C82FB0DDE808 | 2023-06-01
#dfDEBUG = dfTransactionsCleanZZ.filter(col("FundId") == '4BA9FD86-C843-4B04-A300-C82FB0DDE808') # & col("AsOfDate") == '2018-01-31' ) 
#display(dfDEBUG)

#dfDEBUG2 = dfXactionFlowAggZZ.filter(col("FundId") == '4BA9FD86-C843-4B04-A300-C82FB0DDE808') 
#display(dfDEBUG2)

# dfDEBUG2 = dfTransactions.filter(col("FundId") == '4BA9FD86-C843-4B04-A300-C82FB0DDE808') # & col("AsOfDate") == '2018-01-31' ) 
# display(dfDEBUG2)

# dfDEBUG1=dfTransactionsCleanZZ.filter(col("FundId") == 'CD7E0E9D-FDC5-4DC9-BAF8-5DA50795AFD2')
# dfDEBUG1=dfTransactionsCleanZZ.filter(col("FundId") == '047EBF6C-653E-4AC1-9ED8-054434965EAB')
# dfDEBUG1=dfFundPaidFINAL.filter(col("FundId") == '047EBF6C-653E-4AC1-9ED8-054434965EAB')
# display(dfDEBUG1)

# dfDEBUG=dfXactionFlowAggZZ.filter(col("FundId") == 'CD7E0E9D-FDC5-4DC9-BAF8-5DA50795AFD2')

# dfDEBUG=dfExcludeNetToZero.filter(col("FundId") == '047EBF6C-653E-4AC1-9ED8-054434965EAB')
# display(dfDEBUG)


# dfExcludeNetToZero = spark.sql("select vw.FundId as FundId,vw.ExposureDate as ExposureDate,SUM(IFNULL(vw.TransactionAmountInLocal,0) + IFNULL(vw.TransactionAmountOutLocal,0)) AS TransactionAmount FROM LakehouseSilver.CashflowTransactionDetail vw where IFNULL(vw.TransactionTag,'--') not like 'ZZ-#%' and upper(FundId)= '047EBF6C-653E-4AC1-9ED8-054434965EAB' GROUP BY vw.FundId,vw.ExposureDate ")  
# dfExcludeNetToZero = dfExcludeNetToZero.withColumn("FundId", upper(dfExcludeNetToZero["FundId"]))
# display(dfExcludeNetToZero)




# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
