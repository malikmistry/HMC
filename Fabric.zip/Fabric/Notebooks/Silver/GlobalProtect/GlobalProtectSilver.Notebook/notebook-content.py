# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# ---------- inputs ----------
source_rel = "Bronze/GlobalProtect"
silver_rel = "Silver/UserNetworkAccessGlobalProtect"
entra_rel  = "Bronze/EntraUsers"
codes_rel  = "Bronze/CountryCodes"

# ---------- read sources ----------
src_df = read_delta(bronze_lh_id, source_rel)
entra_df = (
    read_delta(bronze_lh_id, entra_rel)
    .select(
        F.col("userPrincipalName").cast("string").alias("userPrincipalName"),
        F.col("department").cast("string").alias("department"),
        F.col("givenName").cast("string").alias("givenName"),
        F.col("surname").cast("string").alias("surname"),
    )
    .where(F.col("userPrincipalName").isNotNull())
)

codes_df = (
    read_delta(bronze_lh_id, codes_rel)
    .select(
        F.col("Azure").cast("string").alias("Azure"),
        F.col("GlobalProtect").cast("string").alias("GlobalProtect"),
        F.col("Country").cast("string").alias("CountryFull"),
        F.col("BlackList").cast("boolean").alias("BlackList"),
        F.col("GreyList").cast("boolean").alias("GreyList"),
        F.col("WhiteList").cast("boolean").alias("WhiteList"),
    )
)
# ---------- normalize GlobalProtect ----------
# Columns observed: when, user, computer, public_ip, City, Region, Country, ETLLoadDateTime
# Strip any DOMAIN\ prefix; keep email as-is if present
clean_user = F.regexp_replace(F.col("user"), r'^.*\\', '')
who_token  = F.lower(F.trim(clean_user))

src_norm = (
    src_df
    .withColumn("timestamp_raw", F.col("when").cast("timestamp"))
    # GlobalProtect rows are successful connections; default success=True.
    # If you have a status column, replace this with a mapping.
    .withColumn("success", F.lit(True))
    .withColumn("who", who_token)
    .withColumn("who_token", who_token)
    .withColumn("ipAddress", F.col("public_ip").cast("string"))
    .withColumn("city", F.col("City").cast("string"))
    .withColumn("state", F.col("Region").cast("string"))
    .withColumn("country_raw", F.col("Country").cast("string"))
    .withColumn("deviceDisplayName", F.col("computer").cast("string"))
    .withColumn("Source", F.lit("GlobalProtect"))
    .alias("l")
)

# ---------- normalize Entra & CountryCodes ----------
entra_norm = (
    entra_df
    .withColumn("upn_norm",  F.lower(F.trim(F.col("userPrincipalName"))))
    .withColumn("upn_local", F.lower(F.substring_index(F.col("userPrincipalName"), "@", 1)))
    .dropDuplicates(["upn_norm"])
    .alias("e")
)

codes_norm = (
    codes_df
    .withColumn("az_match",     F.upper(F.trim(F.col("Azure"))))
    .withColumn("gp_match",     F.upper(F.trim(F.coalesce(F.col("GlobalProtect"), F.col("CountryFull")))))
    .withColumn("name_match",   F.upper(F.trim(F.col("CountryFull"))))
    .withColumn("name_match",   F.regexp_replace(F.col("name_match"), r"\s*\(THE\)$", ""))
    .alias("cc")
)

# ---------- join to Entra on local-part ----------
joined_le = src_norm.join(
    entra_norm,
    on=F.col("l.who_token") == F.col("e.upn_local"),
    how="left"
)

# ---------- country mapping (code OR full name) ----------
country_candidate_uc = F.upper(F.trim(F.col("l.country_raw")))
country_candidate_uc = F.regexp_replace(country_candidate_uc, r"\s*\(THE\)$", "")

joined_cc = joined_le.join(
    F.broadcast(codes_norm),
    (country_candidate_uc == F.col("cc.az_match")) |
    (country_candidate_uc == F.col("cc.gp_match")) |
    (country_candidate_uc == F.col("cc.name_match")),
    how="left"
)

# ---------- derivations ----------
user_name = F.trim(F.concat_ws(" ", F.col("e.givenName"), F.col("e.surname")))

who_lc = F.lower(F.col("l.who"))
user_only = F.when(
    who_lc.rlike(r'@(?:[a-z0-9-]+\.)?hmc\.harvard\.edu$'),
    F.substring_index(F.col("l.who"), "@", 1)
).otherwise(F.lit(None).cast("string"))

country_final = F.coalesce(F.col("cc.CountryFull"), F.col("l.country_raw").cast("string"))

location_col = F.concat_ws(
    ", ",
    F.trim(F.col("l.city")),
    F.trim(F.col("l.state")),
    F.trim(country_final)
)

country_code = F.upper(F.trim(F.coalesce(F.col("cc.Azure"), F.col("l.country_raw"))))
login_outside_us = (
    F.when(country_code.isNull(), F.lit(False))
     .when((country_code == F.lit("US")) | (country_code == F.lit("UNITED STATES")), F.lit(False))
     .otherwise(F.lit(True))
)

# ---------- select (schema-compatible) ----------
silver_df = (
    joined_cc.select(
        F.col("l.timestamp_raw").alias("timestamp"),
        F.col("l.success").alias("success"),
        F.col("l.who").cast("string").alias("who"),
        user_only.alias("User"),
        F.col("l.ipAddress").alias("ipAddress"),
        F.col("l.city").alias("city"),
        F.col("l.state").alias("state"),
        country_final.alias("country"),
        location_col.alias("location"),
        login_outside_us.alias("LoginOutsideUS"),
        F.lit(None).cast("string").alias("deviceClass"),
        F.lit(None).cast("string").alias("deviceOS"),
        F.col("l.deviceDisplayName").alias("deviceDisplayName"),
        F.lit(None).cast("string").alias("dirOSVersion"),
        F.col("e.department").cast("string").alias("department"),
        F.coalesce(F.col("cc.BlackList"), F.lit(False)).alias("BlackList"),
        F.coalesce(F.col("cc.GreyList"),  F.lit(False)).alias("GreyList"),
        F.coalesce(F.col("cc.WhiteList"), F.lit(False)).alias("WhiteList"),
        F.col("l.Source").alias("Source"),
        user_name.alias("UserName"),
    )
)

# ---------- write to Silver ----------
target_path = tbl_path(curated_lh_id, silver_rel)
(silver_df.write
    .format("delta")
    .mode("overwrite")           # switch to "append" with dedupe for incremental loads
    .option("overwriteSchema", "true")
    .save(target_path)
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
