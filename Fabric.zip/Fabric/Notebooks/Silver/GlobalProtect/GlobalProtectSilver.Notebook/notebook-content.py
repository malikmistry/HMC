# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "13ef97da-5da2-466d-8c5f-2a70572c6558",
# META       "default_lakehouse_name": "lh_bronze",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         },
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from functools import reduce

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = None
BronzeLHId = None
CuratedLHId = None
TaskList = None
NotebookName = None
LakehouseName = None
RawLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}, TaskList = {TaskList}, NotebookName = {NotebookName}, LakehouseName = {LakehouseName}, RawLHId = {RawLHId}")

if WorkspaceId == None:
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

bronze_lh_id = get_basepath(WorkspaceId, BronzeLHId)

curated_lh_id = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from functools import reduce
from pyspark.sql import functions as F

def tbl_path(base, rel):
    return f"{base}/Tables/{rel}"

def read_delta(base, rel):
    return spark.read.format("delta").load(tbl_path(base, rel))

# ---------- inputs ----------
source_rel = "Bronze/GlobalProtect"
silver_rel = "Silver/UserNetworkAccessGlobalProtect"
entra_rel  = "Bronze/EntraUsers"
codes_rel  = "Bronze/CountryCodes"

# ---------- read sources ----------
src_df = read_delta(bronze_lh_id, source_rel)

entra_df = (
    read_delta(bronze_lh_id, entra_rel)
    .select(
        F.col("userPrincipalName").cast("string").alias("userPrincipalName"),
        F.col("department").cast("string").alias("department"),
        F.col("givenName").cast("string").alias("givenName"),
        F.col("surname").cast("string").alias("surname"),
    )
    .where(F.col("userPrincipalName").isNotNull())
)

codes_df = (
    read_delta(bronze_lh_id, codes_rel)
    .select(
        F.col("Azure").cast("string").alias("Azure"),
        F.col("GlobalProtect").cast("string").alias("GlobalProtect"),
        F.col("Country").cast("string").alias("CountryFull"),
        F.col("BlackList").cast("boolean").alias("BlackList"),
        F.col("GreyList").cast("boolean").alias("GreyList"),
        F.col("WhiteList").cast("boolean").alias("WhiteList"),
    )
)

# ---------- helpers to tolerate schema drift (case-insensitive) ----------
def col_ci(df, name):
    """
    Case-insensitive column resolver: returns the actual Column if found,
    otherwise returns None.
    """
    lower_map = {c.lower(): c for c in df.columns}
    actual = lower_map.get(name.lower())
    return F.col(actual) if actual else None

def col_opt(df, name):
    """
    Return df[name] if present (case-insensitive), else NULL literal.
    """
    c = col_ci(df, name)
    return c if c is not None else F.lit(None)

def coalesce_any(df, names):
    """
    Coalesce over a list of candidate names (case-insensitive), in order.
    """
    cols = [c for n in names if (c := col_ci(df, n)) is not None]
    return F.coalesce(*cols) if cols else F.lit(None)

# candidates for commonly changed columns
CANDIDATES = {
    # prefer event time over ETL load time, but include both
    "timestamp":  ["when", "date", "Date", "timestamp", "time", "_time", "EventTime", "ETLLoadDateTime"],
    "user":       ["user", "User", "who", "username", "principal", "email", "user_name", "upn", "userPrincipalName"],
    "ip":         ["public_ip", "ip", "ipAddress", "IPAddress", "src_ip", "publicIp"],
    "city":       ["City", "city", "CityName"],
    "state":      ["Region", "state", "province", "State", "region", "RegionName"],
    "country":    ["Country", "country", "country_code", "countryCode", "countryName", "CountryName"],
    "device":     ["computer", "device", "hostname", "deviceDisplayName", "DeviceName", "Device"],
    "action":     ["action", "result", "status", "Status"],  # success/failure/allow/deny/etc.
    "os":         ["os", "deviceOS", "dirOSVersion"],
}

# ---------- normalize GlobalProtect ----------
raw_user = coalesce_any(src_df, CANDIDATES["user"]).cast("string")
clean_user = F.regexp_replace(raw_user, r'^.*\\', '')            # strip DOMAIN\
user_norm  = F.lower(F.trim(clean_user))                         # may be local or full email
user_local = F.lower(F.substring_index(user_norm, "@", 1))       # robust local-part

# status → success boolean
raw_action = coalesce_any(src_df, CANDIDATES["action"]).cast("string")
action_norm = F.lower(F.trim(raw_action))
success_col = (
    F.when(action_norm.isNull(), True)
     .when(action_norm.isin("success", "succeeded", "allow", "allowed", "ok", "pass"), True)
     .when(action_norm.isin("failure", "failed", "deny", "denied", "blocked", "error"), False)
     .otherwise(True)  # default behavior you had previously
)

src_norm = (
    src_df
    .withColumn("timestamp_raw", coalesce_any(src_df, CANDIDATES["timestamp"]).cast("timestamp"))
    .withColumn("success", success_col)
    .withColumn("who", user_norm)
    .withColumn("who_token", user_norm)
    .withColumn("user_norm", user_norm)
    .withColumn("user_local", user_local)
    .withColumn("ipAddress", coalesce_any(src_df, CANDIDATES["ip"]).cast("string"))
    .withColumn("city", coalesce_any(src_df, CANDIDATES["city"]).cast("string"))
    .withColumn("state", coalesce_any(src_df, CANDIDATES["state"]).cast("string"))
    .withColumn("country_raw", coalesce_any(src_df, CANDIDATES["country"]).cast("string"))
    .withColumn("deviceDisplayName", coalesce_any(src_df, CANDIDATES["device"]).cast("string"))
    .withColumn("Source", F.lit("GlobalProtect"))
    .alias("l")
)

# ---------- normalize Entra ----------
entra_norm = (
    entra_df
    .withColumn("upn_norm",  F.lower(F.trim(F.col("userPrincipalName"))))
    .withColumn("upn_local", F.lower(F.substring_index(F.col("userPrincipalName"), "@", 1)))
    .dropDuplicates(["upn_norm"])
    .alias("e")
)

# ---------- normalize CountryCodes ----------
codes_norm = (
    codes_df
    .withColumn("az_match",   F.upper(F.trim(F.col("Azure"))))
    .withColumn("gp_match",   F.upper(F.trim(F.coalesce(F.col("GlobalProtect"), F.col("CountryFull")))))
    .withColumn("name_match", F.upper(F.trim(F.col("CountryFull"))))
    .withColumn("name_match", F.regexp_replace(F.col("name_match"), r"\s*\(THE\)$", ""))
    .alias("cc")
)

# ---------- join to Entra: local-part OR full email ----------
joined_le = src_norm.join(
    entra_norm,
    on=((F.col("l.user_local") == F.col("e.upn_local")) | (F.col("l.user_norm") == F.col("e.upn_norm"))),
    how="left"
)

# ---------- country mapping (code OR full name) ----------
country_candidate_uc = F.upper(F.trim(F.col("l.country_raw")))
country_candidate_uc = F.regexp_replace(country_candidate_uc, r"\s*\(THE\)$", "")

joined_cc = joined_le.join(
    F.broadcast(codes_norm),
    (country_candidate_uc == F.col("cc.az_match")) |
    (country_candidate_uc == F.col("cc.gp_match")) |
    (country_candidate_uc == F.col("cc.name_match")),
    how="left"
)

# ---------- derivations ----------
user_name = F.trim(F.concat_ws(" ", F.col("e.givenName"), F.col("e.surname")))
country_final = F.coalesce(F.col("cc.CountryFull"), F.col("l.country_raw").cast("string"))

location_col = F.concat_ws(
    ", ",
    F.trim(F.col("l.city")),
    F.trim(F.col("l.state")),
    F.trim(country_final)
)

country_code = F.upper(F.trim(F.coalesce(F.col("cc.Azure"), F.col("l.country_raw"))))
login_outside_us = (
    F.when(country_code.isNull(), F.lit(False))
     .when((country_code == F.lit("US")) | (country_code == F.lit("UNITED STATES")), F.lit(False))
     .otherwise(F.lit(True))
)

# ---------- select (schema-compatible) ----------
silver_df = (
    joined_cc.select(
        F.col("l.timestamp_raw").alias("timestamp"),
        F.col("l.success").alias("success"),
        F.col("l.who").cast("string").alias("who"),
        F.col("l.who").cast("string").alias("User"),   # keep your simplification
        F.col("l.ipAddress").alias("ipAddress"),
        F.col("l.city").alias("city"),
        F.col("l.state").alias("state"),
        country_final.alias("country"),
        location_col.alias("location"),
        login_outside_us.alias("LoginOutsideUS"),
        F.lit(None).cast("string").alias("deviceClass"),
        F.lit(None).cast("string").alias("deviceOS"),
        F.col("l.deviceDisplayName").alias("deviceDisplayName"),
        F.lit(None).cast("string").alias("dirOSVersion"),
        F.col("e.department").cast("string").alias("department"),
        F.coalesce(F.col("cc.BlackList"), F.lit(False)).alias("BlackList"),
        F.coalesce(F.col("cc.GreyList"),  F.lit(False)).alias("GreyList"),
        F.coalesce(F.col("cc.WhiteList"), F.lit(False)).alias("WhiteList"),
        F.col("l.Source").alias("Source"),
        user_name.alias("UserName"),
    )
)

# ---------- write to Silver ----------
target_path = tbl_path(curated_lh_id, silver_rel)
(
    silver_df.write
    .format("delta")
    .mode("overwrite")           # consider 'append' + dedupe for prod
    .option("overwriteSchema", "true")
    .save(target_path)
)

print(f"Wrote {silver_rel} to {target_path}")



# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
