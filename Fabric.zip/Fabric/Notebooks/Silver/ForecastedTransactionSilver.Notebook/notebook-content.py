# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# # This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
# WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
# BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
# CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
# TaskList = "{\"JobAuditKey\":1526,\"TaskKey\":115,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"CrimsonXFundTradeForecastedTransaction\",\"SinkTableName\":\"FundTradeForecastedTransaction\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"13\",\"NotebookName\":\"ForecastedTransactionSilver\",\"SinkLakehouseName\":\"lh_curated\",\"RawStoragePath\":null,\"RawStorageFileName\":null,\"RelativeUrl\":null}"
# NotebookName = "ForecastedTransactionSilver"
# LakehouseName = "lh_curated"
# RawLHId = "920a12cc-7104-4013-a2a3-d7baa57e9e3f"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""
NotebookName = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType, StringType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tasklist = json.loads(f"[{TaskList}]")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def is_df_empty(df, column_name=None, excluded_value=None):
    if column_name is not None and excluded_value is not None:
        df = df.filter(col(column_name) != excluded_value)
    return df.limit(1).count() == 0

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.FundTradeForecastedTransaction (
# MAGIC     FundTradeForecastedTransactionId BIGINT NOT NULL,
# MAGIC     FundTradeId VARCHAR(36) NOT NULL,
# MAGIC     SettlementDate DATE,
# MAGIC     ExposureDate DATE,
# MAGIC     Amount DECIMAL(38,2),
# MAGIC     Description STRING,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from datetime import date, datetime, timezone
from pyspark.sql import functions as F
from pyspark.sql.types import StringType, DecimalType
from delta.tables import DeltaTable

def process_task(task, bronze_lh_id, curated_lh_id):
    try:
        source_path = f"{bronze_lh_id}/Tables/{task['SourceSchemaName']}/{task['SourceTableName']}"
        target_path = f"{curated_lh_id}/Tables/{task['SinkSchemaName']}/{task['SinkTableName']}"

        # ETL Load timestamp
        etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        # Read Bronze sources
        df_source = spark.read.format("delta").load(source_path).alias("ftf")
        df_fundtrade = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXFundTrade").alias("ft")
        df_currency = spark.read.format("delta").load(f"{bronze_lh_id}/Tables/Bronze/CrimsonXCurrency").alias("c")

        # Transform
        result_df = (
            df_source
            .join(df_fundtrade, F.col("ft.FundTradeId") == F.col("ftf.FundTradeId"))
            .join(df_currency, F.col("c.CurrencyId") == F.col("ft.CurrencyId"))
            .filter((F.col("ftf.IsDeleted") == 0) & (F.col("ft.IsDeleted") == 0))
            .select(
                F.col("ftf.FundTradeForecastedTransactionId"),
                F.col("ftf.FundTradeId").cast(StringType()).alias("FundTradeId"),
                F.col("ftf.SettlementDate"),
                F.col("ftf.ExposureDate"),
                F.col("ftf.Amount").cast(DecimalType(38, 2)).alias("Amount"),
                F.col("ftf.Description"),
                F.to_timestamp(F.lit(etlloadtime), "yyyy-MM-dd'T'HH:mm:ss'Z'").alias("ETLLoadDateTime")

            )
        )

        # Enforce NOT NULL rules
        required_cols = ["FundTradeForecastedTransactionId", "FundTradeId", "ETLLoadDateTime"]
        for col_name in required_cols:
            result_df = result_df.filter(F.col(col_name).isNotNull())


        # Truncate the Silver table before inserting
        if DeltaTable.isDeltaTable(spark, target_path):
            spark.sql(f"TRUNCATE TABLE Silver.{task['SinkTableName']}")

        # Append new data
        result_df.write.format("delta").mode("append").save(target_path)

        print("Completed")

    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise RuntimeError("Failed") from e


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)


        # Process the task
        result = process_task(task_item,bronze_lh_basepath,curated_lh_basepath)

    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
