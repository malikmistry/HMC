# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# MARKDOWN ********************

# This requirement was modified, this became a column in Classification

# CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

lh_bronze_basepath = get_basepath(WorkspaceId, BronzeLHId)
lh_curated_basepath = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#     CASE 
#         WHEN f.isCoinvest = 1 THEN 
#             CASE 
#                 WHEN COALESCE(f.BudgetStrategyId, e.BudgetStrategyId, bcm.BudgetStrategyId) = 3 THEN 'PE, Buyout Coinvest'
#                 WHEN COALESCE(f.BudgetStrategyId, e.BudgetStrategyId, bcm.BudgetStrategyId) = 5 THEN 'PE, Venture Coinvest'
#                 WHEN COALESCE(f.BudgetStrategyId, e.BudgetStrategyId, bcm.BudgetStrategyId) IN (9, 10) THEN 'RE, Coinvest'
#                 WHEN COALESCE(f.BudgetStrategyId, e.BudgetStrategyId, bcm.BudgetStrategyId) = 11 THEN 'Energy Coinvest'
#                 WHEN COALESCE(f.BudgetStrategyId, e.BudgetStrategyId, bcm.BudgetStrategyId) = 16 THEN 'PE, Growth Coinvest'
#                 WHEN COALESCE(f.BudgetStrategyId, e.BudgetStrategyId, bcm.BudgetStrategyId) = 17 THEN 'PE Growth Venture Coinvest'
#                 WHEN COALESCE(f.BudgetStrategyId, e.BudgetStrategyId, bcm.BudgetStrategyId) = 20 THEN 'Climate Transition Coinvest'
#                 ELSE bs.Description
#             END
#         ELSE bs.Description
#     END AS BudgetStrategy

# FROM Silver.Classification c
# JOIN Silver.Fund f ON c.FundId = f.FundId
# LEFT JOIN Silver.Entity e ON f.EntityId = e.EntityId
# LEFT JOIN Silver.BudgetStrategyClassificationMap bcm
#   ON c.Level1Description = bcm.AssetClass 
#  AND (bcm.Strategy IS NULL OR COALESCE(bcm.Strategy, '') = COALESCE(c.Level2Description, ''))
# LEFT JOIN Silver.BudgetStrategy bs 
#   ON bs.BudgetStrategyId = COALESCE(f.BudgetStrategyId, e.BudgetStrategyId, bcm.BudgetStrategyId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Create temp views
spark.read.format("delta").load(f"{lh_curated_basepath}/Tables/Silver/BudgetStrategyClassificationMap").createOrReplaceTempView("BudgetStrategyClassificationMap")
spark.read.format("delta").load(f"{lh_curated_basepath}/Tables/Silver/Classification").createOrReplaceTempView("Classification")
spark.read.format("delta").load(f"{lh_curated_basepath}/Tables/Silver/Fund").createOrReplaceTempView("Fund")
spark.read.format("delta").load(f"{lh_curated_basepath}/Tables/Silver/Entity").createOrReplaceTempView("Entity")
spark.read.format("delta").load(f"{lh_curated_basepath}/Tables/Bronze/vwClassificationMap").createOrReplaceTempView("vwClassificationMap")
spark.read.format("delta").load(f"{lh_curated_basepath}/Tables/Silver/BudgetStrategy").createOrReplaceTempView("BudgetStrategy")

target_path = f"{lh_curated_basepath}/Tables/Silver/FundBudgetStrategy"


df_final = spark.sql("""
-- expand BudgetStrategyClassificationMap
WITH BudgetStrategyClassificationMapExpanded AS (
    SELECT
        bscm.BudgetStrategyClassificationMapId,
        bscm.BudgetStrategyId,
        CASE
            WHEN c1.ParentClassificationId = 0 AND c1.ClassificationLevelId = 1 THEN c1.Description
            ELSE c2.Description
        END AS AssetClass,
        CASE
            WHEN c2.ParentClassificationId IS NULL AND c2.ClassificationLevelId IS NULL THEN NULL
            ELSE c1.Description
        END AS Strategy
    FROM BudgetStrategyClassificationMap bscm
    LEFT JOIN Classification c1 ON c1.ClassificationId = bscm.ClassificationId
    LEFT JOIN Classification c2 ON c2.ClassificationId = c1.ParentClassificationId AND c2.ClassificationLevelId > 0
),

-- base mapping from Fund to Budget Strategy
BudgetStrategyBase AS (
    SELECT
        f.FundId,
        COALESCE(f.BudgetStrategyId, e.BudgetStrategyId, bcm.BudgetStrategyId) AS BaseBudgetStrategyId,
        f.isCoinvest
    FROM Fund f
    JOIN Entity e ON e.EntityId = f.EntityId
    JOIN vwClassificationMap cm ON cm.HMCObjectId = f.FundId
    LEFT JOIN BudgetStrategyClassificationMapExpanded bcm
        ON cm.Level1Description = bcm.AssetClass
        AND (bcm.Strategy IS NULL OR COALESCE(bcm.Strategy, '') = COALESCE(cm.Level2Description, ''))
)

-- Strategy Assignment
SELECT
    b.FundId,
    CASE
        WHEN NOT b.isCoinvest THEN b.BaseBudgetStrategyId
        ELSE CASE
            WHEN b.BaseBudgetStrategyId = 3 THEN 4
            WHEN b.BaseBudgetStrategyId = 5 THEN 6
            WHEN b.BaseBudgetStrategyId IN (9, 10) THEN 14
            WHEN b.BaseBudgetStrategyId = 11 THEN 15
            WHEN b.BaseBudgetStrategyId = 16 THEN 18
            WHEN b.BaseBudgetStrategyId = 20 THEN 21
            WHEN b.BaseBudgetStrategyId = 17 THEN 22
            ELSE b.BaseBudgetStrategyId
        END
    END AS BudgetStrategyId,
    CASE
        WHEN NOT b.isCoinvest THEN bs.Description
        ELSE CASE
            WHEN b.BaseBudgetStrategyId = 3 THEN bs4.Description
            WHEN b.BaseBudgetStrategyId = 5 THEN bs6.Description
            WHEN b.BaseBudgetStrategyId IN (9, 10) THEN bs14.Description
            WHEN b.BaseBudgetStrategyId = 11 THEN bs15.Description
            WHEN b.BaseBudgetStrategyId = 16 THEN bs18.Description
            WHEN b.BaseBudgetStrategyId = 20 THEN bs21.Description
            WHEN b.BaseBudgetStrategyId = 17 THEN bs22.Description
            ELSE bs.Description
        END
    END AS BudgetStrategy
FROM BudgetStrategyBase b
JOIN BudgetStrategy bs ON bs.BudgetStrategyId = b.BaseBudgetStrategyId
LEFT JOIN BudgetStrategy bs4 ON bs4.BudgetStrategyId = 4
LEFT JOIN BudgetStrategy bs6 ON bs6.BudgetStrategyId = 6
LEFT JOIN BudgetStrategy bs14 ON bs14.BudgetStrategyId = 14
LEFT JOIN BudgetStrategy bs15 ON bs15.BudgetStrategyId = 15
LEFT JOIN BudgetStrategy bs18 ON bs18.BudgetStrategyId = 18
LEFT JOIN BudgetStrategy bs21 ON bs21.BudgetStrategyId = 21
LEFT JOIN BudgetStrategy bs22 ON bs22.BudgetStrategyId = 22
JOIN Fund f ON f.FundId = b.FundId
WHERE f.FundStructureId <> 0
""")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#wrte the df to the Delta table
df_final.write.format("delta").mode("overwrite").save(target_path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
