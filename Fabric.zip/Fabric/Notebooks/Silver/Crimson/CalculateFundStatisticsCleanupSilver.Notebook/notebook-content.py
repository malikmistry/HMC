# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import decimal
import requests
from datetime import date, datetime
from requests.exceptions import HTTPError, ConnectionError, Timeout, RequestException
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, DecimalType, DateType, StringType, IntegerType, LongType
from pyspark.sql.functions import to_date, lower
from delta.tables import DeltaTable

spark.conf.set('spark.sql.caseSensitive', True)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
CalculateFundStatisticsUrl = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
CalculateFundStatisticsUrl = "https://winfunctionappdotnet-dev1.azurewebsites.net/api/CalculateFundStatistics?code=B7moEvO0QIn28NXomoZM9wCsOAlAR9BRDFtsovvyqEurAzFul14xrA=="

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./CalculateFundStatisticsSilver

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

start_time = datetime.now()
print(f"CleanupFundStatistics: {start_time.strftime('%Y-%m-%d %H:%M:%S')}" )

print(f"Deleting from ProcessFundChanges...")
delta_table = DeltaTable.forPath(spark, f"{bronze_lh_basepath}/Tables/Bronze/ProcessFundChanges")
delta_table.delete()

end_time = datetime.now()
elapsed = end_time - start_time  # Returns a timedelta
print("Total elapsed time:", elapsed)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

