# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""
NotebookName = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "{\"JobAuditKey\":537,\"TaskKey\":116,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"CrimsonXFundTrade\",\"SinkTableName\":\"FundTrade\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"14\",\"NotebookName\":\"FundTradeSilver\",\"SinkLakehouseName\":\"lh_curated\"}"
NotebookName = "FundTradeSilver"
LakehouseName = "lh_curated"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#we will attach the sinklakehouse to the notebook
if LakehouseName == 'lh_bronze':
    LakehouseId = BronzeLHId
elif LakehouseName == 'lh_curated':
    LakehouseId = CuratedLHId

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

 %%sql
 CREATE TABLE IF NOT EXISTS Silver.FundTrade(
 	FundTradeType varchar(8000) NOT NULL,
 	FundTradeStatus varchar(8000) NOT NULL,
 	VerbalCommitmentDate date,
 	CommitmentDate date NOT NULL,
 	TradeAmountLocal decimal(38, 2),
	TradeAmountUSD decimal(38,2),
 	CurrencyId int NOT NULL,
 	CompletedDate date ,
 	IsFullRedemption BOOLEAN ,
 	ExecutiveSignoffHMCUserId varchar(256),
	ExecutiveSignoff varchar(250),
	ExecutiveSignoffInitials varchar(2),
 	ExecutiveSignoffDate TIMESTAMP,
 	InvestmentSignoffHMCUserId varchar(256),
	InvestmentSignoff varchar(250),
	InvestmentSignoffInitials varchar(2),
 	InvestmentSignoffDate TIMESTAMP,		
 	ODDSignoffHMCUserId varchar(256) ,
	ODDSignoff varchar(250),
	ODDSignoffInitials varchar(2),	
 	ODDSignoffDate TIMESTAMP,
 	LegalSignoffHMCUserId varchar(256) ,
	LegalSignoff varchar(250),
	LegalSignoffInitials varchar(2),	
 	LegalSignoffDate TIMESTAMP,
 	FinalOperationsSignoffHMCUserId varchar(256) ,
	FinalOperationsSignoff varchar(250),
	FinalOperationsSignoffInitials varchar(2),		
 	FinalOperationsSignoffDate TIMESTAMP,
 	FundTradeId varchar(36) NOT NULL,
 	FundId varchar(36) NOT NULL,
 	FundTradeStatusId int  NOT NULL,
 	ETLLoadDateTime timestamp NOT NULL 
 )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tasklist = json.loads(f"{TaskList}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def is_df_empty(df, column_name=None, excluded_value=None):
    if column_name is not None and excluded_value is not None:
        df = df.filter(col(column_name) != excluded_value)
    return df.limit(1).count() == 0

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# 
# **Process Fund Trade Silver Table**

# CELL ********************

def process_task(task,bronze_lh_id,curated_lh_id):
    try:
        source_path = f"{bronze_lh_id}/Tables/{task['SourceSchemaName']}/{task['SourceTableName']}"
        target_path = f"{curated_lh_id}/Tables/{task['SinkSchemaName']}/{task['SinkTableName']}"
        # datetime_col = 'Date_Time'
        print(source_path)
        print(target_path)


        #Read table path
        bronzefundtradestatus_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXFundTradeStatus"
        bronzefundtradetype_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXFundTradeType"
        bronzefund_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXFund"
        bronzecurrency_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXCurrency"
        bronzefundtradeapproval_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXFundTradeApproval"
        silverhmcuser_path = f"{curated_lh_basepath}/Tables/Silver/HMCUser"
        silverfxrate_path = f"{curated_lh_basepath}/Tables/Silver/FXRate"        


        today_date = date.today()
        today_str = date.today().strftime('%Y-%m-%d')
        #yesterday_str = (today_str - timedelta(days=1)).strftime('%Y-%m-%d')
        # Set watermark
        #etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        # TRY Read source
        try:
            df_source = spark.read.format("delta").load(source_path)
            df_source.createOrReplaceTempView("src")

            df_bronzefundtradestatus = spark.read.format("delta").load(bronzefundtradestatus_path)
            df_bronzefundtradestatus.createOrReplaceTempView("CrimsonXFundTradeStatus")
            df_bronzefundtradetype = spark.read.format("delta").load(bronzefundtradetype_path)
            df_bronzefundtradetype.createOrReplaceTempView("CrimsonXFundTradeType")
            df_bronzefund = spark.read.format("delta").load(bronzefund_path)
            df_bronzefund.createOrReplaceTempView("CrimsonXFund")
            df_bronzecurrency = spark.read.format("delta").load(bronzecurrency_path)
            df_bronzecurrency.createOrReplaceTempView("CrimsonXCurrency")
            df_silverfxrate = spark.read.format("delta").load(silverfxrate_path)
            df_silverfxrate.createOrReplaceTempView("FXRate")
            df_bronzefundtradeapproval = spark.read.format("delta").load(bronzefundtradeapproval_path)
            df_bronzefundtradeapproval.createOrReplaceTempView("CrimsonXFundTradeApproval")
            df_silveruser = spark.read.format("delta").load(silverhmcuser_path)
            df_silveruser.createOrReplaceTempView("HMCUser")            
            
            # Spark SQL
            query = f"""
                SELECT ftty.Description AS FundTradeType
                       ,fts.Description AS FundTradeStatus
                       ,ft.VerbalCommitmentDate
                       ,ft.CommitmentDate
                       ,CAST(ft.TradeAmountLocal * 1000000 AS DECIMAL(38,2)) AS TradeAmountLocal
                       ,CAST((CAST(ft.TradeAmountLocal * 1000000 AS DECIMAL(38,2)) * fx.FXRate) AS DECIMAL(38,2)) AS TradeAmountUSD
                       ,C.CurrencyId
                       ,ft.CompletedDate
                       ,ft.IsFullRedemption
                       ,ftexe.SignoffHMCUserId AS ExecutiveSignoffHMCUserId
                       ,ehu.DisplayName as ExecutiveSignoff
                       ,ehu.Initials as ExecutiveSignoffInitials                       
                       ,ftexe.SignoffDate AS ExecutiveSignoffDate
                       ,ftidd.SignoffHMCUserId AS InvestmentSignoffHMCUserId
	                   ,ihu.DisplayName as InvestmentSignoff
	                   ,ihu.Initials as InvestmentSignoffInitials                       
                       ,ftidd.SignoffDate AS InvestmentSignoffDate
                       ,ftodd.SignoffHMCUserId AS ODDSignoffHMCUserId
	                   ,ohu.DisplayName as ODDSignoff
	                   ,ohu.Initials as ODDSignoffInitials
                       ,ftodd.SignoffDate AS ODDSignoffDate
                       ,ftldd.SignoffHMCUserId AS LegalSignoffHMCUserId
                       ,lhu.DisplayName as LegalSignoff
                       ,lhu.Initials as LegalSignoffInitials
                       ,ftldd.SignoffDate AS LegalSignoffDate
                       ,ftops.SignoffHMCUserId AS FinalOperationsSignoffHMCUserId
                       ,fthu.DisplayName as FinalOperationsSignoff
                       ,fthu.Initials as FinalOperationsSignoffInitials
                       ,ftops.SignoffDate AS FinalOperationsSignoffDate
                       ,CAST(ft.FundTradeId AS VARCHAR(36)) AS FundTradeId, CAST(ft.FundId AS VARCHAR(36)) AS FundId
                       ,ft.FundTradeStatusId
                       ,current_timestamp AS ETLLoadDateTime
                FROM src ft
                        LEFT JOIN CrimsonXFundTradeStatus fts ON fts.FundTradeStatusId = ft.FundTradeStatusId
                        LEFT JOIN CrimsonXFundTradeType ftty ON ftty.FundTradeTypeId = ft.FundTradeTypeId
                        JOIN CrimsonXFund F ON F.FundId = ft.FundId
                        JOIN CrimsonXCurrency C ON C.CurrencyId = ft.CurrencyId
                        JOIN FXRate fx ON fx.CurrencyId = C.CurrencyId AND fx.IsLatest = 1
                        LEFT OUTER join CrimsonXFundTradeApproval AS ftexe ON ftexe.FundTradeId = ft.FundTradeId AND ftexe.FundTradeApprovalTypeId = 1
                        LEFT OUTER join CrimsonXFundTradeApproval AS ftidd ON ftidd.FundTradeId = ft.FundTradeId AND ftidd.FundTradeApprovalTypeId = 2
                        LEFT OUTER join CrimsonXFundTradeApproval AS ftodd ON ftodd.FundTradeId = ft.FundTradeId AND ftodd.FundTradeApprovalTypeId = 3
                        LEFT OUTER join CrimsonXFundTradeApproval AS ftldd ON ftldd.FundTradeId = ft.FundTradeId AND ftldd.FundTradeApprovalTypeId = 4
                        LEFT OUTER join CrimsonXFundTradeApproval AS ftops ON ftops.FundTradeId = ft.FundTradeId AND ftops.FundTradeApprovalTypeId = 5
                        LEFT JOIN HMCUser ehu ON ehu.HMCUserId = ftexe.SignoffHMCUserId
                        LEFT JOIN HMCUser ihu ON ihu.HMCUserId = ftidd.SignoffHMCUserId
                        LEFT JOIN HMCUser ohu ON ohu.HMCUserId = ftodd.SignoffHMCUserId
                        LEFT JOIN HMCUser lhu ON lhu.HMCUserId = ftldd.SignoffHMCUserId
                        LEFT JOIN HMCUser fthu ON fthu.HMCUserId = ftops.SignoffHMCUserId                        
                WHERE ft.IsDeleted = 0
            """

            result_df = spark.sql(query)
            #result_df.show(5)
        except Exception as e:
            raise RuntimeError(f"Source path does not exist or failed to load: {source_path}") from e
        # Write the result as a Delta table
        result_df.write.format("delta").mode("overwrite").save(target_path)
        #df_today.write.format("delta").mode("overwrite").save(target_path)
        print('Completed')
    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise RuntimeError(f"Failed") from e

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)


        # Process the task
        result = process_task(task_item,bronze_lh_basepath,curated_lh_basepath)

    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise
#abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXFundTrade

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
