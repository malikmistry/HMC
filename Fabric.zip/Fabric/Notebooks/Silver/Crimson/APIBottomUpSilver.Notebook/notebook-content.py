# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import json
from datetime import datetime, date, timedelta, timezone
from delta.tables import DeltaTable
from pyspark.sql.utils import AnalysisException
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DecimalType, DateType, TimestampType, LongType
from pyspark.sql import DataFrame
from typing import Dict
import uuid
from typing import Dict, List
from pyspark.sql.functions import (
    col, lit, trim, lower, month, year, when, current_date, current_timestamp, udf
)
import uuid
from pyspark.sql.functions import udf

spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "{\"JobAuditKey\":754,\"TaskKey\":203,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":null,\"SourceTableName\":null,\"SinkTableName\":null,\"SinkSchemaName\":\"Bronze\",\"NotebookKeyNotebookKey\":\"19\",\"NotebookName\":\"APIBottomUpBronze\",\"SinkLakehouseName\":\"lh_bronze\",\"RawStoragePath\":\"HMCReport\",\"RawStorageFileName\":\"FundLevelCalc.json\"}"
NotebookName = "APIBottomUpBronze"
LakehouseName = "lh_bronze"
RawLHId = "920a12cc-7104-4013-a2a3-d7baa57e9e3f"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""
NotebookName = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark",
# META   "frozen": true,
# META   "editable": false
# META }

# CELL ********************

tasklist = json.loads(f"{TaskList}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
print(etlloadtime)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS Silver.EntityAllocations(
# MAGIC 
# MAGIC               EntityId VARCHAR(36) NOT NULL
# MAGIC               , EntityAllocationId VARCHAR(36) NOT NULL
# MAGIC               , ReportFrequencyId INT NOT NULL
# MAGIC               , BudgetStrategyId INT NOT NULL
# MAGIC               , AllocatedDate DATE NOT NULL
# MAGIC               , AllocationAge INT NOT NULL
# MAGIC               , AllocationYear INT NOT NULL
# MAGIC               , CommitmentAmount DECIMAL(38, 2)
# MAGIC               , CallAmount DECIMAL(38, 2)
# MAGIC               , CallPercent DECIMAL(38, 6)
# MAGIC               , DistributionAmount DECIMAL(38, 2)
# MAGIC               , DistributionPercent DECIMAL(38, 6)
# MAGIC               , FMVAmount DECIMAL(38, 2)
# MAGIC               , FMVPercent DECIMAL(38, 6)
# MAGIC               , MarketValue DECIMAL(38,2)
# MAGIC               , UnfundedAmount DECIMAL(38, 2)
# MAGIC               , UnfundedPercent DECIMAL(38, 6)
# MAGIC               , AsOfDate DATE NOT NULL
# MAGIC               , ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC 
# MAGIC )
# MAGIC 
# MAGIC  

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS Silver.FundBudget(
# MAGIC               FundId VARCHAR(36) NOT NULL
# MAGIC               , FundBudgetId VARCHAR(36) NOT NULL
# MAGIC               , ReportFrequencyId INT NOT NULL
# MAGIC               , BudgetType VARCHAR(50) NOT NULL
# MAGIC               , BudgetStrategyId INT NOT NULL
# MAGIC               , BudgetDate DATE NOT NULL
# MAGIC               , BudgetAge INT NOT NULL
# MAGIC               , BudgetFiscalYear INT NOT NULL
# MAGIC               , CommitmentAmount DECIMAL(38, 2)
# MAGIC               , CallAmount DECIMAL(38, 2)
# MAGIC               , CallPercent DECIMAL(38, 6)
# MAGIC               , DistributionAmount DECIMAL(38, 2)
# MAGIC               , DistributionPercent DECIMAL(38, 6)
# MAGIC               , FMVAmount DECIMAL(38, 2)
# MAGIC               , FMVPercent DECIMAL(38, 6)
# MAGIC               , MarketValue DECIMAL(38,2)
# MAGIC               , UnfundedAmount DECIMAL(38, 2)
# MAGIC               , UnfundedPercent DECIMAL(38, 6)
# MAGIC               , AsOfDate DATE NOT NULL
# MAGIC               , ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC 
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS Silver.BudgetIncremental(
# MAGIC               BudgetCategoryId INT NOT NULL       
# MAGIC               , BudgetIncrementalId VARCHAR(36) NOT NULL
# MAGIC               , BudgetCategoryName VARCHAR(100) NOT NULL
# MAGIC               , ReportFrequencyId INT NOT NULL
# MAGIC               , IncrementalDate DATE NOT NULL
# MAGIC               , IncrementalAge INT NOT NULL
# MAGIC               , IncrementalFiscalYear INT NOT NULL
# MAGIC               , CommitmentAmount DECIMAL(38, 2)
# MAGIC               , CallAmount DECIMAL(38, 2)
# MAGIC               , CallPercent DECIMAL(38, 6)
# MAGIC               , DistributionAmount DECIMAL(38, 2)
# MAGIC               , DistributionPercent DECIMAL(38, 6)
# MAGIC               , FMVAmount DECIMAL(38, 2)
# MAGIC               , FMVPercent DECIMAL(38, 6)
# MAGIC               , MarketValue DECIMAL(38,2)
# MAGIC               , UnfundedAmount DECIMAL(38, 2)
# MAGIC               , UnfundedPercent DECIMAL(38, 6)
# MAGIC               , AsOfDate DATE NOT NULL
# MAGIC               , ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC 
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# FundBudget schema
fund_budget_schema = StructType([
    StructField("FundId", StringType(), False),
    StructField("FundBudgetId", StringType(), False),
    StructField("ReportFrequencyId", IntegerType(), False),
    StructField("BudgetType", StringType(), False),
    StructField("BudgetStrategyId", IntegerType(), False),
    StructField("BudgetDate", DateType(), False),
    StructField("BudgetAge", IntegerType(), False),
    StructField("BudgetFiscalYear", IntegerType(), False),
    StructField("CommitmentAmount", DecimalType(38, 2), True),
    StructField("CallAmount", DecimalType(38, 2), True),
    StructField("CallPercent", DecimalType(38, 6), True),
    StructField("DistributionAmount", DecimalType(38, 2), True),
    StructField("DistributionPercent", DecimalType(38, 6), True),
    StructField("FMVAmount", DecimalType(38, 2), True),
    StructField("FMVPercent", DecimalType(38, 6), True),
    StructField("MarketValue", DecimalType(38, 2), True),
    StructField("UnfundedAmount", DecimalType(38, 2), True),
    StructField("UnfundedPercent", DecimalType(38, 6), True),
    StructField("AsOfDate", DateType(), False),
    StructField("ETLLoadDateTime", TimestampType(), False)
])


# EntityAllocations schema
entity_allocations_schema = StructType([
    StructField("EntityId", StringType(), False),
    StructField("EntityAllocationId", StringType(), False),
    StructField("ReportFrequencyId", IntegerType(), False),
    StructField("BudgetStrategyId", IntegerType(), False),
    StructField("AllocatedDate", DateType(), False),
    StructField("AllocationAge", IntegerType(), False),
    StructField("AllocationYear", IntegerType(), False),
    StructField("CommitmentAmount", DecimalType(38, 2), True),
    StructField("CallAmount", DecimalType(38, 2), True),
    StructField("CallPercent", DecimalType(38, 6), True),
    StructField("DistributionAmount", DecimalType(38, 2), True),
    StructField("DistributionPercent", DecimalType(38, 6), True),
    StructField("FMVAmount", DecimalType(38, 2), True),
    StructField("FMVPercent", DecimalType(38, 6), True),
    StructField("MarketValue", DecimalType(38, 2), True),
    StructField("UnfundedAmount", DecimalType(38, 2), True),
    StructField("UnfundedPercent", DecimalType(38, 6), True),
    StructField("AsOfDate", DateType(), False),
    StructField("ETLLoadDateTime", TimestampType(), False)
])


# BudgetStrategyIncrementals schema
budget_incremental_schema = StructType([
    StructField("BudgetCategoryId", IntegerType(), False),
    StructField("BudgetIncrementalId", StringType(), False),
    StructField("BudgetCategoryName", StringType(), False),
    StructField("ReportFrequencyId", IntegerType(), False),
    StructField("IncrementalDate", DateType(), False),
    StructField("IncrementalAge", IntegerType(), False),
    StructField("IncrementalFiscalYear", IntegerType(), False),
    StructField("CommitmentAmount", DecimalType(38, 2), True),
    StructField("CallAmount", DecimalType(38, 2), True),
    StructField("CallPercent", DecimalType(38, 6), True),
    StructField("DistributionAmount", DecimalType(38, 2), True),
    StructField("DistributionPercent", DecimalType(38, 6), True),
    StructField("FMVAmount", DecimalType(38, 2), True),
    StructField("FMVPercent", DecimalType(38, 6), True),
    StructField("MarketValue", DecimalType(38, 2), True),
    StructField("UnfundedAmount", DecimalType(38, 2), True),
    StructField("UnfundedPercent", DecimalType(38, 6), True),
    StructField("AsOfDate", DateType(), False),
    StructField("ETLLoadDateTime", TimestampType(), False)
])


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def delta_table_exists(path: str) -> bool:
    return DeltaTable.isDeltaTable(spark, path)

def delete_if_exists(path: str, condition: str):
    if delta_table_exists(path):
        spark.sql(f"DELETE FROM delta.`{path}` WHERE {condition}")

def write_delta(df, path: str, mode: str = "append"):
    df.write.format("delta").mode(mode).save(path)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# from pyspark.sql import functions as F
# from pyspark.sql.functions import col, lit, trim, lower, month, year, when
# from typing import Dict, List
# from pyspark.sql.types import StructType

# def process_task(
#     column_mapping: Dict[str, str],
#     target_schema: StructType,
#     target_path: str,
#     write_mode: str = "append",
#     surrogate_key_col: str = None,
#     not_null_columns: List[str] = None,  # array of required NOT NULL cols
# ) -> None:

#     # Explicit apiSource-to-frequency mapping
#     api_source_to_frequency = {
#         "FundLevelCalc": "Year",
#         "FundLevelCalcMonthly": "Month",
#     }
#     default_frequency = "Month"

#     # Load Bronze tables
#     bottomup_bronze = (
#         spark.read.format("delta")
#         .load(f"{bronze_lh_basepath}/Tables/Bronze/BottomUp")
#         .alias("bu")
#     )
#     bumonth_bronze = (
#         spark.read.format("delta")
#         .load(f"{bronze_lh_basepath}/Tables/Bronze/BottomUpMonthComponent")
#         .alias("bumonth")
#     )
#     buyear_bronze = (
#         spark.read.format("delta")
#         .load(f"{bronze_lh_basepath}/Tables/Bronze/BottomUpYearComponent")
#         .alias("buyear")
#     )
#     fundtype = (
#         spark.read.format("delta")
#         .load(f"{bronze_lh_basepath}/Tables/Bronze/FundType")
#         .alias("ft")
#     )
#     reportfreq = (
#         spark.read.format("delta")
#         .load(f"{bronze_lh_basepath}/Tables/Bronze/ReportFrequency")
#         .alias("rf")
#     )
#     rundetails = (
#         spark.read.format("delta")
#         .load(f"{bronze_lh_basepath}/Tables/Bronze/BottomUpRunDetails")
#         .alias("rundet")
#     )

#     # Get AsOfDate from rundetails
#     as_of_date = (
#         rundetails.select("asOfDate").first()["asOfDate"]
#         if "asOfDate" in rundetails.columns
#         else None
#     )

#     if as_of_date is not None:
#         bottomup_bronze = bottomup_bronze.filter(col("AsOfDate") == as_of_date)

#     # Join tables
#     df_joined = (
#         bottomup_bronze
#         .join(bumonth_bronze, on="rowId", how="left")
#         .join(buyear_bronze, on="rowId", how="left")
#         .join(
#             fundtype,
#             trim(lower(bottomup_bronze["calcType"])) == trim(lower(fundtype["Description"])),
#             how="left",
#         )
#     )

#     # Get frequency from rundetails
#     api_source_value = (
#         rundetails.select("apiSource").first()["apiSource"]
#         if "apiSource" in rundetails.columns
#         else None
#     )
#     frequency_label = api_source_to_frequency.get(api_source_value, default_frequency)

#     df_joined = df_joined.withColumn("ReportFrequency", lit(frequency_label))
#     df_joined = df_joined.join(
#         reportfreq, df_joined["ReportFrequency"] == reportfreq["Description"], how="left"
#     )

#     # Extract ReportingMonth and ReportingYear
#     df_joined = (
#         df_joined.withColumn(
#             "Month",
#             when(col("ReportFrequency") == "Year", lit(7)).when(
#                 col("ReportFrequency") == "Month", month(col("AsOfDate"))
#             ),
#         )
#         .withColumn(
#             "Year",
#             when(col("ReportFrequency") == "Year", year(col("AsOfDate"))).when(
#                 col("ReportFrequency") == "Month", year(col("AsOfDate"))
#             ),
#         )
#     )

#     # Select and rename according to mapping
#     df_selected = df_joined.select(
#         [col(src).alias(dst) for src, dst in column_mapping.items()]
#     )

#     # Cast columns to match schema
#     for field in target_schema.fields:
#         if field.name in df_selected.columns:
#             df_selected = df_selected.withColumn(
#                 field.name, col(field.name).cast(field.dataType)
#             )

#     # Enforce NOT NULL filters
#     if not_null_columns:
#         for c in not_null_columns:
#             if c in df_selected.columns:
#                 df_selected = df_selected.filter(col(c).isNotNull())

#     # Add surrogate key if specified
#     if surrogate_key_col:
#         df_selected = df_selected.withColumn(surrogate_key_col, uuid_udf())

#     # Add audit columns
#     df_selected = (
#         df_selected.withColumn("AsOfDate", lit(as_of_date))
#         .withColumn("ETLLoadDateTime", lit(etlloadtime))
#     )

#     # Deduplicate by ReportFrequency if applicable
#     report_frequency_current = (
#         df_selected.select("ReportFrequencyId").first()["ReportFrequencyId"]
#         if "ReportFrequencyId" in df_selected.columns
#         else None
#     )
#     condition = f"ReportFrequency = {report_frequency_current}" if report_frequency_current else None

#     if condition:
#         delete_if_exists(target_path, condition)

#     # Write to Delta
#     write_delta(df_selected, target_path)

#     print(f"Table written to: {target_path}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************



def build_target_df(target: str, bottomup_bronze, buyear_bronze, bumonth_bronze, as_of_date, etlloadtime):
    """
    Build DataFrame for each target using source table aliases.
    """
    if target == "EntityAllocations":
        # Yearly
        yearly = (
            bottomup_bronze.alias("bu")
            .join(buyear_bronze.alias("yc"), "rowId")
            .filter((F.col("bu.calcType") == "Allocated") & (F.col("bu.ReportFrequencyId") == 1))
            .select(
                F.col("bu.entityId").alias("EntityId"),
                F.col("yc.rowId").alias("EntityAllocationId"),
                F.lit(1).alias("ReportFrequencyId"),
                F.col("bu.budgetStrategyId").alias("BudgetStrategyId"),
                F.col("bu.inceptionDate").alias("AllocatedDate"),
                F.col("yc.age").alias("AllocationAge"),
                F.col("yc.year").alias("AllocationYear"),
                F.col("yc.commit").alias("CommitmentAmount"),
                F.col("yc.callPct").alias("CallPercent"),
                F.col("yc.callAmt").alias("CallAmount"),
                F.col("yc.distPct").alias("DistributionPercent"),
                F.col("yc.distAmt").alias("DistributionAmount"),
                F.col("yc.fmvAmt").alias("FMVAmount"),
                F.col("yc.fmvPct").alias("FMVPercent"),
                F.col("yc.mktVal").alias("MarketValue"),
                F.col("yc.unfunded").alias("UnfundedAmount"),
                F.col("yc.unfundedPercent").alias("UnfundedPercent"),
                F.lit(as_of_date).alias("AsOfDate"),
                F.lit(etlloadtime).alias("ETLLoadDateTime"),
            )
        )

        # Monthly
        monthly = (
            bumonth_bronze.alias("m")
            .join(bottomup_bronze.alias("bu"), "rowId")
            .filter(F.col("bu.calcType") == "Allocated")
            .select(
                F.col("entityId").alias("EntityId"),
                F.col("rowId").alias("EntityAllocationId"),
                F.lit(2).alias("ReportFrequencyId"),
                F.col("budgetStrategyId").alias("BudgetStrategyId"),
                F.col("date").alias("AllocatedDate"),
                F.col("age").alias("AllocationAge"),
                F.col("fiscalYear").alias("AllocationYear"),
                F.coalesce(F.col("commitment"), F.col("originalCommitment")).alias("CommitmentAmount"),
                F.col("CallPct").alias("CallPercent"),
                F.col("CallAmt").alias("CallAmount"),
                F.col("DistPct").alias("DistributionPercent"),
                F.col("DistAmt").alias("DistributionAmount"),
                F.col("FmvAmt").alias("FMVAmount"),
                F.col("FmvPct").alias("FMVPercent"),
                F.col("MktVal").alias("MarketValue"),
                F.col("Unfunded").alias("UnfundedAmount"),
                F.col("UnfundedPct").alias("UnfundedPercent"),
                F.lit(as_of_date).alias("AsOfDate"),
                F.lit(etlloadtime).alias("ETLLoadDateTime"),
            )
        )

        return yearly.unionByName(monthly)

    elif target == "FundBudget":
        # Yearly
        yearly = (
            bottomup_bronze.alias("bu")
            .join(buyear_bronze.alias("yc"), "rowId")
            .filter(
                (F.col("bu.calcType").isin("PublicDrawdown", "Uncategorized", "SidePocket", "Existing")) &
                (F.col("bu.ReportFrequencyId") == 1)
            )
            .select(
                F.col("bu.fundId").alias("FundId"),
                F.col("yc.rowId").alias("FundBudgetId"),
                F.lit(1).alias("ReportFrequencyId"),
                F.col("bu.calcType").alias("BudgetType"),
                F.col("bu.budgetStrategyId").alias("BudgetStrategyId"),
                F.expr("date_add(add_months(bu.inceptionDate, (yc.age-1)*12), 0)").alias("BudgetDate"),
                F.col("yc.age").alias("BudgetAge"),
                F.col("yc.year").alias("BudgetFiscalYear"),
                F.col("yc.commit").alias("CommitmentAmount"),
                F.col("yc.callPct").alias("CallPercent"),
                F.col("yc.callAmt").alias("CallAmount"),
                F.col("yc.distPct").alias("DistributionPercent"),
                F.col("yc.distAmt").alias("DistributionAmount"),
                F.col("yc.fmvAmt").alias("FMVAmount"),
                F.col("yc.fmvPct").alias("FMVPercent"),
                F.col("yc.mktVal").alias("MarketValue"),
                F.col("yc.unfunded").alias("UnfundedAmount"),
                F.col("yc.unfundedPercent").alias("UnfundedPercent"),
                F.lit(as_of_date).alias("AsOfDate"),
                F.lit(etlloadtime).alias("ETLLoadDateTime"),
            )
        )

        # Monthly
        monthly = (
            bumonth_bronze.alias("m")
            .join(bottomup_bronze.alias("bu"), "rowId")
            .filter(F.col("bu.calcType").isin("PublicDrawdown", "Uncategorized", "SidePocket", "Existing"))
            .select(
                F.col("fundId").alias("FundId"),
                F.col("rowId").alias("FundBudgetId"),
                F.lit(2).alias("ReportFrequencyId"),
                F.col("calcType").alias("BudgetType"),
                F.col("budgetStrategyId").alias("BudgetStrategyId"),
                F.col("date").alias("BudgetDate"),
                F.col("age").alias("BudgetAge"),
                F.col("fiscalYear").alias("BudgetFiscalYear"),
                F.coalesce(F.col("commitment"), F.col("originalCommitment")).alias("CommitmentAmount"),
                F.col("CallPct").alias("CallPercent"),
                F.col("CallAmt").alias("CallAmount"),
                F.col("DistPct").alias("DistributionPercent"),
                F.col("DistAmt").alias("DistributionAmount"),
                F.col("FmvAmt").alias("FMVAmount"),
                F.col("FmvPct").alias("FMVPercent"),
                F.col("MktVal").alias("MarketValue"),
                F.col("Unfunded").alias("UnfundedAmount"),
                F.col("UnfundedPct").alias("UnfundedPercent"),
                F.lit(as_of_date).alias("AsOfDate"),
                F.lit(etlloadtime).alias("ETLLoadDateTime"),
            )
        )

        df = yearly.unionByName(monthly)
        return df

    elif target == "BudgetIncremental":
        # Yearly
        yearly = (
            bottomup_bronze.alias("bu")
            .join(buyear_bronze.alias("yc"), "rowId")
            .filter(
                (F.col("bu.calcType") == "Incremental") &
                (F.col("bu.ReportFrequencyId") == 1)
            )
            .select(
                F.col("bu.budgetCategoryId").alias("BudgetCategoryId"),
                F.col("bu.budgetCategoryName").alias("BudgetCategoryName"),
                F.col("bu.rowId").alias("BudgetIncrementalId"),
                F.lit(1).alias("ReportFrequencyId"),
                F.col("bu.inceptionDate").alias("IncrementalDate"),
                F.col("yc.age").alias("IncrementalAge"),
                F.col("yc.year").alias("IncrementalFiscalYear"),
                F.col("yc.commit").alias("CommitmentAmount"),
                F.col("yc.callPct").alias("CallPercent"),
                F.col("yc.callAmt").alias("CallAmount"),
                F.col("yc.distPct").alias("DistributionPercent"),
                F.col("yc.distAmt").alias("DistributionAmount"),
                F.col("yc.fmvAmt").alias("FMVAmount"),
                F.col("yc.fmvPct").alias("FMVPercent"),
                F.col("yc.mktVal").alias("MarketValue"),
                F.col("yc.unfunded").alias("UnfundedAmount"),
                F.col("yc.unfundedPercent").alias("UnfundedPercent"),
                F.lit(as_of_date).alias("AsOfDate"),
                F.lit(etlloadtime).alias("ETLLoadDateTime"),
            )
        )

        # Monthly
        monthly = (
            bumonth_bronze.alias("m")
            .join(bottomup_bronze.alias("bu"), "rowId")
            .filter(F.col("bu.calcType") == "Incremental")
            .select(
                F.col("budgetCategoryId").alias("BudgetCategoryId"),
                F.col("budgetCategoryName").alias("BudgetCategoryName"),
                F.col("rowId").alias("BudgetIncrementalId"),
                F.lit(2).alias("ReportFrequencyId"),
                F.col("date").alias("IncrementalDate"),
                F.col("age").alias("IncrementalAge"),
                F.col("fiscalYear").alias("IncrementalFiscalYear"),
                F.coalesce(F.col("commitment"), F.col("originalCommitment")).alias("CommitmentAmount"),
                F.col("CallPct").alias("CallPercent"),
                F.col("CallAmt").alias("CallAmount"),
                F.col("DistPct").alias("DistributionPercent"),
                F.col("DistAmt").alias("DistributionAmount"),
                F.col("FmvAmt").alias("FMVAmount"),
                F.col("FmvPct").alias("FMVPercent"),
                F.col("MktVal").alias("MarketValue"),
                F.col("Unfunded").alias("UnfundedAmount"),
                F.col("UnfundedPct").alias("UnfundedPercent"),
                F.lit(as_of_date).alias("AsOfDate"),
                F.lit(etlloadtime).alias("ETLLoadDateTime"),
            )
        )

        df = yearly.unionByName(monthly)
        return df

    else:
        raise ValueError(f"Unsupported target: {target}")



def process_task(
    target_schema: StructType,
    target: str,
    target_path: str,
    bronze_lh_basepath: str,
    etlloadtime,
    write_mode: str = "append",
    surrogate_key_col: str = None,
    not_null_columns: List[str] = None,
    task = None
) -> None:

    # Load Bronze tables
    bottomup_bronze = spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/BottomUp")
    buyear_bronze   = spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/BottomUpYearComponent")
    bumonth_bronze  = spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/BottomUpMonthComponent")
    rundetails      = spark.read.format("delta").load(f"{bronze_lh_basepath}/Tables/Bronze/BottomUpRunDetails")
    
    # Define a UDF to generate UUIDs
    uuid_udf = udf(lambda: str(uuid.uuid4()), StringType())

    # AsOfDate
    as_of_date = rundetails.select("asOfDate").first()["asOfDate"] if "asOfDate" in rundetails.columns else None

    # Build df per target with proper aliases
    df = build_target_df(target, bottomup_bronze, buyear_bronze, bumonth_bronze, as_of_date, etlloadtime)
    df_selected = df

    schema_cols = [f.name for f in target_schema.fields]

    # Force-cast all fields in schema to target types
    for field in target_schema.fields:
        df_selected = df_selected.withColumn(field.name, F.col(field.name).cast(field.dataType))


    # Enforce NOT NULL constraints
    if not_null_columns:
        for c in not_null_columns:
            if c in df_selected.columns:
                df_selected = df_selected.filter(col(c).isNotNull())

    # Add surrogate key column if required
    if surrogate_key_col:
        df_selected = df_selected.withColumn(surrogate_key_col, uuid_udf())

    df_selected = df_selected.dropDuplicates(df_selected.columns)

    # Write
    if not DeltaTable.isDeltaTable(spark, target_path):
        df_selected.write.format("delta").mode("append").save(target_path)
    else:
        # This is a daily reload so trunating the table completely
        spark.sql(f"TRUNCATE TABLE lh_curated.Silver.{target}")
        df_selected.write.format("delta").mode(write_mode).save(target_path)
    print(f"Table written to: {target_path}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # ----------------- FundBudget -----------------
# fund_budget_cm = {
#     "FundId": "FundId",
#     "FundBudgetId": "FundBudgetId",
#     "ReportFrequencyId": "ReportFrequencyId",
#     "BudgetType": "BudgetType",
#     "BudgetStrategyId": "BudgetStrategyId",
#     "BudgetDate": "BudgetDate",
#     "BudgetAge": "BudgetAge",
#     "BudgetFiscalYear": "BudgetFiscalYear",
#     "CommitmentAmount": "CommitmentAmount",
#     "CallPercent": "CallPercent",
#     "CallAmount": "CallAmount",
#     "DistributionPercent": "DistributionPercent",
#     "DistributionAmount": "DistributionAmount",
#     "FMVAmount": "FMVAmount",
#     "FMVPercent": "FMVPercent",
#     "MarketValue": "MarketValue",
#     "UnfundedAmount": "UnfundedAmount",
#     "UnfundedPercent": "UnfundedPercent",
#     "AsOfDate": "AsOfDate",
#     "ETLLoadDateTime": "ETLLoadDateTime"
# }

# # ----------------- EntityAllocations -----------------
# entity_allocations_cm = {
#     "EntityId": "EntityId",
#     "EntityAllocationId": "EntityAllocationId",
#     "ReportFrequencyId": "ReportFrequencyId",
#     "BudgetStrategyId": "BudgetStrategyId",
#     "AllocatedDate": "AllocatedDate",
#     "AllocationAge": "AllocationAge",
#     "AllocationYear": "AllocationYear",
#     "CommitmentAmount": "CommitmentAmount",
#     "CallPercent": "CallPercent",
#     "CallAmount": "CallAmount",
#     "DistributionPercent": "DistributionPercent",
#     "DistributionAmount": "DistributionAmount",
#     "FMVAmount": "FMVAmount",
#     "FMVPercent": "FMVPercent",
#     "MarketValue": "MarketValue",
#     "UnfundedAmount": "UnfundedAmount",
#     "UnfundedPercent": "UnfundedPercent",
#     "AsOfDate": "AsOfDate",
#     "ETLLoadDateTime": "ETLLoadDateTime"
# }

# # ----------------- BudgetIncremental -----------------
# budget_strategy_incrementals_cm = {
#     "BudgetCategoryId": "BudgetCategoryId",
#     "BudgetCategoryName": "BudgetCategoryName",
#     "BudgetIncrementalId": "BudgetIncrementalId",
#     "ReportFrequencyId": "ReportFrequencyId",
#     "IncrementalDate": "IncrementalDate",
#     "IncrementalAge": "IncrementalAge",
#     "IncrementalFiscalYear": "IncrementalFiscalYear",
#     "CommitmentAmount": "CommitmentAmount",
#     "CallPercent": "CallPercent",
#     "CallAmount": "CallAmount",
#     "DistributionPercent": "DistributionPercent",
#     "DistributionAmount": "DistributionAmount",
#     "FMVAmount": "FMVAmount",
#     "FMVPercent": "FMVPercent",
#     "MarketValue": "MarketValue",
#     "UnfundedAmount": "UnfundedAmount",
#     "UnfundedPercent": "UnfundedPercent",
#     "AsOfDate": "AsOfDate",
#     "ETLLoadDateTime": "ETLLoadDateTime"
# }

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([BronzeLHId, CuratedLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)
        # Process the tasks
        fund_budget = process_task(
            # column_mapping=fund_budget_cm,
            task =  task_item,
            target_schema=fund_budget_schema,
            target = 'FundBudget',
            bronze_lh_basepath = bronze_lh_basepath,
            target_path=f"{curated_lh_basepath}/Tables/Silver/FundBudget",
            etlloadtime=etlloadtime,
            not_null_columns=["FundId", "FundTypeId", "ReportFrequency", "Age", "Month", "Year"]
        )

        entity_allocations = process_task(
            # column_mapping=entity_allocations_cm,
            task =  task_item,
            target_schema=entity_allocations_schema,
            target = 'EntityAllocations',
            bronze_lh_basepath = bronze_lh_basepath,
            target_path=f"{curated_lh_basepath}/Tables/Silver/EntityAllocations",
            etlloadtime= etlloadtime,
            not_null_columns=["EntityId", "StartingAge", "ReportFrequency", "Age", "Month", "Year"]
        )

        budget_strategy_incrementals = process_task(
            # column_mapping=budget_strategy_incrementals_cm,
            task =  task_item,
            target_schema= budget_incremental_schema,
            target = 'BudgetIncremental',
            bronze_lh_basepath = bronze_lh_basepath,
            target_path=f"{curated_lh_basepath}/Tables/Silver/BudgetIncremental",
            etlloadtime= etlloadtime,
            not_null_columns=["BudgetStrategyId"]
            )

    except Exception as e:
        print(f"Error processing task: {e}")
        raise Exception


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
