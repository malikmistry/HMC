# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {}
# META }

# PARAMETERS CELL ********************

# standard parameters passed in via MDF
WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'
CalculateFundProjectedFeesUrl = "https://winfunctionappdotnet-dev1.azurewebsites.net/api/CalculateFundProjectedFees?code=7xJNiq1mbpfEsu7M-E78fYi5CVB_wKP_KWcuhUIvAoJOAzFuqQ-Mpw=="

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import decimal
import requests
import time

from datetime import datetime
from requests.exceptions import HTTPError, ConnectionError, Timeout, RequestException
from pyspark.sql import functions
from pyspark.sql.types import StructType, StructField, DecimalType, DateType, StringType, IntegerType, BooleanType
from delta.tables import DeltaTable
from urllib.parse import quote

spark.conf.set('spark.sql.caseSensitive', True)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# taken from CalculateFundLiquidityCostsSilver. Check if the logic is correct. If it's the same move to a shared notebook
def get_active_funds():
    """
    Gets all funds that have a market value OR private funds with a remaining unfunded amount.
    """
    start_time = time.perf_counter()
    # Columns
    fund_id = "FundId"
    end_balance = "EndBalance"
    as_of_date = "AsOfDate"
    unfunded_amount_local = "UnfundedAmountLocal"
    weighted_days_type_id = "WeightedDaysTypeId"
    nav_date = "NAVDate"

    fund_market_value = (
        spark.read.format("delta")
            .load(f"{curated_lh_basepath}/Tables/Silver/FundMarketValue")
    )

    max_nav_date = fund_market_value.agg(functions.max(nav_date).alias(nav_date)).first()[0]

    fund_ids_with_market_values = (
        fund_market_value.filter((F.col(end_balance) > 0) & (F.col(nav_date) == functions.lit(max_nav_date)))
        .select(fund_id)
        .distinct()
    )

    drawdown_fund_analytic_data_frame = (
        spark.read.format("delta")
            .load(f"{curated_lh_basepath}/Tables/Gold/DrawdownFundAnalytic")
    )

    max_as_of = drawdown_fund_analytic_data_frame.agg(functions.max(as_of_date).alias(as_of_date)).first()[0]

    fund_ids_with_unfunded_amount = (
        drawdown_fund_analytic_data_frame
            .filter(
                (functions.col(unfunded_amount_local) > 0) & (functions.col(as_of_date) == functions.lit(max_as_of))
            )
            .select(fund_id)
            .distinct()
    )

    fund_ids = fund_ids_with_market_values.union(fund_ids_with_unfunded_amount).distinct()

    count = fund_ids.count()
    print(f"Got {count} active fund(s) in {time.perf_counter() - start_time} seconds")

    return [r.FundId for r in fund_ids.collect()]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def retrieve_fund_projected_fees(fund_ids):
    """
    Calls the Azure function to get the projected fees for a set of funds.
    """

    projected_fees = http_post(CalculateFundProjectedFeesUrl, fund_ids)

    # Convert floats to decimals
    float_keys_to_convert = ["projectedFees"]
    projected_fees = [convert_floats_to_decimal(row, float_keys_to_convert) for row in projected_fees]

    print(f"Retrieved {len(projected_fees)} projected fee(s)")
    return projected_fees

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

start_time = datetime.now()
print(f"CalculateFundProjectedFees: {start_time.strftime('%Y-%m-%d %H:%M:%S')}" )

fund_ids = get_active_funds()
retrieve_fund_projected_fees(fund_ids)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
