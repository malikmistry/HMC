# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""
NotebookName = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "{\"JobAuditKey\":537,\"TaskKey\":116,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"CrimsonXFund\",\"SinkTableName\":\"Fund\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"14\",\"NotebookName\":\"FundSilver\",\"SinkLakehouseName\":\"lh_curated\"}"
NotebookName = "FundSilver"
LakehouseName = "lh_curated"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS Silver.Fund(
# MAGIC 	FundId varchar(36) NOT NULL,
# MAGIC 	FundName varchar(8000) NOT NULL,
# MAGIC 	EntityId varchar(36) NOT NULL,
# MAGIC 	FundStructureId int NOT NULL,
# MAGIC 	FundStructure varchar(100),
# MAGIC 	FundStatusId int NOT NULL,
# MAGIC 	FundStatus varchar(100),
# MAGIC 	InvestmentFormId int,
# MAGIC 	InvestmentForm varchar(100),
# MAGIC 	MarketClassification varchar(10),
# MAGIC 	VintageYear int,
# MAGIC 	IsFundShorted boolean,
# MAGIC 	CalculationMethodologyId int,
# MAGIC 	IsCoInvest boolean,
# MAGIC 	FundValuationFrequency int,
# MAGIC 	FundCurrencyId int,
# MAGIC 	HasSideLetter boolean,
# MAGIC 	PerformanceIndexId varchar(36),
# MAGIC 	FirstCashflowDate date,
# MAGIC 	LastCashflowDate date,
# MAGIC 	FirstManagerReturnDate date,
# MAGIC 	FirstValuationDate date,
# MAGIC 	LastValuationDate date,
# MAGIC 	HMCInceptionDate date,
# MAGIC 	FirstCommitmentDate date,
# MAGIC 	LastCommitmentDate date,
# MAGIC 	IsActive boolean,
# MAGIC 	ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tasklist = json.loads(f"{TaskList}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def is_df_empty(df, column_name=None, excluded_value=None):
    if column_name is not None and excluded_value is not None:
        df = df.filter(col(column_name) != excluded_value)
    return df.limit(1).count() == 0

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# 
# **Process Fund Trade Silver Table**

# CELL ********************

def process_task(task,bronze_lh_id,curated_lh_id):
    try:
        source_path = f"{bronze_lh_id}/Tables/{task['SourceSchemaName']}/{task['SourceTableName']}"
        target_path = f"{curated_lh_id}/Tables/{task['SinkSchemaName']}/{task['SinkTableName']}"
        datetime_col = 'Date_Time'
        print(source_path)
        print(target_path)
        #abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXFund

        #Read table path
        bronzeclassificationmap_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXClassificationMap"
        bronzetagmaster_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXTagMaster"
        bronzetag_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXTag"
        silvercashflowtrandetail_path = f"{curated_lh_id}/Tables/Silver/CashflowTransactionDetail"
        silverfundreturn_path = f"{curated_lh_id}/Tables/Silver/FundReturn"
        silverfundvaluation_path = f"{curated_lh_id}/Tables/Silver/FundValuation"

        bronzefundstructure_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXFundStructure"
        bronzepipelinestatus_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXPipelineStatus"
        bronzeinvestmentform_path = f"{bronze_lh_id}/Tables/Bronze/CrimsonXInvestmentForm"
#        bronzeactivebookfundmapping_path = f"{bronze_lh_id}/Tables/Bronze/SolovisActiveBookFundMapping"
        silverfundcommitment_path = f"{curated_lh_id}/Tables/Silver/FundCommitment"
        silverfundmarketvalue_path = f"{curated_lh_id}/Tables/Silver/FundMarketValue"
        golddrawdownfundanalytic_path = f"{curated_lh_id}/Tables/Gold/DrawdownFundAnalytic"

        today_date = date.today()
        today_str = date.today().strftime('%Y-%m-%d')
        #yesterday_str = (today_str - timedelta(days=1)).strftime('%Y-%m-%d')
        # Set watermark
        etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        # TRY Read source
        try:
            df_source = spark.read.format("delta").load(source_path)
            df_source.createOrReplaceTempView("src")

            df_bronzeclassificationmap = spark.read.format("delta").load(bronzeclassificationmap_path)
            df_bronzeclassificationmap.createOrReplaceTempView("CrimsonXClassificationMap")
            df_bronzetagmaster = spark.read.format("delta").load(bronzetagmaster_path)
            df_bronzetagmaster.createOrReplaceTempView("CrimsonXTagMaster")
            df_bronzetag = spark.read.format("delta").load(bronzetag_path)
            df_bronzetag.createOrReplaceTempView("CrimsonXTag")

            df_silvercashflowtrandetail = spark.read.format("delta").load(silvercashflowtrandetail_path)
            df_silvercashflowtrandetail.createOrReplaceTempView("CashflowTransactionDetail")
            df_silverfundreturn = spark.read.format("delta").load(silverfundreturn_path)
            df_silverfundreturn.createOrReplaceTempView("FundReturn")
            df_silverfundvaluation = spark.read.format("delta").load(silverfundvaluation_path)
            df_silverfundvaluation.createOrReplaceTempView("FundValuation")
            df_bronzefundstructure = spark.read.format("delta").load(bronzefundstructure_path)
            df_bronzefundstructure.createOrReplaceTempView("CrimsonXFundStructure")

            df_bronzepipelinestatus = spark.read.format("delta").load(bronzepipelinestatus_path)
            df_bronzepipelinestatus.createOrReplaceTempView("CrimsonXPipelineStatus")
            df_bronzeinvestmentform = spark.read.format("delta").load(bronzeinvestmentform_path)
            df_bronzeinvestmentform.createOrReplaceTempView("CrimsonXInvestmentForm")
#            df_bronzeactivebookfundmapping = spark.read.format("delta").load(bronzeactivebookfundmapping_path)
#            df_bronzeactivebookfundmapping.createOrReplaceTempView("SolovisActiveBookFundMapping")
            df_silverfundcommitment = spark.read.format("delta").load(silverfundcommitment_path)
            df_silverfundcommitment.createOrReplaceTempView("FundCommitment")
            df_silverfundmarketvalue = spark.read.format("delta").load(silverfundmarketvalue_path)
            df_silverfundmarketvalue.createOrReplaceTempView("FundMarketValue")

            df_golddrawdownfundanalytic = spark.read.format("delta").load(golddrawdownfundanalytic_path)
            df_golddrawdownfundanalytic.createOrReplaceTempView("DrawdownFundAnalytic")

            # Spark SQL
            query = f"""
SELECT CAST(f.FundId AS VARCHAR(36)) As FundId
       , f.FundName
       , CAST(f.EntityId AS VARCHAR(36))
       , f.FundStructureId 
	   , fs.Description as FundStructure
       , f.PipelineStatusId as FundStatusId
	   , ps.Description as FundStatus
       , f.InvestmentFormId
	   , cif.Description as InvestmentForm
	   , CASE WHEN fs.Description = 'Drawdown' THEN 'Private'
		      ELSE 'Public' END as MarketClassification
       , f.VintageYear
--	   , abfm.ActiveBookType as FundType
       , f.IsFundShorted 
       , f.CalculationMethodologyId
       , (coinv.FundId IS NOT NULL) AS IsCoInvest  
       , f.PeriodEndValuationsFrequencyId AS FundValuationFrequency
       , f.CurrencyId as FundCurrencyId
       , f.HasSideLetter
       , CAST(f.ExposureIndexId as VARCHAR(36)) as PerformanceIndexId
       , CAST(expdate.FirstCashflowDate AS DATE) FirstCashflowDate
       , CAST(expdate.LastCashflowDate AS DATE) LastCashflowDate            
       , CAST(managerdate.FirstManagerReturnDate AS DATE) FirstManagerReturnDate 
       , CAST(valdate.FirstValuationDate AS DATE) FirstValuationDate
       , CAST(valdate.LastValuationDate AS DATE) LastValuationDate
       , CASE WHEN expdate.FirstCashflowDate < valdate.FirstValuationDate THEN 
				CASE WHEN DAY(DATEADD(DAY,1,expdate.FirstCashflowDate)) = 1 THEN CAST(DATEADD(DAY,1,expdate.FirstCashflowDate) AS DATE) 
					 ELSE CAST(expdate.FirstCashflowDate AS DATE) END
			  ELSE
				CASE WHEN DAY(DATEADD(DAY,1,valdate.FirstValuationDate)) = 1 THEN CAST(DATEADD(DAY,1,valdate.FirstValuationDate) AS DATE) 
					 ELSE CAST(valdate.FirstValuationDate AS DATE) END
		 END AS HMCInceptionDate      
	   , com.FirstCommitmentDate
	   , com.LastCommitmentDate
	   , CASE WHEN active.FundId IS NULL THEN FALSE ELSE TRUE END as IsActive
       , current_timestamp() AS ETLLoadDateTime       
FROM src f
		JOIN CrimsonXFundStructure fs ON f.FundStructureId = fs.FundStructureId
		JOIN CrimsonXPipelineStatus ps ON ps.PipelineStatusId = f.PipelineStatusId
        LEFT JOIN CrimsonXInvestmentForm cif ON cif.InvestmentFormId = f.InvestmentFormId
--		LEFT JOIN (SELECT DISTINCT FundId, ActiveBookType 
--			  FROM SolovisActiveBookFundMapping) abfm ON abfm.FundId = f.FundId 
 		LEFT JOIN (SELECT DISTINCT f.FundId 
 				   FROM CrimsonXTagMaster tm
 							JOIN CrimsonXTag t ON t.TagId = tm.TagId
 							JOIN src f ON f.FundId = tm.HMCObjectId
 				   WHERE tm.TagId = 7) coinv ON f.FundId = coinv.FundId           
		LEFT JOIN (select FundId, min(ExposureDate) as FirstCashflowDate, max(ExposureDate) as LastCashflowDate 
				   from CashflowTransactionDetail
				   where CashflowTransactionTypeId not in (5,18,13)
							AND (TransactionAmountInLocal != 0
										or TransactionAmountOutLocal != 0
										or MarketValueEffectLocal != 0
										or CommitmentEffectLocal != 0
										or ReturnedAmountLocal != 0
										or UnfundedAdjustmentLocal != 0
										or FundedAmountLocal != 0
										or RecallableAmountLocal != 0) 
			       group by FundId) expdate ON f.FundId = expdate.FundId
		LEFT JOIN (select FundId, min(EndDate) as FirstManagerReturnDate 
				   from FundReturn
				   where ReturnSourceId = 2
				   group by FundId) managerdate ON f.FundId = managerdate.FundId
		LEFT JOIN (select FundId,min(ValuationDate) as FirstValuationDate, max(ValuationDate) as LastValuationDate 
				   from FundValuation
				   group by FundId) valdate ON f.FundId = valdate.FundId  
		LEFT JOIN (select FundId, min(CommitmentDate) as FirstCommitmentDate, max(CommitmentDate) as LastCommitmentDate
			       from FundCommitment
				   group by FundId) com ON com.FundId = f.FundId
		LEFT JOIN (select distinct f.FundId
			       from src f 
							LEFT JOIN (SELECT FundId, EndBalance 
								       FROM FundMarketValue
									   WHERE NAVDate = (SELECT MAX(NAVDate) FROM FundMarketValue)) fmv ON fmv.FundId = f.FundId
						    LEFT JOIN (SELECT FundId, UnfundedAmountLocal
									   FROM DrawdownFundAnalytic
									   WHERE AsOfDate = (SELECT MAX(AsOfDate) FROM DrawdownFundAnalytic)) dfa ON f.FundId = dfa.FundId
				   where fmv.EndBalance != 0
							OR (f.FundStructureId = 1 AND dfa.UnfundedAmountLocal != 0)) active ON active.FundId = f.FundId
            """

            # query = f"""

            # SELECT
            #     CAST(LOWER(F.FundId) AS VARCHAR(36)) As FundId
            #     ,F.FundName
            #     ,CAST(F.EntityId AS VARCHAR(36))
            #     ,F.FundStructureId 
            #     ,F.PipelineStatusId as FundStatusId
            #     ,F.InvestmentFormId
            #     ,F.VintageYear
            #     ,F.IsFundShorted 
            #     ,F.CalculationMethodologyId
            #     ,CASE WHEN coinv.FundId IS NULL THEN 0 ELSE 1 END IsCoInvest 
            #     ,F.PeriodEndValuationsFrequencyId AS FundValuationFrequency
            #     ,F.CurrencyId as FundCurrencyId
            #     ,F.HasSideLetter
            #     ,CAST(expdate.FirstCashflowDate AS DATE) FirstCashflowDate
            #     ,CAST(expdate.LastCashflowDate AS DATE) LastCashflowDate
            #     ,CAST(managerdate.FirstManagerReturnDate AS DATE) FirstManagerReturnDate
            #     ,CAST(valdate.FirstValuationDate AS DATE) FirstValuationDate
            #     ,CAST(valdate.LastValuationDate AS DATE) LastValuationDate
            #     ,CASE WHEN expdate.FirstCashflowDate < valdate.FirstValuationDate 
            #     THEN 
            #         CASE WHEN DAY(DATEADD(DAY,1,expdate.FirstCashflowDate)) = 1 
            #             THEN CAST(DATEADD(DAY,1,expdate.FirstCashflowDate) AS DATE) 
            #             ELSE CAST(expdate.FirstCashflowDate AS DATE) 
            #         END
            #     ELSE
            #         CASE WHEN DAY(DATEADD(DAY,1,valdate.FirstValuationDate)) = 1 
            #             THEN CAST(DATEADD(DAY,1,valdate.FirstValuationDate) AS DATE) 
            #             ELSE CAST(valdate.FirstValuationDate AS DATE) 
            #         END
            #     END AS HMCInceptionDate
            #     ,com.CommitmentDate as FirstCommitmentDate
            #     ,current_timestamp() AS ETLLoadDateTime
            # FROM src F
            
            # LEFT JOIN (
            #     SELECT DISTINCT FundId FROM CrimsonXTagMaster tm
            #     JOIN CrimsonXTag t 
            #         ON t.TagId = tm.TagId
            #     JOIN src f 
            #         ON f.FundId = tm.HMCObjectId
            #     WHERE tm.TagId = 7
            # ) coinv
            #     ON LOWER(F.FundId) = LOWER(coinv.FundId)
            # LEFT JOIN (
            #     select FundId, min(ExposureDate) as FirstCashflowDate, max(ExposureDate) as LastCashflowDate 
            #     from CashflowTransactionDetail
            #     where CashflowTransactionTypeId not in (5,18,13)
            #     AND (TransactionAmountInLocal != 0
			# 				or TransactionAmountOutLocal != 0
			# 				or MarketValueEffectLocal != 0
			# 				or CommitmentEffectLocal != 0
			# 				or ReturnedAmountLocal != 0
			# 				or UnfundedAdjustmentLocal != 0
			# 				or FundedAmountLocal != 0
			# 				or RecallableAmountLocal != 0) 
            #     group by FundId
            # ) expdate
            #     ON F.FundId = expdate.FundId
            # LEFT JOIN (
            #     select FundId, min(EndDate) as FirstManagerReturnDate from lh_curated.Silver.FundReturn
            #     where ReturnSourceId = 2
            #     group by FundId 
            #     -- select FundId, min(ReturnDate) as FirstManagerReturnDate from CrimsonXFundReturn
            #     -- where ReturnSourceId = 2
            #     -- group by FundId 
            # ) managerdate
            #     ON F.FundId = managerdate.FundId
            # LEFT JOIN (
            #     select FundId,min(ValuationDate) as FirstValuationDate, max(ValuationDate) as LastValuationDate 
            #     --SELECT ValuationDate
            #     from CrimsonXFundValuation
            #     group by FundId
            # ) valdate
            #     ON F.FundId = valdate.FundId
			# LEFT JOIN (
			# 	select FundId, min(CommitmentDate) as CommitmentDate
			# 	from lh_curated.Silver.FundCommitment
			# 	group by FundId
			# ) com ON com.FundId = F.FundId                

            # """
            truncateQuery = f"""
               TRUNCATE TABLE Silver.{task['SinkTableName']}
            """
            spark.sql(truncateQuery)

            result_df = spark.sql(query)
            #result_df.show(5)
        except Exception as e:
            raise RuntimeError(f"Source path does not exist or failed to load: {source_path}") from e
        # Write the result as a Delta table
        result_df.write.format("delta").mode("append").save(target_path)
        result_df.printSchema()
        #df_today.write.format("delta").mode("overwrite").save(target_path)
        print('Completed')
    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise RuntimeError(f"Failed") from e

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print("start")

for task_item in tasklist:
    #print(tasklist)
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)


        # Process the task
        result = process_task(task_item,bronze_lh_basepath,curated_lh_basepath)

    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise
#abfss://33535eb8-4d07-49bc-b3a5-cc91d3aa6ced@onelake.dfs.fabric.microsoft.com/13ef97da-5da2-466d-8c5f-2a70572c6558/Tables/Bronze/CrimsonXFundTrade

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
