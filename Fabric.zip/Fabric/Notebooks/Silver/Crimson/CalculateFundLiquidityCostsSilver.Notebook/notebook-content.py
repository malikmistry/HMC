# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

# standard parameters passed in via MDF
WorkspaceId = None
BronzeLHId = None
CuratedLHId = None

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

import decimal
import requests
import time

from datetime import datetime
from requests.exceptions import HTTPError, ConnectionError, Timeout, RequestException
from pyspark.sql import functions
from pyspark.sql.types import StructType, StructField, DecimalType, DateType, StringType, IntegerType, BooleanType
from delta.tables import DeltaTable
from urllib.parse import quote

spark.conf.set('spark.sql.caseSensitive', True)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

print(f"Params: WorkspaceId = {WorkspaceId}, BronzeLHId = {BronzeLHId}, CuratedLHId = {CuratedLHId}")

if WorkspaceId == None:
    print("WorkspaceId was None. This is ok for development.  Just hardcode value here.")
    # "DEV - Crimson" values
    WorkspaceId = '33535eb8-4d07-49bc-b3a5-cc91d3aa6ced'
    BronzeLHId = '13ef97da-5da2-466d-8c5f-2a70572c6558'
    CuratedLHId = 'e9fc4e80-ff69-4d45-bbdd-892592889465'

fund_liquidity_cost = "FundLiquidityCost"
curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)

# Columns
fund_id = "FundId"
end_balance = "EndBalance"
as_of_date = "AsOfDate"
unfunded_amount_local = "UnfundedAmountLocal"
weighted_days_type_id = "WeightedDaysTypeId"
nav_date = "NAVDate"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def convert_floats_to_decimal(row):
    for key in ["weightedDays", "liquidityCost"]:
        if key in row and isinstance(row[key], float):
            row[key] = decimal.Decimal(str(row[key]))
    
    return row

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_active_funds():
    """
    Gets all funds that have a market value OR private funds with a remaining unfunded amount.
    """
    start_time = time.perf_counter()

    fund_market_value = (
        spark.read.format("delta")
            .load(f"{curated_lh_basepath}/Tables/Silver/FundMarketValue")
    )

    max_nav_date = fund_market_value.agg(functions.max(nav_date).alias(nav_date)).first()[0]

    fund_ids_with_market_values = (
        fund_market_value.filter((F.col(end_balance) > 0) & (F.col(nav_date) == functions.lit(max_nav_date)))
        .select(fund_id)
        .distinct()
    )

    drawdown_fund_analytic_data_frame = (
        spark.read.format("delta")
            .load(f"{curated_lh_basepath}/Tables/Gold/DrawdownFundAnalytic")
    )

    max_as_of = drawdown_fund_analytic_data_frame.agg(functions.max(as_of_date).alias(as_of_date)).first()[0]

    fund_ids_with_unfunded_amount = (
        drawdown_fund_analytic_data_frame
            .filter(
                (functions.col(unfunded_amount_local) > 0) & (functions.col(as_of_date) == functions.lit(max_as_of))
            )
            .select(fund_id)
            .distinct()
    )

    fund_ids = fund_ids_with_market_values.union(fund_ids_with_unfunded_amount).distinct()

    count = fund_ids.count()
    print(f"Got {count} active fund(s) in {time.perf_counter() - start_time} seconds")

    return [r.FundId for r in fund_ids.collect()]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def delete_updated_fund_ids(fund_ids):
    """
    Deletes rows corresponding to the passed in fund ids, as long as the weighted days type is not "Override".
    """
    start_time = time.perf_counter()
    override = 99

    DeltaTable.forPath(spark, f"{curated_lh_basepath}/Tables/Silver/{fund_liquidity_cost}").delete(
        (functions.col(fund_id).isin(fund_ids)) & (functions.col(weighted_days_type_id) != override)
    )

    print(f"Deleted rows for {len(fund_ids)} fund(s) in {time.perf_counter() - start_time} seconds")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def retrieve_fund_liquidity_costs(fund_ids):
    """
    Calls the Azure function to get the liquidity costs for a set of funds.
    """
    today = quote(datetime.utcnow().strftime("%m/%d/%Y"))
    code = "mrjIzDcgQ3P_UdPqFSPR1zEENqdmWf3SeWXvoSZnyI3iAzFuSI08TQ=="
    endpoint = f"https://winfunctionappdotnet-dev1.azurewebsites.net/api/CalculateFundLiquidityCost?processDate={today}&code={code}"
    liquidity_costs = http_post(endpoint, fund_ids)

    # Convert floats to decimals
    liquidity_costs = [convert_floats_to_decimal(row) for row in liquidity_costs]

    print(f"Retrieved {len(liquidity_costs)} liquidity cost(s)")
    return liquidity_costs

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def insert_fund_liquidity_costs(liquidity_costs):
    """
    Inserts the fund liquidty costs into the database.
    """
    schema = StructType([
        StructField("fundId", StringType(), False),
        StructField("weightedDaysTypeId", IntegerType(), False),
        StructField("liquidityOptionId", IntegerType(), False),
        StructField("weightedDays", DecimalType(38, 11)),
        StructField("liquidityCost", DecimalType(38, 11)),
        StructField("isDefault", BooleanType(), False),
        StructField("error", StringType())
    ])

    liquidity_costs_data_frame = (
        spark.createDataFrame(liquidity_costs, schema)
            .withColumn("ETLLoadDateTime", functions.current_timestamp())
            .select(
                # Add aliases for column case difference
                functions.col("fundId").alias("FundId"),
                functions.col("weightedDaysTypeId").alias("WeightedDaysTypeId"),
                functions.col("liquidityOptionId").alias("LiquidityOptionId"),
                functions.col("weightedDays").alias("WeightedDays"),
                functions.col("liquidityCost").alias("LiquidityCost"),
                functions.col("isDefault").alias("IsDefault"),
                functions.col("error").alias("Error"),
                functions.col("ETLLoadDateTime")
            )
        )

    print(f"Inserting {len(liquidity_costs)} rows into {fund_liquidity_cost}")

    liquidity_costs_data_frame.write.format("delta").mode("append").save(f"{curated_lh_basepath}/Tables/Silver/{fund_liquidity_cost}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def main():
    """
    Inserts the fund liquidity costs for all active funds.
    """
    start_time = time.perf_counter()

    fund_ids = get_active_funds()
    delete_updated_fund_ids(fund_ids)

    insert_fund_liquidity_costs(retrieve_fund_liquidity_costs(fund_ids))

    print(f"Completed in {time.perf_counter() - start_time} seconds")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

main()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
