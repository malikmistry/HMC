# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import decimal
import requests
from datetime import date, datetime
from requests.exceptions import HTTPError, ConnectionError, Timeout, RequestException
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, DecimalType, DateType, StringType, IntegerType, LongType
from pyspark.sql.functions import to_date, lower
from delta.tables import DeltaTable

spark.conf.set('spark.sql.caseSensitive', True)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
CalculateFundStatisticsUrl = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
CalculateFundStatisticsUrl = "https://winfunctionappdotnet-dev1.azurewebsites.net/api/CalculateFundStatistics?code=B7moEvO0QIn28NXomoZM9wCsOAlAR9BRDFtsovvyqEurAzFul14xrA=="

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./CalculateFundStatisticsSilver

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

statistic_types = [
    statistic_irr,
    statistic_md_return,
    statistic_gross_return,
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def deleteFundReturns(fund_ids):
    print(f"Deleting from FundReturn...")
    delta_table = DeltaTable.forPath(spark, f"{curated_lh_basepath}/Tables/Silver/FundReturn")
    delta_table.delete(condition = F.col("FundId").isin(fund_ids).__and__(F.col("ReturnSourceId").__eq__(1)))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def mergeFundReturns(fund_ids, returns_json):

    start_time = datetime.now()

    returns_json_schema = StructType([
        StructField("fundId", StringType(), False),
        StructField("statisticTypeId", IntegerType(), False),
        StructField("returnTypeId", IntegerType(), False),
        StructField("returnSourceId", IntegerType(), False),
        StructField("frequencyId", IntegerType(), False),
        StructField("calculationMethodologyId", IntegerType(), True),
        StructField("endDate", StringType(), False),    # parse later
        StructField("value", DecimalType(38, 11), True),
        StructField("error", StringType(), True),
        StructField("detailsKey", StringType(), True),
        StructField("detailsFingerprint", StringType(), True),
        StructField("asOfDate", DateType(), True)
    ])

    returns_json_df = spark.createDataFrame(returns_json, schema=returns_json_schema)

    # Convert string to actual DateType
    returns_json_df = returns_json_df.withColumn("endDate", to_date("endDate", "yyyy-MM-dd"))

    print("Number of return stream rows returned:", returns_json_df.count())

    deleteFundReturns(fund_ids)

    # statistics_df.printSchema()
    # statistics_df.show(truncate=False)

    returns_df = returns_json_df.select(
        F.col("fundId").alias("FundId"),
        F.col("returnTypeId").alias("ReturnTypeId"),      
        F.col("returnSourceId").alias("ReturnSourceId"),      
        F.col("frequencyId").alias("FrequencyId"),      
        F.col("calculationMethodologyId").alias("CalculationMethodologyId"),     
        F.col("endDate").alias("EndDate"),               
        F.col("value").alias("ReturnValue"),
        F.col("error").alias("ReturnError"),
        F.col("detailsKey").alias("ReturnDetailsKey"))

    returns_df = returns_df.withColumn("AsOfDate", F.lit(date.today()))
    returns_df = returns_df.withColumn("ETLLoadDateTime", F.lit(datetime.now()))

    # returns_df.printSchema()
    # returns_df.show(truncate=True)

    print(f"Merging fund returns...")

    returns_df.write.format("delta").mode("append").save(f"{curated_lh_basepath}/Tables/Silver/FundReturn")

    spark.catalog.refreshTable("Silver.FundReturn")

    end_time = datetime.now()
    elapsed = end_time - start_time  # Returns a timedelta
    print("mergeFundReturns elapsed time:", elapsed)    

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def getStatisticRequests(funds):
    fund_statistic_requests = []

    for fund in funds:
        
        fund_request = {
            "fundId": fund["FundId"],
            "statisticRequests": [],
            "returnStreamRequests": [],            
            "includeDetails": True,
            "overrideDetailsLocation": "fund-statistic-details"     
        }

        if (fund["LastValuationDate"] is None):
            print(f"Skipping fund {fund['FundId']}: LastValuationDate is NULL")
            continue  

        if isLastDayOfMonth(fund["LastValuationDate"]):
            end_date = fund["LastValuationDate"].strftime("%Y-%m-%d")
        else:
            end_date = previousMonthEnd(fund["LastValuationDate"]).strftime("%Y-%m-%d")

        # horizons
        for stat_type in statistic_types: 

            if  fund["FundName"].startswith("General Expense"):
                continue  

            if (stat_type == statistic_gross_return and fund["FundStructureId"] == fund_structure_drawdown):
                continue

            if (stat_type == statistic_gross_return and fund["FundName"].startswith("HMC Internal")):
                continue   

            if fund["FundName"].startswith("General Expense"):
                continue   

            for time_period in horizon_time_periods:
                request = {
                    "statisticTypeId": stat_type,
                    "timePeriodId": time_period[0],
                    "endDate": end_date
                }
                fund_request["statisticRequests"].append(request)

        # net return streams
        stream_stat_type = statistic_irr if fund["CalculationMethodologyId"] == calc_method_irr else statistic_md_return
        frequency = freq_quarterly if (fund["FundValuationFrequency"] == freq_quarterly or fund["FundValuationFrequency"] == freq_semi_annually or fund["FundValuationFrequency"] == freq_annually) else freq_monthly
        request = {
            "statisticTypeId": stream_stat_type,
            "frequencyId": frequency,
            "endDate": end_date
        }
        fund_request["returnStreamRequests"].append(request) 

        request = {
            "statisticTypeId": stream_stat_type,
            "frequencyId": freq_calendar_year,
            "endDate": end_date
        }
        fund_request["returnStreamRequests"].append(request)     

        request = {
            "statisticTypeId": stream_stat_type,
            "frequencyId": freq_fiscal_year,
            "endDate": end_date
        }
        fund_request["returnStreamRequests"].append(request)                                  

        # gross return streams
        if (fund["FundStructureId"] != fund_structure_drawdown):

            if (fund["FundName"].startswith("General Expense") or fund["FundName"].startswith("HMC Internal")):
                fund_statistic_requests.append(fund_request)
                continue  

            request = {
                "statisticTypeId": statistic_gross_return,
                "frequencyId": freq_monthly,
                "endDate": end_date
            }
            fund_request["returnStreamRequests"].append(request)   

            request = {
                "statisticTypeId": statistic_gross_return,
                "frequencyId": freq_calendar_year,
                "endDate": end_date
            }
            fund_request["returnStreamRequests"].append(request)     

            request = {
                "statisticTypeId": statistic_gross_return,
                "frequencyId": freq_fiscal_year,
                "endDate": end_date
            }
            fund_request["returnStreamRequests"].append(request)   

        fund_statistic_requests.append(fund_request)
    # print(fund_statistic_requests)

    return fund_statistic_requests

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

start_time = datetime.now()
print(f"CalculateFundStatistics: {start_time.strftime('%Y-%m-%d %H:%M:%S')}" )

updated_funds_df = getChangedFunds()
# updated_funds_df = getActiveFunds()
# updated_funds_df = getAllFunds()

# test_funds_df = spark.createDataFrame([("788f210b-d6b5-422b-bc79-7abe304ba4eb",)], ["FundId"])
# updated_funds_df = updated_funds_df.join(test_funds_df, on=["FundId", "FundId"], how="left_semi")

batch_size = 200
updated_funds = updated_funds_df.collect()

total_fund_requests = 0
for i in range(0, len(updated_funds), batch_size):
    print(f"Processing funds {i + 1} through {i + batch_size}...")
    batch_funds = updated_funds[i:i + batch_size]

    batch_statistic_requests = getStatisticRequests(batch_funds)
    batch_request_data = {
        "notificationKey": "Net/Gross Return",
        "notifyOnSuccess": True,
        "fundStatistics": batch_statistic_requests
    }

    print("Fund requests in batch:", len(batch_statistic_requests))
    total_fund_requests += len(batch_statistic_requests)

    # print(batch_request_data)

    batch_start_time = datetime.now()
    batch_ids = [row["FundId"] for row in batch_funds]

    statistics_json = calcFundStatistics(batch_request_data)
    mergeHorizonReturns(batch_ids, statistics_json["statisticValues"], "FundHorizonReturn")
    mergeFundReturns(batch_ids, statistics_json["returnStreamValues"])

    batch_end_time = datetime.now()
    batch_elapsed = batch_end_time - batch_start_time  # Returns a timedelta
    print("Batch elapsed time:", batch_elapsed)

print("Total fund requests:", total_fund_requests)

end_time = datetime.now()
elapsed = end_time - start_time  # Returns a timedelta
print("Total elapsed time:", elapsed)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# df = spark.sql("SELECT * FROM lh_curated.Gold.FundHorizonReturn where ITDError is NOT NULL ORDER BY FundId, StatisticTypeId LIMIT 1000")
# display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# df = spark.sql("SELECT * FROM lh_curated.Silver.FundReturn where ReturnError is not NULL")
# display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************


# spark.conf.set('spark.sql.caseSensitive', True)

# spark.sql(""" DROP TABLE Gold.FundHorizonReturn """)

# spark.sql("""
# CREATE TABLE Gold.FundHorizonReturn (
#     FundId varchar(36) NOT NULL,
#     StatisticTypeId int NOT NULL,    
#     EndDate date NOT NULL,
#     ITD decimal(38,6),
#     ITDError string,
#     ITDDetailsKey string,
#     HMCITD decimal(38,6),
#     HMCITDError string,
#     HMCITDDetailsKey string,
#     CYTD decimal(38,6),
#     CYTDError string,
#     CYTDDetailsKey string,
#     FYTD decimal(38,6),
#     FYTDError string,
#     FYTDDetailsKey string,
#     OneYear decimal(38,6),
#     OneYearError string,
#     OneYearDetailsKey string,
#     ThreeYear decimal(38,6),
#     ThreeYearError string,
#     ThreeYearDetailsKey string,
#     FiveYear decimal(38,6),
#     FiveYearError string,
#     FiveYearDetailsKey string,
#     SevenYear decimal(38,6),
#     SevenYearError string,
#     SevenYearDetailsKey string,
#     TenYear decimal(38,6),
#     TenYearError string,
#     TenYearDetailsKey string,
#     FifteenYear decimal(38,6),
#     FifteenYearError string,
#     FifteenYearDetailsKey string,
#     TwentyYear decimal(38,6),
#     TwentyYearError string,
#     TwentyYearDetailsKey string,
#     AsOfDate date NOT NULL,
#     ETLLoadDateTime TIMESTAMP NOT NULL
# )
# USING DELTA
# """)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# spark.conf.set('spark.sql.caseSensitive', True)

# #spark.sql(""" DROP TABLE Silver.FundReturn """)

# spark.sql("""
# CREATE TABLE Silver.FundReturn (
#     FundId varchar(36) NOT NULL,
#     ReturnTypeId int NOT NULL,    
#     ReturnSourceId int NOT NULL,        
#     FrequencyId int NOT NULL,        
#     CalculationMethodologyId int,        
#     EndDate date NOT NULL,
#     ReturnValue decimal(38,11),
#     ReturnError string,
#     ReturnDetailsKey string,
#     AsOfDate date NOT NULL,
#     ETLLoadDateTime TIMESTAMP NOT NULL    
# )
# USING DELTA
# """) 

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
