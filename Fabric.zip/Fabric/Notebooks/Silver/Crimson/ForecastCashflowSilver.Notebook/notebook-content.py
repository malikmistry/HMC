# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""
NotebookName = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
# BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
# CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
# TaskList = "{\"JobAuditKey\":537,\"TaskKey\":116,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"CrimsonXForecastedCashFlow\",\"SinkTableName\":\"ForecastedCashFlow\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"14\",\"NotebookName\":\"FundTradeSilver\",\"SinkLakehouseName\":\"lh_curated\"}"
# NotebookName = ""
# LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

#we will attach the sinklakehouse to the notebook
if LakehouseName == 'lh_bronze':
    LakehouseId = BronzeLHId
elif LakehouseName == 'lh_curated':
    LakehouseId = CuratedLHId

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Import required libraries
from datetime import datetime, date, timedelta, timezone
from pyspark.sql.functions import row_number, col, to_date, to_timestamp, max as spark_max, current_timestamp, date_format, round, format_string, when, monotonically_increasing_id, format_number
from collections import defaultdict
import json
from pyspark.sql import Row
from pyspark.sql import functions as F
from notebookutils import mssparkutils
from pyspark.sql.functions import to_date, to_timestamp, col, lit
import os
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
log = []

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC   CREATE TABLE IF NOT EXISTS Silver.ForecastedCashFlow(
# MAGIC   	ForecastedCashFlowId bigint NOT NULL,
# MAGIC   	ForecastedCashFlowDate date NOT NULL,
# MAGIC   	Amount decimal(38, 2) NOT NULL,
# MAGIC   	Description varchar(8000) ,
# MAGIC   	ForecastedCashFlowTypeId bigint ,
# MAGIC   	IsDeleted boolean ,
# MAGIC   	SettleDate date ,
# MAGIC   	FundId varchar(36),
# MAGIC   	ETLLoadDateTime Timestamp NOT NULL
# MAGIC   )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************


# CELL ********************

tasklist = json.loads(f"{TaskList}")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def is_df_empty(df, column_name=None, excluded_value=None):
    if column_name is not None and excluded_value is not None:
        df = df.filter(col(column_name) != excluded_value)
    return df.limit(1).count() == 0

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def get_basepath(
    workspace_id, 
    lakehouse_id
) -> str:
    lh_basepath = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}"
    return lh_basepath

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def process_task(task,bronze_lh_id,curated_lh_id):
    try:
        source_path = f"{bronze_lh_id}/Tables/{task['SourceSchemaName']}/{task['SourceTableName']}"
        target_path = f"{curated_lh_id}/Tables/{task['SinkSchemaName']}/{task['SinkTableName']}"
        datetime_col = 'Date_Time'
        #Read tables

        isTargetEmpty=0
        max_id = 0

        today_date = date.today()
        today_str = date.today().strftime('%Y-%m-%d')
        #yesterday_str = (today_str - timedelta(days=1)).strftime('%Y-%m-%d')
        # Set watermark
        etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        # TRY Read source
        try:
            df_source = spark.read.format("delta").load(source_path)
            df_source.createOrReplaceTempView("src")
            truncateQuery = f"""
                TRUNCATE TABLE Silver.{task['SinkTableName']}
            """
            spark.sql(truncateQuery)
            # Spark SQL
            query = f"""
                SELECT 
                ForecastedCashFlowId
                ,ForecastedCashFlowDate
                ,CAST(Amount AS DECIMAL(38,2)) AS Amount
                ,Description
                ,ForecastedCashFlowTypeId
                ,IsDeleted
                ,SettleDate
                ,CAST(FundId AS VARCHAR(36)) AS FundId
                ,'{etlloadtime}'AS ETLLoadDateTime
                FROM src
                WHERE IsDeleted = 0
            """
            result_df = spark.sql(query)
            #result_df.show(5)
        except Exception as e:
            raise RuntimeError(f"Source path does not exist or failed to load: {source_path}") from e
        # Write the result as a Delta table
        result_df.write.format("delta").mode("append").save(target_path)
        #df_today.write.format("delta").mode("overwrite").save(target_path)
        print('Completed')
    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise RuntimeError(f"Failed") from e

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)


        # Process the task
        result = process_task(task_item,bronze_lh_basepath,curated_lh_basepath)

    except Exception as e:
        mssparkutils.notebook.exit(f"FAILED: {e}")
        raise


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
