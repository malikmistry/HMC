# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         },
# META         {
# META           "id": "13ef97da-5da2-466d-8c5f-2a70572c6558"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
TaskList = "{\"JobAuditKey\":1607,\"TaskKey\":63,\"TaskType\":\"NotebookTask\",\"SourceSchemaName\":\"Bronze\",\"SourceTableName\":\"CrimsonXUniverse\",\"SinkTableName\":\"Universe\",\"SinkSchemaName\":\"Silver\",\"NotebookKeyNotebookKey\":\"3\",\"NotebookName\":\"UniverseSilver\",\"SinkLakehouseName\":\"lh_curated\",\"RawStoragePath\":null,\"RawStorageFileName\":null,\"RelativeUrl\":null}"
NotebookName = "UniverseSilver"
LakehouseName = "lh_curated"
RawLHId = "920a12cc-7104-4013-a2a3-d7baa57e9e3f"


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
TaskList = ""
NotebookName = ""
LakehouseName = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql.types import StringType
from datetime import datetime, timezone, date

spark.conf.set("spark.sql.caseSensitive","true")
spark.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
spark.conf.set("spark.sql.analyzer.maxIterations", 1000)
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./notebook_utils

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
print(etlloadtime)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

tasklist = json.loads(f"{TaskList}")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.Universe (
# MAGIC     UniverseId VARCHAR(36) NOT NULL,
# MAGIC     UniverseName STRING NOT NULL,
# MAGIC     UniverseDescription STRING,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# MAGIC %%sql
# MAGIC CREATE TABLE IF NOT EXISTS lh_curated.Silver.UniverseFunds (
# MAGIC     UniverseId VARCHAR(36) NOT NULL,
# MAGIC     FundId VARCHAR(36) NOT NULL,
# MAGIC     ETLLoadDateTime TIMESTAMP NOT NULL
# MAGIC )

# METADATA ********************

# META {
# META   "language": "sparksql",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def process_task(task, bronze_lh_id, curated_lh_id):
    try:
        source_path = f"{bronze_lh_id}/Tables/{task['SourceSchemaName']}/{task['SourceTableName']}"
        target_path = f"{curated_lh_id}/Tables/{task['SinkSchemaName']}"
        universepublic_path = f"{target_path}/UniversePublic"
        universefunds_path = f"{target_path}/UniverseFunds"
        vwuniverse_path = f"{target_path}/Universe"

        etlloadtime = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        print(f"ETLLoadDateTime = {etlloadtime}")


        # Read Universe source
        df_universe = spark.read.format("delta").load(source_path)

        # Filter public universes
        df_ispublic = (
            df_universe
            .filter(
                (F.col("OwnerId").isin("systemaccount", "snevilyj")) &
                (F.col("IsPublic") == 1)
            )
            .withColumn("ETLLoadDateTime", F.lit(etlloadtime))
        )

        df_ispublic.write.format("delta").mode("overwrite").option("mergeSchema", "true").save(universepublic_path)
        df_ispublic.createOrReplaceTempView("UniversePublic")

        # Universe metadata
        dfvwUniverse = spark.sql("SELECT UniverseId, UniverseName, UniverseDescription FROM UniversePublic")
        dfvwUniverse = (
            dfvwUniverse
            .withColumn("UniverseId", F.col("UniverseId").cast(StringType()))
            .withColumn("UniverseName", F.col("UniverseName").cast(StringType()))
            .withColumn("ETLLoadDateTime", F.to_timestamp(F.lit(etlloadtime)))
            .filter(F.col("UniverseId").isNotNull() & F.col("UniverseName").isNotNull())
        )
        dfvwUniverse.write.format("delta").mode("append").save(vwuniverse_path)

        # UniverseFunds
        dfuniverse = spark.sql("SELECT UniverseId, FilterExpression FROM UniversePublic") \
            .filter(F.col("FilterExpression").isNotNull() & (F.col("FilterExpression") != ""))

        df_final = []
        for row in dfuniverse.collect():
            universe_id = row["UniverseId"]
            filter_expression = row["FilterExpression"]

            # replace table reference with delta path
            filter_expression = filter_expression.replace(
                "vwUniverseFunds", 
                f"delta.`{bronze_lh_basepath}/Tables/Bronze/vwUniverseFunds`"
            )

            if filter_expression.strip():
                query = f"""
                    SELECT DISTINCT FundId 
                    FROM delta.`{bronze_lh_basepath}/Tables/Bronze/vwUniverseFunds`
                    WHERE {filter_expression}
                """
                dfFunds = spark.sql(query)

                df_final.extend([
                    (universe_id, f["FundId"]) for f in dfFunds.collect()
                ])


        df_table = spark.createDataFrame(df_final, schema=["UniverseId", "FundId"])
        df_table = (
            df_table
            .withColumn("UniverseId", F.col("UniverseId").cast(StringType()))
            .withColumn("FundId", F.col("FundId").cast(StringType()))
            .withColumn("ETLLoadDateTime", F.to_timestamp(F.lit(etlloadtime)))
            .filter(F.col("UniverseId").isNotNull() & F.col("FundId").isNotNull())
        )

        df_table.write.format("delta").mode("append").save(universefunds_path)

        print("Completed")

    except Exception as e:
        raise RuntimeError(f"Failed: {e}") from e


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************


# CELL ********************

for task_item in tasklist:
    try:
        # Skip if any required ID is missing
        if not all([CuratedLHId, BronzeLHId, WorkspaceId]):
            print("Skipping due to missing required GUID(s)")
            raise Exception
            
        # Build paths
        bronze_lh_basepath = get_basepath(WorkspaceId, BronzeLHId)
        curated_lh_basepath = get_basepath(WorkspaceId, CuratedLHId)
        process_task(task_item, bronze_lh_basepath,  curated_lh_basepath)
    except Exception as e:
        # mssparkutils.notebook.exit(f"FAILED: {e}")
        raise


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
