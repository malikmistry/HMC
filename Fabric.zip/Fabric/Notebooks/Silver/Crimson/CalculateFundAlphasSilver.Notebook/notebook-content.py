# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "e9fc4e80-ff69-4d45-bbdd-892592889465",
# META       "default_lakehouse_name": "lh_curated",
# META       "default_lakehouse_workspace_id": "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced",
# META       "known_lakehouses": [
# META         {
# META           "id": "e9fc4e80-ff69-4d45-bbdd-892592889465"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

import decimal
import requests
from datetime import date, datetime
from requests.exceptions import HTTPError, ConnectionError, Timeout, RequestException
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, DecimalType, DateType, StringType, IntegerType, LongType
from pyspark.sql.functions import to_date, lower
from delta.tables import DeltaTable

spark.conf.set('spark.sql.caseSensitive', True)


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# PARAMETERS CELL ********************

WorkspaceId = ""
BronzeLHId = ""
CuratedLHId = ""
CalculateFundStatisticsUrl = ""

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

WorkspaceId = "33535eb8-4d07-49bc-b3a5-cc91d3aa6ced"
BronzeLHId = "13ef97da-5da2-466d-8c5f-2a70572c6558"
CuratedLHId = "e9fc4e80-ff69-4d45-bbdd-892592889465"
CalculateFundStatisticsUrl = "https://winfunctionappdotnet-dev1.azurewebsites.net/api/CalculateFundStatistics?code=B7moEvO0QIn28NXomoZM9wCsOAlAR9BRDFtsovvyqEurAzFul14xrA=="

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

%run ./CalculateFundStatisticsSilver

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

statistic_types = [
    statistic_gross_alpha,
    statistic_gross_manager_alpha,
    statistic_gross_strategy_alpha,
    statistic_net_alpha
]

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

def getStatisticRequests(funds):
    fund_statistic_requests = []

    for fund in funds:
        
        fund_request = {
            "fundId": fund["FundId"],
            "statisticRequests": [],
            "returnStreamRequests": [],            
            "includeDetails": True,
            "overrideDetailsLocation": "fund-statistic-details"
        }

        if (fund["LastValuationDate"] is None):
            print(f"Skipping fund {fund['FundId']}: LastValuationDate is NULL")
            continue  

        if fund["FundName"].startswith("General Expense"):
            print(f"Skipping fund {fund['FundName']}")
            continue  

        if fund["FundName"].startswith("HMC Internal"):
            print(f"Skipping fund {fund['FundName']}")
            continue              

        if isLastDayOfMonth(fund["LastValuationDate"]):
            end_date = fund["LastValuationDate"].strftime("%Y-%m-%d")
        else:
            end_date = previousMonthEnd(fund["LastValuationDate"]).strftime("%Y-%m-%d")

        # horizons
        for stat_type in statistic_types: 

             for time_period in horizon_time_periods:
                request = {
                    "statisticTypeId": stat_type,
                    "timePeriodId": time_period[0],
                    "endDate": end_date
                }
                fund_request["statisticRequests"].append(request)

        fund_statistic_requests.append(fund_request)

    return fund_statistic_requests

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

start_time = datetime.now()
print(f"CalculateFundStatistics: {start_time.strftime('%Y-%m-%d %H:%M:%S')}" )

updated_funds_df = getChangedFunds()
# updated_funds_df = getActiveFunds()
# updated_funds_df = getAllFunds()

# test_funds_df = spark.createDataFrame([("81851c27-00d6-4e59-8f62-75b7c634416b",)], ["FundId"])
# updated_funds_df = updated_funds_df.join(test_funds_df, on=["FundId", "FundId"], how="left_semi")

batch_size = 200
updated_funds = updated_funds_df.collect()

total_fund_requests = 0
for i in range(0, len(updated_funds), batch_size):
    print(f"Processing funds {i + 1} through {i + batch_size}...")
    batch_funds = updated_funds[i:i + batch_size]

    batch_statistic_requests = getStatisticRequests(batch_funds)
    batch_request_data = {
        "notificationKey": "Alpha",
        "notifyOnSuccess": True,
        "fundStatistics": batch_statistic_requests
    }

    print("Fund requests in batch:", len(batch_statistic_requests))
    total_fund_requests += len(batch_statistic_requests)

    # print(batch_request_data)

    batch_start_time = datetime.now()
    batch_ids = [row["FundId"] for row in batch_funds]

    statistics_json = calcFundStatistics(batch_request_data)
    mergeHorizonReturns(batch_ids, statistics_json["statisticValues"], "FundHorizonAlpha")

    batch_end_time = datetime.now()
    batch_elapsed = batch_end_time - batch_start_time  # Returns a timedelta
    print("Batch elapsed time:", batch_elapsed)

print("Total fund requests:", total_fund_requests)

end_time = datetime.now()
elapsed = end_time - start_time  # Returns a timedelta
print("Total elapsed time:", elapsed)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# df = spark.sql("SELECT * FROM lh_curated.Gold.FundHorizonAlpha ORDER BY FundId, StatisticTypeId LIMIT 1000")
# df = spark.sql(""" 
#     SELECT * from Gold.FundHorizonAlpha
#     WHERE
#         (ITDError is NOT NULL and ITDError <> 'Incomplete time period.')
#     ORDER by FundId
# """)
# display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# df = spark.sql("SELECT ReturnSourceId, count(*) FROM lh_curated.Silver.FundReturn group by ReturnSourceId order by ReturnSourceId")
# display(df)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************


# CELL ********************


# spark.conf.set('spark.sql.caseSensitive', True)

# # spark.sql(""" DROP TABLE Gold.FundHorizonAlpha """)

# spark.sql("""
# CREATE TABLE Gold.FundHorizonAlpha (
#     FundId varchar(36) NOT NULL,
#     StatisticTypeId int NOT NULL,    
#     EndDate date NOT NULL,
#     ITD decimal(38,6),
#     ITDError string,
#     ITDDetailsKey string,
#     HMCITD decimal(38,6),
#     HMCITDError string,
#     HMCITDDetailsKey string,
#     CYTD decimal(38,6),
#     CYTDError string,
#     CYTDDetailsKey string,
#     FYTD decimal(38,6),
#     FYTDError string,
#     FYTDDetailsKey string,
#     OneYear decimal(38,6),
#     OneYearError string,
#     OneYearDetailsKey string,
#     ThreeYear decimal(38,6),
#     ThreeYearError string,
#     ThreeYearDetailsKey string,
#     FiveYear decimal(38,6),
#     FiveYearError string,
#     FiveYearDetailsKey string,
#     SevenYear decimal(38,6),
#     SevenYearError string,
#     SevenYearDetailsKey string,
#     TenYear decimal(38,6),
#     TenYearError string,
#     TenYearDetailsKey string,
#     FifteenYear decimal(38,6),
#     FifteenYearError string,
#     FifteenYearDetailsKey string,
#     TwentyYear decimal(38,6),
#     TwentyYearError string,
#     TwentyYearDetailsKey string,
#     AsOfDate date NOT NULL,
#     ETLLoadDateTime TIMESTAMP NOT NULL
# )
# USING DELTA
# """)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# spark.conf.set('spark.sql.caseSensitive', True)

# spark.sql(""" DROP TABLE Silver.FundReturn """)

# spark.sql("""
# CREATE TABLE Silver.FundReturn (
#     FundId varchar(36) NOT NULL,
#     ReturnTypeId int NOT NULL,    
#     ReturnSourceId int NOT NULL,        
#     FrequencyId int NOT NULL,        
#     CalculationMethodologyId int,        
#     EndDate date NOT NULL,
#     ReturnValue decimal(38,11),
#     ReturnError string,
#     ReturnDetailsKey string,
#     AsOfDate date NOT NULL,
#     ETLLoadDateTime TIMESTAMP NOT NULL    
# )
# USING DELTA
# """) 

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# spark.conf.set('spark.sql.caseSensitive', True)

# spark.sql(""" DROP TABLE Silver.FundStatisticsExcludedFunds """)

# spark.sql("""
# CREATE TABLE Silver.FundStatisticsExcludedFunds (
#     FundId varchar(36) NOT NULL
# )
# USING DELTA
# """) 

# excluded_funds_df = spark.createDataFrame([
#     ("392a50f7-6a5a-410c-8e2d-5c77e02117c2",), # HMC Stock Distributions
#     ("6dd56666-f892-4148-b62a-d7a150ae4053",), # Net Notional AR-AP Adjustments
#     ("370ce44d-1a1c-49ec-86d8-b17983cbe165",), # Overhead Expenses - TIPS
#     ("8635ed5a-d7c5-4f64-944b-2d4845109005",), # Overhead Expenses - High Yield
#     ("35057789-6384-44a7-8d72-87ffc5d8e125",), # House Euro Equity
#     ("41bcc69d-64f7-48d7-b171-9a26204e4bb2",), # Tufnell Park Global Rates
#     ("706e5320-dbeb-476f-bc1a-f5a3328826d0",), # Iron Park Capital Investors LP
#     ("b1a2a7e5-fbd9-468e-be6d-f84191271085",), # OAL Adjustment (Historical)
#     ("dc9bbef9-088b-4a8d-9701-53fd33662902",), # Regent JV II
#     ("e82b41f9-f565-472a-969f-2add7fb93f8c",), # RE Direct A/R
#     ("f97fc410-a838-40d8-a208-b8af5e7e4313",), # Event Driven
#     ("0f21e6bd-5f03-413a-a29d-20ae4ba5b4e7",), # HURP
#     ("ff31f733-0f20-4072-a9e0-77f1bdc3faed",), # HURP
#     ("2a57501b-40a0-4e95-9f96-2e39f5b9eb9f",), # HURP
#     ("7a2cb9d0-50a7-4173-9496-2aa852066019",), # HURP
#     ("b98ae363-8620-4114-aa5d-0d06938f9362",), # HURP
#     ("ed660200-0859-4eb7-bbc4-0fd84652f825",) # HURP
# ], ["FundId"])

# excluded_funds_df.write.format("delta").mode("append").save("Tables/Silver/FundStatisticsExcludedFunds")

# spark.catalog.refreshTable("Silver.FundStatisticsExcludedFunds")

# excluded_funds = excluded_funds_df.collect()
# excluded_fund_ids = [row["FundId"] for row in excluded_funds]
# print(excluded_fund_ids)

# deleteFundHorizonReturns(excluded_fund_ids)
# deleteFundReturns(excluded_fund_ids)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
